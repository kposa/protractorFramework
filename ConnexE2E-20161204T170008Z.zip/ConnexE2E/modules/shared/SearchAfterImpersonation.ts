/// <reference path="../../typings/index.d.ts" />

import {Element} from './Element';
import { filterElements, isActive, containingText } from '../../modules_v3/helpers/filterElementHelpers';
import { clickElement } from '../../modules_v3/helpers/clickElementHelpers';

let e = new Element();

export class SearchAfterImpersonation {

    public searchBarHamburger = $('div[ng-click="showNav()"]');
    public searchBarHamburgerMenuParent = $('div.box-content.palette-c.drawer.left.expanded');

    public clickSearchBarHamburger():void {
        e.clickElement(this.searchBarHamburger);
    }

    public selectImpersonateFromHamburger():void {
        let impersonateOption = $$('li[ng-if="canImpersonate"]').get(0);
        e.clickElement(impersonateOption);
    }

    public selectFeatureFlagsFromHamburger():void {
        let featureFlagsOption = $$('li[ng-if="canImpersonate"]').get(1);
        e.clickElement(featureFlagsOption);
    }

    public selectInvoiceAdjustmentFromHamburger():void {
        let invoiceAdjustmentsOption = $('li[ng-if="showInvoiceAdjustment()"]');
        e.clickElement(invoiceAdjustmentsOption);
    }

    public clickReportsFromHamburger():void {
        let reportsOption = $('div[ng-if="vm.reportMenuVisible()"]');
        e.clickElement(reportsOption);
    }

    public selectReport(name:string):void {
        let dropdownOption = filterElements(
            $$('li[ng-repeat="report in vm.reports"]'),
            [
                isActive(true),
                containingText(name)
            ]
        )().first();
        clickElement(dropdownOption);
    }
    
    public searchByCriteria(criteria:string):void {
        let searchIcon = $('div[ng-click="vm.startSearch()"]');
        e.clickElement(searchIcon);
        let searchField = $('input[placeholder="Search"]');
        searchField.clear();
        searchField.sendKeys(criteria);
        searchField.sendKeys(protractor.Key.ENTER);
    }

    public selectOperationSearchResult():void {
        let allResults = $$('div.site-content');
        let foundResult = allResults.$$('li[ng-click="vm.selectOperation(o.id)"]').get(0);
        e.clickElement(foundResult);
    }

    public selectSearchResult(id:number):void {
        let allResults = $$('div.pm-card');
        let foundResult = allResults.filter(function (elem) {
            return elem.getAttribute('at').then(function (at) {
                if(!at) return null;
                return at === id.toString();
            });
        }).get(0);
        e.clickElement(foundResult);
    }
    
    
}