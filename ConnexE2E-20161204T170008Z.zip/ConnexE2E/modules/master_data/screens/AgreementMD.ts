/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

export class AgreementMD {

    public isAgreementTypeColumnDisplayed(): Promise<string> {
        return $$('div.ng-scope.layout-row.flex-100').get(1).$('span[flex="25"]').getText();
    }

    public isDateSignedColumnDisplayed(): Promise<string> {
        return $$('div.ng-scope.layout-row.flex-100').get(1).$('span[flex="10"]').getText();
    }

    public isSignedByRepColumnDisplayed(): Promise<string> {
        return $$('div.ng-scope.layout-row.flex-100').get(1).$$('span[flex="20"]').get(0).getText();
    }

    public isSignedByOtherColumnDisplayed(): Promise<string> {
        return $$('div.ng-scope.layout-row.flex-100').get(1).$$('span[flex="20"]').get(1).getText();
    }

    public isEditAgreementIconDisplayed(): Promise<boolean> {
        let editAgreementIcon = $('button[ng-click="vm.showEditAgreement()"]');
        return editAgreementIcon.isDisplayed();
    }

    public isShowEditCommentIconDisplayed(): Promise<boolean> {
        let showEditCommentIcon = $('button[ng-click="vm.showEditComment()"]');
        return showEditCommentIcon.isDisplayed();
    }

    public isDeleteAgreementIconDisplayed(): Promise<boolean> {
        let deleteAgreementIcon = $('button[ng-click="vm.deleteAgreement()"]');
        return deleteAgreementIcon.isDisplayed();
    }

    public clickEditAgreementIcon(): void {
        let editAgreementIcon = $('button[ng-click="vm.showEditAgreement()"]');
        clickElement(editAgreementIcon);
    }

    public clickShowEditCommentIcon(): void {
        let showEditCommentIcon = $('button[ng-click="vm.showEditComment()"]');
        clickElement(showEditCommentIcon);
    }

    public clickDeleteAgreementIcon(): void {
        let deleteAgreementIcon = $('button[ng-click="vm.deleteAgreement()"]');
        clickElement(deleteAgreementIcon);
    }

}