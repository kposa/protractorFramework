export interface query341020Results {
    agencyId: string
    personFirstName: string
    personLastName: string
    personType: string
}

export function query341020 () {
    const {E2EOperationsDatabaseName} = process.env;
    return `
    
select  p.pioneerid, ap.agencyId, p.FirstName as personFirstName, p.LastName as personLastName, p.email, p.culturename, apt.Name as personType
from ${E2EOperationsDatabaseName}.masterdata.Person p
join ${E2EOperationsDatabaseName}.masterdata.agencyperson ap on ap.pioneerid = p.pioneerid
join ${E2EOperationsDatabaseName}.masterdata.AgencyPersonType apt on apt.agencypersontypeid = ap.agencypersontypeid
where  p.culturename = 'en-US'
and ap.isprimary = 1 

`;
}


