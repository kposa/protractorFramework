/// <reference path="../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import Promise = webdriver.promise.Promise;
import {Element} from '../../shared/Element';
import {MaterialDesignElement} from "../../shared/MaterialDesignElement";

let e = new Element();
let md = new MaterialDesignElement();

export class BalancesSS {

    public goToActivityStatement(accountDescriptionName?:string):void {
        let allActivityStatements = $$('div[ng-if="item.paymentCanBeMade"]');
        let goToActivityStatementButton = md.getFirstListItem(allActivityStatements, accountDescriptionName);
        goToActivityStatementButton = goToActivityStatementButton.$('i[ng-click="vm.goToActivityStatement(item)"]');
        e.clickElement(goToActivityStatementButton);
    }

    get titleText():Promise<string> {
        return $('div.pm-title').getText();
    }
}