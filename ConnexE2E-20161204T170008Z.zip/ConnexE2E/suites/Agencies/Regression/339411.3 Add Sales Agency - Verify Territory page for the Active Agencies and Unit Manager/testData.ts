/// <reference path='../../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';
import { activeAgenciesForTerritoryPageResults, activeAgenciesForTerritoryPage } from './queries';

export default class TestDataForTerritoryPage extends BaseTestData {

    public agencyId: string;

    protected queries = [
        this.getActiveAgenciesForTerritoryPage()
    ];

    private getActiveAgenciesForTerritoryPage (): () => Promise<activeAgenciesForTerritoryPageResults> {
        return () => {
            const sql = activeAgenciesForTerritoryPage();
            const results = this.queryService.executeSql<activeAgenciesForTerritoryPageResults[]>(sql);

            return results
                .then(data => {
                    const row = <activeAgenciesForTerritoryPageResults>getRandomQueryResult(data);
                    this.agencyId = row.agencyId;
                    return row;
                });
        };
    }

}