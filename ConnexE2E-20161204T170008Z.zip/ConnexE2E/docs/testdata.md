# [Connex E2E Documentation](/)

## Test Data

Test data is any data that is required by a test to run. Each test owns a `TestData` where required data is defined and populated.

```
class TestData extends BaseTestData {}
```

### BaseTestData

`BaseTestData` is the parent class for all `TestData` classes.

### Populating Data

Populating data involves [fetching](#fetchingdata) and [mapping](#mappingdata) data to a `TestData` instance.

#### Fetching Data

Data can be fetched from a number of different sources. The most common are querying SQL and stored procedures which the [`QueryService`](/services/queryService.html) handles.

##### From SQL

```
function populateSomeData (queryService: QueryService): () => Promise<any> {
  return () => {
    return queryService.executeSql<any>('some sql...');
  }; 
}
```

###### SQL Statements

SQL statements should ideally be functions that return a string. Dynamic values in the sql statement should be in the form of function arguments:

```
function sqlStatement (id: number) {
  return `
  select *
  from database.dbo.Users
  where id = ${id}
  `;
}
```

or [environmental variables](/envVars.html):

```
function sqlStatement (id: number) {
  return `
  select *
  from database.dbo.Users
  where id = ${id}
  and year = ${process.env.E2ESalesPeriodYear}
  `;
}
```

SQL statements should also use [environmental variables](/envVars.html) for database names to ensure the correct database is used in each environment:

```
function sqlStatement (id: number) {
  return `
  select *
  from ${process.env.E2EAccountingDatabaseName}.dbo.Users
  where id = ${id}
  `;
}
```

##### From Stored Procs

Stored procs are called by name:

```
interface results {
  description: string;
}

function populateSomeData (queryService: QueryService): () => Promise<any> {
  return () => {
    return queryService.executeProc<results>('procName');
  }; 
}
```

They also accept input parameters:

```
interface results {
  description: string;
}

function populateDescription (queryService: QueryService): () => Promise<any> {
  return () => {
    return queryService.executeProc<results>('procName', { someParam: false });
  }; 
}
```

#### Mapping Data

Mapping data is taking fetched data and assigning to a `TestData` instance.

```
function populateSomeData (queryService: QueryService, td: BaseTestData): () => Promise<any> {
  return () => {
    const results = queryService.executeSql<any>('some sql...');
    
    results.then(rows => rows[0]).then(row => {
      td.someValue = row.someValue;
    });
  }; 
}
```

#### Defining what data a test requires

These fetching & mapping query functions can be composed together in the `queries` property on `TestData` objects to define what data a test requires.

```
function populateIdAndName (td: BaseTestData): () => Promise<any> {
  return () => {
    getIdAndName().then(data => {
      td.name = data.name; // Smith, John
      td.id = data.id; // 123
      return data;
    });
  }; 
}

function populateEmail (td: BaseTestData): () => Promise<any> {
  return () => {
    getEmail().then(data => {
      td.email = data.email; // john@smith.com
      return data;
    });
  }; 
}

class TestData000000 extends BaseTestData {
  protected queries = [
    populateIdAndName(this),
    populateEmail(this)
  ];
}
```

You can use previously populated data for future population as well.

```
function populateAccountType (td: BaseTestData): () => Promise<any> {
  return () => {
    getAccountType(td.id).then(data => {
      td.accountType = data.accountType // user
      return data;
    });
  }; 
}
```

**Note**: These query functions are ran in sequence and are not passed results from the previously ran functions but instead are passed the `TestData` instance. This means that the functions both read & write data from/to the `TestData` instance.

```
class TestData000000 extends BaseTestData {
  protected queries = [
    populateIdAndName(this),
    populateEmail(this),
    populateAccountType(this)
  ];
}
```

This would not work:

```
class TestData000000 extends BaseTestData {
  protected queries = [
    populateAccountType(this),
    populateIdAndName(this),
    populateEmail(this)
  ];
}
```

### Domain Objects

`BaseTestData` has array properties for a number of domain objects and should where this data is inserted when populating test data.

- BusinessPartner
- Invoice
- Operation
- Product
- ProductLine
- Proposal
- RoutingNumber
- SalesAgency
- SalesRepresentative
- Share
- Subproduct
- Territory
- User

#### Setting

```
const td = new BaseTestData();

td.products; // [ Product, Product, ... ]

td.products.push({
  id: '123';
  name: 'Hybrid 32';
  productLine: 'Corn';
  subproduct: 'ER11';
  units: 10;
  price: 20;
});
```

#### Getting

Calling the singular form of the domain object arrays returns the first object in the array. It will throw an error if no items are in the array.

```
td.product; // { id: '123', name: 'Hybrid 32', ... }
```

### Populating static data

This pattern is useful for storing custom test data that doesn't align with the domain objects.

```
class TestData000000 extends BaseTestData {
  public age: number = 100;
}
```