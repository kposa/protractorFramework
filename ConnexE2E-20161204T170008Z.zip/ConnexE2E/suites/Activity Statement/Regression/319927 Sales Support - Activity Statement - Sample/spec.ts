/// <reference path="../../../../typings/index.d.ts" />

import {ActivityStatementSS} from "../../../../modules/sales_support/screens/ActivityStatementSS";
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
	'319927',
	'Sales Support - Activity Statement - Sample',
    UserRole.SALES_SUPPORT,
    ApplicationFeature.ACTIVITY_STATEMENT
);

describe(test.stringify, () => {
    let activityStatement = new ActivityStatementSS();

    itw(test.description, () => {
        //TODO: Implement td.populate + bootstrap

        // should go to Activity Statement page
        browser.get('https://salesstagingtx.pioneer.com/#/sales-support/activity-statement/invoice/20299399/share/7678902');

        // should verify a row reading [Sample Discount - 100.0%] displays below the [Retail Value] line.
        expect(activityStatement.isSampleDiscountDisplayed).toBeTruthy();

        // should expand the [Retail Value]
        activityStatement.expandRetailValueRow();

        // should verify a sample line item entry was correctly created, including the [Sample] label under the [Product Discount] column
        expect(activityStatement.isSampleExistAfterRetailValueRowExpanded).toBeTruthy();

        // should verify the [Retail Value] on the sample line item matches the amount shown for the row reading [Sample Discount - 100.0%]
        expect(activityStatement.isSampleRetailValueEqualsSampleDiscountValue).toBeTruthy();
    }, 'This is currently a bad candidate for automation because the data is hard to mimic');
});