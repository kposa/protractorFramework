export interface IQuery {
    label:string;
    sql:(values:any[]) => string;
    context:Object;
    render(renderContext:Object):string;
    toString():string;
}