/// <reference path="../../../../typings/index.d.ts" />

import { sharedViewAndUpdatePVCSteps } from '../shared/sharedViewAndUpdatePVCSteps';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { sharedViewAndUpdatePVCTestData } from '../shared/sharedViewAndUpdatePVCTestData';

const test = new TestCase(
    '363415',
    'PVC View and Update for Territory',
    UserRole.MASTER_DATA,
    ApplicationFeature.COMMISSIONS
);

describe(test.stringify, () => {
    const td = new sharedViewAndUpdatePVCTestData('AAJ', 'Territories');
    sharedViewAndUpdatePVCSteps(test.description, td);
});