/// <reference path="../../../../typings/index.d.ts" />

import { AgreementsSR } from "../../../../modules/sales_rep/screens/AgreementsSR";
import { PreviewDocumentSR } from "../../../../modules/sales_rep/screens/PreviewDocumentSR";
import ActionMenuView from '../../../../modules_v3/views/shared/ActionMenuPartialView';
import TestData319803 from './testData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';
import { SalesRepBusinessPartnersFullView } from '../../../../modules_v3/views/salesRep/SalesRepBusinessPartnersFullView';
import { SalesRepOperationsFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationsFullView';

const test = new TestCase(
    '319803',
    'French Sales Rep can sign the Technology Agreement',
    UserRole.SALES_REP,
    ApplicationFeature.AGREEMENTS
);

describe(test.stringify, () => {

    const td = new TestData319803();
    const businessPartnersScreenView = new SalesRepBusinessPartnersFullView();
    const operationsScreenView = new SalesRepOperationsFullView();
    const actionMenuView = new ActionMenuView();
    let ag = new AgreementsSR();
    let pd = new PreviewDocumentSR();

    itw(test.description, () => {
        // bootstrap (load, login, reset feature flags, impersonate)
        bootstrap(td.salesRepresentative);

        // should select an operation
        operationsScreenView.search(td.operation.name);
        operationsScreenView.clickSearchResultContainingText(td.operation.name);

        // should go to business partners page when you click on [business partners] from the ellipse
        actionMenuView.openMenu();
        actionMenuView.selectMenuItemContainingText(`partenaires d'affaires`);
        expect(browser.getCurrentUrl()).toContain('customers');

        // should assert on navigating to [Agreements] page when user clicks on [agreement] button
        businessPartnersScreenView.clickAgreementsButtonByName(td.businessPartner.name);

        // should assert on signing the technology agreement if not signed'
        ag.clickSignAgreementAndSignTheAgreement();

        // should assert on navigating to [Preview Agreement] page when user clicks on [View] button for the signed agreement
        ag.clickViewForTheSignedAgreement();

        // should assert on the display of [Email] and [Print] icons on the [Preview Agreement] page
        expect(pd.isEmailIconDisplayed()).toBeTruthy();
        expect(pd.isPrintIconDisplayed()).toBeTruthy();
    });
});