/// <reference path='../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import { NotImplementedError } from '../../../common/exception/Exceptions';
import { IView } from '../../interfaces/common/IView';
import { clickElement } from '../../helpers/clickElementHelpers';
import { isPresentAndDisplayed, isAriaChecked } from '../../helpers/utilityElementHelpers';

export class MasterDataOperationManagementCommunicationsFullView implements IView {

    private acceptButton = $('button[ng-click="vm.optIn(true)"]');
    private sendReqDocsViaBar = $('md-switch[ng-show="!vm.processing"]');

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    clickAcceptIfDisplayed () {
        isPresentAndDisplayed(this.acceptButton).then((id) => {
            if (id) {
                clickElement(this.acceptButton.$('span'));
            }
        });
    }

    isSendReqDocsViaButtonOn ():Promise<boolean> {
        return isAriaChecked(this.sendReqDocsViaBar);
    }

    clickSendReqDocViaButton () {
        clickElement(this.sendReqDocsViaBar.$('div.md-thumb.md-ink-ripple'));
    }

    documentsCommunicationModes () {
        return $$('div[ng-repeat="mode in vm.requiredCommunicationModes"]').getText();
    }
}
