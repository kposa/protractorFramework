/// <reference path="../../../../typings/index.d.ts" />

import Promise = protractor.promise.Promise;
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import {
    operationsAndCustomersForSalesRepResults,
    operationsAndCustomersForSalesRep
} from '../330708 Sales Support - Activity Statement - DP Payment &  ePayment/queries';

export class TestData330712 extends BaseTestData {

    public discountName:string;
    public productLine1:string = 'Corn';
    public productLine2:string = 'Soybeans';
    public amount:string = '15000';
    public refundAmount1:string = '500';
    public refundAmount2:string = '$500.00';
    public routingNum:string = '073000228';
    public accountNum:string = '123456789';
    public customerEmail:string = 'abc123@gmail.com';
    public salesRepUserID:string = 'bussaro@phiext.com';

    protected queries:(() => Promise<any>)[] = [
        this.getOperationsAndCustomersForSalesRep()
    ];

    private getOperationsAndCustomersForSalesRep ():() => Promise<operationsAndCustomersForSalesRepResults> {
        return () => {
            const sql = operationsAndCustomersForSalesRep(this.salesRepUserID, this.salesPeriod.id);
            const results = this.queryService.executeSql<operationsAndCustomersForSalesRepResults[]>(sql);

            return results
                .then(data => {
                    const row = <operationsAndCustomersForSalesRepResults>getRandomQueryResult(data);

                    this.operations.push({
                        id: row.operationId,
                        name: row.operationName
                    });

                    this.businessPartners.push({
                        id: row.customerId,
                        name: row.customerName
                    });

                    return row;
                });
        };
    }
}