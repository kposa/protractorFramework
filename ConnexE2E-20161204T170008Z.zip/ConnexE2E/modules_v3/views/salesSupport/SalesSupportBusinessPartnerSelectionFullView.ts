/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;
import { IView } from '../../interfaces/common/IView';
import { NotImplementedError } from '../../../common/exception/Exceptions';
import { filterElements, isActive, matchingText } from '../../helpers/filterElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';

export class SalesSupportBusinessPartnerSelectionFullView implements IView {

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    selectBusinessPartner (businessPartnerName:string) {
        clickElement(filterElements(
            $$('div[ng-click="navigate(customer.customerId)"]'),
            [ isActive(true), matchingText(businessPartnerName) ]
        )().first());
    }
}