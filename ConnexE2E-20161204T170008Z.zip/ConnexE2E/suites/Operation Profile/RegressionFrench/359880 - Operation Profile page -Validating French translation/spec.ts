/// <reference path="../../../../typings/index.d.ts" />

import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { TestData359880 } from './testData';
import { itw } from '../../../../modules_v3/helpers/itw';
import { SalesRepOperationsFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationsFullView';
import { SalesRepEllipsePartialView } from '../../../../modules_v3/views/salesRep/SalesRepEllipsePartialView';
import { SalesRepOperationProfilePageFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationProfilePageFullView';

const test = new TestCase(
    '359880',
    'Operation Profile page - Validating French translation',
    UserRole.SALES_REP,
    ApplicationFeature.OPERATION_PROFILE
);

describe(test.stringify, () => {
    const td = new TestData359880();
    let salesRepOperationsFullView = new SalesRepOperationsFullView();
    let ellipse = new SalesRepEllipsePartialView();
    let operationProfilePage = new SalesRepOperationProfilePageFullView();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            bootstrap(td.salesRepresentative);

            //search for an operation and click on it
            salesRepOperationsFullView.search(td.operation.name);
            salesRepOperationsFullView.clickSearchResultContainingText(td.operation.name);

            //select operation profile link from the ellipse to navigate to the operation profile page
            ellipse.select('Profil d’opération');

            //should verify if all of the following headers are displayed on the operation Profile page
            expect(operationProfilePage.getDisplayedHeaders()).toContain('Acres commerciaux');
            expect(operationProfilePage.getDisplayedHeaders()).toContain('Acres commerciaux pour produits concurrents');
            expect(operationProfilePage.getDisplayedHeaders()).toContain('Champs de production de semences');
            expect(operationProfilePage.getDisplayedHeaders()).toContain('Producteur laitier');
            expect(operationProfilePage.getDisplayedHeaders()).toContain('Autre bétail');
            expect(operationProfilePage.getDisplayedHeaders()).toContain('Autres');

            //should verify that clicking on the [+] button for each of the section pops up the dialog box
            operationProfilePage.clickAddButtonForHeadersContainingText('Acres commerciaux');
            operationProfilePage.commercialAcresDialog.clickDelete();
            operationProfilePage.clickAddButtonForHeadersContainingText('Acres commerciaux pour produits concurrents');
            operationProfilePage.competitiveCommercialAcresDialog.clickDelete();
            operationProfilePage.clickAddButtonForHeadersContainingText('Producteur laitier');
            operationProfilePage.dairyProducerDialog.clickDelete();
            operationProfilePage.clickAddButtonForHeadersContainingText('Autre bétail');
            operationProfilePage.otherLivestockDialog.clickDelete();
            operationProfilePage.clickAddButtonForHeadersContainingText('Autres');
            operationProfilePage.otherDialog.clickDelete();
            operationProfilePage.clickAddButtonForSeedProductionAcres();
            operationProfilePage.seedProductionAcresDialog.clickDelete();

        }, fail);
    });
});