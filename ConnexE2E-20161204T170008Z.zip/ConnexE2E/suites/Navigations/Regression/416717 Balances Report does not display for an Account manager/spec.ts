/// <reference path="../../../../typings/index.d.ts" />

import TestData416717 from './testData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { itw } from '../../../../modules_v3/helpers/itw';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { AccountManagerHamburgerDrawerPartialView } from '../../../../modules_v3/views/accountManager/AccountManagerHamburgerDrawerPartialView';
import { AccountManagerOperationsFullView } from '../../../../modules_v3/views/accountManager/AccountManagerOperationsFullView';

const test = new TestCase(
    '416717',
    'Balances Report does not display for an Account manager',
    UserRole.ACCOUNT_MANAGER,
    ApplicationFeature.NAVIGATIONS
);

describe(test.stringify, () => {
    const td = new TestData416717();
    let accountManagerOperations = new AccountManagerOperationsFullView();
    let hamburgerDrawer = new AccountManagerHamburgerDrawerPartialView();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            bootstrap(td.accountManagerUser);

            // should click the hamburger menu
            accountManagerOperations.clickSearchBarHamburger();

            // should click Reports from the hamburger menu
            hamburgerDrawer.clickItemFromHamburgerMenu('Reports');

            // should verify that the Balances report link is not present for an account manager
            expect(hamburgerDrawer.isBalancesReportDisplayed('Balances Report')).toBeFalsy();

        }, fail);
    });
});