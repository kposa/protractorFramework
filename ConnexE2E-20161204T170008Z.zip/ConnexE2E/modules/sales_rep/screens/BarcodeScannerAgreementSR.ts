import Promise = webdriver.promise.Promise;
import {clickElement} from "../../../modules_v3/helpers/clickElementHelpers";

let backButton = $('i.fa.fa-chevron-left');

export class BarcodeScannerAgreementSR {

    public clickSignButton():void {
        clickElement(backButton);
    }
    
    public clickBackButton():void {
        clickElement(backButton);
    }

    get isAgreementsHeaderDisplayed():Promise<boolean> {
        let AgreementSignHeader = $('div[ng-click="vm.back()"]');
        return AgreementSignHeader.getText().then(function (text) {
            return Boolean(~text.indexOf('agreements'));
        })
    }

    get isBackButtonDisplayed():Promise<boolean> {
        return backButton.isDisplayed();
    }

    get salesRepNameDisplayed():Promise<string> {
        let nameArea = $('div.current.semibold');
        return nameArea.getText().then(function(txt) {
            return txt.replace(/ /g,''); //some data has weird spacing - removing whitespace
        });
    }

    get titleDisplayed():Promise<string> {
        let titleCard = $('div.page-title').$('span.flex-expand ');
        return titleCard.getText();
    }

    get versionDisplayed():Promise<string> {
        let versionCard = $('div.page-title').$$('span').get(1);
        return versionCard.getText();
    }

    get textInFooterDisplayed():Promise<string> {
        let footerCard = $('div.document-footer');
        return footerCard.getText();
    }
}
