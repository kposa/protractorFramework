/// <reference path="../../../../typings/index.d.ts" />

import MasterDataMasterSearchFullView from '../../../../modules_v3/views/masterData/MasterDataMasterSearchFullView';
import MasterDataCommissionsTabFullView from '../../../../modules_v3/views/masterData/MasterDataCommissionsTabFullView';
import { MasterDataOtherCommissionsFullView } from '../../../../modules_v3/views/masterData/MasterDataOtherCommissionsFullView';
import { sharedOtherCommissionTestData } from '../shared/sharedOtherCommissionTestData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
    '435798',
    'Add-Upd-Del Other Commissions w/Classification for Specified Range',
    UserRole.MASTER_DATA,
    ApplicationFeature.COMMISSIONS
);

describe(test.stringify, () => {
    const masterDataMasterSearchFullView = new MasterDataMasterSearchFullView();
    const masterDataCommissionsTabFullView = new MasterDataCommissionsTabFullView();
    const masterDataOtherCommissionsFullView = new MasterDataOtherCommissionsFullView();
    const td = new sharedOtherCommissionTestData();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.masterDataUser);

            // select a random sales agency
            masterDataMasterSearchFullView.search(td.randSalesAgencyId);
            masterDataMasterSearchFullView.selectFilterContainingText('Sales agencies');
            masterDataMasterSearchFullView.clickSearchResultContainingText(td.randSalesAgencyId);

            // navigate to the Other Commission screen
            masterDataCommissionsTabFullView.clickTabContainingText('Commission');
            masterDataCommissionsTabFullView.clickCardContainingText('Other Commission');

            // add a commission with classification
            masterDataOtherCommissionsFullView.addCommission('With classification');

            // select a sales year
            masterDataOtherCommissionsFullView.selectSalesYear(td.salesPeriod.year.toString());

            // select a classification
            masterDataOtherCommissionsFullView.selectClassification('C2');

            // select a program
            masterDataOtherCommissionsFullView.selectProgram('SAM');

            // select Specified Range type
            masterDataOtherCommissionsFullView.selectType('Specified Range');

            // verify negative numbers are not allowed in percent field
            masterDataOtherCommissionsFullView.enterPercentValueForProdLine('-1');
            expect(masterDataOtherCommissionsFullView.getPercentValue()).toEqual('1');

            // verify that the required message appears when the field is selected and then deselected
            masterDataOtherCommissionsFullView.clearPercentFieldForProdLine();
            expect(masterDataOtherCommissionsFullView.verifyPercentFieldIsRequired('Required'))
                .toBeTruthy();

            // verify only 2 decimal places are allowed
            masterDataOtherCommissionsFullView.enterPercentValueForProdLine('66.123');
            expect(masterDataOtherCommissionsFullView.getPercentValue()).toEqual('66.12');

            // enter a valid percent
            masterDataOtherCommissionsFullView.enterPercentValueForProdLine(td.randomValue);

            // verify that negatives aren't allowed in the [From] and [To] fields
            masterDataOtherCommissionsFullView.enterToRevenueAmount('-1');
            expect(masterDataOtherCommissionsFullView.getToRevenueAmount()).toEqual('1');

            masterDataOtherCommissionsFullView.enterFromRevenueAmount('-5');
            expect(masterDataOtherCommissionsFullView.getFromRevenueAmount()).toEqual('5');

            // verify that the [Must be greater than From] message appears for [To] field
            expect(masterDataOtherCommissionsFullView.verifyErrorMessageDisplays('Must be greater than From'))
                .toBeTruthy();

            // clear [From] and [To], verify the required message appears for [From]
            masterDataOtherCommissionsFullView.enterFromRevenueAmount('');
            masterDataOtherCommissionsFullView.enterToRevenueAmount('');
            expect(masterDataOtherCommissionsFullView.verifyErrorMessageDisplays('Required'))
                .toBeTruthy();

            // enter valid data into the [From] and [To] fields
            masterDataOtherCommissionsFullView.enterFromRevenueAmount(td.randomValueFrom.toString());
            masterDataOtherCommissionsFullView.enterToRevenueAmount(td.randomValueGreaterThanFrom.toString());

            // click the plus to add a new specified range
            masterDataOtherCommissionsFullView.addNewCommissionConfiguration();

            // enter a valid percent
            masterDataOtherCommissionsFullView.enterPercentValueForProdLine(td.randomValueTwo);

            // verify the [Apply to all products] box is checked
            expect(masterDataOtherCommissionsFullView.verifyApplyToAllProductsIsChecked()).toBeTruthy();

            // click save and add to create a second commission with 3 specified ranges
            masterDataOtherCommissionsFullView.clickSalesAgencyOtherCommissionsSave('Save & Add');

            // set up the second commission
            masterDataOtherCommissionsFullView.selectSalesYear(td.salesPeriod.year.toString());
            masterDataOtherCommissionsFullView.selectClassification('C1');
            masterDataOtherCommissionsFullView.selectProgram('SAM');
            masterDataOtherCommissionsFullView.selectType('Specified Range');

            // enter valid data for 1st specified range of the second commission
            masterDataOtherCommissionsFullView.enterPercentValueForProdLine(td.randomValue);
            masterDataOtherCommissionsFullView.enterFromRevenueAmount(td.randomValueFrom.toString());
            masterDataOtherCommissionsFullView.enterToRevenueAmount(td.randomValueGreaterThanFrom.toString());

            // click the plus to add a second specified range
            masterDataOtherCommissionsFullView.addNewCommissionConfiguration();

            // enter valid data for 2nd specified range of the second commission
            masterDataOtherCommissionsFullView.enterPercentValueForProdLine(td.randomValueTwo);
            masterDataOtherCommissionsFullView.enterToRevenueAmount(td.randomValueGreater2.toString());

            // click the plus to add a third specified range
            masterDataOtherCommissionsFullView.addNewCommissionConfiguration();

            // enter valid data for 3rd specified range of the second commission
            masterDataOtherCommissionsFullView.enterPercentValueForProdLine(td.randomValueThree);
            masterDataOtherCommissionsFullView.enterToRevenueAmount(td.randomValueGreater3.toString());

            // click the plus to add a fourth specified range
            masterDataOtherCommissionsFullView.addNewCommissionConfiguration();

            // enter valid data for 4th specified range of the second commission
            masterDataOtherCommissionsFullView.enterPercentValueForProdLine(td.randomValueFour);
            masterDataOtherCommissionsFullView.enterToRevenueAmount(td.randomValueGreater4.toString());

            // click the plus to add a fifth specified range
            masterDataOtherCommissionsFullView.addNewCommissionConfiguration();

            // enter valid data for 5th specified range of the second commission
            masterDataOtherCommissionsFullView.enterPercentValueForProdLine(td.randomValueFive);
            masterDataOtherCommissionsFullView.enterToRevenueAmount(td.randomValueGreater5.toString());

            // click save and close
            masterDataOtherCommissionsFullView.clickSalesAgencyOtherCommissionsSave('Save & Close');

            // delete an added row
            masterDataOtherCommissionsFullView.removeFirstCommissionRow();
            masterDataOtherCommissionsFullView.clickCancelDeleteConfirmation('Delete');

            // update one of the commissions
            masterDataOtherCommissionsFullView.editFirstCommissionRow();
            masterDataOtherCommissionsFullView.selectProgram('Other');

            // save the change
            masterDataOtherCommissionsFullView.saveAfterEdit();

            // delete remaining row
            masterDataOtherCommissionsFullView.removeFirstCommissionRow();
            masterDataOtherCommissionsFullView.clickCancelDeleteConfirmation('Delete');
        }, fail);
    });
});
