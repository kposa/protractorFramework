/// <reference path="../../../../typings/index.d.ts" />

import Promise = protractor.promise.Promise;

export default class AddSalesAgencyData {

    public agencyId: Promise<string>;
    public firstName:string = 'Abc';
    public lastName:string = 'Test';
    public streetAddress1:string = '5454 Vista Dr';
    public streetAddress2:string = '#1';
    public city:string = 'West Des Moines';
    public state: string = 'Iowa';
    public county:string = 'Polk';
    public postalCode:string = '50266';
    public phoneNumber:string = '5554449999';
    public phoneNumber1:string = '5158887725';
    public routingNum:string = '123456789';
    public accountNum:string = '123456789';
    public vendorName:string = 'John';
    public taxValue:string = '123456789';
    public note:string = 'Hello12345';
    public suffixDropdownOptions: Array<string> = ['Jr.','Sr.','I','II','III','IV','V'];
    public agencyGroupDropdownOptions: Array<string> = ['Contract','Employee','Organization','Pooling Warehouse'];
    public countryDropdownOptions: Array<string> = ['Canada','United States'];
    public cardsAndIcons: Array<string> =
        ['domain','General','terrain','Territory','mail','Mailing Address','home','Street Address','local_phone',
            'Phone Numbers','visibility','Status','attach_money','Financial','inbox','Vendor','speaker_notes','Notes'];
    public checkboxes: Array<string> = ['Seed', 'Dairy', 'Livestock','Promoter', 'Logistics Provider', 'Encirca Services'];

}






