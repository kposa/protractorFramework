/// <reference path="../../../../typings/index.d.ts" />
import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';

export default class TestData359129 extends BaseTestData {
    constructor () {
        super();

        this.salesRepresentatives.push({
            id: 'aaseeds@phiext.com',
            name: 'Klink'
        });
    }
}