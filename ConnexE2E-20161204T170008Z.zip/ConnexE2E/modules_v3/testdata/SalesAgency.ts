/// <reference path="../../typings/index.d.ts" />

import { Entity } from './Entity';

export interface SalesAgency extends Entity {
    email?:string;
    address?:string;
    country?:string;
}