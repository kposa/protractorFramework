/// <reference path="../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;
import Promise = protractor.promise.Promise;

import { textMatchesText, textContainsText, textContainsExactText } from './utilityHelpers';

/** Passed to factoryFilterFn to further specify selectors to run filter on */
export type selectorFn = (element:ElementFinder) => ElementFinder;
/** Function that filters an ElementArrayFinder and returns an ElementArrayFinder */
export type filterFn = (elements:ElementArrayFinder) => ElementArrayFinder;
/** Configures/returns a filterFn */
export type factoryFilterFn = (criteria:any, selectorFn?:selectorFn) => filterFn;

/**
 * Filters elements with text matching criteria
 * @param criteria
 * @param selectorFn
 * @returns {function(ElementArrayFinder): ElementArrayFinder}
 */
export function matchingText (criteria:string, selectorFn?:selectorFn):filterFn {
    return (elements:ElementArrayFinder):ElementArrayFinder => {
        return elements.filter(element => {
            return (selectorFn ? selectorFn(element) : element).getText().then(text => {
                return textMatchesText(text, criteria);
            });
        });
    }
}

/**
 * Filters elements with text matching exact criteria
 * @param criteria
 * @param selectorFn
 * @returns {function(ElementArrayFinder): ElementArrayFinder}
 */
export function matchingExactText (criteria:string, selectorFn?:selectorFn):filterFn {
    return (elements:ElementArrayFinder):ElementArrayFinder => {
        return elements.filter(element => {
            return (selectorFn ? selectorFn(element) : element).getText().then(text => {
                return text === criteria;
            });
        });
    }
}

/**
 * Filters elements with text containing criteria
 * @param criteria
 * @param selectorFn
 * @returns {function(ElementArrayFinder): ElementArrayFinder}
 */
export function containingText (criteria:string, selectorFn?:selectorFn):filterFn {
    return (elements:ElementArrayFinder):ElementArrayFinder => {
        return elements.filter(element => {
            return (selectorFn ? selectorFn(element) : element).getText().then(text => {
                return textContainsText(text, criteria);
            });
        });
    }
}

/**
 * Filters elements with text containing exact criteria
 * @param criteria
 * @param selectorFn
 * @returns {function(ElementArrayFinder): ElementArrayFinder}
 */
export function containingExactText (criteria:string, selectorFn?:selectorFn):filterFn {
    return (elements:ElementArrayFinder):ElementArrayFinder => {
        return elements.filter(element => {
            return (selectorFn ? selectorFn(element) : element).getText().then(text => {
                return textContainsExactText(text, criteria);
            });
        });
    }
}

type attributeCriteria = { attribute:string, value:string };

/**
 * Filter elements with attribute value matching criteria
 * @param criteria
 * @param selectorFn
 * @returns {function(ElementArrayFinder): ElementArrayFinder}
 */
export function matchingAttributeValue (criteria:attributeCriteria, selectorFn?:selectorFn):filterFn {
    return (elements:ElementArrayFinder):ElementArrayFinder => {
        return elements.filter(element => {
            return (selectorFn ? selectorFn(element) : element).getAttribute(criteria.attribute).then(value => {
                if(value == null) return false;
                return textMatchesText(value, criteria.value);
            });
        });
    }
}

/**
 * Filter elements with attribute value containing criteria
 * @param criteria
 * @param selectorFn
 * @returns {function(ElementArrayFinder): ElementArrayFinder}
 */
export function containingAttributeValue (criteria:attributeCriteria,
                                          selectorFn?:selectorFn,
                                          shouldNotContain?:boolean):filterFn {
    return (elements:ElementArrayFinder):ElementArrayFinder => {
        return elements.filter(element => {
            return (selectorFn ? selectorFn(element) : element).getAttribute(criteria.attribute).then(value => {
                let contains = textContainsText(value, criteria.value);
                return shouldNotContain ? !contains : contains;
            });
        });
    }
}

/**
 * Filters elements that are/not displayed on page by criteria
 * @param criteria
 * @param selectorFn
 * @returns {function(ElementArrayFinder): ElementArrayFinder}
 */
export function isDisplayed (criteria:boolean, selectorFn?:selectorFn):filterFn {
    return (elements:ElementArrayFinder):ElementArrayFinder => {
        return elements.filter(element => {
            return (selectorFn ? selectorFn(element) : element).isDisplayed().then(displayed => {
                return displayed === criteria;
            });
        });
    }
}

/**
 * Filters elements that are/not present in DOM by criteria
 * @param criteria
 * @param selectorFn
 * @returns {function(ElementArrayFinder): ElementArrayFinder}
 */
export function isPresent (criteria:boolean, selectorFn?:selectorFn):filterFn {
    return (elements:ElementArrayFinder):ElementArrayFinder => {
        return elements.filter(element => {
            return (selectorFn ? selectorFn(element) : element).isPresent().then(present => {
                return present === criteria;
            });
        });
    }
}

/**
 * Filters elements that are/not present in DOM and displayed on page by criteria
 * @param criteria
 * @param selectorFn
 * @returns {function(ElementArrayFinder): ElementArrayFinder}
 */
export function isActive (criteria:boolean, selectorFn?:selectorFn):filterFn {
    return (elements:ElementArrayFinder):ElementArrayFinder => {
        return elements.filter(element => {
            const e = (selectorFn ? selectorFn(element) : element);
            return protractor.promise
                .all([ e.isPresent(), e.isDisplayed() ])
                .then(results => {
                    const [present, displayed] = results;
                    return present === criteria && displayed === criteria;
                });
        });
    }
}

/**
 * Runs array of filter functions against elements.
 * This returns a function so filtering is lazily evaluated
 * @param elements
 * @param filterFunctions
 * @returns {function(): ElementArrayFinder}
 */
export function filterElements (elements:ElementArrayFinder, filterFunctions:filterFn[]):() => ElementArrayFinder {
    return () => filterFunctions.reduce((e, fn) => fn(e), elements);
}