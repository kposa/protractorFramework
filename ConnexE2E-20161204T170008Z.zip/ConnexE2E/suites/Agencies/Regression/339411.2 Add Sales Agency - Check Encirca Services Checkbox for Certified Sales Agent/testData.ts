/// <reference path='../../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';
import { agenciesWithCertifiedSalesAgent } from './queries';
import { activeAgenciesForTerritoryPageResults } from '../339411.3 Add Sales Agency - Verify Territory page for the Active Agencies and Unit Manager/queries';

export default class TestDataForEncircaServicesCheckbox extends BaseTestData {

    public agencyId: string;

    protected queries = [
        this.getAgenciesWithCertifiedSalesAgent()
    ];

    private getAgenciesWithCertifiedSalesAgent (): () => Promise<activeAgenciesForTerritoryPageResults> {
        return () => {
            const sql = agenciesWithCertifiedSalesAgent();
            const results = this.queryService.executeSql<activeAgenciesForTerritoryPageResults[]>(sql);

            return results
                .then(data => {
                    const row = <activeAgenciesForTerritoryPageResults>getRandomQueryResult(data);
                    this.agencyId = row.agencyId;
                    return row;
                });
        };
    }

}