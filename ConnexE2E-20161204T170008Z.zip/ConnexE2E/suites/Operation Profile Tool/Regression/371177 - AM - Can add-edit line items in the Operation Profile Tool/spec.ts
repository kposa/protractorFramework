/// <reference path="../../../../typings/index.d.ts" />

import { AccountManagerOperationsFullView } from '../../../../modules_v3/views/accountManager/AccountManagerOperationsFullView';
import { TestData371177 } from './testData';
import { itw } from '../../../../modules_v3/helpers/itw';
import { AccountManagerHamburgerDrawerPartialView } from '../../../../modules_v3/views/accountManager/AccountManagerHamburgerDrawerPartialView';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { AccountManagerOperationProfilePageFullView } from '../../../../modules_v3/views/accountManager/AccountManagerOperationProfilePageFullView';
import { AccountManagerOperationProfileToolFullView } from '../../../../modules_v3/views/accountManager/AccountManagerOperationProfileToolFullView';

const test = new TestCase(
    '371177',
    'AM - Can add-edit line items in the Operation Profile Tool',
    UserRole.ACCOUNT_MANAGER,
    ApplicationFeature.OPERATION_PROFILE_TOOL
);

describe(test.stringify, () => {
    const td = new TestData371177();
    let accountManagerOperations = new AccountManagerOperationsFullView();
    let hamburgerDrawer = new AccountManagerHamburgerDrawerPartialView();
    let operationProfileTool = new AccountManagerOperationProfileToolFullView();
    let operationProfilePage = new AccountManagerOperationProfilePageFullView();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            bootstrap(td.salesRepresentative);

            // should click the hamburger menu
            accountManagerOperations.clickSearchBarHamburger();

            // should click Operation Profile Tool from the hamburger menu
            hamburgerDrawer.clickItemFromHamburgerMenu('Operation Profile Tool');

            // should verify a hamburger icon displayed on Operation Profile Tool page
            expect(operationProfileTool.isHamburgerDisplayed()).toBeTruthy();

            // should verify that the text in the header contains 'Operation Profile Tool'
            expect(operationProfileTool.textOnOperationProfileToolPage()).toContain('Operation profile tool');

            // should verify that the text in the header contains 'Agency'
            expect(operationProfileTool.textOnOperationProfileToolPage()).toContain('Agency');

            // should verify if the label, 'Please select an agency is displayed'
            expect(operationProfileTool.textOnOperationProfileToolPage()).toContain('Please select a sales agency');

            // should click on the Agency drop down
            operationProfileTool.clickAgencyDropDown();

            // should select an agency from the drop down
            operationProfileTool.selectAgencyFromDropDown(td.salesAgency.name);

            // should verify that headers display correctly
            expect(operationProfileTool.isOperationHeaderDisplayed()).toBeTruthy();
            expect(operationProfileTool.isPrimaryDecisionMakerHeaderDisplayed()).toBeTruthy();
            expect(operationProfileTool.isTotalCommercialAcresHeaderDisplayed()).toBeTruthy();
            expect(operationProfileTool.isLivestockHeaderDisplayed()).toBeTruthy();
            expect(operationProfileTool.isLastUpdatedHeaderDisplayed()).toBeTruthy();

            // should verify all operation names are populated
            expect(operationProfileTool.areAllOperationNamesPopulated()).toBeTruthy();

            // should verify all primary decision maker names are populated
            expect(operationProfileTool.areAllPrimaryDecisionMakerNamesPopulated()).toBeTruthy();

            // should verify all total commercial acres are populated
            expect(operationProfileTool.areAllTotalCommercialAcresPopulated()).toBeTruthy();

            // should click on the first record
            operationProfileTool.clickTheFirstOperationRow();

            // should click on the '+' sign for commercial acres
            operationProfilePage.clickCommercialAcresAddButton();

            // should select the first product line from the drop down menu
            operationProfilePage.commercialAcresDialog.selectProductLineFromDropdown();

            // should enter numeric value into Dryland Acres Field
            operationProfilePage.commercialAcresDialog.enterValueIntoDrylandAcresInput();

            // should click on Save button
            operationProfilePage.commercialAcresDialog.clickSave();

            // should click on the okay button of the warning message
            operationProfilePage.commercialAcresDialog.clickOk();

            // should click on the first commercial acres row and edit the Dryland acres value
            operationProfilePage.clickFirstCommercialAcresLineItem();
            operationProfilePage.commercialAcresDialog.enterValueIntoDrylandAcresInput();
            operationProfilePage.commercialAcresDialog.clickSave();

            // should click on the back arrow on the operation profile page
            operationProfilePage.clickBackArrow();

            // should assert on going back to operation profile tool page after clicking on the back arrow
            expect(operationProfileTool.textOnOperationProfileToolPage()).toContain('Operation profile tool');

        }, fail);
    });
});