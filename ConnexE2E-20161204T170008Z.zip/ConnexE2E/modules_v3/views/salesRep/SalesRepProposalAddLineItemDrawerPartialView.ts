/// <reference path='../../../typings/index.d.ts' />
import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;

import { IAddLineItemDrawerPartialView } from "../../interfaces/partialViews/IAddLineItemDrawerPartialView";

import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

import SalesRepUnitsEntryDrawer from './SalesRepUnitsEntryDrawerPartialView';
import Promise = protractor.promise.Promise;
import { NotImplementedError } from '../../../common/exception/exceptions';
import { IView } from '../../interfaces/common/IView';

export class SalesRepProposalAddLineItemDrawerPartialView implements IView, IAddLineItemDrawerPartialView {
    private element:ElementFinder = $('section.lineitem.palette-b');
    private productList = $('section.expandedproduct');
    private productListItems = this.productList.$$('div.product');
    private subProductList = $('section.expandedsubproduct');
    private subProductListItems = this.subProductList.$$('div.subproduct');
    private unitsEntryDrawer = new SalesRepUnitsEntryDrawer();

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    private getProductFromList (productId?:string):ElementFinder {
        if (!productId) {
            return this.productListItems.first();
        } else {
            return this.productListItems.filter(e => e.getText().then(t => t === productId)).first();
        }
    }

    private getSubproductFromList (subProductId?:string):ElementFinder {
        return this
            .subProductListItems
            .filter(e => e.getText().then(t => subProductId ? t === subProductId : true))
            .first();
    }

    selectProductLine ():Promise <boolean> {
        throw new NotImplementedError();
    }

    public selectProduct (productId?:string):void {
        clickElement(this.getProductFromList(productId));
    }

    public selectSubProduct (subProductId?:string):void {
        this.subProductList.isPresent().then(present => {
            if (present) {
                clickElement(this.getSubproductFromList(subProductId));
            }
        });
    }

    public fillInputUnits (value:string):void {
        this.unitsEntryDrawer.fillInputUnits(value);
        this.unitsEntryDrawer.close();
    }

    clickDirectShipmentSection ():void {
        throw new NotImplementedError();
    }

    public close ():void {
        clickElement(this.element.$('div.drawer-close-icon-container'));
    }

}
