/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import { filterElements, isActive, containingText } from '../../../modules_v3/helpers/filterElementHelpers';
import ElementArrayFinder = protractor.ElementArrayFinder;
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

export class AgencyEditPersonMD {

    public clickButton(buttonTxt: string) : void {
        let button = filterElements(
            $$('button'),
            [
                isActive(true),
                containingText(buttonTxt)
            ]
        )().first();
        clickElement(button);
    }

    public getCardsText(): ElementArrayFinder {
        let cardText = $$('div.card-header.grey-text').$$('span');
        return cardText;
    }

    public selectCard(cardTxt: string): void {
        let card = filterElements(
            $$('md-card-content'),
            [
                isActive(true),
                containingText(cardTxt)
            ]
        )().first();
        clickElement(card);
    }








}