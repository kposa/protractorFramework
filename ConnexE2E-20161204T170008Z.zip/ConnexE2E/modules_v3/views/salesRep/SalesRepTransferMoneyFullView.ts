/// <reference path='../../../typings/index.d.ts' />
import ElementFinder = protractor.ElementFinder;

import {ITransferMoneyFullView} from '../../interfaces/fullViews/ITransferMoneyFullView';

import { clickElement } from '../../helpers/clickElementHelpers';
import { filterElements, isActive, matchingText } from '../../helpers/filterElementHelpers';
import { NotImplementedError } from '../../../common/exception/exceptions';
import { IView } from '../../interfaces/common/IView';
import Promise = protractor.promise.Promise;

export default class SalesRepTransferMoneyFullView implements IView, ITransferMoneyFullView {
    private element:ElementFinder = $('section.field-transfer-money');
    private transferFromDropdown:ElementFinder = this.element.$('transfer-from');
    private transferToDropdown:ElementFinder = this.element.$('transfer-to');
    private amount:ElementFinder = this.element.$(`section[label='Amount']`);
    private transferButton:ElementFinder = this.element.$(`button[ng-click='vm.transferMoney()']`);
    private moneyDrawer:ElementFinder = this.element.$('section.moneydrawer');
    private moneyDrawerResetButton = this.moneyDrawer.$(`div[ng-click='vm.reset()']`);
    private moneyDrawerAcceptButton = this.moneyDrawer.$(`div[ng-click='vm.close()']`);

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    public selectTransferFromByInvoiceNameAndSalesPeriodName(invoiceName:string, salesperiodName:string):void {
        clickElement(this.transferFromDropdown);

        const salesperiod = filterElements(this.transferFromDropdown.$$(`div[ng-repeat='group in vm.salesPeriods']`), [
            isActive(true),
            matchingText(salesperiodName, e => e.$(`span.subheader`))
        ])().first();

        const invoice = filterElements(salesperiod.$$(`div[ng-repeat='from in vm.fromBySalesPeriod(group)']`), [
            isActive(true),
            matchingText(invoiceName, e => e.$(`div.pm-listitem-primary`))
        ])().first();

        clickElement(invoice);
    }

    public selectTransferToByInvoiceNameAndSalesPeriodName(invoiceName:string, salesperiodName:string):void {
        clickElement(this.transferToDropdown);

        const salesperiod = filterElements(this.transferToDropdown.$$(`div[ng-repeat='group in vm.salesPeriods']`), [
            isActive(true),
            matchingText(salesperiodName, e => e.$(`span.subheader`))
        ])().first();

        const invoice = filterElements(salesperiod.$$(`div[ng-repeat='to in vm.toBySalesPeriod(group)']`), [
            isActive(true),
            matchingText(invoiceName, e => e.$(`div.pm-listitem-primary`))
        ])().first();

        clickElement(invoice);
    }

    public enterAmount(amount:number):void {
        clickElement(this.amount);
        clickElement(this.moneyDrawerResetButton);
        this.amount.sendKeys(amount.toString(10));
        clickElement(this.moneyDrawerAcceptButton);
    }

    public clickTransferButton():void {
        clickElement(this.transferButton);
    }
}