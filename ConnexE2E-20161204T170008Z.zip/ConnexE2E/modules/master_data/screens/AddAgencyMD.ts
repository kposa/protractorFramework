/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;
import { filterElements, isActive, containingText } from '../../../modules_v3/helpers/filterElementHelpers';
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

export class AddAgencyMD {

    get isAddAgencyDisplayed(): Promise<string> {
        return $('div.md-toolbar-tools').getText();
    }

    public selectRadioButtonForFirstNameLastNameAndSuffix():void {
        clickElement($$('div.md-container.md-ink-ripple').get(1));
    }

    public enterFirstName(firstName: any): void {
        let firstNameContainer = $('input[ng-model="vm.firstName"]');
        firstNameContainer.sendKeys(firstName);
    }

    public enterLastName(lastName: any): void {
        let lastNameContainer = $('input[ng-model="vm.lastName"]');
        lastNameContainer.sendKeys(lastName);
    }

    public getSuffixDropdownOptions(): ElementArrayFinder {
        let allResults = $$('md-option[ng-repeat="suffix in vm.suffixes"]')
                            .$$('div.md-text');
        return allResults;
    }

    public getAgencyGroupDropdownOptions(): ElementArrayFinder {
        let allResults = $$('md-option[ng-repeat="agencyGroup in vm.agencyGroups"]')
                            .$$('div.md-text');
        return allResults;
    }

    public getCountryDropdownOptions(): ElementArrayFinder {
        let allResults = $$('md-option[ng-repeat="country in vm.countries"]')
                            .$$('div.md-text');
        return allResults;
    }

    public clickSuffixDropdown(): void {
        let suffixDropdown = $('md-select[ng-model="vm.suffix.Value"]');
        clickElement(suffixDropdown);
    }

    public selectOptionFromSuffixDropdown(suffix: string): void {
        let selectOption = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(suffix)
            ]
        )().first();
        clickElement(selectOption);
    }

    public clickAgencyGroupDropdown(): void {
        let agencyGroupDropdowm = $('md-select[ng-model="vm.agencyGroupId"]');
        clickElement(agencyGroupDropdowm);
    }

    public selectOptionFromAgencyGroupDropdown(agencyGroup: string): void {
        let selectOption = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(agencyGroup)
            ]
        )().first();
        clickElement(selectOption);
    }

    public clickCountryDropdown(): void {
        let countryDropdown = $('md-select[ng-model="vm.countryId"]');
        clickElement(countryDropdown);
    }

    public selectOptionFromCountryDropdown(country: string): void {
        let selectOption = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(country)
            ]
        )().first();
        clickElement(selectOption);
    }

    public clickNextButton(): void {
        let nextButton = $('button[ng-click="vm.setSubmitAttempted()"]');
        clickElement(nextButton);
    }

    public getHeader(): Promise<string> {
        let parent = $('div.ng-scope.layout-column.flex');
        return parent.getText();
    }

}