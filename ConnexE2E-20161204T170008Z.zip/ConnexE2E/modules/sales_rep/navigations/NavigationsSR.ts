/// <reference path='../../../typings/index.d.ts' />

/**
 * This class will contain wrapper functions for common navigation between pages
 */
import ElementFinder = protractor.ElementFinder;

import {Search} from "../../shared/Search";
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';
import {filterElements, isActive, matchingText, containingText} from '../../../modules_v3/helpers/filterElementHelpers';
import ImpersonationFullView from '../../../modules_v3/views/shared/ImpersonationFullView';
import {SalesRepOperationsFullView} from '../../../modules_v3/views/salesRep/SalesRepOperationsFullView'

let search = new Search();
const impersonationFullView = new ImpersonationFullView();
const salesRepOperationsFullView = new SalesRepOperationsFullView();

export class NavigationsSR {

    private ellipseElem = $('div.fa.fa-ellipsis-v');
    private ellipseMenuSection = $('.actions');

    public goBackToOperationScreen(attempts?:number):void {
        if (!attempts) attempts = 0;
        clickElement($('div.back'));

        var addAcctDescButton = $('button[ng-click="CreateAccountDescription()"]');
        addAcctDescButton.isDisplayed().then((iD) => {
            if (!iD && attempts < 10)
                this.goBackToOperationScreen(attempts + 1);
        }, () => {
            if (attempts < 10)
                this.goBackToOperationScreen(attempts + 1);
        });
    }

    public ellipse(item:string):void {
        this.openEllipseIfNotAlreadyOpen();

        browser.sleep(500); //tests are flaky here
        clickElement(filterElements(this.ellipseMenuSection.$$('div.action'), [
            isActive(true),
            containingText(item)
        ])().first());
    }

    private openEllipse():void {
        browser.sleep(5000); //tests are flaky here
        clickElement(this.ellipseElem);
    }

    private openEllipseIfNotAlreadyOpen():void {
        this.ellipseMenuSection.isDisplayed().then((iD) => {
            if (!iD) this.openEllipse();
        }, () => {
            this.openEllipse();
        });
    }

    public impersonate(user_name:string, user_id:string):void {
        search.clickSearchBarHamburger();
        search.selectImpersonateFromHamburger();
        impersonationFullView.search(user_name);
        impersonationFullView.clickSearchResultContainingText(user_id);
    }

    public selectItemFromHamburgerMenu(itemName:string):void {
        let hamburger = $('div[ng-click="showNav()"]');
        clickElement(hamburger);
        clickElement(this.getHamburgerMenuItem(itemName));
    }

    private getHamburgerMenuItem(itemName:string):ElementFinder {
        let allHamburgerMenuItems = $$('ul.navigation-list.pm-style-body-2').$$('span');

        return filterElements(allHamburgerMenuItems, [
            isActive(true),
            matchingText(itemName)
        ])().first();
    }
}