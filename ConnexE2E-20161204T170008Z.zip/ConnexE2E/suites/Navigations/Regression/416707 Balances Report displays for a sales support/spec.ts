/// <reference path="../../../../typings/index.d.ts" />

import TestData416707 from './testData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { itw } from '../../../../modules_v3/helpers/itw';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { SalesSupportMasterSearchFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportMasterSearchFullView';

const test = new TestCase(
    '416707',
    'Balances Report displays for a sales support',
    UserRole.SALES_REP,
    ApplicationFeature.NAVIGATIONS
);

describe(test.stringify, () => {
    const td = new TestData416707();
    let salesSupportMasterSearchFullView = new SalesSupportMasterSearchFullView();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            bootstrap(td.salesSupportUser);

            //should click on the hamburger
            salesSupportMasterSearchFullView.clickSearchBarHamburger();

            //should click on reports from the hamburger
            salesSupportMasterSearchFullView.hamburgerMenu.selectMenuItemMatchingText('Reports');

            // should click on Balances Report
            salesSupportMasterSearchFullView.hamburgerMenu.selectMenuItemMatchingText('Balances report');

        }, fail);
    });
});