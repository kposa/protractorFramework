/// <reference path="../../../../typings/index.d.ts" />
import Promise = protractor.promise.Promise;

import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import { orgUnitFinder, orgUnitResults } from './sharedOtherCommissionQueries';
import { getRandomNumberAsString, getRandomNumber } from '../../../../modules_v3/helpers/utilityHelpers';
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';

export class sharedOtherCommissionTestData extends BaseTestData {
    /** Value used to full inputs in PVC form */
    public randomValue = getRandomNumberAsString();
    public randomValueTwo = getRandomNumberAsString();
    public randomValueThree = getRandomNumberAsString();
    public randomValueFour = getRandomNumberAsString();
    public randomValueFive = getRandomNumberAsString();

    public randomValueFrom = getRandomNumber();
    public randomValueGreaterThanFrom = (this.randomValueFrom + 5);
    public randomValueGreater2 = (this.randomValueGreaterThanFrom + 5);
    public randomValueGreater3 = (this.randomValueGreater2 + 5);
    public randomValueGreater4 = (this.randomValueGreater3 + 5);
    public randomValueGreater5 = (this.randomValueGreater4 + 5);

    public randSalesAgencyId:string;

    protected queries: (() => Promise<any>)[] = [
        this.findOrgUnits(),
    ];

    private findOrgUnits ():() => Promise<orgUnitResults> {
        return () => {
            const sql = orgUnitFinder(this.salesPeriod.id);
            const results = this.queryService.executeSql<orgUnitResults[]>(sql);

            return results.then(data => {
                const row = <orgUnitResults>getRandomQueryResult(data);
                this.randSalesAgencyId = row.salesAgencyId;

                return row;
            });
        };
    }
}