/// <reference path="../../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import Promise = webdriver.promise.Promise;
import {DrawerSS} from "../../shared/DrawerSS";
import {Element} from "../../../shared/Element";
import {MaterialDesignElement} from "../../../shared/MaterialDesignElement";

let dwr = new DrawerSS();
let e = new Element();
let md = new MaterialDesignElement();

export class DirectShipmentDrawerSS {

    private drawerSection = $('section.salessupport-directship');
    private shipToDisplayValueSection = $('section[ng-click="dsvm.openCustomerDrawer()"]');
    private shipToDrawerSection = $('section.salessupport-products-directship-customer');
    private earliestDeliveryDateSection = $('section[is-required="dsvm.isEariestDeliveryDateRequired()"]');

    public selectBusinessPartnerToShipTo(business_partner_name?:string, listIndex?:number, selectDifferentListItem?:boolean):void {
        this.openShipToDrawerIfNotAlreadyOpen();
        dwr.selectListItem(this.shipToDrawerSection, business_partner_name, listIndex, selectDifferentListItem);
    }

    public clickShipToSection() {
        e.clickElement(this.shipToDisplayValueSection);
    }

    public clear():void {
        e.clickElement($('div[ng-click="dsvm.clear()"]'))
    }

    public close():void {
        let closeBtn = $('div[ng-click="dsvm.close()"]');
        dwr.close(closeBtn)
    }

    public enterShippingDirections(text:string):void {
        let shippingDirectionsDisplayValueSection = $('section[value="dsvm.drawer.value.customer.directions"]');
        let textarea = shippingDirectionsDisplayValueSection.$('textarea');
        e.clickElement(shippingDirectionsDisplayValueSection);
        textarea.sendKeys(protractor.Key.BACK_SPACE);
        textarea.sendKeys(text);
    }

    public setEarliestDeliveryDate(date:string) {
        let earliestDeliveryDateDisplayValue = md.getDisplayValue(this.earliestDeliveryDateSection);
        e.clickElement(earliestDeliveryDateDisplayValue);

        let earliestDeliveryDateInput = this.earliestDeliveryDateSection.$('input');
        earliestDeliveryDateInput.sendKeys(protractor.Key.BACK_SPACE);
        earliestDeliveryDateInput.sendKeys(date);
    }

    private openShipToDrawerIfNotAlreadyOpen():void {
        let self = this;
        this.isShipToDrawerDisplayed.then(function (shipToDrawerIsDisplayed) {
            if (!shipToDrawerIsDisplayed) self.clickShipToSection();
        });
    }

    get isDisplayed():Promise<boolean> {
        return this.drawerSection.getAttribute('class').then(function (classes) {
            return classes.indexOf('expanded') > -1;
        });
    }

    get isShipToDrawerDisplayed():Promise<boolean> {
        return this.shipToDrawerSection.getAttribute('class').then(function (classes) {
            return classes.indexOf('expanded') > -1;
        });
    }

    get shipToText():Promise<string> {
        return dwr.getDisplayValueText(this.shipToDisplayValueSection);
    }

    get earliestDeliveryDateText():Promise<string> {
        return dwr.getDisplayValueText(this.earliestDeliveryDateSection);
    }
}