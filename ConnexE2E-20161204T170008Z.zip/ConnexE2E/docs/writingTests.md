# [Connex E2E Documentation](/)

## Writing Tests

### Stucture: describe/it

Tests consist of a single `describe` and an `it` (using the `it` wrapper function [`itw`](/helpers/itw.html)) block.

```
describe(`[TestCase/Team]`, () => {
    itw('Test description', () => {
        // Automation...
    });
});
```

This design pattern allows as many protractor tests to run in parallel on the [grid](/grid.html) as possible.

### Pending tests

See [itw#pending](/helpers/itw.html#pending).

### Views

[`Views`](./views.html) used in the test should be declared in the `describe` block to be used inside the `it` block.

```
describe(`[TestCase/Team]`, () => {
    const someView = new SomeView();
    itw('Test description', () => {
        // Automation...
        someView.action();
    });
});
```

### Test Data

If the test requires [test data](/testdata.html) then `td.populatePromise()` is called and all automation occurs in the `then` callback. Jasmine's `fail` method needs to be passed as the second parameter so the test fails if test data does not populate.

```
describe(`[TestCase/Team]`, () => {
    const td = new TestData();
    
    itw('Test description', () => {
        td.populatePromise().then(() => {
            // Automation...
        }, fail);
    });
});
```

### Sales Period

By default [`BaseTestData`](/testdata.html) will default to whatever sales period is [configured](/salesperiod.html#configuration). This sales period can be [overwritten](/salesperiod.html#singletestoverwrite) on a test by test basis but must be done before `td.populatePromise()` is called.

### Bootstrap

[`bootstrap`](/helpers/bootstrap.html) is the first automation step in a test and it loads Connex, logs in, impersonates and reset feature flags.

#### Impersonating

`bootstrap` accepts a `User` object from `BaseTestData` as its first argument. This `User` is who will be impersonated.