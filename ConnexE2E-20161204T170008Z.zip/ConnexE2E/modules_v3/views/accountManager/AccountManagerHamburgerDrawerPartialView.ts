/// <reference path='../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import { clickElement } from '../../helpers/clickElementHelpers';
import {
    filterElements,
    isActive,
    containingText,
} from '../../helpers/filterElementHelpers';
import { IHamburgerMenuPartialView } from '../../interfaces/partialViews/IHamburgerMenuPartialView';
import { IView } from '../../interfaces/common/IView';
import { NotImplementedError } from '../../../common/exception/Exceptions';

export class AccountManagerHamburgerDrawerPartialView implements IView, IHamburgerMenuPartialView {

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    clickItemFromHamburgerMenu (itemName:string):void {
        let hamburgerMenuItem = filterElements(
            $('div.box-content.palette-c').$$('span'),
            [
                isActive(true),
                containingText(itemName)
            ]
        )().first();
        clickElement(hamburgerMenuItem);
    }

    isBalancesReportDisplayed (name:string):Promise<boolean> {
        return filterElements(
            $$('li[ng-repeat="report in vm.reports"]'),
            [
                isActive(true),
                containingText(name)
            ]
        )().count().then(c => c > 0);
    }
}