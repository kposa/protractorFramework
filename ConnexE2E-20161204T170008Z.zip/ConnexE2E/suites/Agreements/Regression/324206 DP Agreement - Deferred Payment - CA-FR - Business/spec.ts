/// <reference path="../../../../typings/index.d.ts" />

import {SharedDPAgreementSteps} from "../shared/SharedDPAgreementSteps";
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import {SharedDPAgreementTestData} from "../shared/SharedDPAgreementTestData";

const test = new TestCase(
	'324206',
	'DP Agreement - Deferred Payment - CA-FR - Business',
	UserRole.SALES_REP,
	ApplicationFeature.NAVIGATIONS
);

describe(test.stringify, () => {
    const sharedDPAgreementSteps = new SharedDPAgreementSteps();
    const td = new SharedDPAgreementTestData();

    td.customerType = 2;
    td.customerCultureName = 'fr-ca';
    td.customerHasMissingAgreement = true;
    td.excludeCustomerRegion = 'QC';
    td.useAlternateNavigationToDPAgreement = true;

    sharedDPAgreementSteps.run(test.description, td);
});