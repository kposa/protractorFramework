/// <reference path='../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import { NotImplementedError } from '../../../common/exception/Exceptions';
import { IView } from '../../interfaces/common/IView';
import { clickElement } from '../../helpers/clickElementHelpers';

export class MasterDataCustomerFullView implements IView {

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    selectFirstOperation () {
        clickElement($$('div.pm-listitem').first());
    }
}