/// <reference path="../../../../typings/index.d.ts" />
import Promise = protractor.promise.Promise;

import { getRandomQueryResult, isUndefined } from '../../../../modules_v3/helpers/utilityHelpers';
import { organizationalUnit, organizationalUnitResults } from './sharedMasterDataSearchQueries';
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';

export default class TestDataMasterDataSearch extends BaseTestData {
    public typeId: string;
    public searchTerm: string;
    public category: string;
    public resultType: string;
    protected queries = new Array;

    constructor (type: string, cat: string, result: string, salesPeriod?: number) {
        super();
        this.typeId = type;
        this.category = cat;
        this.resultType = result;
        if (salesPeriod)
            this.salesPeriod.setTo(salesPeriod);
        this.queries = [
            this.populateOrganizationalUnit(this.typeId)
        ];
    }

    private populateOrganizationalUnit (organizationalUnitId: string): () => Promise<organizationalUnitResults> {
        const sql = organizationalUnit(this.salesPeriod.id, organizationalUnitId);
        return () => {
            const results = this.queryService.executeSql<organizationalUnitResults>(sql);
            return results.then(data => {
                const row = <organizationalUnitResults>getRandomQueryResult(data);

                this.searchTerm = row.searchTerm;

                return row;
            });
        };
    }
}