# ==============================================================================
# PARAMETERS
# ==============================================================================

Param(
    # Paths
    [string]$RootPath = "C:\tfs\FieldSales\Connex\ConnexE2E",

    # Protractor
    [string]$Grid = "true",
    [string]$Suite = "all_smoke",

    # Connex
    [string]$ConnexRootUrl = "https://salesstagingtx.pioneer.com/",
    [string]$ConnexUsername = "tfstctrl",
    [string]$ConnexPassword = "6T5RdfEr4#$#eM",

	# Databases
    [string]$InvoicesDatabaseName = "invoicesdemo",
    [string]$InvoicesDBConnection = "Server=JHTRSQ01,1600;Database=$InvoicesDatabaseName;User Id=ConnexAutoTest;Password=MbWq77X35hSrwYxN;MultipleActiveResultSets=true;Async=true;Connection Timeout=15000",
    [string]$PaymentsDatabaseName = "paymentsdemo",
    [string]$PaymentsDBConnection = "Server=JHTRSQ01,1600;Database=$PaymentsDatabaseName;User Id=ConnexAutoTest;Password=MbWq77X35hSrwYxN;MultipleActiveResultSets=true;Async=true;Connection Timeout=15000",
    [string]$AccountingDatabaseName = "accountingdemo",
    [string]$AccountingDBConnection = "Server=JHTRSQ01,1600;Database=$AccountingDatabaseName;User Id=ConnexAutoTest;Password=MbWq77X35hSrwYxN;MultipleActiveResultSets=true;Async=true;Connection Timeout=15000",
    [string]$OperationsDatabaseName = "operationsdemo",
    [string]$OperationsDBConnection = "Server=JHTRSQ01,1600;Database=$OperationsDatabaseName;User Id=ConnexAutoTest;Password=MbWq77X35hSrwYxN;MultipleActiveResultSets=true;Async=true;Connection Timeout=15000",
    [string]$ReportingDatabaseName = "FieldSales_ReportingDemo",
    [string]$ReportingDBConnection = "Server=JHTRSQ01,1600;Database=$ReportingDatabaseName;User Id=ConnexAutoTest;Password=MbWq77X35hSrwYxN;MultipleActiveResultSets=true;Async=true;Connection Timeout=15000",
    # Config
    [string]$Locale = "en-us"
)

# ==============================================================================
# SETUP
# ==============================================================================

# Set RootPath to CWD if present
if ($PSScriptRoot){
    $RootPath = $PSScriptRoot
} elseif(split-path -parent $MyInvocation.MyCommand.Definition) {
    $RootPath = split-path -parent $MyInvocation.MyCommand.Definition
}

# Tell powershell to stop the script if an error is encountered - even a normally non-terminating one (like file not found).
$ErrorActionPreference = "Stop"

# ==============================================================================
# EXECUTE TESTS
# ==============================================================================

echo @"
--------------------------------------------------------------------------------
Connex E2E

Suite: $Suite
BaseUrl: $ConnexRootUrl
Grid: $Grid
RootPath: $RootPath

Invoices DB: $InvoicesDatabaseName
Payments DB: $PaymentsDatabaseName
Accounting DB: $AccountingDatabaseName
Operations DB: $OperationsDatabaseName
Reporting DB: $ReportingDatabaseName
--------------------------------------------------------------------------------
"@

cd $RootPath

# Install node dependencies
npm install

# Run tests
npm test -- `
    --IsRunningOnOctopus=true `
    --suite=$Suite `
    --Grid=$Grid `
    --BaseUrl=$ConnexRootUrl `
    --ConnexUsername=$ConnexUsername `
    --ConnexPassword=$ConnexPassword `
    --InvoicesDatabaseName=$InvoicesDatabaseName `
    --InvoicesDBConnection=$InvoicesDBConnection `
    --PaymentsDatabaseName=$PaymentsDatabaseName `
    --PaymentsDBConnection=$PaymentsDBConnection `
    --AccountingDatabaseName=$AccountingDatabaseName `
    --AccountingDBConnection=$AccountingDBConnection `
    --OperationsDatabaseName=$OperationsDatabaseName `
    --OperationsDBConnection=$OperationsDBConnection
    --ReportingDatabaseName=$ReportingDatabaseName `
    --ReportingDBConnection=$ReportingDBConnection `