/// <reference path="../../../../typings/index.d.ts" />

import Promise = protractor.promise.Promise;
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';
import {
    testDataForChargeAndCredit, testDataForChargeAndCreditResults,
    chargeAndCreditNamesByOperationAndSalesPeriod, chargeAndCreditNamesByOperationAndSalesPeriodResults
} from './queries';
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';

export default class TestData319937 extends BaseTestData {

    public operationId:string;
    public chargeAndCreditName:string;
    public chargeAndCreditAmount:string;

    protected queries:(() => Promise<any>)[] = [
        this.getTestDataForChargeAndCreditResults(),
        this.getChargeAndCreditNamesByOperationAndSalesPeriod()
    ];

    private getTestDataForChargeAndCreditResults ():() => Promise<testDataForChargeAndCreditResults> {
        return () => {
            const sql = testDataForChargeAndCredit(this.salesPeriod.id);
            const results = this.queryService.executeSql<testDataForChargeAndCreditResults[]>(sql);

            return results
                .then(data => {
                    const row = <testDataForChargeAndCreditResults>getRandomQueryResult(data);

                    this.salesAgencies.push({
                        id: row.salesAgentId,
                        name: row.salesAgentName
                    });

                    this.operations.push({
                        id: row.operationId,
                        name: row.operationName
                    });

                    this.businessPartners.push({
                        id: row.businessPartnerId,
                        name: row.businessPartnerName
                    });

                    this.operationId = row.operationId;

                    return row;
                });
        };
    }

    private getChargeAndCreditNamesByOperationAndSalesPeriod ():() => Promise<chargeAndCreditNamesByOperationAndSalesPeriodResults> {
        return () => {
            const sql = chargeAndCreditNamesByOperationAndSalesPeriod(this.operationId, this.salesPeriod.id);
            const results = this.queryService.executeSql<chargeAndCreditNamesByOperationAndSalesPeriodResults[]>(sql);

            return results
                .then(data => {
                    const row = <chargeAndCreditNamesByOperationAndSalesPeriodResults>getRandomQueryResult(data);

                    this.chargeAndCreditName = row.chargeAndCreditName;

                    return row;
                });
        };
    }
}