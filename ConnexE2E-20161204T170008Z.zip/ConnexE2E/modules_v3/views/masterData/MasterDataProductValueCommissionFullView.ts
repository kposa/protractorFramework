/// <reference path='../../../typings/index.d.ts' />
import Promise = protractor.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;

import {IProductValueCommissionFullView} from "../../interfaces/fullViews/IProductValueCommissionFullView";
import { filterElements, matchingText, containingText, isActive } from '../../helpers/filterElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';
import { isAriaChecked } from '../../helpers/utilityElementHelpers';

export class MasterDataProductValueCommissionFullView implements IProductValueCommissionFullView {
    private element = $(`section.product-value`);
    private tabs = this.element.$$(`md-tab-item[ng-repeat='tab in $mdTabsCtrl.tabs']`);
    private inputs = this.element.$$(`md-input-container`);
    private saveButton = this.element.$(`button[ng-click='vm.saveConfiguration()']`);

    private salesAgencySalesYears =  $$(`tr.md-row.ng-scope[ng-repeat='data in vm.productValueConfigurationsData']>td.md-cell:nth-child(1)`);
    private salesAgencyAccelerationPoints = $$(`tr.md-row.ng-scope[ng-repeat='data in vm.productValueConfigurationsData']>td.md-cell:nth-child(4)`);
    private salesAgencyOverAccelerationPoints = $$(`tr.md-row.ng-scope[ng-repeat='data in vm.productValueConfigurationsData']>td.md-cell:nth-child(5)`);
    private salesAgencyUnderAccelerationPoints = $$(`tr.md-row.ng-scope[ng-repeat='data in vm.productValueConfigurationsData']>td.md-cell:nth-child(6)`);
    private salesAgencyPVCMenu = $$(`button.md-icon-button.md-button.md-ink-ripple[aria-label='more_vert']`);
    private salesAgencyPVCMenuItems = $$(`button.md-button.md-ink-ripple[role='menuitem']`);

    private salesAgencySaveButton = $(`button[ng-click='vm.save()']`);
    private salesAgencyAccelerationPointField = $(`input[ng-model='vm.configuration.accelerationPointPercent']`);
    private salesAgencyOverAccelerationPointField = $(`input[ng-model='vm.configuration.overAccelerationPointPercent']`);
    private salesAgencyUnderAccelerationPointField = $(`input[ng-model='vm.configuration.underAccelerationPointPercent']`);
    private salesAgencyOverrideBaseRevenueField = $(`input[ng-model='vm.baseRevenueOverrideAmount']`);
    private salesAgencyApplyToAllProductsBox = $(`md-checkbox[ng-checked='vm.allProducts()']`);

    removeProductLineItem() {
        let salesAgencyTrashCanBtn = $$(`button.md-icon-button.md-button[ng-click='vm.delete(material)']`).first();
        clickElement(salesAgencyTrashCanBtn);
    }

    addProductLineItem() {
        let salesAgencyAddButton = $(`button[ng-click='vm.add()']`);
        clickElement(salesAgencyAddButton);
    }

    selectItemFromProductLineDropDownAcreGrowth(item:string):Promise<string> {
        let productLineListBox = $(`md-select[aria-label='{{ vm.productLineLabel }}']`);
        clickElement(productLineListBox);

        let salesAgencyProductLineContent = $$(`md-content`).last().getAttribute('innerText');
        let list = $$(`md-option[ng-repeat='productLine in vm.availableProducts | filterAcreProductLine : vm.productList : material']`);
        clickElement(filterElements(list, [isActive(true), containingText(item)])().first());

        return salesAgencyProductLineContent;
    }

    /*
     * The purpose of this function is twofold:
     * 1.) It will select the given element from the Product Line dropdown menu.
     * 2.) It will return a string containing all of the items in the dropdown menu delimited by hyphens
     *          - this list is stored within the innerText of the element md-content
     *
     * This allows one to verify that only the expected products exist in the current dropdown menu
     */
    selectItemFromProductLineDropDown(item:string):Promise<string> {
        let productLineListBox = $(`md-select[aria-label='Product line']`);
        clickElement(productLineListBox);

        let salesAgencyProductLineContent = $$(`md-content`).last().getAttribute('innerText');
        let list = $$(`md-option[ng-repeat='productLine in vm.availableProducts | filterProductLine : vm.productList : material']`);
        clickElement(filterElements(list, [isActive(true), containingText(item)])().first());

        return salesAgencyProductLineContent;
    }

    isApplyToAllProductsChecked():Promise<boolean> {
        return isAriaChecked(this.salesAgencyApplyToAllProductsBox);
    }

    getSalesAgencyPreviousSalesYear():Promise<string> {
        return this.salesAgencySalesYears.first().getText();
    }
    getSalesAgencyCurrentSalesYear():Promise<string> {
        return this.salesAgencySalesYears.last().getText();
    }

    displayCurrentYearSalesAgencyConfig(editOption:string) {
        clickElement(this.salesAgencyPVCMenu.last());
        clickElement(filterElements(this.salesAgencyPVCMenuItems, [isActive(true), containingText(editOption)])().first());
    }

    getCurrentSalesYearAccelerationPoint():Promise<string> {
        return this.salesAgencyAccelerationPoints.last().getText();
    }
    getCurrentSalesYearOverAccelerationPoint():Promise<string> {
        return this.salesAgencyOverAccelerationPoints.last().getText();
    }
    getCurrentSalesYearUnderAccelerationPoint():Promise<string>  {
        return this.salesAgencyUnderAccelerationPoints.last().getText();
    }

    fillSalesAgencyAccelerationPoint(saAPValue:string) {
        this.salesAgencyAccelerationPointField.clear();
        this.salesAgencyAccelerationPointField.sendKeys(saAPValue);
    }

    fillSalesAgencyOverAccelerationPoint(saOAPValue:string) {
        this.salesAgencyOverAccelerationPointField.clear();
        this.salesAgencyOverAccelerationPointField.sendKeys(saOAPValue);
    }

    fillSalesAgencyUnderAccelerationPoint(saUAPValue:string) {
        this.salesAgencyUnderAccelerationPointField.clear();
        this.salesAgencyUnderAccelerationPointField.sendKeys(saUAPValue);
    }

    fillSalesAgencyOverrideBaseRevenue(saOBRevenue:string) {
        this.salesAgencyOverrideBaseRevenueField.clear();
        this.salesAgencyOverrideBaseRevenueField.sendKeys(saOBRevenue);
    }

    getSalesAgencyOverrideBaseRevenue():Promise<string> {
        return this.salesAgencyOverrideBaseRevenueField.getAttribute('value');
    }

    getSalesAgencyOverrideAccelerationPoint():Promise<string> {
        return this.salesAgencyAccelerationPointField.getAttribute('value');
    }
    getSalesAgencyOverrideOverAccelerationPoint():Promise<string> {
        return this.salesAgencyOverAccelerationPointField.getAttribute('value');
    }
    getSalesAgencyOverrideUnderAccelerationPoint():Promise<string> {
        return this.salesAgencyUnderAccelerationPointField.getAttribute('value');
    }

    toggleSalesAgencyApplyToAllProducts() {
        clickElement(this.salesAgencyApplyToAllProductsBox);
    }

    /**
     * Click back arrow button
     */
    clickBack():void {
        let backButton = $(`button[ng-click='vm.onBack()']`);
        clickElement(backButton);
    }

    /**
     * Click 'Base Values' tab
     */
    clickBaseValuesTab () {
        clickElement(filterElements(this.tabs, [isActive(true), matchingText('Base Values')])().first());
    }

    /**
     * Clears all inputs in form with the given string labels
     */
    clearAllInputs (lblList: any[]) {
        let list: Array<string> = lblList;

        for (let _i = 0; _i < list.length; _i++) {
            this.clearInputByLabelContainingText(list[ _i ]);
        }
    }

    clickTabMatchingText(text:string):void {
        clickElement(filterElements(this.tabs, [isActive(true), matchingText(text)])().first());
    }

    clickTabContainingText(text:string):void {
        clickElement(filterElements(this.tabs, [isActive(true), containingText(text)])().first());
    }

    getInputByLabelMatchingText(text:string):ElementFinder {
        return filterElements(this.inputs, [isActive(true), matchingText(text, e => e.$(`label`))])()
            .first()
            .$(`input`);
    }

    getInputByLabelContainingText(text:string):ElementFinder {
        return filterElements(this.inputs, [isActive(true), containingText(text, e => e.$(`label`))])()
            .first()
            .$(`input`);
    }

    getInputValueByLabelMatchingText(text:string):Promise<string> {
        return filterElements(this.inputs, [isActive(true), matchingText(text)])()
            .first()
            .$(`input`)
            .getAttribute('value');
    }

    getInputValueByLabelContainingText(text:string):Promise<string> {
        return filterElements(this.inputs, [isActive(true), containingText(text)])()
            .first()
            .$(`input`)
            .getAttribute('value');
    }

    fillInputByLabelMatchingText(text:string, inputText:string):void {
        this.clearInputByLabelMatchingText(text);
        this.getInputByLabelMatchingText(text).sendKeys(inputText);
    }

    fillInputByLabelContainingText(text:string, inputText:string):void {
        this.clearInputByLabelContainingText(text);
        this.getInputByLabelContainingText(text).sendKeys(inputText);
    }

    clearInputByLabelMatchingText(text:string):void {
        this.getInputByLabelMatchingText(text).clear();
    }

    clearInputByLabelContainingText(text:string):void {
        this.getInputByLabelContainingText(text).clear();
    }

    blurInputByLabelMatchingText(text:string):void {
        browser.executeScript('return arguments[0].blur()', this.getInputByLabelMatchingText(text));
    }

    blurInputByLabelContainingText(text:string):void {
        browser.executeScript('return arguments[0].blur()', this.getInputByLabelContainingText(text));
    }

    formCanBeSubmitted():Promise<boolean> {
        return this.saveButton.isEnabled();
    }

    salesAgencyFormCanBeSubmitted():Promise<boolean> {
        return this.salesAgencySaveButton.isEnabled();
    }

    cancelSalesAgencyPVC() {
        let salesAgencyCancelButton = $(`button[ng-click='vm.close()']`);
        clickElement(salesAgencyCancelButton);
    }

    submitSalesAgencyPVC() {
        clickElement(this.salesAgencySaveButton);
    }

    submitForm():void {
        clickElement(this.saveButton);
    }

}