/// <reference path="../../../typings/index.d.ts" />

import {IExpandableMenuView} from "../common/IExpandableMenuView";

export interface IActionPartialView extends IExpandableMenuView {
}