interface DatabaseNameServiceEnvs {
    [s: string]: string;
    tx: string;
    staging: string;
}

interface DatabaseNameServiceDatabases {
    [s: string]: DatabaseNameServiceEnvs;
    invoices: DatabaseNameServiceEnvs;
    payments: DatabaseNameServiceEnvs;
    operations: DatabaseNameServiceEnvs;
    accounting: DatabaseNameServiceEnvs;
}

export default class DatabaseNameService {
    public databases: DatabaseNameServiceDatabases = {
        'invoices': {
            tx: 'invoices',
            staging: 'invoicesdemo'
        },
        'payments': {
            tx: 'payments',
            staging: 'paymentsdemo'
        },
        'operations': {
            tx: 'operations',
            staging: 'operationsdemo'
        },
        'accounting': {
            tx: 'accounting',
            staging: 'accountingdemo'
        }
    };

    public envDatabaseName (baseDatabaseName: string, env: string): string {
        const envDatabaseName = this.databases[baseDatabaseName][env];

        if (typeof envDatabaseName === 'undefined') {
            throw new Error(`No database found with base name '${baseDatabaseName}' in env '${env}'`);
        }

        return envDatabaseName;
    }
}