/// <reference path='../../../typings/index.d.ts' />
import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;
import { NotImplementedError } from '../../../common/exception/Exceptions';
import { IView } from '../../interfaces/common/IView';
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';

export default class SalesRepPreviewDocumentFullView implements IView {

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    verifyPrintIcon ():Promise<boolean> {
        let printIcon = $('i[ng-click="vm.printDocument()"]');
        return isPresentAndDisplayed(printIcon);
    }

    verifyEmail ():Promise<boolean> {
        let emailIcon = $('section.field-document-email-dialog');
        clickElement(emailIcon);
        let textAreas = $('div.email-entry-area');
        return isPresentAndDisplayed(textAreas);
    }

}
