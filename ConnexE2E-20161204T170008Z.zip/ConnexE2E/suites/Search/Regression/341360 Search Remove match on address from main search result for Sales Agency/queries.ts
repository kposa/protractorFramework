export interface query341360Results {
    agencyId: string
    street1: string
    street2: string
    city: string
    postalCode: string
    firstName: string
    lastName: string

}
export function query341360 () {
    const {E2EOperationsDatabaseName} = process.env;
    return `

select aa.agencyId, aa.street1, aa.street2, aa.city, aa.postalCode, aa.regionId, ag.firstName, ag.lastName 
from ${E2EOperationsDatabaseName}.masterdata.AgencyAddress aa
join ${E2EOperationsDatabaseName}.masterdata.agency ag on ag.agencyId = aa.agencyId
where aa.addresstypeid = 1
and ag.firstName != ''
and ag.lastName != ''

`;
}


