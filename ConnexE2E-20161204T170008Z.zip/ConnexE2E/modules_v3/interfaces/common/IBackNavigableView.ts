/// <reference path="../../../typings/index.d.ts" />

export interface IBackNavigableView {
    clickBack():void;
}