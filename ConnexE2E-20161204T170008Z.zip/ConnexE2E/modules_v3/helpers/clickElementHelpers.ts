/// <reference path="../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;
import Promise = protractor.promise.Promise;
import { checkForOopsScreen, closePopupNotifications } from './oopsScreenHelpers';

export function clickElement (element:ElementFinder, customErrorMessage?:string):void {
    element.click();
    checkForOopsScreen();
    closePopupNotifications();
}