/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;
import {Helpers} from "../../shared/Helpers";
import {Element} from "./../../shared/Element";
import ElementFinder = protractor.ElementFinder;

export class EncircaViewPaymentsCS {

    public arePaymentsDisplayed():Promise<boolean> {
        var paymentsSection = $('section.viewpayment');
        return paymentsSection.isDisplayed();

    }
}