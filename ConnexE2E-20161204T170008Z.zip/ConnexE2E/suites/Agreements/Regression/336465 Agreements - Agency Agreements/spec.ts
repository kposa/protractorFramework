/// <reference path='../../../../typings/index.d.ts' />

import {SearchMD2} from "../../../../modules/master_data/screens/SearchMD2";
import {ButtonMD} from "../../../../modules/master_data/shared/ButtonMD";
import {AgencyMD} from "../../../../modules/master_data/screens/AgencyMD";
import {AddAgreementMD} from "../../../../modules/master_data/screens/AddAgreementMD";
import {AgencyAgreementsMD} from "../../../../modules/master_data/screens/AgencyAgreementsMD";
import {AgreementMD} from "../../../../modules/master_data/screens/AgreementMD";
import {AgreementsAddCommentMD} from "../../../../modules/master_data/screens/AgreementsAddCommentMD";
import { bootstrap } from '../../../SharedSteps/bootstrap';
import TestData336465 from "./testData";
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
	'336465',
	'Agreements - Agency Agreements',
	UserRole.MASTER_DATA,
	ApplicationFeature.AGREEMENTS
);

describe(test.stringify, () => {
    const td = new TestData336465();
    let searchMD = new SearchMD2();
    let agencyMD = new AgencyMD();
    let addAgreementMD = new AddAgreementMD();
    let agencyAgreementsMD = new AgencyAgreementsMD();
    let agreementMD = new AgreementMD();
    let agreementsAddCommentMD = new AgreementsAddCommentMD();
    let buttonMD = new ButtonMD();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.masterDataUser);

            // should select sales agency
            searchMD.searchByCriteria(td.agencyId);
            searchMD.selectSearchResultByResultType('Sales agency');

            // should verify sales agency id displayed
            expect(agencyMD.isSalesAgencyIdDisplayedOnBlueRibbon()).toContain(td.agencyId);

            // should verify hamburger menu displayed
            expect(agencyMD.isHamburgerMenuDisplayed()).toBeTruthy();

            // should click agreements tab
            agencyMD.selectTab('AGREEMENTS');

            // should click [+] FAB button
            buttonMD.clickAddIcon();

            // should verify add agreement displayed
            expect(addAgreementMD.verifyAddAgreementDisplayed()).toEqual('Add Agreement');

            // should verify [X] button displayed
            expect(addAgreementMD.verifyCancelButtonDisplayed()).toBeTruthy();

            // should verify agreement type drop down displayed
            expect(addAgreementMD.verifyAgreementTypeDropdownDisplayed()).toBeTruthy();

            // should verify date signed dropdown displayed
            expect(addAgreementMD.verifyDateSignedDropdownDisplayed()).toBeTruthy();

            // should verify signed by rep dropdown displayed
            expect(addAgreementMD.isSignedByRepDropdownDisplayed()).toBeTruthy();

            // should verify signed by other text field displayed
            expect(addAgreementMD.verifySignedByOtherTextFieldDisplayed()).toBeTruthy();

            // should verify add button displayed
            expect(addAgreementMD.verifyAddButtonDisplayed()).toEqual('ADD');

            // should click add button
            buttonMD.clickAddButton();

            // should verify validation message
            expect(addAgreementMD.isRequiredDisplayed()).toContain('Required');

            // should select agreement type from dropdown
            addAgreementMD.selectAgreementTypeFromDropdown();

            // should select a date
            addAgreementMD.selectTodaysDateFromDatePicker();

            // should select sales rep from signed by rep dropdown
            addAgreementMD.selectSignedByRepFromDropdown();

            // should verify maximum character length of [Signed By Other] input container
            expect(addAgreementMD.verifySignedByOtherInputContainerMaxCharacterLength()).toEqual('50');

            // should enter details in signed by other container
            addAgreementMD.inputSignedByOther(td.signedByOther);

            // should click add button
            buttonMD.clickAddButton();

            // should verify reqiuired information displayed
            expect(agencyAgreementsMD.isSignedByTextDisplayedOnCard()).toContain('Signed By:');
            expect(agencyAgreementsMD.isDateSignedTextDisplayedOnCard()).toContain('Date Signed: ');

            // should select agreement card
            agencyAgreementsMD.clickAgreementCard();

            // should verify columns are displayed
            expect(agreementMD.isAgreementTypeColumnDisplayed()).toEqual('Agreement Type');
            expect(agreementMD.isDateSignedColumnDisplayed()).toEqual('Date Signed');
            expect(agreementMD.isSignedByRepColumnDisplayed()).toEqual('Signed By Rep');
            expect(agreementMD.isSignedByOtherColumnDisplayed()).toEqual('Signed By Other');

            // should verify icons are displayed 
            expect(agreementMD.isEditAgreementIconDisplayed()).toBeTruthy();
            expect(agreementMD.isShowEditCommentIconDisplayed()).toBeTruthy();
            expect(agreementMD.isDeleteAgreementIconDisplayed()).toBeTruthy();

            // should click edit icon and verify multiple dropdowns are displayed 
            agreementMD.clickEditAgreementIcon();
            expect(addAgreementMD.verifyAgreementTypeDropdownDisplayed()).toBeTruthy();
            expect(addAgreementMD.isSignedByRepDropdownDisplayed()).toBeTruthy();
            buttonMD.clickAddButton();

            // should verify comment input container maximum character length 
            agreementMD.clickShowEditCommentIcon();
            expect(agreementsAddCommentMD.verifyCommentContainerMaximumCharacterLength()).toEqual('256');
            buttonMD.clickAddButton();

            // should check delete icon works
            agreementMD.clickDeleteAgreementIcon();
        }, fail);
    });
});