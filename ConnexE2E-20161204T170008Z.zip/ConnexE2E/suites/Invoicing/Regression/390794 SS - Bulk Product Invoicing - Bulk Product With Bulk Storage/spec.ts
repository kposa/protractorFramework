/// <reference path="../../../../typings/index.d.ts" />

import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { sharedSalesSupportBulkStorageVerificationSteps } from '../shared/SharedSalesSupportBulkStorageVerificationSteps';
import { SharedBulkStorageVerificationTestData } from '../../../Proposals/Regression/shared/SharedBulkStorageVerificationTestData';

const test = new TestCase(
    '390794',
    'SS - Bulk Product Invoicing - Bulk Product With Bulk Storage',
    UserRole.SALES_SUPPORT,
    ApplicationFeature.INVOICING
);

describe(test.stringify, () => {
    const td = new SharedBulkStorageVerificationTestData();
    td.agencyHasBulkStorage = true;
    sharedSalesSupportBulkStorageVerificationSteps(td, test.description);
});