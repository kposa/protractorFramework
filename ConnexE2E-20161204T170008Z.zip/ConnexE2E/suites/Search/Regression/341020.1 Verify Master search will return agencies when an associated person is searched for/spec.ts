/// <reference path="../../../../typings/index.d.ts" />

import { bootstrap } from "../../../SharedSteps/bootstrap";
import { itw } from '../../../../modules_v3/helpers/itw';
import TestData341020 from './testData';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import MasterDataMasterSearchFullView from '../../../../modules_v3/views/masterData/MasterDataMasterSearchFullView';

const test = new TestCase(
	'341020.1',
	'Verify Master search will return agencies when an associated person is searched for',
	UserRole.MASTER_DATA,
	ApplicationFeature.SEARCH
);

describe(test.stringify, () => {
    const td = new TestData341020();
    let masterDataMasterSearchFullView = new MasterDataMasterSearchFullView();

    itw(test.description, () => {
        td.populatePromise().then(() => {

            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.masterDataUser);

            //should search for sales agencies by person name
            masterDataMasterSearchFullView.searchByTwoCriteria(td.personFirstName, td.personLastName);
            masterDataMasterSearchFullView.selectFilterContainingText('Sales agencies');

            //should verify the search result displays correctly
            expect(masterDataMasterSearchFullView.getSearchResultContentByContainingHeadline(td.agencyId))
                .toContain(td.personFirstName);
            expect(masterDataMasterSearchFullView.getSearchResultContentByContainingHeadline(td.agencyId))
                .toContain(td.personLastName);
            expect(masterDataMasterSearchFullView.getSearchResultContentByContainingHeadline(td.agencyId))
                .toContain(td.personType);
        }, fail);
    });
});