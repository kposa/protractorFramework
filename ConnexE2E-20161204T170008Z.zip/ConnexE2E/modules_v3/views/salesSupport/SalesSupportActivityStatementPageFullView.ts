/// <reference path='../../../typings/index.d.ts' />
import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;
import { IView } from '../../interfaces/common/IView';
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';
import { filterElements, isActive, containingText } from '../../helpers/filterElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';

export class SalesSupportActivityStatementPageFullView implements IView {

    isViewDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('section.activity-statement'));
    }

    private getTransactionRowByTransactionTypeName (type:string):ElementFinder {
        return filterElements($$('li[ng-repeat="type in balance.transactionTypeBalance"]'),
            [ isActive(true), containingText(type, e => e.$('div.flex-horizontal.pm-listitem')
                .$('div.flex-horizontal.type-chevron').$('div.type.text')) ])().first();
    }

    getTransactionTypeAmmountByTransactionType (type:string):Promise<string> {
        return this.getTransactionRowByTransactionTypeName(type).$('div.flex-horizontal.pm-listitem')
            .$$('div.row-item.numeric').get(0).getText();
    }

    getTransactionTypeTextByTransactionType (type:string):Promise<string> {
        return this.getTransactionRowByTransactionTypeName(type).$('div.flex-horizontal.pm-listitem')
            .$('div.flex-horizontal.type-chevron').$('div.type.text').getText();
    }

    getToastMessageDisplayedInLowerRightCorner ():Promise<string> {
        return $('div.md-toast-content').$('span.flex').getText();
    }

    clickDismissButton () {
        clickElement($('button[ng-click="toast.resolve()"]'));
    }

}
