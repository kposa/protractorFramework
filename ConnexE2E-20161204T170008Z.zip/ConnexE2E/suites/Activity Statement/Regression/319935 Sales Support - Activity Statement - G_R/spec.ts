/// <reference path="../../../../typings/index.d.ts" />
import stringify = QueryString.stringify;

import {NavigationsSS} from '../../../../modules/sales_support/navigations/NavigationsSS';
import {Search} from '../../../../modules/shared/Search';
import {OperationSS} from "../../../../modules/sales_support/screens/OperationSS";
import {DiscountsSS} from "../../../../modules/sales_support/screens/DiscountsSS";
import TestData319935 from './testData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
	'319935',
	'Sales Support - Activity Statement - G&R',
    UserRole.SALES_SUPPORT,
    ApplicationFeature.ACTIVITY_STATEMENT
);

describe(test.stringify, () => {
    const td = new TestData319935();
    let navSS = new NavigationsSS();
    let operationSS = new OperationSS();
    let discountSS = new DiscountsSS();
    let search = new Search();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.salesSupportUser);

            // should select an operation
            search.searchByCriteria(td.operation.name);
            search.selectRadioButton('Operations');
            search.selectSearchResult(parseInt(td.operation.id));

            // should select the Account Description
            operationSS.selectAccountDescription(td.invoice.name);

            // should select the Invoice
            operationSS.toasterMenu_selectInvoice();

            // should select [Discounts] from the hamburger
            navSS.selectItemFromHamburgerMenu('Discounts');

            // should [GrowthRetention] displays
            expect(discountSS.isGrowthDiscountDisplayed(td.discountName)).toBe(true);
            
        }, fail);
    });
});