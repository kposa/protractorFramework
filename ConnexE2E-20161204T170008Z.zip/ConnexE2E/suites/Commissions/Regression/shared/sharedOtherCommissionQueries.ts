/// <reference path="../../../../typings/index.d.ts" />

const { E2EOperationsDatabaseName } = process.env;

export interface orgUnitResults {
    salesAgencyId:string
    territory:string,
    area:string,
    cu:string,
    country:string
}

export function orgUnitFinder (salesPeriodId:number) {
    return `
    select 
        ou.OrganizationalUnitId as salesAgencyId,
        ou.ParentOrganizationalUnitId as territory, 
        oup.ParentOrganizationalUnitId as area, 
        op.parentorganizationalunitid as cu,
        p.ParentOrganizationalUnitId as country
    from ${E2EOperationsDatabaseName}.masterdata.organizationalunitparent ou
    join ${E2EOperationsDatabaseName}.masterdata.organizationalunitparent oup 
    on ou.ParentOrganizationalUnitId=oup.OrganizationalUnitId and ou.TimePeriodId=oup.TimePeriodId
    join ${E2EOperationsDatabaseName}.masterdata.organizationalunitparent op 
    on oup.ParentOrganizationalUnitId=op.OrganizationalUnitId and oup.TimePeriodId=op.TimePeriodId
    join ${E2EOperationsDatabaseName}.masterdata.organizationalunitparent p 
    on op.ParentOrganizationalUnitId=p.OrganizationalUnitId and op.TimePeriodId=p.TimePeriodId
    where ou.TimePeriodId=${salesPeriodId}
  `;
}