/// <reference path="../../../../typings/index.d.ts" />

import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import {TestData405008} from './testData';
import { itw } from '../../../../modules_v3/helpers/itw';
import ITSupportSearchPageFullView from '../../../../modules_v3/views/itSupport/ITSupportSearchPageFullView';
import { ITSupportOperationProfileToolFullView } from '../../../../modules_v3/views/itSupport/ITSupportOperationProfileToolFullView';
import { ITSupportOperationProfilePageFullView } from '../../../../modules_v3/views/itSupport/ITSupportOperationProfilePageFullView';
import { ITSupportEllipsePartialView } from '../../../../modules_v3/views/itSupport/ITSupportEllipsePartialView';

const test = new TestCase(
    '405008',
    'IT support user - Access to [Operation Profile Tool] page',
    UserRole.IT_SUPPORT,
    ApplicationFeature.OPERATION_PROFILE_TOOL
);

describe(test.stringify, () => {
    const td = new TestData405008();
    let search = new ITSupportSearchPageFullView();
    let ellipse = new ITSupportEllipsePartialView();
    let operationProfileTool = new ITSupportOperationProfileToolFullView();
    let operationProfilePage = new ITSupportOperationProfilePageFullView();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            bootstrap(td.itSupportUser);

            //search for a sales agency using the id
            search.search(td.salesAgency.id);

            //click on the agency result
            search.clickSearchResultContainingText(td.salesAgency.id);

            //select operation profile Tool link from the ellipse to navigate to the operation profile tool page
            ellipse.select('Operation Profile Tool');

            // should verify a hamburger icon displayed on Operation Profile Tool page
            expect(operationProfileTool.isHamburgerDisplayed()).toBeTruthy();

            // should verify that the text in the header contains 'Operation Profile Tool'
            expect(operationProfileTool.textOnOperationProfileToolHeader()).toContain('Operation profile tool');

            // should verify that the text in the header contains the name  of the sales Agency
            expect(operationProfileTool.textOnOperationProfileToolHeader()).toContain(td.salesAgency.name.trim());

            // should verify that headers display correctly
            expect(operationProfileTool.isOperationHeaderDisplayed()).toBeTruthy();
            expect(operationProfileTool.isPrimaryDecisionMakerHeaderDisplayed()).toBeTruthy();
            expect(operationProfileTool.isTotalCommercialAcresHeaderDisplayed()).toBeTruthy();
            expect(operationProfileTool.isLivestockHeaderDisplayed()).toBeTruthy();
            expect(operationProfileTool.isLastUpdatedHeaderDisplayed()).toBeTruthy();

            // should verify all operation names are populated
            expect(operationProfileTool.areAllOperationNamesPopulated()).toBeTruthy();

            // should verify all primary decision maker names are populated
            expect(operationProfileTool.areAllPrimaryDecisionMakerNamesPopulated()).toBeTruthy();

            // should verify all total commercial acres are populated
            expect(operationProfileTool.areAllTotalCommercialAcresPopulated()).toBeTruthy();

            // should click on the first record
            operationProfileTool.clickTheFirstOperationRow();

            //should assert on the display of the current year in the header
            expect(operationProfilePage.textOnOperationProfileHeader()).toContain(td.salesPeriod.year);

        }, fail);
    });
});