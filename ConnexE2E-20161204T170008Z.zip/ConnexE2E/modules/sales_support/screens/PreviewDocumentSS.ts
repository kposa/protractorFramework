/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import {Element} from "./../../shared/Element";
import {Helpers} from "../../shared/Helpers";

let e = new Element();
let hlp = new Helpers();
let emailIcon = $('i[ng-click="vm.showEmail()"]');
let sendButtonEnabled = $('button.pm-flat-button.primary');
let dialogBox = $('div.pm-expand.pm-vertical.email-entry-area');

export class PreviewDocumentSS {
    private messageSection = $('section.pm-expand.pm-text');
    private messageLabel = this.messageSection.$('div.pm-text-label');
    public isEmailIconDisplayed():Promise<boolean> {
        return emailIcon.isDisplayed();
    }

    public clickEmailIcon():void {
        e.clickElement(emailIcon);
    }

    public isPrintIconDisplayed():Promise<boolean> {
        let printIcon = $('i[ng-click="vm.printDocument()"]');
        return printIcon.isDisplayed();
    }

    public isEmailIconDialogBoxDisplayed():Promise<boolean> {
        return dialogBox.isDisplayed();
    }

    public isEmailIconDialogClosed():Promise<boolean> {
        return dialogBox.isDisplayed();
    }

    public isAddRecipientsDialogBoxDisplayed():Promise<boolean> {
        let addAdditionalRecipientsDisplay = $('div.entry-area-item-label.ng-binding').element(by.xpath('..'));
        let dialogFormDisplay = addAdditionalRecipientsDisplay.$('textarea[ng-model="vm.emailsEntered"]');
        return dialogFormDisplay.isDisplayed();
    }

   /* public isSendButtonInactive():Promise<boolean> { //TODO if test case needs it
        let sendButtonDisabled = $('button.pm-flat-button.disabled');
        return sendButtonDisabled.isDisplayed();
    }*/

    public isSendButtonEnabled():Promise<boolean> {
        return sendButtonEnabled.isDisplayed();
    }

    public clickSendButton():void {
        e.clickElement(sendButtonEnabled);
    }

    public verifyMessageLabel(): Promise<String>{
        return this.messageLabel.getText();
    }

    public enterValueInStandardDisclaimerDialog(text:string):void {
        e.clickElement(this.messageLabel);
        let standardDisclaimerDialog = this.messageSection.$('textarea[ng-model="vm.value"]');
        standardDisclaimerDialog.sendKeys(text);
    }

    public urlOfTheCurrentPage() {
        return browser.getCurrentUrl();
    }


}