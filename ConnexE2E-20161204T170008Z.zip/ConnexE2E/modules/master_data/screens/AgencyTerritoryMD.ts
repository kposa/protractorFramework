/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';
import {
    filterElements, isActive, containingText,
    matchingAttributeValue
} from '../../../modules_v3/helpers/filterElementHelpers';
import { aria_disabled } from '../../../modules_v3/helpers/utilityElementHelpers';

export class AgencyTerritoryMD {

    private territoryLayoutParent = $('div.ng-scope.layout-column.flex');
    private territoryDropdown = $('md-select[name="territory"]');
    private salesPeriodDropdown = $('md-select[name="salesPeriod"]');

    get verifyTerritoryPageDisplayed ():Promise<string> {
        return this.territoryLayoutParent.getText();
    }

    public selectSalesPeriodFromDropdown (sp:string):void {
        let dropdownOption = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(sp)
            ]
        )().first();
        clickElement(this.salesPeriodDropdown);
        clickElement(dropdownOption);
    }

    public selectTerritoryFromDropdown ():void {
        let firstDropdownOption = $('md-option[value="ADL"]');
        clickElement(this.territoryDropdown);
        clickElement(firstDropdownOption);
    }

    public updateSalesPeriod ():void {
        let secondOption = $('md-option[value="20"]');
        clickElement(this.salesPeriodDropdown);
        clickElement(secondOption);
    }

    public updateTerritory ():void {
        let secondDropdownOption = $('md-option[value="ADM"]');
        clickElement(this.territoryDropdown);
        clickElement(secondDropdownOption);
    }

    public areAllTerritoryDropdownsDisabled ():Promise<boolean> {
        return filterElements($$('md-select[name="territory"]'), [
            isActive(true),
            matchingAttributeValue({ attribute: aria_disabled, value: 'false' })
        ])().count().then(c => c == 0);
    }
}