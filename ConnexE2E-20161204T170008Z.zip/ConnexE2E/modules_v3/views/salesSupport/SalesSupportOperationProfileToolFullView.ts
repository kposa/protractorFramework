/// <reference path='../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';
import { NotImplementedError } from '../../../common/exception/Exceptions';
import { IView } from '../../interfaces/common/IView';

export class SalesSupportOperationProfileToolFullView implements IView {

    private eachOperation = $$('button[ng-click="vm.selectOperation(operation.operationId)"]');
    private tableHeaders = $('md-list.header-row');

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    public isHamburgerDisplayed ():Promise<boolean> {
        let operationProfileToolHamburger = $('button[aria-label="Menu"]');
        return isPresentAndDisplayed(operationProfileToolHamburger);
    }

    public textOnOperationProfileToolHeader ():Promise<string> {
        return $('md-toolbar.md-toolbar-tools').getText();
    }

    public isOperationHeaderDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed(this.tableHeaders.$('span[at="operation-name"]'));
    }

    public isPrimaryDecisionMakerHeaderDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed(this.tableHeaders.$('span[at="primary-decision-maker"]'));
    }

    public isTotalCommercialAcresHeaderDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed(this.tableHeaders.$('div.right-column'));
    }

    public isLivestockHeaderDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('div.header-column.livestock-column'));
    }

    public isLastUpdatedHeaderDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('div.lastOccurredOn-column.header-column'));
    }

    public areAllOperationNamesPopulated ():Promise<boolean> {
        let operationNames = $$('div[at="operation-name"]');
        let operationNamesText:boolean = true;
        return browser.controlFlow().execute(() => {
            operationNames.each((elem) => {
                elem.getText().then((displayedText) => {
                    if (displayedText == "") {
                        operationNamesText = false;
                    }
                });
            });
        }).then(() => {
            return operationNamesText;
        });
    }

    public areAllPrimaryDecisionMakerNamesPopulated ():Promise<boolean> {
        let primaryDecisionMakerNames = $$('div[at="primary-decision-maker"]');
        let primaryDecisionMakerText:boolean = true;
        return browser.controlFlow().execute(() => {
            primaryDecisionMakerNames.each((elem) => {
                elem.getText().then((displayedText) => {
                    if (displayedText == "") {
                        primaryDecisionMakerText = false;
                    }
                });
            });
        }).then(() => {
            return primaryDecisionMakerText;
        });
    }

    public areAllTotalCommercialAcresPopulated ():Promise<boolean> {
        let totalCommercialAcres = this.eachOperation.$$('div.right-column');
        let textInOperationNames:boolean = true;
        return browser.controlFlow().execute(() => {
            totalCommercialAcres.each((elem) => {
                elem.getText().then((displayedText) => {
                    if (displayedText == "") {
                        textInOperationNames = false;
                    }
                });
            });
        }).then(() => {
            return textInOperationNames;
        });
    }

    public clickTheFirstOperationRow ():void {
        let firstRecord = this.eachOperation.first();
        clickElement(firstRecord);
    }
}
