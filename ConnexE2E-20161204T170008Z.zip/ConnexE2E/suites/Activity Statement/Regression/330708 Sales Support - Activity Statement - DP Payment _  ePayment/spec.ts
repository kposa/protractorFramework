/// <reference path="../../../../typings/index.d.ts" />

import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { TestData330708 } from './testData';
import { signAgreements } from '../../../SharedSteps/Sales Rep/signAgreements';
import {
    createAccountDescription,
    AccountDescriptionShare
} from '../../../SharedSteps/Sales Rep/createAccountDescription';
import { SalesRepOperationsFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationsFullView';
import { SalesRepInvoiceFullView } from '../../../../modules_v3/views/salesRep/SalesRepInvoiceFullView';
import { SalesSupportMasterSearchFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportMasterSearchFullView';
import SalesSupportNavigationMenuPartialView from '../../../../modules_v3/views/salesSupport/SalesSupportNavigationMenuPartialView';
import { SalesSupportActivityStatementPageFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportActivityStatementPageFullView';
import { itw } from '../../../../modules_v3/helpers/itw';
import { SalesRepInvoiceAddLineItemDrawerPartialView } from '../../../../modules_v3/views/salesRep/SalesRepInvoiceAddLineItemDrawerPartialView';
import { SalesRepEllipsePartialView } from '../../../../modules_v3/views/salesRep/SalesRepEllipsePartialView';
import { SalesRepBusinessPartnersFullView } from '../../../../modules_v3/views/salesRep/SalesRepBusinessPartnersFullView';
import { SalesSupportCustomersPageFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportCustomersPageFullView';
import { SalesSupportEPaymentFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportEPaymentFullView';
import SalesSupportOperationBalancesFullView from '../../../../modules_v3/views/salesSupport/SalesSupportOperationBalancesFullView';
import { SalesRepOperationFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationFullView';
import { SalesRepDeferredPaymentsFullView } from '../../../../modules_v3/views/salesRep/SalesRepDeferredPaymentsFullView';
import { SalesRepBusinessPartnerBalancesFullView } from '../../../../modules_v3/views/salesRep/SalesRepBusinessPartnerBalancesFullView';
import { getNegativeOrPositiveCurrencyString } from '../../../../modules_v3/helpers/utilityHelpers';

const test = new TestCase(
    '330708',
    'Sales Support - Activity Statement - DP Payment & ePayment',
    UserRole.SALES_SUPPORT,
    ApplicationFeature.ACTIVITY_STATEMENT
);

describe(test.stringify, () => {
    const td = new TestData330708();
    let salesRepOperationsFullView = new SalesRepOperationsFullView();
    let salesRepInvoiceFullView = new SalesRepInvoiceFullView();
    let salesSupportMasterSearchFullView = new SalesSupportMasterSearchFullView();
    let salesRepEllipsePartialView = new SalesRepEllipsePartialView();
    let salesRepOperationFullView = new SalesRepOperationFullView();
    let salesSupportNavigationMenuPartialView = new SalesSupportNavigationMenuPartialView();
    let salesSupportActivityStatementPageFullView = new SalesSupportActivityStatementPageFullView();
    let salesRepInvoiceAddLineItemDrawerPartialView = new SalesRepInvoiceAddLineItemDrawerPartialView();
    let salesRepBusinessPartnersFullView = new SalesRepBusinessPartnersFullView();
    let salesRepBusinessPartnerBalancesFullView = new SalesRepBusinessPartnerBalancesFullView();
    let salesRepDeferredPaymentsFullView = new SalesRepDeferredPaymentsFullView();
    let salesSupportCustomersPageFullView = new SalesSupportCustomersPageFullView();
    let salesSupportEPaymentFullView = new SalesSupportEPaymentFullView();
    let salesSupportOperationBalancesFullView = new SalesSupportOperationBalancesFullView();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.salesRepUser);

            //should search an operation
            salesRepOperationsFullView.search(td.operation.id);

            //should select an operation
            salesRepOperationsFullView.clickSearchResultMatchingText(td.operations[ 0 ].name);

            // should create a new account description
            createAccountDescription({
                salesPeriod: td.salesPeriod.id,
                shares: [ new AccountDescriptionShare(td.businessPartner, '100') ]
            }, td);

            //should sign agreements
            signAgreements({ businessPartners: td.businessPartners });

            //should click Invoice
            browser.controlFlow().execute(()=> {
                salesRepOperationFullView.clickInvoiceButton(td.invoices[ 0 ].name);
            });

            //should add line item
            salesRepInvoiceFullView.addLineItem(td.productLine1);
            salesRepInvoiceAddLineItemDrawerPartialView.selectFirstProduct();
            salesRepInvoiceAddLineItemDrawerPartialView.selectFirstSubProduct();
            salesRepInvoiceAddLineItemDrawerPartialView.fillInputUnits('50');
            salesRepInvoiceAddLineItemDrawerPartialView.close();

            //should add another line item
            salesRepInvoiceFullView.addLineItem(td.productLine2);
            salesRepInvoiceAddLineItemDrawerPartialView.selectFirstProduct();
            salesRepInvoiceAddLineItemDrawerPartialView.selectFirstSubProduct();
            salesRepInvoiceAddLineItemDrawerPartialView.fillInputUnits('50');
            salesRepInvoiceAddLineItemDrawerPartialView.close();

            //should open ellipsis menua and select business partner
            salesRepEllipsePartialView.select('business partners');

            //should click the balance button by customer name
            salesRepBusinessPartnersFullView.clickBalancesButtonByName(td.businessPartners[ 0 ].name);

            //should verify business partner balances page displayed
            expect(salesRepBusinessPartnerBalancesFullView.isViewDisplayed()).toBeTruthy();

            //should open ellipsis emnu and select deferred payment
            salesRepEllipsePartialView.select('deferred payment');

            //should verify deferred payments page displayed
            expect(salesRepDeferredPaymentsFullView.isViewDisplayed()).toBeTruthy();

            //should store invoice balance in testdata file
            browser.controlFlow().execute(()=>{
                salesRepDeferredPaymentsFullView.getInvoiceBalance(td.invoices[ 0 ].name).then((val)=>{
                    td.invoiceBalance = val;
                });
            });

            //should click [Pay All]
            salesRepDeferredPaymentsFullView.clickPayAllButton();

            //should click [Finish]
            salesRepDeferredPaymentsFullView.clickFinishButton();
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.salesSupportUser);

            // should search operation
            salesSupportMasterSearchFullView.search(td.operations[ 0 ].id);
            salesSupportMasterSearchFullView.selectFilterContainingText('Operations');
            salesSupportMasterSearchFullView.clickSearchResultContainingText(td.operations[ 0 ].name);

            //should access the [Business partner] screen
            salesSupportNavigationMenuPartialView.openMenu();
            salesSupportNavigationMenuPartialView.selectMenuItemContainingText('Business partners');

            //should click customer line
            salesSupportCustomersPageFullView.clickCustomerLine(td.businessPartners[ 0 ].name);

            //should click the [Hamburger] menu and select [Epayments]
            salesSupportNavigationMenuPartialView.openMenu();
            salesSupportNavigationMenuPartialView.selectMenuItemContainingText('Epayments');

            //should enter amount in the [$Payment] field
            browser.controlFlow().execute(()=> {
                salesSupportEPaymentFullView.enterAmountInPaymentField(td.amount.replace(/[^0-9.]/g, ''), td.invoices[ 0 ].name);
            });

            //should click [CONTINUE]
            salesSupportEPaymentFullView.clickContinueButton();

            //should enter the [Routing number]
            salesSupportEPaymentFullView.paymentInformationSectionUS.enterRoutingNumber(td.routingNum);

            //should enter identical account numbers in the [Account number] and [Confirm account number] fields
            salesSupportEPaymentFullView.paymentInformationSectionUS.enterAccountNumber(td.accountNum);
            salesSupportEPaymentFullView.paymentInformationSectionUS.confirmAccountNumber(td.confirmAccountNum);

            //should enter the [Confirmation email]
            salesSupportEPaymentFullView.paymentInformationSectionUS.enterConfirmationEmail(td.customerEmail);

            //should click [ACCEPT]
            salesSupportEPaymentFullView.paymentInformationSectionUS.clickAcceptButton();

            //should open hamburger menu and click [Balances]
            salesSupportNavigationMenuPartialView.openMenu();
            salesSupportNavigationMenuPartialView.selectMenuItemContainingText('Balances');

            //should go to activity statement page
            browser.controlFlow().execute(()=> {
                salesSupportOperationBalancesFullView.clickInvoiceByNameAndSalesPeriod(td.invoices[ 0 ].name, td.salesPeriod.name);
            });

            // should display names of the payment types and the total amount for each payment type
            expect(salesSupportActivityStatementPageFullView.getTransactionTypeTextByTransactionType('Deferred'))
                .toContain('Payment - Deferred Payment');
            expect(salesSupportActivityStatementPageFullView.getTransactionTypeTextByTransactionType('ePayment'))
                .toContain('Payment - ePayment');
            browser.controlFlow().execute(()=>{
                expect(salesSupportActivityStatementPageFullView.getTransactionTypeAmmountByTransactionType('Deferred'))
                    .toContain(td.invoiceBalance);
            });
            expect(salesSupportActivityStatementPageFullView.getTransactionTypeAmmountByTransactionType('ePayment'))
                .toContain(td.amount);

            //should verify toast message and click [DISMISS]
            expect(salesSupportActivityStatementPageFullView.getToastMessageDisplayedInLowerRightCorner())
                .toContain('This customer has unprocessed payments or refunds');
            salesSupportActivityStatementPageFullView.clickDismissButton();

        }, fail);
    });
});