/// <reference path="../../../../typings/index.d.ts" />
import Promise = protractor.promise.Promise;

import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';
import { ITSupportWithPioneerBalanceNonZeroPriorSalesPeriod, ITSupportWithPioneerBalanceNonZeroPriorSalesPeriodResults  } from './queries';

export default class TestData349487 extends BaseTestData {
    public netInvoice: string;
    public netPayments: string;
    public netPending: string;
    public pioneerBalance: string;
    public salesPeriodYear:string;
    public salesPeriodSeason :string;
    
    protected queries: (() => Promise<any>)[] = [
        this.getITSupportWithPioneerBalanceNonZeroPriorSalesPeriod()
    ];

    private getITSupportWithPioneerBalanceNonZeroPriorSalesPeriod (): () => Promise<ITSupportWithPioneerBalanceNonZeroPriorSalesPeriodResults> {
        return () => {
            const sql = ITSupportWithPioneerBalanceNonZeroPriorSalesPeriod();
            const results = this.queryService.executeSql<ITSupportWithPioneerBalanceNonZeroPriorSalesPeriodResults[]>(sql);

            return results
                .then(data => {
                    const row = <ITSupportWithPioneerBalanceNonZeroPriorSalesPeriodResults>getRandomQueryResult(data);

                    this.salesRepresentatives.push({
                        id: row.salesRepId,
                        name: row.salesRepName
                    });

                    this.operations.push({
                        id: row.operationId,
                        name: row.operationName
                    });

                    this.invoices.push({
                        id: row.invoiceId,
                        name: row.invoiceName
                    });
                    
                    this.salesAgencies.push({
                        id: row.salesAgencyId,
                        name: row.salesAgencyName
                    });

                    this.businessPartners.push({
                        id:row.businessPartnerId,
                        name: row.businessPartnerName
                    });
                    
                    this.salesPeriodYear = row.salesPeriodYear;
                    this.salesPeriodSeason = row.salesPeriodSeason;
                    this.netInvoice = row.netInvoice.toString();
                    this.netPayments = row.netPayments.toString();
                    this.netPending = row.netPending.toString();
                    this.pioneerBalance = row.pioneerBalance.toString();

                    return row;
                });
        };
    }
}










