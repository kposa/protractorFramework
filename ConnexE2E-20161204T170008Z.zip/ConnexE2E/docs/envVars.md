# [Connex E2E Documentation](/)

## Environmental Variables

| Name                          | tx                             | stagin                               | Description |
|:------------------------------|:-------------------------------|:-------------------------------------|:------------|
| `E2EGridIsEnabled`            | `false`                        | `false`                              | If the selenium grid should be used during tests
| `E2EBaseUrl`                  | `https://salestx.pioneer.com/` | `https://salesstagingtx.pioneer.com` | Connex URL to use during tests
| `E2ELocale`                   | `en-us`                        | `en-us`                              | Locale used by Chrome during tests 
| `E2EUsername`                 | `tfstctrl`                     | `tfstctrl`                           | Username used to log into Connex
| `E2EPassword`                 | `6T5RdfEr4#$#eM`               | `6T5RdfEr4#$#eM`                     | Password used to log into Connex
| `E2EDefaultSalesPeriodId`     | `21`                           | `21`                                 | Default sales period id to use during tests 
| `E2EDefaultSalesPeriodYear`   | `2017`                         | `2017`                               | Default sales period year to use during tests
| `E2EDefaultSalesPeriodSeason` | `Spring`                       | `Spring`                             | Default sales period season to use during tests
| `E2EDefaultSalesPeriodName`   | `2017 Spring`                  | `2017 Spring`                        | Default sales period name to use during tests
| `E2EAccountingDatabaseName`   | `accounting`                   | `accountingdemo`                     | Accounting database name
| `E2EInvoicesDatabaseName`     | `invoices`                     | `invoicesdemo`                       | Invoices database name
| `E2EOperationsDatabaseName`   | `operations`                   | `operationsdemo`                     | Operations database name
| `E2EPaymentsDatabaseName`     | `payments`                     | `paymentsdemo`                       | Payments database name
| `E2EReportingDatabaseName`    | `FieldSales_Reporting`         | `FieldSales_ReportingDemo`           | Reporting database name
| `E2EAccountingDBConnection`
| `E2EInvoicesDBConnection`
| `E2EOperationsDBConnection`
| `E2EPaymentsDBConnection`
| `E2EReportingDBConnection`

### Configuration

See [Configuration#EnvironmentalVariables](/configuration.html#environmentalvariables)