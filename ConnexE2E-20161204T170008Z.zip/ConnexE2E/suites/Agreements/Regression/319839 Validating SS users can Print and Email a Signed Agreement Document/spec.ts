/// <reference path="../../../../typings/index.d.ts" />

import {Search} from "../../../../modules/shared/Search";
import {AgreementsSS} from "../../../../modules/sales_support/screens/AgreementsSS";
import {NavigationsSS} from '../../../../modules/sales_support/navigations/NavigationsSS';
import {PreviewDocumentSS} from "../../../../modules/sales_support/screens/PreviewDocumentSS";
import TestData319839 from './testData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
	'319839',
	'Validating SS users can Print and Email a Signed Agreement Document',
	UserRole.SALES_SUPPORT,
	ApplicationFeature.AGREEMENTS
);

describe(test.stringify, () => {
    const td = new TestData319839();
    let search = new Search();
    let ag = new AgreementsSS();
    let nav = new NavigationsSS();
    let pd = new PreviewDocumentSS();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.salesSupportUser);

            // should select a business partner who has a signed agreement
            search.searchByCriteria(td.businessPartner.id);
            search.selectRadioButton('Business partners');
            search.selectSearchResult(parseInt(td.businessPartner.id));

            // should select agreements from the hamburger and verify if user is on Agreements page
            nav.selectItemFromHamburgerMenu('Agreements');
            expect(ag.urlOfTheCurrentPage()).toContain('agreements');

            // should assert on the display of [Agreements> Business partner name] in the header
            expect(ag.verifyHeader()).toEqual('Agreements > ' + td.businessPartner.name);

            // should verify if the signed agreement displays under signed section
            expect(ag.verifyIfAgreementIsUnderSigned()).toEqual('Signed');

            // should click on the eyeball icon for the signed agreement and verify if user lands on[Preview Agreements]
            ag.clickOnEyeballForSignedTechAgreement();
            expect(pd.urlOfTheCurrentPage()).toContain('documents');

            // should assert on the display of [Email] and [Print] icons on the [Preview Agreement] page
            expect(pd.isEmailIconDisplayed()).toBeTruthy();
            expect(pd.isPrintIconDisplayed()).toBeTruthy();

            // should assert on the display of dialog box when you click on [Email] Icon
            pd.clickEmailIcon();
            expect(pd.isEmailIconDialogBoxDisplayed()).toBeTruthy();

            // should assert on the display of Message label
            expect(pd.verifyMessageLabel()).toEqual('Message');

            // should assert on [send] button being enabled when you enter text in the standard disclaimer dialog box
            pd.enterValueInStandardDisclaimerDialog('Including this message to verify that the send button is not disabled');
            expect(pd.isSendButtonEnabled()).toBeTruthy();

            // should assert on clicking [send] button
            pd.clickSendButton();

            // should assert on closing of email dialog box on Preview Document when you click on [send] button
            expect(pd.isEmailIconDialogBoxDisplayed()).toBeFalsy();
        }, fail);
    });
});