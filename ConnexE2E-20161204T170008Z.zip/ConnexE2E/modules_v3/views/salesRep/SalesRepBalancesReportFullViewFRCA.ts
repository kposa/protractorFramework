/// <reference path='../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import {
    getNegativeOrPositiveCurrencyStringInFrench,
    salesPeriodSeasonToFrench, getBalanceReportsRow
} from "../../helpers/utilityHelpers";
import SalesRepBalancesReportFullView from './SalesRepBalancesReportFullView';
export default class SalesRepBalancesReportFullViewFRCA extends SalesRepBalancesReportFullView {

    netInvoiceValueDisplayed (operation:string, invoice:string, businessPartner:string, salesPeriodYear:string, salesPeriodSeason:string):Promise<string> {
        salesPeriodSeason = salesPeriodSeasonToFrench(salesPeriodSeason);
        let salesPeriod = salesPeriodYear + salesPeriodSeason;
        return getBalanceReportsRow(operation, invoice, businessPartner, salesPeriod).$('td[at="net-invoice-value"]').getText().then(function (price) {
            return getNegativeOrPositiveCurrencyStringInFrench(price);
        });
    }

    netPaymentsDisplayed (operation:string, invoice:string, businessPartner:string, salesPeriodYear:string, salesPeriodSeason:string):Promise<string> {
        salesPeriodSeason = salesPeriodSeasonToFrench(salesPeriodSeason);
        let salesPeriod = salesPeriodYear + salesPeriodSeason;
        return getBalanceReportsRow(operation, invoice, businessPartner, salesPeriod).$('td[at="net-payments"]').getText().then(function (price) {
            return getNegativeOrPositiveCurrencyStringInFrench(price);
        });
    }

    netPendingPaymentsDisplayed (operation:string, invoice:string, businessPartner:string, salesPeriodYear:string, salesPeriodSeason:string):Promise<string> {
        salesPeriodSeason = salesPeriodSeasonToFrench(salesPeriodSeason);
        let salesPeriod = salesPeriodYear + salesPeriodSeason;
        return getBalanceReportsRow(operation, invoice, businessPartner, salesPeriod).$('td[at="net-pending-payments"]').getText().then(function (price) {
            return getNegativeOrPositiveCurrencyStringInFrench(price);
        });
    }

    pioneerBalanceDisplayed (operation:string, invoice:string, businessPartner:string, salesPeriodYear:string, salesPeriodSeason:string):Promise<string> {
        salesPeriodSeason = salesPeriodSeasonToFrench(salesPeriodSeason);
        let salesPeriod = salesPeriodYear + salesPeriodSeason;
        return getBalanceReportsRow(operation, invoice, businessPartner, salesPeriod).$('td[at="pioneer-balance"]').getText().then(function (price) {
            return getNegativeOrPositiveCurrencyStringInFrench(price);
        });
    }
}
