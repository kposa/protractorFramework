/// <reference path="../../../../typings/index.d.ts" />

import { SearchMD2 } from "../../../../modules/master_data/screens/SearchMD2";
import { AgencyMD } from "../../../../modules/master_data/screens/AgencyMD";
import { bootstrap } from "../../../SharedSteps/bootstrap";
import { itw } from '../../../../modules_v3/helpers/itw';
import { AgencyGeneralMD } from '../../../../modules/master_data/screens/AgencyGeneralMD';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import TestDataForEncircaServicesCheckbox from './testData';

const test = new TestCase(
	'339411.2',
	'Add Sales Agency - Check Encirca Services Checkbox for Certified Sales Agent',
	UserRole.MASTER_DATA,
	ApplicationFeature.AGENCIES
);

describe(test.stringify, () => {
    const td = new TestDataForEncircaServicesCheckbox();
    let searchMD = new SearchMD2();
    let agencyMD = new AgencyMD();
    let agencyGeneralMD = new AgencyGeneralMD();

    itw(test.description, () => {
        td.populatePromise().then(() => {

            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.masterDataUser);

            //should select sales agency
            searchMD.searchByCriteria(td.agencyId);
            searchMD.selectSearchResultByResultType('Sales agency');

            //should select territory card
            agencyMD.selectGeneralCard();

            //should verify [Territory] drop down and [Trash] buttons are disabled for an active agency
            expect(agencyGeneralMD.isCheckboxChecked('Encirca Services')).toBeTruthy();
            expect(agencyGeneralMD.isCheckboxDisabled('Encirca Services')).toBeTruthy();

        }, fail);
    });
});

// For the certified sales agent it checks if Encirca Services Checkbox is checked/disabled