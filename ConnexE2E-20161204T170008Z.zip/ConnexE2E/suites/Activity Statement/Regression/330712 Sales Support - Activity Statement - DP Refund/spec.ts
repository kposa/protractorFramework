/// <reference path="../../../../typings/index.d.ts" />

import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { TestData330712 } from './testData';
import { signAgreements } from '../../../SharedSteps/Sales Rep/signAgreements';
import {
    createAccountDescription,
    AccountDescriptionShare
} from '../../../SharedSteps/Sales Rep/createAccountDescription';
import { SalesRepOperationsFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationsFullView';
import { SalesRepInvoiceFullView } from '../../../../modules_v3/views/salesRep/SalesRepInvoiceFullView';
import { SalesSupportMasterSearchFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportMasterSearchFullView';
import SalesSupportNavigationMenuPartialView from '../../../../modules_v3/views/salesSupport/SalesSupportNavigationMenuPartialView';
import { SalesSupportActivityStatementPageFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportActivityStatementPageFullView';
import { itw } from '../../../../modules_v3/helpers/itw';
import { SalesRepInvoiceAddLineItemDrawerPartialView } from '../../../../modules_v3/views/salesRep/SalesRepInvoiceAddLineItemDrawerPartialView';
import { SalesRepEllipsePartialView } from '../../../../modules_v3/views/salesRep/SalesRepEllipsePartialView';
import { SalesRepBusinessPartnersFullView } from '../../../../modules_v3/views/salesRep/SalesRepBusinessPartnersFullView';
import { SalesRepOperationFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationFullView';
import { SalesRepRefundsFullView } from '../../../../modules_v3/views/salesRep/SalesRepRefundsFullView';
import { SalesSupportOperationFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportOperationFullView';
import { SalesRepDeferredPaymentsFullView } from '../../../../modules_v3/views/salesRep/SalesRepDeferredPaymentsFullView';
import { SalesRepBusinessPartnerBalancesFullView } from '../../../../modules_v3/views/salesRep/SalesRepBusinessPartnerBalancesFullView';

const test = new TestCase(
    '330712',
    'Sales Support - Activity Statement - DP Refund',
    UserRole.SALES_SUPPORT,
    ApplicationFeature.ACTIVITY_STATEMENT
);

describe(test.stringify, () => {
    const td = new TestData330712();
    let salesRepOperationsFullView = new SalesRepOperationsFullView();
    let salesRepInvoiceFullView = new SalesRepInvoiceFullView();
    let salesSupportMasterSearchFullView = new SalesSupportMasterSearchFullView();
    let salesRepEllipsePartialView = new SalesRepEllipsePartialView();
    let salesRepOperationFullView = new SalesRepOperationFullView();
    let salesSupportNavigationMenuPartialView = new SalesSupportNavigationMenuPartialView();
    let salesSupportActivityStatementPageFullView = new SalesSupportActivityStatementPageFullView();
    let salesRepInvoiceAddLineItemDrawerPartialView = new SalesRepInvoiceAddLineItemDrawerPartialView();
    let salesRepBusinessPartnersFullView = new SalesRepBusinessPartnersFullView();
    let salesRepBusinessPartnerBalancesFullView = new SalesRepBusinessPartnerBalancesFullView();
    let salesRepDeferredPaymentsFullView = new SalesRepDeferredPaymentsFullView();
    let salesRepRefundsFullView = new SalesRepRefundsFullView();
    let salesSupportOperationFullView = new SalesSupportOperationFullView();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.salesRepUser);

            //should search an operation
            salesRepOperationsFullView.search(td.operation.id);

            //should select an operation
            salesRepOperationsFullView.clickSearchResultMatchingText(td.operations[ 0 ].name);

            // should create a new account description
            createAccountDescription({
                salesPeriod: td.salesPeriod.id,
                shares: [ new AccountDescriptionShare(td.businessPartner, '100') ]
            }, td);

            //should sign agreements
            signAgreements({ businessPartners: td.businessPartners });

            //should click Invoice
            browser.controlFlow().execute(()=> {
                salesRepOperationFullView.clickInvoiceButton(td.invoices[ 0 ].name);
            });

            //should add line item
            salesRepInvoiceFullView.addLineItem(td.productLine1);
            salesRepInvoiceAddLineItemDrawerPartialView.selectFirstProduct();
            salesRepInvoiceAddLineItemDrawerPartialView.selectFirstSubProduct();
            salesRepInvoiceAddLineItemDrawerPartialView.fillInputUnits('20');
            salesRepInvoiceAddLineItemDrawerPartialView.close();

            //should add another line item
            salesRepInvoiceFullView.addLineItem(td.productLine2);
            salesRepInvoiceAddLineItemDrawerPartialView.selectFirstProduct();
            salesRepInvoiceAddLineItemDrawerPartialView.selectFirstSubProduct();
            salesRepInvoiceAddLineItemDrawerPartialView.fillInputUnits('20');
            salesRepInvoiceAddLineItemDrawerPartialView.close();

            //should open ellipsis menua and select business partner
            salesRepEllipsePartialView.select('business partners');

            //should click the balance button by customer name
            salesRepBusinessPartnersFullView.clickBalancesButtonByName(td.businessPartners[ 0 ].name);

            //should verify business partner balances page displayed
            expect(salesRepBusinessPartnerBalancesFullView.isViewDisplayed()).toBeTruthy();

            //should open ellipsis menu and select deferred payment
            salesRepEllipsePartialView.select('deferred payment');

            //should verify deferred payments page displayed
            expect(salesRepDeferredPaymentsFullView.isViewDisplayed()).toBeTruthy();

            //should enter amount
            browser.controlFlow().execute(()=> {
                salesRepDeferredPaymentsFullView.enterAmountInPaymentField(td.amount, td.invoices[ 0 ].name);
            });

            //should close keypad drawer
            salesRepDeferredPaymentsFullView.paymentKeypadSection.close();

            //should click [Finish]
            salesRepDeferredPaymentsFullView.clickFinishButton();

            //should return to the [balances] screen
            salesRepDeferredPaymentsFullView.clickBack();

            //Should click the [ellipse] menu in the upper-right and select [$ refunds]
            salesRepEllipsePartialView.select('refunds');

            //should verify that sales rep refunds page displayed
            expect(salesRepRefundsFullView.isViewDisplayed()).toBeTruthy();

            //should enter the refund amount
            browser.controlFlow().execute(()=> {
                salesRepRefundsFullView.enterAmountInPaymentField(td.refundAmount1, td.invoices[ 0 ].name);
            });

            //should close keypad drawer
            salesRepRefundsFullView.paymentKeypadSection.close();

            //should click [Issue Refund]
            salesRepRefundsFullView.clickIssueRefund();

            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.salesSupportUser);

            // should search operation
            salesSupportMasterSearchFullView.search(td.operations[ 0 ].id);
            salesSupportMasterSearchFullView.selectFilterContainingText('Operations');
            salesSupportMasterSearchFullView.clickSearchResultContainingText(td.operations[ 0 ].name);

            //should go to activity statement page
            browser.controlFlow().execute(()=> {
                salesSupportOperationFullView.selectAccountDescription(td.invoices[ 0 ].name);
            });

            //should click on invoice on the toster menu
            salesSupportOperationFullView.toasterMenu.selectMenuItemContainingText('Invoice');

            //should open hamburger menu
            salesSupportNavigationMenuPartialView.openMenu();

            //should go to activity statement page
            salesSupportNavigationMenuPartialView.selectMenuItemContainingText('Activity statement');

            // should verify the name of the refund type and the total amount for the refund
            expect(salesSupportActivityStatementPageFullView.getTransactionTypeTextByTransactionType('Refund')).toContain('Refund - Deferred Payment');
            expect(salesSupportActivityStatementPageFullView.getTransactionTypeAmmountByTransactionType('Refund')).toContain(td.refundAmount2);

            //should verify toast message and click [DISMISS]
            expect(salesSupportActivityStatementPageFullView.getToastMessageDisplayedInLowerRightCorner())
                .toContain('This customer has unprocessed payments or refunds');
            salesSupportActivityStatementPageFullView.clickDismissButton();

        }, fail);
    });
});