/// <reference path="../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import Promise = webdriver.promise.Promise;
import {Element} from "../../shared/Element";
import {MaterialDesignElement} from "../../shared/MaterialDesignElement";

let e = new Element();
let md = new MaterialDesignElement();

export class DrawerSS {

    private defaultCloseButton = $('[at="close-drawer"]');

    /**
     * A generic function to select a list item from most drawers
     * @param parent - usually the section name of the current drawer
     * @param menuItemName [optional] - the primary text for a list item
     * @param listIndex [optional]
     * @param selectDifferentFromPrevious [optional] - chooses any list item WITHOUT the '.current' class
     */
    public selectListItem(parent:ElementFinder, menuItemName?:string, listIndex?:number, selectDifferentFromPrevious?:boolean) {
        if (typeof listIndex === 'undefined') listIndex = 0;

        let allListItemNames = parent.$$('.pm-listitem');
        let listItem = allListItemNames.filter(function (elem) {
            return elem.getAttribute('class').then(function (pm_listitem_classes:string) {
                return elem.$('div.pm-listitem-primary').getText().then(function (displayedMenuItemTitle:string) {
                    if (selectDifferentFromPrevious) return !~pm_listitem_classes.indexOf('current');
                    else if (menuItemName) return displayedMenuItemTitle === menuItemName;
                    return true;
                });
            });
        }).get(listIndex);
        e.clickElement(listItem);
    }

    public enterUnits(parent:ElementFinder, units:string) {
        let keypadDigit: ElementFinder;
        units.split('').forEach(function (digit) {
            keypadDigit = parent.element(by.cssContainingText('[ng-click*=addDigit]', digit));
            e.clickElement(keypadDigit);
        });
    }

    public getDisplayValueText(parent:ElementFinder):Promise<string> {
        return md.getDisplayValue(parent).getText();
    }

    public close(closeButton?:ElementFinder) {
        if (!closeButton) closeButton = this.defaultCloseButton;
        e.clickElement(closeButton);
    }

    public holdToDelete(elem:ElementFinder) {
        browser.actions().mouseDown(elem.getWebElement()).perform();
        browser.wait(function () {
            var deferred = protractor.promise.defer();
            elem.isDisplayed().then(function (isDisplayed) {
                deferred.fulfill(!isDisplayed);
            });
            return deferred.promise;
        });
        browser.actions().mouseUp().perform();
    }

    public enterUnitsInBlackDrawerKeypad(units:string, alreadyFoundParent?:any):void {
        let self = this;
        browser.controlFlow().execute(function () {

            var enterUnits = function (keyPadSection: any) {

                var allNumbersInKeypad = keyPadSection.$$('[ng-click*=addDigit]');  //any element that contains addDigit in the ng-click attribute
                allNumbersInKeypad.each(function (elemInKeypad: ElementFinder, i: number) {
                    elemInKeypad.getText().then(function (txt: string) {
                        if (txt.indexOf(firstNumberFromString) > -1) {
                            e.clickElement(elemInKeypad);
                        }
                    });
                });

                allNumbersInKeypad = keyPadSection.$$('section.decimalSeparator');
                allNumbersInKeypad.each(function (elemInKeypad: ElementFinder, i: number) {
                    elemInKeypad.getText().then(function (txt: string) {
                        if (txt.indexOf(firstNumberFromString) > -1) {
                            e.clickElement(elemInKeypad);
                        }
                    });
                });

                browser.controlFlow().execute(function () {
                    self.enterUnitsInBlackDrawerKeypad(units.substr(1), keyPadSection);
                });
            };

            units = units.toString();

            if (units.length !== 0) {
                var firstNumberFromString = units.charAt(0);

                if (alreadyFoundParent) {   //use existing parent if function calls itself
                    enterUnits(alreadyFoundParent);
                } else {    //otherwise find the parent by ancestor of a displayed digit
                    var allDigitElements = $$('[ng-click*=addDigit]');
                    allDigitElements.filter(function (elem, index) {
                        return elem.isDisplayed().then(function (isDisplayed) {
                            return isDisplayed === true;
                        });
                    }).then(function (filteredElems) {
                        if (!filteredElems.length) {
                            /*  logger.takeScreenShot('units digit was not displayed');*/
                            expect(false).toBe(true, 'failed: could not find a units digit. Is the units keypad displayed?');
                        }

                        browser.controlFlow().execute(function () {
                            var someDisplayedDigitElem = filteredElems[0];
                            var displayedKeypadSection = someDisplayedDigitElem.element(by.xpath('ancestor::section[1]'));  //get closest parent section
                            enterUnits(displayedKeypadSection);
                        });
                    });
                }
            }
        });
    }
}