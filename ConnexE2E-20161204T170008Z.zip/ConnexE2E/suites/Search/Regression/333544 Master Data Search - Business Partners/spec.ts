/// <reference path="../../../../typings/index.d.ts" />

import sharedMasterDataSearchSteps from '../shared/sharedMasterDataSearchSteps';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import TestDataMasterDataSearch from '../shared/sharedMasterDataSearchTestData';

const test = new TestCase(
	'333544',
	'Master Data Search - Business Partners',
    UserRole.MASTER_DATA,
    ApplicationFeature.SEARCH
);

describe(test.stringify, () => {
    const td = new TestDataMasterDataSearch('BP', 'Business partners', 'Business partner');
    sharedMasterDataSearchSteps(test.description, td);
});