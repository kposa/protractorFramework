export interface salesRepsWithASingleAgencyResults {
    salesRepId:string,
    salesRepName:string,
    salesAgencyName:string,
    salesAgencyId:string
}

export function salesRepsWithASingleAgency () {
    const { E2EInvoicesDatabaseName } = process.env;

    return `
    SELECT DISTINCT TOP 20
        u.Name salesRepName, 
        u.UserId salesRepId, 
        sa.SalesAgencyId salesAgencyId,
        sa.Name salesAgencyName
        FROM ${E2EInvoicesDatabaseName}.dbo.UserSalesAgency usa
        JOIN ${E2EInvoicesDatabaseName}.dbo.[User] u on u.UserId = usa.UserId 
        JOIN ${E2EInvoicesDatabaseName}.dbo.SalesAgency sa on usa.SalesAgencyId = sa.SalesAgencyId
        JOIN (SELECT c.UserId, count(SalesAgencyId) numAg FROM ${E2EInvoicesDatabaseName}.dbo.UserSalesAgency c group by c.UserId ) counted on counted.UserId = usa.UserId
        WHERE counted.numAg = 1 
   `;
}