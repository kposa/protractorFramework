/// <reference path="../../../../typings/index.d.ts" />

import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import {
    territoriesWithGrowthAndRetentionPrograms,
    territoriesWithGrowthAndRetentionProgramsResults
} from './SharedSalesRepEllipseNavigationQueries';
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';
import { EllipseItem2 } from '../../../../modules_v3/testdata/EllipseItem';
import { SalesRepProposalDiscountsFullView } from '../../../../modules_v3/views/salesRep/SalesRepProposalDiscountsFullView';
import { SalesRepChargesAndCreditsFullView } from '../../../../modules_v3/views/salesRep/SalesRepChargesAndCreditsFullView';
import { SalesRepDeliverFullView } from '../../../../modules_v3/views/salesRep/SalesRepDeliverFullView';
import { SalesRepAccountDescriptionFullView } from '../../../../modules_v3/views/salesRep/SalesRepAccountDescriptionFullView';
import { SalesRepBusinessPartnersFullView } from '../../../../modules_v3/views/salesRep/SalesRepBusinessPartnersFullView';
import { SalesRepActivityStatementFullView } from '../../../../modules_v3/views/salesRep/SalesRepActivityStatementFullView';
import { SalesRepDocumentsFullView } from '../../../../modules_v3/views/salesRep/SalesRepDocumentsFullView';
import { SalesRepNewProposalFullView } from '../../../../modules_v3/views/salesRep/SalesRepNewProposalFullView';
import { SalesRepExperimentsFullView } from '../../../../modules_v3/views/salesRep/SalesRepExperimentsFullView';
import { SalesRepGrowthAndRetentionOverviewFullView } from '../../../../modules_v3/views/salesRep/SalesRepGrowthAndRetentionOverviewFullView';
import { SalesRepInvoiceFullView } from '../../../../modules_v3/views/salesRep/SalesRepInvoiceFullView';
import SalesRepDiscountsFullView from '../../../../modules_v3/views/salesRep/SalesRepDiscountsFullView';

export class SharedSalesRepEllipseNavigationTestData extends BaseTestData {

    protected queries:(() => Promise<any>)[] = [
        this.populateTestData()
    ];

    public preEllipseItem:EllipseItem2;
    public ellipseItems:Array<EllipseItem2>;

    public availableEllipseItems = {
        invoice: new EllipseItem2('invoice', new SalesRepInvoiceFullView()),
        products: new EllipseItem2('products', new SalesRepInvoiceFullView()),
        discounts: new EllipseItem2('discounts', new SalesRepDiscountsFullView()),
        proposalDiscounts: new EllipseItem2('discounts', new SalesRepProposalDiscountsFullView()),
        chargesAndCredits: new EllipseItem2('charges and credits', new SalesRepChargesAndCreditsFullView()),
        deliver: new EllipseItem2('deliver', new SalesRepDeliverFullView()),
        accountDescription: new EllipseItem2('account description', new SalesRepAccountDescriptionFullView()),
        businessPartners: new EllipseItem2('business partners', new SalesRepBusinessPartnersFullView()),
        activityStatement: new EllipseItem2('activity statement', new SalesRepActivityStatementFullView()),
        documents: new EllipseItem2('documents', new SalesRepDocumentsFullView()),
        newProposal: new EllipseItem2('new proposal', new SalesRepNewProposalFullView()),
        experiments: new EllipseItem2('experiments', new SalesRepExperimentsFullView()),
        growthAndRetentionOverview: new EllipseItem2('growth and retention overview', new SalesRepGrowthAndRetentionOverviewFullView())
    };

    private populateTestData ():() => Promise<territoriesWithGrowthAndRetentionProgramsResults> {
        return () => {
            const sql = territoriesWithGrowthAndRetentionPrograms(this.salesPeriod.id);
            const results = this.queryService.executeSql<territoriesWithGrowthAndRetentionProgramsResults>(sql);

            return results.then(data => {
                const row = <territoriesWithGrowthAndRetentionProgramsResults>getRandomQueryResult(data);

                this.salesRepresentatives.push({
                    id: row.salesRepId,
                    name: row.salesRepName
                });

                this.operations.push({
                    id: row.operationId,
                    name: row.operationName
                });

                this.salesAgencies.push({
                    id: row.salesAgencyId,
                    name: row.salesAgencyName
                });

                this.businessPartners.push({
                    id: row.customerId,
                    name: row.customerName
                });

                this.territories.push({
                    id: row.territoryId,
                    name: row.territoryName
                });

                return row;
            });
        };
    }
}