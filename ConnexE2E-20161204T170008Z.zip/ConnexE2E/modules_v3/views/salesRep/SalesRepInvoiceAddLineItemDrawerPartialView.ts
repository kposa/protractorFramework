/// <reference path='../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;
import { IAddLineItemDrawerPartialView } from "../../interfaces/partialViews/IAddLineItemDrawerPartialView";
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';
import SalesRepUnitsEntryDrawer from './SalesRepUnitsEntryDrawerPartialView';
import { NotImplementedError } from '../../../common/exception/exceptions';
import { IView } from '../../interfaces/common/IView';
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';

export class SalesRepInvoiceAddLineItemDrawerPartialView implements IView, IAddLineItemDrawerPartialView {
    private element:ElementFinder = $('section.lineitem.palette-b');
    private productList = $('section.product-selector-v3');
    private productListItems = this.productList.$$('div.product');
    private subProductList = $('section.subproduct-selector-v2');
    private subProductListItems = this.subProductList.$$('div.subproduct');
    private unitsEntryDrawer = new SalesRepUnitsEntryDrawer();

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    private getProductFromList (productId?:string):ElementFinder {
        let products = this.productListItems;

        if (typeof productId !== 'undefined') {
            products = products
                .filter(e => e.getText().then(t => t === productId));
        }

        return products.first();
    }

    private getSubproductFromList (subProductId?:string):ElementFinder {
        let subProducts = this.subProductListItems;

        if (typeof subProductId !== 'undefined') {
            subProducts = subProducts
                .filter(e => e.getText().then(t => subProductId ? t === subProductId : true));
        }

        return subProducts.first();
    }

    selectProductLine ():Promise<boolean> {
        throw new NotImplementedError();
    }

    public selectProduct (productId?:string):void {
        isPresentAndDisplayed(this.productList).then(ad => {
            if (ad) clickElement(this.getProductFromList(productId));
        });

    }

    public selectSubProduct (subProductId?:string):void {
        isPresentAndDisplayed(this.subProductList).then(ad => {
            if (ad) clickElement(this.getSubproductFromList(subProductId));
        });
    }

    public fillInputUnits (value:string):void {
        this.unitsEntryDrawer.fillInputUnits(value);
        this.unitsEntryDrawer.close();
    }

    public close ():void {
        clickElement(this.element.$('div.drawer-close-icon-container'));
    }

    selectFirstProduct(){
        clickElement(this.productListItems.get(0));
    }

    selectFirstSubProduct(){
        clickElement(this.subProductListItems.get(0));
    }

    clickDirectShipmentSection ():void {
        throw new NotImplementedError();
    }

}
