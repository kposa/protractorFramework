/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;
import { IOperationFullView } from '../../interfaces/fullViews/IOperationFullView';
import { NotImplementedError } from '../../../common/exception/exceptions';
import { IView } from '../../interfaces/common/IView';
import Promise = protractor.promise.Promise;
import { filterElements, isActive, containingAttributeValue, containingText } from '../../helpers/filterElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';

export default class ITSupportOperationFullView implements IView, IOperationFullView {
    private accountDescriptions = $$('li.account');
    private addAccountDescriptionButton = $(`button.addAccount`);

    isViewDisplayed ():Promise<boolean> {
        return $('section.support-operation').isDisplayed();
    }

    clickFirstActiveAccountDescriptionButtonContainingText (buttonText:string) {
        let allButtons = $$('div.button.semibold');
        let button = filterElements(allButtons, [
            isActive(true),
            containingAttributeValue({ attribute: 'class', value: 'disabled' }, undefined, true),
            containingText(buttonText)
        ])().first();
        clickElement(button);
    }

    clickProposeButton (invoiceName:string):void {
        throw new NotImplementedError();
    }

    clickInvoiceButton (invoiceName:string):void {
        throw new NotImplementedError();
    }

    clickDeliveryButton (invoiceName:string):void {
        throw new NotImplementedError();
    }

    clickAddAccountDescriptionButton ():void {
        throw new NotImplementedError();
    }
}