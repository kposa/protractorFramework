/// <reference path="../../../typings/index.d.ts" />

import {Element} from "../../shared/Element";

let e = new Element();

export class ActionButtonSS {

    public clickFloatingActionBtn() {
        let allFloatingActionButtons = $$('[at="floating-action-button"]');
        e.clickDisplayedElement(allFloatingActionButtons);
    }
}