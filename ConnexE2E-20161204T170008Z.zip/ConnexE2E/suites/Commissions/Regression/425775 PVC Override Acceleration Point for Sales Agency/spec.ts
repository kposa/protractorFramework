/// <reference path="../../../../typings/index.d.ts" />

import MasterDataMasterSearchFullView from '../../../../modules_v3/views/masterData/MasterDataMasterSearchFullView';
import MasterDataCommissionsTabFullView from '../../../../modules_v3/views/masterData/MasterDataCommissionsTabFullView';
import { MasterDataProductValueCommissionFullView } from '../../../../modules_v3/views/masterData/MasterDataProductValueCommissionFullView';
import { TestData425775 } from './testData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
     '425775',
     'PVC Override Acceleration Point for Sales Agency',
     UserRole.MASTER_DATA,
     ApplicationFeature.COMMISSIONS
);

describe(test.stringify, () => {
    const masterDataMasterSearchFullView = new MasterDataMasterSearchFullView();
    const masterDataCommissionsTabFullView = new MasterDataCommissionsTabFullView();
    const masterDataProductValueCommissionFullView = new MasterDataProductValueCommissionFullView();
    const td = new TestData425775();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.masterDataUser);

            // select a sales agency to test
            masterDataMasterSearchFullView.search(td.randSalesAgencyId);
            masterDataMasterSearchFullView.selectFilterContainingText('Sales agencies');
            masterDataMasterSearchFullView.clickSearchResultContainingText(td.randSalesAgencyId);

            // navigate to the sales agency product value commission screen
            masterDataCommissionsTabFullView.clickTabContainingText('Commission');
            masterDataCommissionsTabFullView.clickCardContainingText('Product Value');

            // locate the sales years displayed in each row
            expect(masterDataProductValueCommissionFullView.getSalesAgencyPreviousSalesYear()).toBeTruthy();
            expect(masterDataProductValueCommissionFullView.getSalesAgencyCurrentSalesYear()).toBeTruthy();

            // open acceleration point popup window
            masterDataProductValueCommissionFullView.displayCurrentYearSalesAgencyConfig('Override acceleration point');
            expect(masterDataProductValueCommissionFullView.salesAgencyFormCanBeSubmitted()).toBeFalsy();

            // verify negative numbers are not allowed
            masterDataProductValueCommissionFullView.fillSalesAgencyAccelerationPoint(`-1`);
            expect(masterDataProductValueCommissionFullView.getSalesAgencyOverrideAccelerationPoint()).toEqual('1');
            masterDataProductValueCommissionFullView.fillSalesAgencyOverAccelerationPoint(`-1`);
            expect(masterDataProductValueCommissionFullView.getSalesAgencyOverrideOverAccelerationPoint()).toEqual('1');
            masterDataProductValueCommissionFullView.fillSalesAgencyUnderAccelerationPoint(`-1`);
            expect(masterDataProductValueCommissionFullView.getSalesAgencyOverrideUnderAccelerationPoint()).toEqual('1');

            // verify only one digit is allowed after decimal point
            masterDataProductValueCommissionFullView.fillSalesAgencyAccelerationPoint(`99.67`);
            expect(masterDataProductValueCommissionFullView.getSalesAgencyOverrideAccelerationPoint()).toEqual('99.6');
            masterDataProductValueCommissionFullView.fillSalesAgencyOverAccelerationPoint(`99.67`);
            expect(masterDataProductValueCommissionFullView.getSalesAgencyOverrideOverAccelerationPoint()).toEqual('99.6');
            masterDataProductValueCommissionFullView.fillSalesAgencyUnderAccelerationPoint(`99.67`);
            expect(masterDataProductValueCommissionFullView.getSalesAgencyOverrideUnderAccelerationPoint()).toEqual('99.6');

            // enter valid values
            masterDataProductValueCommissionFullView.fillSalesAgencyAccelerationPoint(td.randomAcceleration);
            masterDataProductValueCommissionFullView.fillSalesAgencyOverAccelerationPoint(td.randomOverAcceleration);
            masterDataProductValueCommissionFullView.fillSalesAgencyUnderAccelerationPoint(td.randomUnderAcceleration);

            // save and submit the valid values
            masterDataProductValueCommissionFullView.submitSalesAgencyPVC();

            // open acceleration point popup window
            masterDataProductValueCommissionFullView.displayCurrentYearSalesAgencyConfig('Override acceleration point');

            // enter different valid data
            masterDataProductValueCommissionFullView.fillSalesAgencyAccelerationPoint(td.randomAccelerationTwo);
            masterDataProductValueCommissionFullView.fillSalesAgencyOverAccelerationPoint(td.randomOverAccelerationTwo);
            masterDataProductValueCommissionFullView.fillSalesAgencyUnderAccelerationPoint(td.randomUnderAccelerationTwo);

            // save and submit the override data
            masterDataProductValueCommissionFullView.submitSalesAgencyPVC();
        }, fail);
    });
});