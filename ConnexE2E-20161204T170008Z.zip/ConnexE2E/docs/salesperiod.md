# [Connex E2E Documentation](/)

## Sales Period

Sales period is at the core of most test data.

### Configuration

Configuration for sales period is in `./localConfig/salesperiod.ts`. The `season` and `name` are derived from the `id` and `year`.

### Accessing

#### Inside of tests

Sales period is exposed as a property `salesPeriod` on `TestData` classes that extend `BaseTestData`.

#### Outside of tests

The sales period that tests default to are accessible as [environmental variables](/envVars.html).

| Name                          | tx            | staging       | Description |
|:------------------------------|:--------------|:--------------|:------------|
| `E2EDefaultSalesPeriodId`     | `21`          | `21`          | Default sales period id to use during tests 
| `E2EDefaultSalesPeriodYear`   | `2017`        | `2017`        | Default sales period year to use during tests
| `E2EDefaultSalesPeriodSeason` | `Spring`      | `Spring`      | Default sales period season to use during tests
| `E2EDefaultSalesPeriodName`   | `2017 Spring` | `2017 Spring` | Default sales period name to use during tests

### Single test overwrite

Some tests will require a different sales period than the default:

```
const td = new BaseTestData();
td.salesPeriod.setTo(20);
```

This will update the year, season and name based on default sales period configuration.

**Note:** This must be set *before* running `td.populatePromise()`;