export interface agencyIdForAddWarehouseResults {
    AgencyId: string
}

export function agencyIdForAddWarehouse () {
    const {E2EOperationsDatabaseName} = process.env;
    return `
    
select 
                           a.AgencyId,
                           a.Name,
                           a.FirstName,
                           a.LastName,
                           a.Suffix,
						   a.AgencyGroupId
from                       ${E2EOperationsDatabaseName}.masterdata.Agency a

left join            ${E2EOperationsDatabaseName}.masterdata.[AgencyWarehouse] aw
                     on  a.AgencyId = aw.AgencyId
where
                           aw.WarehouseId is null
						   and a.AgencyGroupID = 1

`;
}