/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;
import { IOperationFullView } from '../../interfaces/fullViews/IOperationFullView';
import { clickElement } from '../../helpers/clickElementHelpers';
import { NotImplementedError } from '../../../common/exception/exceptions';
import Promise = protractor.promise.Promise;
import { IView } from '../../interfaces/common/IView';
import { filterElements, isActive, matchingAttributeValue } from '../../helpers/filterElementHelpers';

export class SalesRepOperationFullView implements IView, IOperationFullView {

    public salesPeriodDropdown = new SalesRepSalesPeriodDropdown();
    private accountDescriptions = $$('li.account');
    private addAccountDescriptionButton = $(`button.addaccount`);

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    clickProposeButton (invoiceName:string):void {
        const accountDescription = this.getAccountDescription(invoiceName);
        const proposeButton = this.getProposeButtonForAccountDescription(accountDescription);
        clickElement(proposeButton);
    }

    clickInvoiceButton (invoiceName:string):void {
        const accountDescription = this.getAccountDescription(invoiceName);
        const invoiceButton = this.getInvoiceButtonForAccountDescription(accountDescription);
        clickElement(invoiceButton);
    }

    clickDeliveryButton (invoiceName:string):void {
        throw new NotImplementedError();
    }

    clickAddAccountDescriptionButton ():void {
        clickElement(this.addAccountDescriptionButton);
    }

    getAccountDescription (invoiceName:string):ElementFinder {
        return this.accountDescriptions
            .filter(e => e.$('label.account-name').getText().then(text => text === invoiceName))
            .first();
    }

    getProposeButtonForAccountDescription (accountDescription:ElementFinder):ElementFinder {
        return accountDescription.$$('li.stage').get(0).$('div.circle');
    }

    getInvoiceButtonForAccountDescription (accountDescription:ElementFinder):ElementFinder {
        return accountDescription.$$('li.stage').get(1).$('div.circle');
    }

    clickFirstInvoiceHavingLineItems ():void {
        let allInvoicesWithLineItems = $$('label[at="invoiced"]');
        clickElement(allInvoicesWithLineItems.first());
    }
}

/**
 * The sales period drop down menu is displayed after clicking the [+ New Account Description] button
 * It is only shown to the user at times of the year where multiple sales periods are active
 */
class SalesRepSalesPeriodDropdown implements IView {

    private allDropdownItems = $$('li[ng-repeat="salesPeriod in viewData.accountDescriptionSalesPeriods"]');

    isViewDisplayed ():Promise<boolean> {
        return filterElements(this.allDropdownItems, [ isActive(true) ])().count().then((c) => {
            return c > 0;
        });
    }

    selectById (salesPeriodId:number) {
        this.isViewDisplayed().then((d) => {
            if (d) this.clickMenuItem(salesPeriodId);
            else expect(browser.getCurrentUrl()).toContain(salesPeriodId);
        });
    }

    private clickMenuItem (salesPeriodId:number) {
        let menuItem = filterElements(this.allDropdownItems, [
            isActive(true),
            matchingAttributeValue({
                attribute: 'at',
                value: salesPeriodId.toString()
            }, e => e.$(`div.flyoutBox.flex-horizontal`))
        ])().first();
        clickElement(menuItem);

    }
}