/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';
import { isAriaChecked } from '../../../modules_v3/helpers/utilityElementHelpers';

export class AgencyFinancialMD {

    private financialLayoutParent = $('div.ng-scope.layout-column.flex');
    private routingNumberInputContainer = $('input[name="routingNumber"]');
    private accountNumberInputContainer = $('input[name="accountNumber"]');
    private eftStatusCheckbox = $('md-checkbox[ng-model="vm.agencyBankInformation.eftStatus"]');


    get verifyUnitedStatesDisplayed(): Promise<string> {
        return this.financialLayoutParent.getText();
    }

    get verifyRequiredDisplaysForAccountNumber(): Promise<string> {
        return this.financialLayoutParent.getText();
    }

    public selectEftStatusCheckbox(): void {
        clickElement(this.eftStatusCheckbox);
    }

    public verifyIfEftStatusCheckboxChecked(): Promise<boolean> {
        return isAriaChecked(this.eftStatusCheckbox);
    }

    public enterRoutingNumber(routingNum: string): void {
        this.routingNumberInputContainer.clear();
        this.routingNumberInputContainer.sendKeys(routingNum);
    }

    public enterAccountNumber(accountNum: string): void {
        this.accountNumberInputContainer.clear();
        this.accountNumberInputContainer.sendKeys(accountNum);
    }

}