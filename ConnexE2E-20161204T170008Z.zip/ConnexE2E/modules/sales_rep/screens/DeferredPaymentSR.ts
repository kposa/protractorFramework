/// <reference path="../../../typings/index.d.ts" />

/**
 * navigate to Operation screen -> ellipse('business partners') -> click Balances -> ellipse('deferred payment')
 */

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import {Element} from "./../../shared/Element";

let e = new Element();

export class DeferredPaymentSR {

    public clickSignButton():void {
        let signButton = $('button[ng-click="openLoanAgreement(operation, customerId)"]');
        e.clickElement(signButton);
    }

}