/// <reference path="../../../../typings/index.d.ts" />
import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';

export default class TestData324677 extends BaseTestData {
    constructor () {
        super();

        this.businessPartners.push({
            id: '17361611',
            name: 'Brian Herbst'
        });
    }
}