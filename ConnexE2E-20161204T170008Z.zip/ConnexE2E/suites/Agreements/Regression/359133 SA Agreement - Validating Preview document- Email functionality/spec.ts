/// <reference path="../../../../typings/index.d.ts" />

import {AgreementsSR} from "../../../../modules/sales_rep/screens/AgreementsSR";
import {PreviewDocumentSR} from "../../../../modules/sales_rep/screens/PreviewDocumentSR";
import {SalesRepAgreementSR} from "../../../../modules/sales_rep/screens/SalesRepAgreementSR";
import SalesRepNavigationMenuView from '../../../../modules_v3/views/salesRep/SalesRepNavigationMenuPartialView';
import TestData359133 from './testData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
	'359133',
	'SA Agreement - Validating Preview document- Email functionality',
	UserRole.SALES_REP,
	ApplicationFeature.AGREEMENTS
);

describe(test.stringify, () => {
    const td = new TestData359133();
    const navigationMenuView = new SalesRepNavigationMenuView();
    let ag = new AgreementsSR();
    let pd = new PreviewDocumentSR();
    let srAgreement = new SalesRepAgreementSR();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.salesRepresentative);

            // should select the [Barcode Scanner agreement] link from the {Hamburger] option
            navigationMenuView.openMenu();
            navigationMenuView.selectMenuItemContainingText('Agreements');

            // should verify user lands on [Agreements] page when clicking on [ Barcode Scanner Agreement] 
            expect(ag.isAgreementsPagePresent()).toEqual('Agreements', 'failed to land on the [Agreements] page');

            // should assert on the display of [Barcode Scanner Agreement]  with sign button and click sign
            srAgreement.signBarcodeScannerAgreement();

            // should verify if the signed agreement displays under signed section', ():void => {
            expect(srAgreement.verifyIfAgreementIsUnderSigned()).toEqual('Signed Agreements');

            // should assert on clicking the [View] button for the signed Barcode Scanner agreement
            srAgreement.showSignedAgreementPreview();

            // should assert on [Preview Agreement Document] page when clicking on [View] button for the signed Barcode Scanner Agreement agreement
            expect(pd.isPreviewDocumentPagePresent()).toBeTruthy();

            // should assert both [Email] and [Print] icons are displayed icons on the [Preview Agreement] page
            expect(pd.isEmailIconDisplayed()).toBeTruthy();
            expect(pd.isPrintIconDisplayed()).toBeTruthy();

            // should assert the email dialog box when clicking on [Email] Icon
            pd.clickEmailIcon();
            expect(pd.isEmailIconDialogBoxDisplayed()).toBeTruthy();

            // should assert on the display of sales rep\'s name and sales agency\'s email on the dialog box displayed once clicking on [Email] Icon
            expect(pd.verifySalesRepNameDisplayed()).toContain(td.salesAgency.name);

            // should assert on the free form dialog box below Add recipients when clicking on [Email] Icon
            expect(pd.isAddRecipientsDialogBoxDisplayed()).toBeTruthy();

            // should assert on [send] button being inactive when entering an invalid email in [additional email address]  dialog
            pd.enterValueInEmailAddressDialog('abcdef@pioneer', 'clear');
            expect(pd.isSendButtonInactive()).toBeTruthy();

            // should assert on [send] button being enabled when entering a valid email in [additional email address]  dialog
            pd.enterValueInEmailAddressDialog('abcdef@pioneer.com', 'clear');
            expect(pd.isSendButtonEnabled()).toBeTruthy();

            // should assert on [send] button being enabled when entering 2 valid email addresses with a space in [additional email address]  dialog
            pd.enterValueInEmailAddressDialog('abcdef@pioneer.com ghijkl@pioneer.com', 'clear');
            expect(pd.isSendButtonEnabled()).toBeTruthy();

            // should assert on [send] button being enabled when entering 2 valid email addresses with a comma in [additional email address]  dialog
            pd.enterValueInEmailAddressDialog('abcdef@pioneer.com,ghijkl@pioneer.com', 'clear');
            expect(pd.isSendButtonEnabled()).toBeTruthy();

            // should assert on [send] button being enabled when entering 2 valid email addresses with a semicolon in [additional email address]  dialog
            pd.enterValueInEmailAddressDialog('abcdef@pioneer.com;ghijkl@pioneer.com', 'clear');
            expect(pd.isSendButtonEnabled()).toBeTruthy();

            // should assert on [send] button being enabled when entering 2 valid email addresses with an [enter] key in [additional email address]  dialog
            pd.enterValueInEmailAddressDialog('abcdef@pioneer.com', 'clear');
            pd.enterValueInEmailAddressDialog('\n');
            pd.enterValueInEmailAddressDialog('ghijkl@pioneer.com');
            expect(pd.isSendButtonEnabled()).toBeTruthy();

            // should assert on [send] button being enabled when entering text in the standard disclaimer dialog box
            pd.enterValueInStandardDisclaimerDialog('Including this message to verify that the send button is not disabled');
            expect(pd.isSendButtonEnabled()).toBeTruthy();

            // should click on [send] button on the email dialog box
            pd.clickSendButton();

            // should assert on closing of email dialog box on Preview Document when clicking on [send] button
            expect(pd.isEmailIconDialogOpen()).toBeFalsy();
        }, fail);
    });
});