/// <reference path="../../../../typings/index.d.ts" />

import MasterDataMasterSearchFullView from '../../../../modules_v3/views/masterData/MasterDataMasterSearchFullView';
import MasterDataCommissionsTabFullView from '../../../../modules_v3/views/masterData/MasterDataCommissionsTabFullView';
import { MasterDataOtherCommissionsFullView } from '../../../../modules_v3/views/masterData/MasterDataOtherCommissionsFullView';
import { sharedOtherCommissionTestData } from '../shared/sharedOtherCommissionTestData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
    '446025',
    'Add-Upd-Del Other Commissions w/out Classification for All Revenue',
    UserRole.MASTER_DATA,
    ApplicationFeature.COMMISSIONS
);

describe(test.stringify, () => {
    const masterDataMasterSearchFullView = new MasterDataMasterSearchFullView();
    const masterDataCommissionsTabFullView = new MasterDataCommissionsTabFullView();
    const masterDataOtherCommissionsFullView = new MasterDataOtherCommissionsFullView();
    const td = new sharedOtherCommissionTestData();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.masterDataUser);

            // select a random sales agency
            masterDataMasterSearchFullView.search(td.randSalesAgencyId);
            masterDataMasterSearchFullView.selectFilterContainingText('Sales agencies');
            masterDataMasterSearchFullView.clickSearchResultContainingText(td.randSalesAgencyId);

            // navigate to the sales agency Other Commission screen
            masterDataCommissionsTabFullView.clickTabContainingText('Commission');
            masterDataCommissionsTabFullView.clickCardContainingText('Other Commission');

            // add a new commission without classification
            masterDataOtherCommissionsFullView.addCommission('Without classification');

            // configure an All Revenue commission
            masterDataOtherCommissionsFullView.selectSalesYear(td.salesPeriod.year.toString());
            masterDataOtherCommissionsFullView.selectProgram('Exclusivity');
            masterDataOtherCommissionsFullView.selectType('All Revenue');
            masterDataOtherCommissionsFullView.enterMaxCommission(td.randomValue);

            // verify that 0 is not allowed
            masterDataOtherCommissionsFullView.enterPercentValue('0');
            expect(masterDataOtherCommissionsFullView.verifyPercentFieldIsRequired('Must be greater than 0'))
                .toBeTruthy();

            // verify negative numbers are not allowed in percent field
            masterDataOtherCommissionsFullView.enterPercentValue('-1');
            expect(masterDataOtherCommissionsFullView.getPercentValue()).toEqual('1');

            // verify that the required message appears when the field is selected and then deselected
            masterDataOtherCommissionsFullView.clearPercentField();
            expect(masterDataOtherCommissionsFullView.verifyPercentFieldIsRequired('Required'))
                .toBeTruthy();

            // verify only 2 decimal places are allowed
            masterDataOtherCommissionsFullView.enterPercentValue('99.119');
            expect(masterDataOtherCommissionsFullView.getPercentValue()).toEqual('99.11');

            // select save and add
            masterDataOtherCommissionsFullView.clickSalesAgencyOtherCommissionsSave('Save & Add');

            // configure a new All Revenue commission
            masterDataOtherCommissionsFullView.selectSalesYear(td.salesPeriod.year.toString());
            masterDataOtherCommissionsFullView.selectProgram('Other');
            masterDataOtherCommissionsFullView.selectType('All Revenue');
            masterDataOtherCommissionsFullView.enterMaxCommission(td.randomValue);
            masterDataOtherCommissionsFullView.enterPercentValue(td.randomValueTwo);

            // select save and close
            masterDataOtherCommissionsFullView.clickSalesAgencyOtherCommissionsSave('Save & Close');

            // start to delete the first row then cancel
            masterDataOtherCommissionsFullView.removeFirstCommissionRow();
            masterDataOtherCommissionsFullView.clickCancelDeleteConfirmation('Cancel');

            // actually delete the first row
            masterDataOtherCommissionsFullView.removeFirstCommissionRow();
            masterDataOtherCommissionsFullView.clickCancelDeleteConfirmation('Delete');

            // open one of the remaining rows for editing
            masterDataOtherCommissionsFullView.editFirstCommissionRow();

            // change the program drop down selection
            masterDataOtherCommissionsFullView.selectProgram('Rep Retention');

            // save the change
            masterDataOtherCommissionsFullView.saveAfterEdit();

            // actually delete a second row
            masterDataOtherCommissionsFullView.removeFirstCommissionRow();
            masterDataOtherCommissionsFullView.clickCancelDeleteConfirmation('Delete');
        }, fail);
    });
});