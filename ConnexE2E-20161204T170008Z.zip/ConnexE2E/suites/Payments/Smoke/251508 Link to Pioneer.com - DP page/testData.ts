/// <reference path="../../../../typings/index.d.ts" />

import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import { existingData } from '../../../../modules_v3/testdata/sharedQueries/existingData/index';

export class testData extends BaseTestData {
    protected queries:(() => Promise<any>)[] = [
        existingData(this.queryService, this)
    ];
}