/// <reference path='../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;
import { IMasterSearchFullView } from "../../interfaces/fullViews/IMasterSearchFullView";

import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';
import {
    filterElements,
    isActive,
    containingText,
    matchingText,
    matchingAttributeValue
} from '../../../modules_v3/helpers/filterElementHelpers';
import { NotImplementedError } from '../../../common/exception/exceptions';
import { IView } from '../../interfaces/common/IView';
import { SalesSupportSelectTerritoryPageFullView } from './SalesSupportSelectTerritoryPageFullView';
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';
import { SalesSupportHamburgerDrawerPartialView } from './SalesSupportHamburgerDrawerPartialView';

export class SalesSupportMasterSearchFullView implements IView, IMasterSearchFullView {

    public hamburgerMenu = new HamburgerMenu();

    private searchInput:ElementFinder = $(`input[data-ng-model='criteria']`);
    private filterList:ElementFinder = $(`section.category-refinement`);
    private filters:ElementArrayFinder = this.filterList.$$(`section.pm-listitem-primary`);
    private searchResults:ElementArrayFinder = $$(`div[ng-repeat="item in vm.itemList"]`);
    private salesSupportSelectTerritoryPageFullView = new SalesSupportSelectTerritoryPageFullView();
    private searchBarHamburger = $('i[ng-click="drawerVM.toggleDrawerPosition()"]');

    private clickSeeMoreTerritoriesButton ():void {
        var seeMoreTerritoriesButton = $('pm-flat-button[ng-click="vm.showMoreClicked()"] button');
        clickElement(seeMoreTerritoriesButton);
    }

    clickSearchBarHamburger ():void {
        clickElement(this.searchBarHamburger);
    }

    isViewDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('section.indexed-search'));
    }

    search (text:string):void {
        this.openSearch();
        this.inputSearch(text);
        this.submitSearch();
    }

    searchByTwoCriteria (firstCriteria:string, secondCriteria:string):void {
        throw new NotImplementedError();
    }

    openSearch ():void {
        clickElement(this.searchInput);
    }

    inputSearch (text:string):void {
        clickElement(this.searchInput);
        this.searchInput.clear();
        this.searchInput.sendKeys(text);
    }

    submitSearch ():void {
        clickElement(this.searchInput);
        this.searchInput.sendKeys(protractor.Key.ENTER);
    }

    getFilters ():ElementArrayFinder {
        throw new NotImplementedError();
    }

    selectAllFilter ():void {
        clickElement($('div[ng-click="vm.clearSelected()"]'));
    }

    selectFilterMatchingText (text:string):void {
        clickElement(filterElements(this.filters, [ isActive(true), matchingText(text) ])().first());
    }

    selectFilterContainingText (text:string):void {
        clickElement(filterElements(this.filters, [ isActive(true), containingText(text) ])().first());
    }

    getCountOfFilters ():Promise<number> {
        throw new NotImplementedError();
    }

    getCountOfFilterMatchingText (text:string):Promise<number> {
        throw new NotImplementedError();
    }

    getCountOfFilterContainingText (text:string):Promise<number> {
        throw new NotImplementedError();
    }

    clickSearchResultMatchingText (text:string):void {
        clickElement(filterElements(this.searchResults, [ isActive(true), matchingText(text) ])().first());
    }

    clickSearchResultContainingText (text:string):void {
        clickElement(filterElements(this.searchResults, [ isActive(true), containingText(text) ])().first());
    }

    clickBusinessPartnerSearchResult (businessPartnerId:string) {
        clickElement(filterElements(this.searchResults, [
            isActive(true),
            matchingAttributeValue({ attribute: 'at', value: businessPartnerId }, e => e.$(`div.pm-card`))
        ])().first());
    }

    getSearchResultCount ():Promise<number> {
        return this.searchResults.count();
    }

    getSearchResultCountByMatchingResultType (resultType:string):Promise<number> {
        throw new NotImplementedError();
    }

    getSearchResultsByContainingResultType (resultType:string):ElementArrayFinder {
        throw new NotImplementedError();
    }

    getSearchResultCountByContainingResultType (headline:string):Promise<number> {
        throw new NotImplementedError();
    }

    getSearchResultsByContainingHeadline (headline:string):ElementArrayFinder {
        throw new NotImplementedError();
    }

    getSearchResultContentByContainingHeadline (headline:string):Promise<string> {
        throw new NotImplementedError();
    }

    refineByTerritory (territoryName:string):void {
        let territoryRefinementList = $('refinement-list-v2[heading="territory"]');
        let territory = territoryRefinementList.element(by.cssContainingText('div.pm-selection-label', territoryName));
        territory.isPresent().then((iD) => {
            if (iD)
                clickElement(territory);
            else {
                this.clickSeeMoreTerritoriesButton();
                this.salesSupportSelectTerritoryPageFullView.selectTerritory(territoryName);
            }
        });
    }

}

class HamburgerMenu extends SalesSupportHamburgerDrawerPartialView {
}