/// <reference path='../../../typings/index.d.ts' />

import {INavigationMenuPartialView} from "../../interfaces/partialViews/INavigationMenuPartialView";
import { filterElements, matchingText, containingText, isActive } from '../../helpers/filterElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';
import { NotImplementedError } from '../../../common/exception/exceptions';
import Promise = protractor.promise.Promise;
import { IView } from '../../interfaces/common/IView';

export default class SalesRepNavigationMenuPartialView implements IView, INavigationMenuPartialView {
    private element = $(`section.navigation`);
    private menuButton = this.element.$(`div[ng-click='showNav()']`);
    private menuItems = this.element.$$(`li`);

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    openMenu():void {
        clickElement(this.menuButton);
    }

    selectMenuItemMatchingText(text:string):void {
        clickElement(filterElements(this.menuItems, [isActive(true), matchingText(text)])().first());
    }

    selectMenuItemContainingText(text:string):void {
        clickElement(filterElements(this.menuItems, [isActive(true), containingText(text)])().first());
    }
}
