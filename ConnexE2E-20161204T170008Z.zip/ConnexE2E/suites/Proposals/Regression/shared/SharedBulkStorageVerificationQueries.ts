/// <reference path="../../../../typings/index.d.ts" />

const { E2EInvoicesDatabaseName } = process.env;

export interface productRequiringBulkStorageResults {
    salesAgencyName: string;
    salesAgencyId:string;
    salesRepName: string;
    salesRepId: string;
    operationName: string;
    operationId: string;
    customerId: string;
    customerName: string;
    productLine: string;
    productId: string;
    subproductId: string;
}

// US operation with existing account description
export function productRequiringBulkStorage(salesPeriodId: number, agencyHasBulkStorage:boolean): string {
    return `
    SELECT DISTINCT TOP 20 
    u.Name salesRepName, 
    u.UserId salesRepId, 
    o.Name operationName, 
    opc.operationId, 
	c.customerId,
	c.Name customerName,
    pl.Name productLine, 
    p.productId, 
    p.subproductId,
    sa.name salesAgencyName,
    sa.salesAgencyId
    
    FROM ${E2EInvoicesDatabaseName}.catalog.Subproduct sp
    JOIN ${E2EInvoicesDatabaseName}.catalog.Price p ON p.SubproductId = sp.SubproductId
    JOIN ${E2EInvoicesDatabaseName}.catalog.ProductLine pl ON pl.ProductLineId = p.ProductLineId
    JOIN ${E2EInvoicesDatabaseName}.catalog.OperationPriceCatalog opc ON opc.PriceCatalogId = p.PriceCatalogId
    JOIN ${E2EInvoicesDatabaseName}.dbo.UserOperation uo ON uo.OperationId = opc.OperationId AND uo.SalesPeriodId = opc.SalesPeriodId
    JOIN ${E2EInvoicesDatabaseName}.dbo.OperationSalesAgency osa ON osa.OperationId = uo.OperationId AND osa.SalesPeriodId = uo.SalesPeriodId
	JOIN ${E2EInvoicesDatabaseName}.dbo.SalesAgency sa ON sa.SalesAgencyId = osa.SalesAgencyId
    JOIN ${E2EInvoicesDatabaseName}.dbo.[User] u ON u.UserId = uo.UserId
    JOIN ${E2EInvoicesDatabaseName}.dbo.operation o ON o.OperationId = uo.OperationId
    JOIN ${E2EInvoicesDatabaseName}.dbo.OperationCustomer oc ON oc.OperationId = o.OperationId
    JOIN ${E2EInvoicesDatabaseName}.dbo.Customer c ON c.CustomerId = oc.CustomerId
    
    WHERE sp.RequiresBulkStorage = 1
    AND opc.SalesPeriodId = ${salesPeriodId} 
    AND uo.RoleId = 10
    AND c.CultureName = 'en-us'
    AND sa.HasBulkStorage = ${agencyHasBulkStorage ? 1 : 0} 
    AND EXISTS (SELECT 1 FROM dbo.Invoice i WHERE i.SalesPeriodId = uo.SalesPeriodId AND i.OperationId = uo.OperationId)
    `;
}