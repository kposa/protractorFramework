/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;

export interface ISearchableView {
    openSearch():void;
    inputSearch(text:string):void;
    submitSearch():void;
    search(text:string):void;
    searchByTwoCriteria(firstCriteria:string, secondCriteria:string):void;
}