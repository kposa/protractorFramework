/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;

export interface ILoginFullView {
    inputUsername(userName:string):void;
    inputPassword(password:string):void;
    submit():void;
    login(userName:string, password:string): void;
}