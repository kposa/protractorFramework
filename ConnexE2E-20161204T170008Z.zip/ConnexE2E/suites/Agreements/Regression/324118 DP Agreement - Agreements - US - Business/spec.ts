/// <reference path="../../../../typings/index.d.ts" />

import {SharedDPAgreementSteps} from "../shared/SharedDPAgreementSteps";
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import {SharedDPAgreementTestData} from "../shared/SharedDPAgreementTestData";

const test = new TestCase(
	'324118',
	'DP Agreement - Agreements - US - Business',
	UserRole.SALES_REP,
	ApplicationFeature.NAVIGATIONS
);

describe(test.stringify, () => {
    const sharedDPAgreementSteps = new SharedDPAgreementSteps();
    const td = new SharedDPAgreementTestData();

    td.customerType = 2;
    td.customerCultureName = 'en-US';
    td.customerHasMissingCreditLimit = true;
    td.useAlternateNavigationToDPAgreement = true;

    sharedDPAgreementSteps.run(test.description, td);
});