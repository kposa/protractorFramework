const { E2EInvoicesDatabaseName } = process.env;

export interface testDataForChargeAndCreditResults {
    salesAgentName:string;
    salesAgentId:string;
    operationId:string;
    operationName:string;
    businessPartnerId:string,
    businessPartnerName:string;

}

export interface chargeAndCreditNamesByOperationAndSalesPeriodResults {
    chargeAndCreditName:string;

}

export function testDataForChargeAndCredit (salesPeriodId:number) {
    return `
    
    SELECT DISTINCT TOP 500  sat.SalesAgencyId, u.Name AS salesAgentName,u.UserId AS salesAgentId, c.CustomerId AS businessPartnerId, c.Name AS businessPartnerName, o.operationId,o.Name AS operationName
    FROM dbo.SalesAgencyTerritory sat
    JOIN adjustments.ChargeCreditProgram ccp ON  ccp.TerritoryId = sat.TerritoryId
    JOIN adjustments.OperationChargeCreditProgram occp ON occp.ChargeCreditProgramId = ccp.ChargeCreditProgramId
    JOIN adjustments.ChargeCredit cct ON cct.ChargeCreditId = occp.ChargeCreditProgramId
    JOIN dbo.UserOperation uo ON uo.OperationId = occp.OperationId
    JOIN dbo.OperationCustomer oc ON oc.OperationId = uo.OperationId
    JOIN dbo.Operation o ON o.OperationId = oc.OperationId
    JOIN dbo.Customer c ON c.CustomerId = oc.CustomerId
    JOIN dbo.UserSalesAgency usa ON usa.UserId = uo.UserId
    JOIN dbo.[User] u ON u.UserId = usa.UserId
    WHERE sat.SalesPeriodId = ${salesPeriodId}
    
    `;
}

export function chargeAndCreditNamesByOperationAndSalesPeriod (operationId:string, salesPeriodId:number) {
    return `
    
    select cc.Name AS chargeAndCreditName, cc.UnitCost
    from adjustments.ChargeCredit cc
    join adjustments.ChargeCreditPermission ccp
                     on ccp.ChargeCreditId = cc.ChargeCreditId
    join adjustments.OperationChargeCreditProgram occp
                     on occp.ChargeCreditProgramId = ccp.ChargeCreditProgramId
    join dbo.UserOperation uo
                     on uo.OperationId = occp.OperationId
                     and uo.SalesPeriodId = occp.SalesPeriodId
    join [permissions].RolePermission rp
                     on rp.RoleId = uo.RoleId
                     and rp.PermissionId = ccp.PermissionId

    WHERE occp.operationid =  ${operationId}
    AND occp.salesperiodid =  ${salesPeriodId}
    
           `;
}