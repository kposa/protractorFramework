/// <reference path="../../../../typings/index.d.ts" />

import { SalesRepOperationsFullView } from "../../../..//modules_v3/views/salesRep/SalesRepOperationsFullView";
import { SalesRepOperationFullView } from "../../../../modules_v3/views/salesRep/SalesRepOperationFullView";
import { SharedSalesRepEllipseNavigationTestData } from './SharedSalesRepEllipseNavigationTestData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { itw } from '../../../../modules_v3/helpers/itw';
import { SalesRepEllipsePartialView } from '../../../../modules_v3/views/salesRep/SalesRepEllipsePartialView';

const salesRepOperationsFullView = new SalesRepOperationsFullView();
const operationScreenView = new SalesRepOperationFullView();
const ellipse = new SalesRepEllipsePartialView();

export function sharedSalesRepEllipseNavigationSteps (td:SharedSalesRepEllipseNavigationTestData, description:string, pending?:string) {
    itw(description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.salesRepresentative);

            // navigate to [Operation]//
            salesRepOperationsFullView.search(td.operation.name);
            salesRepOperationsFullView.clickSearchResultMatchingText(td.operation.name);

            // click the first sales rep having an invoice//
            operationScreenView.clickFirstInvoiceHavingLineItems();

            if (td.preEllipseItem) {
                // should navigate to the page with the ellipse we want to test
                ellipse.select(td.preEllipseItem.name);

                // should verify the application navigated to the correct page
                expect(td.preEllipseItem.targetView.isViewDisplayed()).toBeTruthy();
            }

            browser.getCurrentUrl().then((lastUrl)=> {
                td.ellipseItems.forEach(ellipseItem => {

                    // should select the given menu item from the ellipse
                    ellipse.select(ellipseItem.name);

                    // should verify the application redirected the user to the correct page
                    expect(ellipseItem.targetView.isViewDisplayed()).toBeTruthy();

                    //should navigate back to the page containing the ellipse we are testing
                    browser.get(lastUrl);
                });
            });
        }, fail);
    }, pending);
}