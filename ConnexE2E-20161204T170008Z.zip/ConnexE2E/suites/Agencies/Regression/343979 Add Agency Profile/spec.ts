/// <reference path='../../../../typings/index.d.ts' />

import {ButtonMD} from "../../../../modules/master_data/shared/ButtonMD";
import {AgencyMD} from "../../../../modules/master_data/screens/AgencyMD";
import {ProfileGeneralMD} from "../../../../modules/master_data/screens/ProfileGeneralMD";
import {SearchMD2} from "../../../../modules/master_data/screens/SearchMD2";
import {ProfileMD} from "../../../../modules/master_data/screens/ProfileMD";
import {ProfileMittMD} from "../../../../modules/master_data/screens/ProfileMittMD";
import {ProfilePersonalComputersMD} from "../../../../modules/master_data/screens/ProfilePersonalComputersMD";
import TestData343979 from "./testData";
import {bootstrap} from "../../../SharedSteps/bootstrap";
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
	'343979',
	'Add Agency Profile',
	UserRole.MASTER_DATA,
	ApplicationFeature.AGENCIES
);

describe(test.stringify, () => {
    const td = new TestData343979();
    let searchMD = new SearchMD2();
    let agencyMD = new AgencyMD();
    let profileMD = new ProfileMD();
    let profileGeneralMD = new ProfileGeneralMD();
    let profileMittMD = new ProfileMittMD();
    let profilePersonalComputersMD = new ProfilePersonalComputersMD();
    let buttonMD = new ButtonMD();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.masterDataUser);

            // should select sales agency
            searchMD.searchByCriteria(td.agencyId);
            searchMD.selectSearchResultByResultType('Sales agency');

            // should verify sales agency id displayed
            expect(agencyMD.isSalesAgencyIdDisplayedOnBlueRibbon()).toContain(td.agencyId);

            // should verify same hamburger menu displayed
            expect(agencyMD.isHamburgerMenuDisplayed()).toBeTruthy();

            // should click profile tab
            agencyMD.selectTab('PROFILE');

            // should verify cards and icons are displayed
            for (var i = 0; i < td.profileTabCardsAndIcons.length; ++i) {
                expect(profileMD.getCardsAndIconsText().get(i).getText()).toEqual(td.profileTabCardsAndIcons[i]);
            }

            // should verify General card contents
            for (var i = 0; i < td.generalCardContent.length; ++i) {
                expect(profileMD.getGeneralCardContents().get(i).getText()).toEqual(td.generalCardContent[i]);
            }

            // should verify MITT card contents
            for (var i = 0; i < td.mittCardContent.length; ++i) {
                expect(profileMD.getMITTCardContents().get(i).getText()).toContain(td.mittCardContent[i]);
            }

            // should verify Personal Computers card contents
            for (var i = 0; i < td.personalComputersCardContent.length; ++i) {
                expect(profileMD.getPersonalComputersCardContents().get(i).getText()).toContain(td.personalComputersCardContent[i]);
            }

            // should select general card
            agencyMD.selectGeneralCardForProfile();

            // should select certified dairy rep dropdown option
            profileGeneralMD.selectCertifiedDairyRepFromDropdown();

            // should enter name and select date
            profileGeneralMD.enterCertifiedLivestockProfessionalName(td.livestockProfessionalName);
            profileGeneralMD.selectTodaysDateFromDatePicker();

            // should select option from pioneer premium seed treatment
            profileGeneralMD.selectPioneerPremiumSeedTreatmentFromDropdown();

            // should Verify that numbers are increasing or decreasing based on up & down counter.
            profileGeneralMD.enterValueInCheckScannersContainer();

            // should verify the first kernal size dropdown options exist
            profileGeneralMD.clickFirstKernelSizeDropdown();
            for (var i = 0; i < td.kernalDropdownOptions.length; ++i) {
                expect(profileGeneralMD.getAllKernelSizeDropdownOptions().get(i).getText()).toEqual(td.kernalDropdownOptions[i]);
            }
            profileGeneralMD.selectFirstOption();

            // should select first, second and third kernal sizes
            profileGeneralMD.selectFirstKernelSizeFromDropdown();
            profileGeneralMD.selectSecondKernelSizeFromDropdown();
            profileGeneralMD.selectThirdKernelSizeFromDropdown();

            // should select the monthly draw checkbox
            profileGeneralMD.selectMonthlyDrawCheckbox();

            // should verify monthly draw for previous year is read only
            expect(profileGeneralMD.verifyMonthlyDrawIsFalse()).toContain('Monthly Draw:');
            buttonMD.clickSaveButton();

            // should select mitt card and remove all agency scanners
            agencyMD.selectMittCard();
            profileMittMD.removeAllAgencyScanners();
            profileMittMD.addAgencyScanner();
            buttonMD.clickSaveButton();
            expect(profileMittMD.verifyRequiredDisplays()).toContain('Required');

            // should enter serial number
            profileMittMD.enterSerialNumber(td.serialNumber);

            // should select todays date from date picker
            profileMittMD.selectTodaysDateFromDatePicker();
            buttonMD.clickSaveButton();

            // should select personal computers card and remove all agency computers
            agencyMD.selctPersonalComputersCard();
            profilePersonalComputersMD.removeAllAgencyComputers();
            profilePersonalComputersMD.addAgencyComputer();
            buttonMD.clickSaveButton();
            expect(profilePersonalComputersMD.verifyRequiredDisplays()).toContain('Required');

            // should enter model number and serial number
            profilePersonalComputersMD.enterModelNumber(td.modelNumber);
            profilePersonalComputersMD.enterSerialNumber(td.serialNumber);
            buttonMD.clickSaveButton();
            
        }, fail);
    });
});