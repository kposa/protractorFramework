/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;

export class ProfileMD {

    private profileTabParent = $('div[ng-if="vm.hasProfileTabBeenSelected"]');
    private generalCardParent = this.profileTabParent.$('md-card[ng-click="vm.navigateToGeneral()"]');
    private mittCardParent = this.profileTabParent.$('md-card[ng-click="vm.navigateToMitt()"]');
    private personalComputersCardParent = this.profileTabParent.$('md-card[ng-click="vm.navigateToPersonalComputers()"]');


    public getCardsAndIconsText(): ElementArrayFinder {
        let allResults = this.profileTabParent.$$('div.card-header.grey-text').$$('span');
        return allResults;
    }

    public getGeneralCardContents(): ElementArrayFinder {
        let allResults = this.generalCardParent.$$('div').get(1).$$('p');
        return allResults;
    }

    public getMITTCardContents(): ElementArrayFinder {
        let allResults = this.mittCardParent.$$('div').get(1).$$('p');
        return allResults;
    }

    public getPersonalComputersCardContents(): ElementArrayFinder {
        let allResults = this.personalComputersCardParent.$$('div').get(1).$$('p');
        return allResults;
    }
}