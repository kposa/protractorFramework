/// <reference path="../../../../typings/index.d.ts" />

import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import { getRandomNumberAsString } from '../../../../modules_v3/helpers/utilityHelpers';
import { existingData } from '../../../../modules_v3/testdata/sharedQueries/existingData/index';
import { createAccountDescriptionProc } from '../../../../modules_v3/testdata/sharedQueries/createAccountDescription/index';

export class sharedViewAndUpdatePVCTestData extends BaseTestData {
    public orgUnit: string;
    public searchText: string;
    public randomNumberAsString: string;

    protected queries: (() => Promise<any>)[] = [
        existingData(this.queryService, this),
        createAccountDescriptionProc(this.queryService, this)
    ];

    constructor (searchText: string, orgUnit: string) {
        super();
        this.searchText = searchText;
        this.orgUnit = orgUnit;
        this.randomNumberAsString = getRandomNumberAsString();
    }
}