/// <reference path="../../typings/index.d.ts" />

import { Entity } from './Entity';

export interface User extends Entity {}