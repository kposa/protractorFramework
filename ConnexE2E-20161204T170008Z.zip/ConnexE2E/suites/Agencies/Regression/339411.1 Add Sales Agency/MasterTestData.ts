/// <reference path='../../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import AddSalesAgencyData from './AddSalesAgencyData';
import UpdateSalesAgencyData from './UpdateSalesAgencyData';

export default class MasterTestData extends BaseTestData {
    public addSalesAgencyData: AddSalesAgencyData = new AddSalesAgencyData();
    public updateSalesAgencyData: UpdateSalesAgencyData = new  UpdateSalesAgencyData();
}