/**
 * Main entry point. Called once DOM has loaded.
 */
function onDOMReady () {
    highlightHash('headerHighlight');
    anchorHeaders();
}

/**
 * Add a highlight class to the element whose id matches url hash
 */
function highlightHash (highlightClass) {
    if (window.location.hash) {
        const headers = document.querySelectorAll(window.location.hash);
        for (var i = 0; i < headers.length; ++i) {
            const header = headers[i];
            const classes = header.className.split(' ');
            classes.push(highlightClass);
            header.className = classes.join(' ');
        }
    }
}

function anchorHeaders () {
    const tags = ['h2', 'h3', 'h4', 'h5', 'h6'];
    const headers = document.querySelectorAll(tags.join(', '));
    for (var i = 0; i < headers.length; ++i) {
        const header = headers[i];
        const headerHTML = header.innerHTML;
        const linkedHTML = '<a href="#'+header.id+'">'+headerHTML+'</a>';
        header.innerHTML = linkedHTML;
    }
}

/** Wait until DOM has loaded before executing javascript */
if(document.readyState !== "complete") {
    window.addEventListener("DOMContentLoaded", function () { onDOMReady (); }, false);
    window.addEventListener("hashchange", function () { highlightHash(); }, false);
}