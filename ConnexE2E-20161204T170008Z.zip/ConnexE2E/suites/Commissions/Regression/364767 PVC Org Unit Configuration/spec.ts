/// <reference path="../../../../typings/index.d.ts" />

import MasterDataMasterSearchFullView from '../../../../modules_v3/views/masterData/MasterDataMasterSearchFullView';
import MasterDataNavigationMenuPartialView from '../../../../modules_v3/views/masterData/MasterDataNavigationMenuPartialView';
import MasterDataCommissionsTabFullView from '../../../../modules_v3/views/masterData/MasterDataCommissionsTabFullView';
import { MasterDataProductValueCommissionFullView } from '../../../../modules_v3/views/masterData/MasterDataProductValueCommissionFullView';
import { TestData364767 } from './testData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
    '364767',
    'PVC Configuration Across Org Units',
    UserRole.MASTER_DATA,
    ApplicationFeature.COMMISSIONS
);

describe(test.stringify, () => {
    const masterDataMasterSearchFullView = new MasterDataMasterSearchFullView();
    const masterDataCommissionsTabFullView = new MasterDataCommissionsTabFullView();
    const masterDataProductValueCommissionFullView = new MasterDataProductValueCommissionFullView();
    const masterDataNavigationMenuPartialView = new MasterDataNavigationMenuPartialView();
    const td = new TestData364767();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.masterDataUser);

            // set pvc info for the grandparent of 'randSalesAgency', its Area is BA
            masterDataMasterSearchFullView.search(td.randArea);
            masterDataMasterSearchFullView.selectFilterContainingText('Areas');
            masterDataMasterSearchFullView.clickSearchResultContainingText(td.randArea);

            expect(masterDataCommissionsTabFullView.getItemCount()).toBeGreaterThan(0);
            expect(masterDataCommissionsTabFullView.hasGivenYearCommission(td.salesPeriod.year)).toBeTruthy();
            expect(masterDataCommissionsTabFullView.hasGivenYearCommission(td.salesPeriod.year - 1)).toBeTruthy();

            // click [Commission] for [Current Year], sales year 2017
            masterDataCommissionsTabFullView.clickGivenYearCommission(td.salesPeriod.year);

            // fill in form
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Acceleration Point', td.randomAreaVal);
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Percent Over Acceleration Point', td.randomAreaVal);
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Percent Under Acceleration Point', td.randomAreaVal);

            // submit form
            expect(masterDataProductValueCommissionFullView.formCanBeSubmitted()).toBeTruthy();
            masterDataProductValueCommissionFullView.submitForm();

            // go back to [Product Value Commissions] page
            masterDataProductValueCommissionFullView.clickBack();

            // return to the [Search] screen in hamburger menu
            masterDataNavigationMenuPartialView.selectOptionFromHamburgerMenu('Search');

            // search for the appropriate Territory, BAE is parent to the Sales Agency in question and child of BA
            masterDataMasterSearchFullView.search(td.randTerritory);
            masterDataMasterSearchFullView.selectFilterContainingText('Territories');
            masterDataMasterSearchFullView.clickSearchResultContainingText(td.randTerritory);

            expect(masterDataCommissionsTabFullView.getItemCount()).toBeGreaterThan(0);
            expect(masterDataCommissionsTabFullView.hasGivenYearCommission(td.salesPeriod.year)).toBeTruthy();
            expect(masterDataCommissionsTabFullView.hasGivenYearCommission(td.salesPeriod.year - 1)).toBeTruthy();

            // click [Commission] for [Current Year], sales year 2017 in Territory BAE
            masterDataCommissionsTabFullView.clickGivenYearCommission(td.salesPeriod.year);

            // PVC values for BAE should default to match it's parent Area, BA
            expect(masterDataProductValueCommissionFullView.getInputValueByLabelContainingText('Acceleration Point')).toEqual(`${td.randomAreaVal} %`);
            expect(masterDataProductValueCommissionFullView.getInputValueByLabelContainingText('Percent Over Acceleration Point')).toEqual(`${td.randomAreaVal} %`);
            expect(masterDataProductValueCommissionFullView.getInputValueByLabelContainingText('Percent Under Acceleration Point')).toEqual(`${td.randomAreaVal} %`);

            // go back to [Product Value Commissions] page
            masterDataProductValueCommissionFullView.clickBack();

            // return to the [Search] screen in hamburger menu
            masterDataNavigationMenuPartialView.selectOptionFromHamburgerMenu('Search');

            // search for the appropriate Sales Agency, Chris Britton (1001756)
            masterDataMasterSearchFullView.search(td.randSalesAgencyId);
            masterDataMasterSearchFullView.selectFilterContainingText('Sales agencies');
            masterDataMasterSearchFullView.clickSearchResultContainingText(td.randSalesAgencyId);

            // click the [Commission] tab, then click the [Product Value] card
            masterDataCommissionsTabFullView.clickTabContainingText('Commission');
            masterDataCommissionsTabFullView.clickCardContainingText('Product Value');

            // verify PVC for the Sales Agency defaults to match its parent Area values for the current sales year
            expect(masterDataProductValueCommissionFullView.getCurrentSalesYearAccelerationPoint()).toEqual(`${td.randomAreaVal} %`);
            expect(masterDataProductValueCommissionFullView.getCurrentSalesYearOverAccelerationPoint()).toEqual(`${td.randomAreaVal} %`);
            expect(masterDataProductValueCommissionFullView.getCurrentSalesYearUnderAccelerationPoint()).toEqual(`${td.randomAreaVal} %`);

            // bring up the override menu for acceleration points
            masterDataProductValueCommissionFullView.displayCurrentYearSalesAgencyConfig('Override acceleration point');

            // reset the pvc values at the sales agency level for current sales year
            masterDataProductValueCommissionFullView.fillSalesAgencyAccelerationPoint(td.randomSalesAgencyVal);
            masterDataProductValueCommissionFullView.fillSalesAgencyOverAccelerationPoint(td.randomSalesAgencyVal);
            masterDataProductValueCommissionFullView.fillSalesAgencyUnderAccelerationPoint(td.randomSalesAgencyVal);

            // submit sales agency commission values
            masterDataProductValueCommissionFullView.submitSalesAgencyPVC();

            // go back to [Commissions] tab
            masterDataProductValueCommissionFullView.clickBack();

            // return to the [Search] screen in hamburger menu
            masterDataNavigationMenuPartialView.selectOptionFromHamburgerMenu('Search');

            // search for the appropriate Territory, BAE is parent to the Sales Agency in question and child of BA
            masterDataMasterSearchFullView.search(td.randTerritory);
            masterDataMasterSearchFullView.selectFilterContainingText('Territories');
            masterDataMasterSearchFullView.clickSearchResultContainingText(td.randTerritory);

            expect(masterDataCommissionsTabFullView.getItemCount()).toBeGreaterThan(0);
            expect(masterDataCommissionsTabFullView.hasGivenYearCommission(td.salesPeriod.year)).toBeTruthy();
            expect(masterDataCommissionsTabFullView.hasGivenYearCommission(td.salesPeriod.year - 1)).toBeTruthy();

            // click [Commission] for [Current Year], sales year 2017 in Territory BAE
            masterDataCommissionsTabFullView.clickGivenYearCommission(td.salesPeriod.year);

            // fill in territory form with new values
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Acceleration Point', td.randomParent);
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Percent Over Acceleration Point', td.randomParent);
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Percent Under Acceleration Point', td.randomParent);

            // go back to [Product Value Commissions] page
            masterDataProductValueCommissionFullView.clickBack();

            // return to the [Search] screen in hamburger menu
            masterDataNavigationMenuPartialView.selectOptionFromHamburgerMenu('Search');

            // search for the appropriate Sales Agency, Chris Britton (1001756)
            masterDataMasterSearchFullView.search(td.randSalesAgencyId);
            masterDataMasterSearchFullView.selectFilterContainingText('Sales agencies');
            masterDataMasterSearchFullView.clickSearchResultContainingText(td.randSalesAgencyId);

            // navigate to the product value commissions screen for sales agency
            masterDataCommissionsTabFullView.clickTabContainingText('Commission');
            masterDataCommissionsTabFullView.clickCardContainingText('Product Value');

            // verify that the sales agency values have not defaulted to match territory
            expect(masterDataProductValueCommissionFullView.getCurrentSalesYearAccelerationPoint()).toEqual(`${td.randomSalesAgencyVal} %`);
            expect(masterDataProductValueCommissionFullView.getCurrentSalesYearOverAccelerationPoint()).toEqual(`${td.randomSalesAgencyVal} %`);
            expect(masterDataProductValueCommissionFullView.getCurrentSalesYearUnderAccelerationPoint()).toEqual(`${td.randomSalesAgencyVal} %`);
        }, fail);
    });
});