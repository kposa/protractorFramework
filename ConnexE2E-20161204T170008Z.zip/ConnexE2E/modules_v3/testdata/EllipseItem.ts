import {convertPageUrlPatternToRegex } from '../helpers/utilityHelpers';
import { IView } from '../interfaces/common/IView';

export class EllipseItem {
    private _name:string;
    private _targetPageUrlPattern:RegExp;

    constructor (name:string, targetPageUrlPattern:string) {
        this._name = name;
        this._targetPageUrlPattern = convertPageUrlPatternToRegex(targetPageUrlPattern);
    }

    public get name ():string {
        return this._name;
    }

    public get targetPageUrlPattern ():RegExp {
        return this._targetPageUrlPattern;
    }
}

export class EllipseItem2 {

    private _name:string;
    private _targetView:IView;

    constructor (name:string, targetView:IView) {
        this._name = name;
        this._targetView = targetView;
    }

    public get name ():string {
        return this._name;
    }

    public set name (value:string) {
        this._name = value;
    }

    public get targetView ():IView {
        return this._targetView;
    }

    public set targetView (value:IView) {
        this._targetView = value;
    }
}