/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import { filterElements, isActive, containingText } from '../../../modules_v3/helpers/filterElementHelpers';
import ElementArrayFinder = protractor.ElementArrayFinder;
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

export class PersonGeneralMD {

    public updateFirstName(firstName: string): void {
        let firstNameInputContainer = $('input[ng-model="vm.firstName"]');
        firstNameInputContainer.clear();
        firstNameInputContainer.sendKeys(firstName);
    }

    public updateMiddleName(middleName: string): void {
        let middleNameInputContainer = $('input[ng-model="vm.middleName"]');
        middleNameInputContainer.clear();
        middleNameInputContainer.sendKeys(middleName);
    }

    public updateLastName(lastName: string): void {
        let lastNameInputContainer = $('input[ng-model="vm.lastName"]');
        lastNameInputContainer.clear();
        lastNameInputContainer.sendKeys(lastName);
    }

    public updatePrefferedName(prefferedName: string): void {
        let prefferedNameInputContainer = $('input[ng-model="vm.preferredName"]');
        prefferedNameInputContainer.clear();
        prefferedNameInputContainer.sendKeys(prefferedName);
    }

    public selectOptionFromSuffixDropdown(suffix: string): void {
        let suffixDropdown = $('md-select[ng-model="vm.suffix.Value"]');
        let dropdownOption = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(suffix)
            ]
            )().first();
        clickElement(suffixDropdown);
        clickElement(dropdownOption);
    }


}