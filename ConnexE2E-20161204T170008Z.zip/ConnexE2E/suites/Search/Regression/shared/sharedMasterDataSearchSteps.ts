/// <reference path="../../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;

import MasterDataMasterSearchFullView from '../../../../modules_v3/views/masterData/MasterDataMasterSearchFullView';
import { bootstrap } from '../../../SharedSteps/bootstrap';

import TestDataMasterDataSearch from './sharedMasterDataSearchTestData';
import { itw } from '../../../../modules_v3/helpers/itw';

export default function sharedMasterDataSearchSteps (description:string, td: TestDataMasterDataSearch, pending?: string) {
    const masterDataMasterSearchFullView = new MasterDataMasterSearchFullView();

    itw(description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.masterDataUser);

            // should select [Category] from [Categories]
            masterDataMasterSearchFullView.selectFilterContainingText(td.category);
            masterDataMasterSearchFullView.getCountOfFilterContainingText(td.category).then(count => {
                if (count > 100) {
                    expect(masterDataMasterSearchFullView.getSearchResultCount()).toEqual(100);
                    expect(masterDataMasterSearchFullView.getSearchResultsCountByContainingResultType(td.resultType)).toEqual(100);
                } else {
                    expect(masterDataMasterSearchFullView.getSearchResultCount()).toEqual(count);
                    expect(masterDataMasterSearchFullView.getSearchResultCountByMatchingResultType(td.resultType)).toEqual(count);
                }
            });

            // should search for [Search Term]
            masterDataMasterSearchFullView.search(td.searchTerm);
            expect(masterDataMasterSearchFullView.getSearchResultsCountByContainingResultType(td.resultType))
                .toEqual(masterDataMasterSearchFullView.getSearchResultCount());

            // should select [All] from [Categories]
            masterDataMasterSearchFullView.selectAllFilter();
        }, fail);
    }, pending);
}