/// <reference path="../../../typings/index.d.ts" />

export interface IFeatureFlagsFullView {
    resetAllFlags():void;
}