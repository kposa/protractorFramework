/// <reference path="../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;

import {ITabbableView} from '../common/ITabbableView';
import {IListableView} from '../common/IListableView';

export interface ICountryFullView extends ITabbableView {
    clickCommissionsTab():void;
}