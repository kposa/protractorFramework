/// <reference path="../../../../typings/index.d.ts" />

import { SharedSalesRepEllipseNavigationTestData } from '../shared/SharedSalesRepEllipseNavigationTestData';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { sharedSalesRepEllipseNavigationSteps } from '../shared/SharedSalesRepEllipseNavigationSteps';

const test = new TestCase(
    '273809',
    'Ellipse Menu - Invoice Account Description Page',
    UserRole.SALES_REP,
    ApplicationFeature.NAVIGATIONS
);

describe(test.stringify, () => {
    const td = new SharedSalesRepEllipseNavigationTestData();

    td.preEllipseItem = td.availableEllipseItems.accountDescription;

    td.ellipseItems = [
        td.availableEllipseItems.invoice,
        td.availableEllipseItems.businessPartners,
        td.availableEllipseItems.newProposal
    ];

    sharedSalesRepEllipseNavigationSteps(td, test.description);
});