/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;
import {MaterialDesignElement} from '../../shared/MaterialDesignElement';
import {Helpers} from '../../shared/Helpers';
import {DeferredPaymentLoanApplicationFormSR} from './DeferredPaymentLoanApplicationFormSR';
import {textContainsText} from '../../../modules_v3/helpers/utilityHelpers';

let md = new MaterialDesignElement();
let hlp = new Helpers();
let dpForm = new DeferredPaymentLoanApplicationFormSR();

export class DeferredPaymentBusinessConfirmationFormSR {

    private taxIdField = $('section[value="vm.customerTaxIdNumber"]');
    private ssnField = $('section[value="vm.coborrowerTaxIdNumber"]');
    private dateOfIncorporationField = $('section[value="vm.dateOfIncorporation"]');
    private presidentName = $('section[value="vm.presidentName"]');

    public enterTaxId(taxId?: string): void {
        if (!taxId) taxId = '123456789';
        md.clickFormField(this.taxIdField);
        md.enterInputText(this.taxIdField, taxId);
        this.focusOutOfAllFields();
    }

    // 2 days ago
    public enterDateOfIncorporation(): void {
        md.clickFormField(this.dateOfIncorporationField);
        md.enterInputText(this.dateOfIncorporationField, hlp.getFormattedDate(2, -2));
        this.focusOutOfAllFields();
    }

    public enterPresidentName(): void {
        let lenderName = 'Autotest President';
        md.clickFormField(this.presidentName);
        md.enterInputText(this.presidentName, lenderName);
        this.focusOutOfAllFields();
    }

    public enterSSN(ssn?: string): void {
        if (!ssn) ssn = '123456789';
        md.clickFormField(this.ssnField);
        md.enterInputText(this.ssnField, ssn);
        this.focusOutOfAllFields();
    }

    public enterDateOfBirth(): void {
        dpForm.enterDateOfBirth();
    }

    public enterRequestedCreditLimit(val: number): void {
        dpForm.enterRequestedCreditLimit(val);
    }

    public clickConfirm(): void {
        dpForm.clickConfirm();
    }

    private focusOutOfAllFields(): void {
        dpForm.focusOutOfAllFields();
    }

    get preApprovedCreditLimitValue(): Promise<string> {
        return dpForm.preApprovedCreditLimitValue;
    }

    get isRequestedCreditLimitFormatted(): Promise<boolean> {
        return dpForm.isRequestedCreditLimitFormatted;
    }

    get isTaxIdFormatted(): Promise<boolean> {
        return this.taxIdField.getText().then((txt) => {
            return textContainsText(txt, '-');
        });
    }

    get isSSNFormatted(): Promise<boolean> {
        return md.getDisplayValue(this.ssnField).getText().then((ssn) => {
            return dpForm.ssnIsFormatted(ssn);
        });
    }

    get isDateOfBirthFormatted(): Promise<boolean> {
        return md.getDisplayValue(dpForm.dateOfBirthField).getText().then((dob) => {
            return dpForm.dateIsFormatted(dob);
        });
    }
}