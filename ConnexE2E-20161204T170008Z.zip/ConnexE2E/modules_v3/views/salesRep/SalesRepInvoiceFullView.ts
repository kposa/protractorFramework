/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;
import Promise = protractor.promise.Promise;
import { IInvoiceFullView } from "../../interfaces/fullViews/IInvoiceFullView";
import { clickElement } from '../../helpers/clickElementHelpers';
import { filterElements, isActive, matchingText } from '../../helpers/filterElementHelpers';
import { IView } from '../../interfaces/common/IView';
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';

export class SalesRepInvoiceFullView implements IView, IInvoiceFullView {

    isViewDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('section.invoice'));
    }

    private getAddLineItemButtonByProductLine (productline?:string):ElementFinder {
        let filterFn = [ isActive(true) ];
        if (productline) filterFn.push(matchingText(productline, e => e.$(`div.flex-expand`)));
        return filterElements($$('div.product-line-header'), filterFn)().first().$('button');
    }

    addLineItem (productLine?:string):void {
        clickElement(this.getAddLineItemButtonByProductLine(productLine));
    }

    clickPreviewInvoice ():void {
        var previewInvoiceIcon = $('i[ng-hide="vm.previewMenu.loading()"]');
        clickElement(previewInvoiceIcon);
    }

    clickShowButtonToPreviewInvoice ():void {
        var showButtonToPreviewInvoice = $('button.pm-flat-button.primary').$('div.pm-button-text');
        if (isPresentAndDisplayed(showButtonToPreviewInvoice)) clickElement(showButtonToPreviewInvoice);
    }

    previewInvoicePresent ():Promise<boolean> {
        let previewinvoiceIcon = $('i[ng-hide="vm.previewMenu.loading()"]');
        return isPresentAndDisplayed(previewinvoiceIcon);
    }
}