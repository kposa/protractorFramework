/// <reference path="../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;

import {ITabbableView} from '../common/ITabbableView';
import {IFillableFormView} from "../common/IFillableFormView";
import {IBackNavigableView} from '../common/IBackNavigableView';

// represents the landing page after selecting the [Product Value] card in the [Commissions] tab
export interface IProductValueCommissionFullView extends ITabbableView, IFillableFormView, IBackNavigableView {

}