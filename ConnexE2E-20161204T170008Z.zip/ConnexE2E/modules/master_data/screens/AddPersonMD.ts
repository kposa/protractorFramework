/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import all = protractor.promise.all;
import ElementArrayFinder = protractor.ElementArrayFinder;
import { filterElements, isActive, containingText } from '../../../modules_v3/helpers/filterElementHelpers';
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

export class AddPersonMD {

    private addPersonLayoutParent = $('div.md-dialog-content.layout-row.flex');

    get verifyAddPersonDisplayed(): Promise<string> {
        return $('md-dialog.md-dialog-size.agency-add-person-associate-dialog').getText();
    }

    get verifyCancelButtonDisplayed(): Promise<boolean> {
        let cancelButton = $('button[ng-click="vm.cancel()"]');
        return cancelButton.isDisplayed();
    }

    public verifyRequiredDisplays(): Promise<string> {
        return this.addPersonLayoutParent.getText();
    }

    public selectSearchResult(): void {
        let searchResult = $$('md-card-content[ng-click="vm.setExistingPerson(searchResult)"]').get(1);
        clickElement(searchResult);
    }

    public enterFirstName(personFirstName: string): void {
        let firstNameContainer = $('input[ng-model="vm.firstName"]');                        //delete
        firstNameContainer.sendKeys(personFirstName);
    }

    public enterMiddleName(personMiddleName: string): void {
        let middleNameContainer = $('input[ng-model="vm.middleName"]');
        middleNameContainer.sendKeys(personMiddleName);
    }

    public enterLastName(personLastName: string): void {
        let lastNameContainer = $('input[ng-model="vm.lastName"]');
        lastNameContainer.sendKeys(personLastName);
    }

    public enterPreferredName(personPreferredName: string): void {
        let lastNameContainer = $('input[ng-model="vm.preferredName"]');
        lastNameContainer.sendKeys(personPreferredName);
    }

    public clickSuffixDropdown(): void {
        let suffixDropdown = $('md-select[ng-model="vm.suffix.Value"]');
        clickElement(suffixDropdown);
    }

    public clickPersonTypeDropdown(): void {
        let personTypeDropdown = $('md-select[ng-model="vm.agencyPersonTypeId"]');
        clickElement(personTypeDropdown);
    }

    public clickPersonStatusDropdown(): void {
        let personStatusDropdown = $('md-select[ng-model="vm.agencyPersonStatusId"]');
        clickElement(personStatusDropdown);
    }

    public selectOptionFromSuffixDropdown(suffix:string): void {
        let dropdownOption = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(suffix)
            ]
        )().first();
        clickElement(dropdownOption);
    }

    public selectOptionFromPersonTypeDropdown(personType: string): void {
        let dropdownOption = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(personType)
            ]
        )().first();
        clickElement(dropdownOption);
    }


    public selectOptionfromPersonStatusDropdown(personStatus: string): void {
        let dropdownOption = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(personStatus)
            ]
        )().first();
        clickElement(dropdownOption);
    }

    public selectEnglishLanguageFromDropdown(): void {
        let languageDropdown = $('md-select[name="language"]');
        let englishDropdownOption = $('md-option[value="en-US"]');
        clickElement(languageDropdown);
        clickElement(englishDropdownOption);
    }

    public clickClearButton(): void {
        let clearButton = $('button[ng-click="vm.clear()"]');
        clickElement(clearButton);
    }

    public clickSaveButtonForFirstCard(): void {
        let saveButton = $('button[ng-click="vm.setSubmitAttempted()"]');
        clickElement(saveButton);
    }

    public getAllSuffixDropdownOptions(): ElementArrayFinder {
        let allResults = $$('md-option[ng-repeat="suffix in vm.suffixes"]').$$('div.md-text');
        return allResults;
    }

    public getAllPersonTypeDropdownOptions(): ElementArrayFinder {
        let allResults = $$('md-option[ng-repeat="agencyPersonType in vm.agencyPersonTypes"]').$$('div.md-text');
        return allResults;
    }

    public getAllPersonStatusDropdownOptions(): ElementArrayFinder {
        let allResults = $$('md-option[ng-repeat="agencyPersonStatus in vm.agencyPersonStatuses"]').$$('div.md-text');
        return allResults;
    }

}