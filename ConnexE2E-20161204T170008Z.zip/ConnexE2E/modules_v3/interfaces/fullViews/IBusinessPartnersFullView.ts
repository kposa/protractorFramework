/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;

export interface IBusinessPartnersFullView {
    clickBalancesButtonByName (customerName:string):void;
    clickAgreementsButtonByName(customerName:string):void;
}