/// <reference path="../../../../typings/index.d.ts" />
import Promise = protractor.promise.Promise;

import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';
import {
    associateSellersWithPioneerBalanceNonZeroPriorSalesPeriod,
    associateSellersWithPioneerBalanceNonZeroPriorSalesPeriodResults
} from './queries';

export default class TestData416677 extends BaseTestData {

    protected queries:(() => Promise<any>)[] = [
        this.getAssociateSellersWithPioneerBalanceNonZeroPriorSalesPeriod()
    ];

    private getAssociateSellersWithPioneerBalanceNonZeroPriorSalesPeriod ():() => Promise<associateSellersWithPioneerBalanceNonZeroPriorSalesPeriodResults> {
        return () => {
            const sql = associateSellersWithPioneerBalanceNonZeroPriorSalesPeriod(this.salesPeriod.id);
            const results = this.queryService.executeSql<associateSellersWithPioneerBalanceNonZeroPriorSalesPeriodResults[]>(sql);

            return results
                .then(data => {
                    const row = <associateSellersWithPioneerBalanceNonZeroPriorSalesPeriodResults>getRandomQueryResult(data);

                    this.salesRepresentatives.push({
                        id: row.salesRepId,
                        name: row.salesRepName
                    });

                    this.operations.push({
                        id: row.operationId,
                        name: row.operationName
                    });

                    this.salesAgencies.push({
                        id: row.salesAgencyId,
                        name: row.salesAgencyName
                    });

                    return row;
                });
        };
    }
}










