/// <reference path="../../../../typings/index.d.ts" />

import Promise = protractor.promise.Promise;
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';
import { canadianUserOperations, canadianUserOperationsResults } from './queries';
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';

export class TestData319936 extends BaseTestData {

    public discountName:string;
    public taxNames: Array<string> = ['Tax','Harmonized','Provincial'];
    public canadianSalesRepUserId:string  = 'roybb@phiext.com';

    protected queries: (() => Promise<any>)[] = [
        this.getCanadianUserOperations()
    ];

    private getCanadianUserOperations (): () => Promise<canadianUserOperationsResults> {
        return () => {
            const sql = canadianUserOperations(this.canadianSalesRepUserId, this.salesPeriod.id);
            const results = this.queryService.executeSql<canadianUserOperationsResults[]>(sql);

            return results
                .then(data => {
                    const row = <canadianUserOperationsResults>getRandomQueryResult(data);

                    this.operations.push({
                        id: row.operationId,
                        name: row.operationName
                    });

                    this.businessPartners.push({
                        id: row.customerId,
                        name: row.customerName
                    });

                    return row;
                });
        };
    }
}