/// <reference path='../../../typings/index.d.ts' />
import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;
import { IView } from '../../interfaces/common/IView';
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';

export class SalesSupportSharesPageFullView implements IView {

    isViewDisplayed(): Promise<boolean> {
        return isPresentAndDisplayed($('section.pm-scrollable-area.pm-vertical'));
    }

}
