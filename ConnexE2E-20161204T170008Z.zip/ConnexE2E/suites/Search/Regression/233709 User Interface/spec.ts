/// <reference path="../../../../typings/index.d.ts" />

import { bootstrap } from '../../../SharedSteps/bootstrap';
import { itw } from '../../../../modules_v3/helpers/itw';
import TestData233709 from './testData';
import SearchDrawerPartialView from '../../../../modules_v3/views/shared/SearchDrawerPartialView';
import { SalesRepOperationsFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationsFullView';
import { TestCase, UserRole, ApplicationFeature } from '../../../../reporters/LogReporter/testConstants';

const test = new TestCase(
    '233709',
    'User Interface',
    UserRole.SALES_REP,
    ApplicationFeature.SEARCH
);

describe(test.stringify, () => {
    const td = new TestData233709();
    const salesRepOperationsFullView = new SalesRepOperationsFullView();
    const searchDrawerPartialView = new SearchDrawerPartialView();

    itw('User Interface', () => {
        // bootstrap (load, login, reset feature flags, impersonate)
        bootstrap(td.salesRepUser);

        //should scroll to the letter
        salesRepOperationsFullView.scrollToLetter('G');

        //should scroll to the letter
        salesRepOperationsFullView.scrollToLetter('A');

        // should search operation
        salesRepOperationsFullView.search(td.text);

        //should check operation list is filtered to only display one entry
        expect(salesRepOperationsFullView.getSearchResultCount()).toEqual(1);

        //should check operation list is filtered to only display the entry for Prairie Sky Game Ranch & Guest Lodge LLC
        expect(salesRepOperationsFullView.getSearchResultContentByContainingId(td.text))
            .toContain(td.operationName);

        //should remove everything from search field and click search icon
        searchDrawerPartialView.inputSearch('');
        searchDrawerPartialView.submitSearch();

        //should display unfiltered operation list again
        expect(salesRepOperationsFullView.getSearchResultCount()).toBeGreaterThan(1);
    });

});