/// <reference path="../../../../typings/index.d.ts" />
import Promise = protractor.promise.Promise;

import {getRandomQueryResult} from '../../../../modules_v3/helpers/utilityHelpers';
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import {sharedDPAgreementQuery, sharedDPAgreementQueryResults} from "./SharedDPAgreementQueries";

export class SharedDPAgreementTestData extends BaseTestData {
    public customerCultureName:string;
    public customerType:number;
    public customerIsRaboBank:boolean = false;
    public customerHasMissingCreditLimit:boolean;
    public customerHasMissingAgreement:boolean;
    public excludeCustomerRegion:string;
    public useAlternateNavigationToDPAgreement:boolean = false;
    protected queries = [
        this.populateUserData()
    ];

    private populateUserData():() => Promise<sharedDPAgreementQueryResults> {
        return () => {
            const sql = sharedDPAgreementQuery(
                this.salesPeriod.id,
                this.customerType,
                this.customerIsRaboBank,
                this.customerCultureName,
                this.customerHasMissingCreditLimit,
                this.customerHasMissingAgreement,
                this.excludeCustomerRegion
            );

            const results = this.queryService.executeSql<sharedDPAgreementQueryResults[]>(sql);

            return results
                .then(data => {
                    const row = <sharedDPAgreementQueryResults>getRandomQueryResult(data);

                    this.salesRepresentatives.push({
                        id: row.salesRepId,
                        name: row.salesRepName
                    });

                    this.operations.push({
                        id: row.operationId,
                        name: row.operationName
                    });

                    this.businessPartners.push({
                        id: row.customerId,
                        name: row.customerName
                    });

                    return row;
                });
        };
    }
}