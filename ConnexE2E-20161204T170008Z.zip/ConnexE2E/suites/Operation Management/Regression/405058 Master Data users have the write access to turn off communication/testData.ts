/// <reference path="../../../../typings/index.d.ts" />

import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import { getSalesRepsInUSCA } from '../../../../modules_v3/testdata/sharedQueries/salesRepsInUSCA/index';

export class TestData405058 extends BaseTestData {
    protected queries:(() => Promise<any>)[] = [
        getSalesRepsInUSCA(this.queryService, this)
    ];
}