/// <reference path="../../../../typings/index.d.ts" />

import MasterDataMasterSearchFullView from '../../../../modules_v3/views/masterData/MasterDataMasterSearchFullView';
import MasterDataCommissionsTabFullView from '../../../../modules_v3/views/masterData/MasterDataCommissionsTabFullView';
import { MasterDataOtherCommissionsFullView } from '../../../../modules_v3/views/masterData/MasterDataOtherCommissionsFullView';
import { sharedOtherCommissionTestData } from '../shared/sharedOtherCommissionTestData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
    '442989',
    'Other Commissions w/Classification Window Field Validations',
    UserRole.MASTER_DATA,
    ApplicationFeature.COMMISSIONS
);

describe(test.stringify, () => {
    const masterDataMasterSearchFullView = new MasterDataMasterSearchFullView();
    const masterDataCommissionsTabFullView = new MasterDataCommissionsTabFullView();
    const masterDataOtherCommissionsFullView = new MasterDataOtherCommissionsFullView();
    const td = new sharedOtherCommissionTestData();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.masterDataUser);

            // select a random sales agency
            masterDataMasterSearchFullView.search(td.randSalesAgencyId);
            masterDataMasterSearchFullView.selectFilterContainingText('Sales agencies');
            masterDataMasterSearchFullView.clickSearchResultContainingText(td.randSalesAgencyId);

            // navigate to the sales agency Other Commission screen
            masterDataCommissionsTabFullView.clickTabContainingText('Commission');
            masterDataCommissionsTabFullView.clickCardContainingText('Other Commission');

            // add a new commission with classification
            masterDataOtherCommissionsFullView.addCommission('With classification');

            // verify sales year field is required
            masterDataOtherCommissionsFullView.verifySalesYearFieldRequired('Required');
            masterDataOtherCommissionsFullView.selectSalesYear((td.salesPeriod.year + 3).toString());

            // verify classification field is required
            masterDataOtherCommissionsFullView.verifyClassificationFieldRequired('Required');

            // verify all options are available
            expect(masterDataOtherCommissionsFullView.verifyClassificationDropDownOption('P')).toBeTruthy();
            expect(masterDataOtherCommissionsFullView.verifyClassificationDropDownOption('P1')).toBeTruthy();
            expect(masterDataOtherCommissionsFullView.verifyClassificationDropDownOption('P2')).toBeTruthy();
            expect(masterDataOtherCommissionsFullView.verifyClassificationDropDownOption('P3')).toBeTruthy();
            expect(masterDataOtherCommissionsFullView.verifyClassificationDropDownOption('C')).toBeTruthy();
            expect(masterDataOtherCommissionsFullView.verifyClassificationDropDownOption('C1')).toBeTruthy();
            expect(masterDataOtherCommissionsFullView.verifyClassificationDropDownOption('C2')).toBeTruthy();
            expect(masterDataOtherCommissionsFullView.verifyClassificationDropDownOption('C3')).toBeTruthy();

            masterDataOtherCommissionsFullView.selectClassification('C');

            // verify program field is required
            // SAM, Accelerated, Associate Seller, Promoter, Other
            masterDataOtherCommissionsFullView.verifyProgramFieldRequired('Required');
            masterDataOtherCommissionsFullView.selectProgram('Associate Seller');

            // select a valid type
            masterDataOtherCommissionsFullView.selectType('All Revenue');

            // enter a valid percent
            masterDataOtherCommissionsFullView.enterPercentValue(td.randomValue);

            // verify negative numbers can't be entered into the Max Commission field
            masterDataOtherCommissionsFullView.enterMaxCommission('-1');
            expect(masterDataOtherCommissionsFullView.getMaxCommissionAmount()).toEqual('1');

            // enter a valid value into the Max Commission field
            masterDataOtherCommissionsFullView.enterMaxCommission(td.randomValueTwo);

            // save and close the commission
            masterDataOtherCommissionsFullView.clickSalesAgencyOtherCommissionsSave('Save & Close');

            // create a new commission with the same sales year
            masterDataOtherCommissionsFullView.addCommission('With classification');

            // add a second commission line item for the same sales year
            masterDataOtherCommissionsFullView.selectSalesYear((td.salesPeriod.year + 3).toString());

            // verify that the previously selected classification is not displayed in the dropdown
            expect(masterDataOtherCommissionsFullView.verifyClassificationDropDownOption('C')).toBeFalsy();

            // close the commissions window
            masterDataOtherCommissionsFullView.clickSalesAgencyOtherCommissionsCancel();

            // delete the created row
            masterDataOtherCommissionsFullView.removeFirstCommissionRow();
            masterDataOtherCommissionsFullView.clickCancelDeleteConfirmation('Delete');
        }, fail);
    });
});