/// <reference path="../../../../typings/index.d.ts" />

import {NavigationsSS} from '../../../../modules/sales_support/navigations/NavigationsSS';
import {Search} from '../../../../modules/shared/Search';
import {BalancesSS} from '../../../../modules/sales_support/screens/BalancesSS';
import {ActivityStatementSS} from "../../../../modules/sales_support/screens/ActivityStatementSS";
import TestData319926 from './testData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
	'319926',
	'Sales Support - Activity Statement - Line Items',
    UserRole.SALES_SUPPORT,
    ApplicationFeature.ACTIVITY_STATEMENT
);

describe(test.stringify, () => {
    const td = new TestData319926();
    let nav = new NavigationsSS();
    let search = new Search();
    let balances = new BalancesSS();
    let activityStatement = new ActivityStatementSS();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.salesSupportUser);

            // should select [Business Partner]
            search.searchByCriteria(td.businessPartner.name);
            search.selectRadioButton('Business partners');
            search.selectSearchResult(parseInt(td.businessPartner.id));

            // should select [Balances] from the hamburger
            nav.selectItemFromHamburgerMenu('Balances');

            // should go to the activity statement by clicking [>] on Balances Page
            balances.goToActivityStatement(td.invoice.name);

            // should verify at least 1 row contains todays date
            expect(activityStatement.is1RowContainsTodaysDate).toBe(true);

            // should verify clicking the icon to the left of the entry for todays date contracts and expands the detail information below
            activityStatement.collapseTransactionRow();
            expect(activityStatement.isTransactionRowCollapsed).toBe(true);
            activityStatement.expandTransactionRow();
            expect(activityStatement.isTransactionRowCollapsed).toBe(false);

            // should verify a row labeled [Retail Value] has a dollar value in the [Amount] column
            expect(activityStatement.isRetailValueRowHasValidAmountValue).toBe(true);

            // should verify clicking the icon to the left of the [Retail Value] label expands and contracts the line item information
            activityStatement.expandRetailValueRow();
            expect(activityStatement.isRetailValueRowHasProductLineColumnWhenExpanded).toBe(true);

            // should verify when expanded the [Retail Value] information correctly displays the columns of information 
            expect(activityStatement.isRetailValueRowHasProductLineColumnWhenExpanded).toBe(true);
            expect(activityStatement.isRetailValueRowHasProductColumnWhenExpanded).toBe(true);
            expect(activityStatement.isRetailValueRowHasSubProductWhenExpanded).toBe(true);
            expect(activityStatement.isRetailValueRowHasUnitsColumnWhenExpanded).toBe(true);
            expect(activityStatement.isRetailValueRowHasRetailValueColumnWhenExpanded).toBe(true);
            expect(activityStatement.isRetailValueRowHasUpdatedByColumnWhenExpanded).toBe(true);
        }, fail);
    });
});