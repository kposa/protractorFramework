/// <reference path="../../../typings/index.d.ts" />

import { SalesRepOperationFullView } from '../../../modules_v3/views/salesRep/SalesRepOperationFullView';
import { SalesRepAccountDescriptionFullView } from '../../../modules_v3/views/salesRep/SalesRepAccountDescriptionFullView';
import moment = require('moment/moment');
import BaseTestData from '../../../modules_v3/testdata/BaseTestData';
import { BusinessPartner } from '../../../modules_v3/testdata/BusinessPartner';

const salesRepOperationsFullView = new SalesRepOperationFullView();
const salesRepAccountDescriptionFullView = new SalesRepAccountDescriptionFullView();

export function createAccountDescription (options:ICreateAccountDescriptionOptions, td:BaseTestData):void {

    //const abc = new ICreateAccountDescriptionOptions();

    // should click the [+ New Account Description] button
    salesRepOperationsFullView.clickAddAccountDescriptionButton();

    //should choose a sales period from the drop down
    salesRepOperationsFullView.salesPeriodDropdown.selectById(options.salesPeriod);

    //should change name of account
    salesRepAccountDescriptionFullView.nameSection.changeName(td, options.accountDescriptionName);

    //should add a Share (only capable of adding 1 share at 100% right now)
    salesRepAccountDescriptionFullView.shareSection.clickAddPayerButton();
    salesRepAccountDescriptionFullView.customerDrawer.selectMenuItemContainingText(options.shares[0].name);

    //should enter share percentage and close percentage entry drawer
    salesRepAccountDescriptionFullView.percentageEntryDrawer.enterPercentage(options.shares[0].percentage);

    //should close payer drawer
    salesRepAccountDescriptionFullView.payerDrawer.close();

    //should save account description
    salesRepAccountDescriptionFullView.save();

    // should go back to the operation screen
    salesRepAccountDescriptionFullView.clickBack();

}

export class AccountDescriptionShare implements BusinessPartner {
    constructor(businessPartner:BusinessPartner, percentage:string) {
        this.id = businessPartner.id;
        this.name = businessPartner.name;
        this.percentage = percentage;
    }
    id:string;
    name:string;
    percentage:string;
}

export interface ICreateAccountDescriptionOptions {
    salesPeriod:number;
    accountDescriptionName?:string;
    shares:AccountDescriptionShare[];
}