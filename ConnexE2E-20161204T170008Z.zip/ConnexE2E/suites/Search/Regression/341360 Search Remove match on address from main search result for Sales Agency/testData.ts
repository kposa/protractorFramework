/// <reference path='../../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';
import { query341360Results, query341360 } from './queries';

export default class TestData341360 extends BaseTestData {

    public agencyId: string = '7146506';
    public street1: string;
    public street2: string;
    public city: string;
    public postalCode: string;
    public firstName: string;
    public lastName: string;

    protected queries = [
        this.getResultFor382287()
    ];

    private getResultFor382287 (): () => Promise<query341360Results> {
        return () => {
            const sql = query341360();
            const results = this.queryService.executeSql<query341360Results[]>(sql);

            return results
                .then(data => {
                    const row = <query341360Results>getRandomQueryResult(data);

                    this.agencyId = row.agencyId;
                    this.street1 = row.street1;
                    this.street2 = row.street2;
                    this.city = row.city;
                    this.postalCode = row.postalCode;
                    this.firstName = row.firstName;
                    this.lastName = row.lastName;

                    return row;
                });
        };
    }

}