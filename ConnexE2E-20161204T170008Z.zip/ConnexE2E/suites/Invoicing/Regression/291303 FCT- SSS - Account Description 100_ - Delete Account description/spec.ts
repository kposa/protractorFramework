/// <reference path="../../../../typings/index.d.ts" />

import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
    '291303',
    'FCT- SSS - Account Description 100% - Delete Account description',
    UserRole.SALES_SUPPORT,
    ApplicationFeature.INVOICING
);

describe(test.stringify, () => {

    itw(test.description, () => {

    }, 'Needs re-write');
});