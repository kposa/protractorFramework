/// <reference path="../../typings/index.d.ts" />

import { Entity } from './Entity';

export interface Operation extends Entity {}