/// <reference path="../../typings/index.d.ts" />

/**
 * Each Connex test should impersonate a user with the correct role
 * This class takes care of the impersonation process and also contains the functionality to select an operation for a sales rep
 */
import ElementFinder = protractor.ElementFinder;

import { clickElement } from '../../modules_v3/helpers/clickElementHelpers';
import { filterElements, isActive, containingText } from '../../modules_v3/helpers/filterElementHelpers';

export class Impersonate {
    private element = $('section.impersonate');
    private searchIcon = this.getDisplayedSearchMagnifierIcon();
    private searchInput = element(by.model('vm.criteria'));
    private users = this.element.$$(`li[data-ng-repeat='user in users']`);

    private allOperationResults = $$('li[ng-click="vm.selectOperation(o.id)"]');

    private getDisplayedSearchMagnifierIcon():ElementFinder {
        return filterElements($$('div[ng-click*="startSearch"]'), [isActive(true)])().first();
    }

    public openSearch () {
        clickElement(this.searchIcon);
    }

    public submitSearch (text:string) {
        this.searchInput.sendKeys(text);
        this.searchInput.sendKeys(protractor.Key.chord(protractor.Key.ENTER));
    }

    public clickUserById (userId:string) {
        clickElement(filterElements(this.users, [isActive(true), containingText(userId)])().first());
    }

    public impersonateUserByNameAndId(userName:string, userId:string):void {
        if(typeof userName === 'undefined' || typeof userId === 'undefined') {
            throw new Error('The impersonator username or userid is undefined');
        }

        this.openSearch();
        this.submitSearch(userName);
        this.clickUserById(userId);
    }

    public searchForAndSelectOperationByName(operationName:string):void {
        if(typeof operationName === 'undefined')
            throw new Error('The operation name is undefined');
        clickElement(this.searchIcon);
        this.searchInput.sendKeys(operationName);
        this.searchInput.sendKeys(protractor.Key.chord(protractor.Key.ENTER));
        clickElement(this.allOperationResults.get(0));
    }

}

