/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import { filterElements, isActive, containingText } from '../../../modules_v3/helpers/filterElementHelpers';
import ElementArrayFinder = protractor.ElementArrayFinder;
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

export class PersonStreetAddressMD {

    public clickSameAsPersonMailingButton(): void {
        let sameAsMailingButton = $('button[ng-click="vm.importPersonMailingAddress()"]');
        clickElement(sameAsMailingButton);
    }

    public updateStreetAddress1(streetAddress1: string): void {
        let streetAddress1InputContainer = $('input[ng-model="vm.personAddress.street1"]');
        streetAddress1InputContainer.clear();
        streetAddress1InputContainer.sendKeys(streetAddress1);
    }

    public updateStreetAddress2(streetAddress2: string): void {
        let streetAddress2InputContainer = $('input[ng-model="vm.personAddress.street2"]');
        streetAddress2InputContainer.clear();
        streetAddress2InputContainer.sendKeys(streetAddress2);
    }

    public updateCity(city: string): void {
        let cityInputContainer = $('input[ng-model="vm.personAddress.city"]');
        cityInputContainer.clear();
        cityInputContainer.sendKeys(city);
    }

    public selectOptionFromStateDropdown(state: string) : void {
        let stateDropdown = $('md-select[name="region"]');
        let dropdownOption = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(state)
            ]
        )().first();
        clickElement(stateDropdown);
        clickElement(dropdownOption);
    }

    public selectOptionFromCountyDropdown(county: string): void {
        let countyDropdown = $('md-select[ng-model="vm.personAddress.countyId"]');
        let selectPolkCounty = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(county)
            ]
        )().first();
        clickElement(countyDropdown);
        clickElement(selectPolkCounty);
    }

    public updatePostalCode(postalCode:string): void {
        let postalCodeInputContainer = $('input[ng-model="vm.personAddress.postalCode"]');
        postalCodeInputContainer.clear();
        postalCodeInputContainer.sendKeys(postalCode);
    }

    public clickRetrieveButton(): void {
        let retrieveButton = $('button[ng-click="vm.getGeoCodeInfo($event)"]');
        clickElement(retrieveButton);
    }

    public getCountryName(): Promise<string> {
        let countryName = $('div.form-control-fixed-height.country-label').$('label.ng-binding');
        return countryName.getText();
    }




}