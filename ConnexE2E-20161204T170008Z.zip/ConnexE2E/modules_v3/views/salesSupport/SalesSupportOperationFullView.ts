/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;
import { IView } from '../../interfaces/common/IView';
import Promise = protractor.promise.Promise;
import { IExpandableMenuView } from '../../interfaces/common/IExpandableMenuView';
import { NotImplementedError } from '../../../common/exception/Exceptions';
import { filterElements, isActive, containingText, matchingText } from '../../helpers/filterElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';
import { SalesSupportHamburgerDrawerPartialView } from './SalesSupportHamburgerDrawerPartialView';

export class SalesSupportOperationFullView implements IView {

    public toasterMenu = new ToasterMenu();
    public accountDescriptions = $$('div[ng-repeat*="account in vm.filteredAccounts"]');
    public hamburgerMenu = new HamburgerMenu();

    isViewDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('section.sales-support-operation'));
    }

    getHeaderTitle ():Promise<string> {
        return $('section.pm-app-bar.pm-background-primary-500').$('div.pm-title').getText();
    }

    clickFirstAccount ():void {
        clickElement($$('div[ng-repeat*="account in vm.filteredAccounts').get(0));
    }

    selectAccountDescription (invoiceName:string):void {
        let accountDescription = this.getAccountDesctiption(invoiceName);
        clickElement(accountDescription);
    }

    private getAccountDesctiption (invoiceName:string):ElementFinder {
        return filterElements(this.accountDescriptions, [ isActive(true), matchingText(invoiceName, e => e.$('div.pm-listitem-primary')) ])().first();
    }

}

class ToasterMenu implements IView, IExpandableMenuView {

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    openMenu ():void {
        throw new NotImplementedError();
    }

    selectMenuItemMatchingText (text:string):void {
        throw new NotImplementedError();
    }

    selectMenuItemContainingText (text:string):void {
        let item = filterElements($$('div.list-item'), [ isActive(true), containingText(text) ])().first();
        clickElement(item);
    }
}

class HamburgerMenu extends SalesSupportHamburgerDrawerPartialView {
}