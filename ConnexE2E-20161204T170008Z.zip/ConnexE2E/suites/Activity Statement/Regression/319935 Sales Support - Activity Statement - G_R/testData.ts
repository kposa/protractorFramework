/// <reference path="../../../../typings/index.d.ts" />
import Promise = protractor.promise.Promise;

import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';
import { operationWithGrowthAndRetentionDiscount, operationWithGrowthAndRetentionDiscountResults  } from './queries';
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';

export default class TestData319935 extends BaseTestData {
    public discountName: string;
    protected queries: (() => Promise<any>)[] = [
        this.getOperationWithGrowthAndRetention()
    ];

    private getOperationWithGrowthAndRetention (): () => Promise<operationWithGrowthAndRetentionDiscountResults> {
        return () => {
            const sql = operationWithGrowthAndRetentionDiscount(this.salesPeriod.id);
            const results = this.queryService.executeSql<operationWithGrowthAndRetentionDiscountResults[]>(sql);

            return results
                .then(data => {
                    const row = <operationWithGrowthAndRetentionDiscountResults>getRandomQueryResult(data);

                    this.salesRepresentatives.push({
                        id: row.salesRepId,
                        name: row.salesRepName
                    });

                    this.operations.push({
                        id: row.operationId,
                        name: row.operationName
                    });

                    this.invoices.push({
                        id: row.invoiceId,
                        name: row.invoiceName
                    });

                    this.discountName = row.discountName;

                    return row;
                });
        };
    }
}