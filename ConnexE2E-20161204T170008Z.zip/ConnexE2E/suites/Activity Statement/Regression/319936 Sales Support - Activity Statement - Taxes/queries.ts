const { E2EInvoicesDatabaseName } = process.env;

export interface canadianUserOperationsResults {
    operationId: string,
    operationName: string,
    customerName:string;
    customerId:string;
}

export function canadianUserOperations (canadianSalesRepUserId:string, salesPeriodId: number) {
    return `
    
    SELECT uo.operationId, o.Name AS operationName, c.customerId, c.name AS customerName
    FROM ${E2EInvoicesDatabaseName}.dbo.UserOperation uo
    JOIN ${E2EInvoicesDatabaseName}.dbo.Operation o ON o.OperationId = uo.OperationId
    JOIN ${E2EInvoicesDatabaseName}.dbo.OperationCustomer oc ON oc.OperationId = o.OperationId
    JOIN ${E2EInvoicesDatabaseName}.dbo.Customer c ON c.CustomerId = oc.CustomerId
    WHERE uo.UserId = ${canadianSalesRepUserId}
    AND uo.SalesPeriodId = ${salesPeriodId}
    ORDER BY o.Name
    
    `;
}