/// <reference path="../../../typings/index.d.ts" />

import { ISearchableWithFilterableResultsView } from "../common/ISearchableWithFilterableResultsView";
import Promise = protractor.promise.Promise;
import ElementArrayFinder = protractor.ElementArrayFinder;

export interface IMasterSearchFullView extends ISearchableWithFilterableResultsView {
    clickBusinessPartnerSearchResult(businessPartnerId:string):void;
    getSearchResultCountByMatchingResultType(resultType:string):Promise<number>;
    getSearchResultCountByContainingResultType(headline:string):Promise<number>;
    getSearchResultsByContainingResultType(resultType:string):ElementArrayFinder;
    getSearchResultsByContainingHeadline(headline:string):ElementArrayFinder;
    getSearchResultContentByContainingHeadline(headline:string):Promise<string>;
    selectAllFilter():void;
    getCountOfFilters():Promise<number>;
    getFilters():ElementArrayFinder;
    getCountOfFilterMatchingText(text:string):Promise<number>;
    getCountOfFilterContainingText(text:string):Promise<number>;
}