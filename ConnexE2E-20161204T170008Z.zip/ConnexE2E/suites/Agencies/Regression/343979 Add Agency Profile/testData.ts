/// <reference path='../../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import ElementArrayFinder = protractor.ElementArrayFinder;
import { agencyIdForAddAgencyProfileResults, agencyIdForAddAgencyProfile } from './queries';
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';

export default class TestData343979 extends BaseTestData {
    public agencyId: string;
    public livestockProfessionalName: string = 'John';
    public taxValue: string = '123456789';
    public note: string = 'Hello12345';
    public serialNumber: string = '99999999';
    public modelNumber: string = '12345asdfG';
    public computerSerialNumber: string = '45678qwerty';
    public profileTabCardsAndIcons: Array<string> = ['domain','General','cast','MITT','laptop_windows','Personal Computers'];
    public generalCardContent: Array<string> = ['Certifications' , 'Equipment', 'Kernel Size & Teatments'];
    public mittCardContent: Array<string> = ['Scanners:'];
    public personalComputersCardContent: Array<string> = ['Count:'];
    public kernalDropdownOptions: Array<string> = ['Round', 'Medium Round', 'Medium Flat', 'Flat'];

    protected queries = [
        this.getAgencyIdForAddAgencyProfile()
    ];

    private getAgencyIdForAddAgencyProfile (): () => Promise<agencyIdForAddAgencyProfileResults> {
        return () => {
            const sql = agencyIdForAddAgencyProfile();
            const results = this.queryService.executeSql<agencyIdForAddAgencyProfileResults[]>(sql);

            return results
                .then(data => {
                    const row = <agencyIdForAddAgencyProfileResults>getRandomQueryResult(data);
                    this.agencyId = row.AgencyId;
                    return row;
                });
        };
    }
}
