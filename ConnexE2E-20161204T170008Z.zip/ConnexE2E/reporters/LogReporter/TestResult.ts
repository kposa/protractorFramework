///<reference path="../../typings/index.d.ts"/>

export class TestResult {
    testCaseId: string;
    testCaseDescription: string;
    userRole: string;
    feature: string;
    status: string;
    pendingReason: string;
    failureMessage: string;
    failureStackTrace: string;
    duration: number;
}