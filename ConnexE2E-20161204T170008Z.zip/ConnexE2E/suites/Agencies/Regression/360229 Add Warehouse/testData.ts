/// <reference path='../../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import { agencyIdForAddWarehouse, agencyIdForAddWarehouseResults } from './queries';
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';

export default class TestData360229 extends BaseTestData {
    public agencyId: string;
    public warehouseName: string = 'Abc';
    public warehouseAbbreviatedName: string = 'U.S';
    public personType: string = 'Sales Rep';
    protected queries = [
        this.getAgencyIdForAddWarehouse()
    ];

    private getAgencyIdForAddWarehouse (): () => Promise<agencyIdForAddWarehouseResults> {
        return () => {
            const sql = agencyIdForAddWarehouse();
            const results = this.queryService.executeSql<agencyIdForAddWarehouseResults[]>(sql);

            return results
                .then(data => {
                    const row = <agencyIdForAddWarehouseResults>getRandomQueryResult(data);
                    this.agencyId = row.AgencyId;
                    return row;
                });
        };
    }


}
