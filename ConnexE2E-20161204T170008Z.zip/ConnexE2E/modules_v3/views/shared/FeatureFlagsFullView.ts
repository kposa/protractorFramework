/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;

import {IFeatureFlagsFullView} from "../../interfaces/fullViews/IFeatureFlagsFullView";
import { clickElement } from '../../helpers/clickElementHelpers';
import { NotImplementedError } from '../../../common/exception/exceptions';
import { IView } from '../../interfaces/common/IView';
import Promise = protractor.promise.Promise;

export default class FeatureFlagsFullView implements IView, IFeatureFlagsFullView {
    private element = $(`section.featureFlags`);
    private resetAllButton = this.element.$(`button[ng-click='reset()']`);
    private allFlagRows = this.element.$$('li[ng-click="toggleFlag(flag)"]');
    private searchInput = $('input.page-search-box');

    private defaultTestingFlags: Array<string> = ['ShowGlobalErrorDetail'];

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    public resetAllFlags(additionalFlags?:Array<string>):void {
        clickElement(this.resetAllButton);
        this.setAdditionalTestingFlags(additionalFlags);
    }

    private setAdditionalTestingFlags(additionalFlags?:Array<string>):void {
        additionalFlags = additionalFlags ? additionalFlags.concat(this.defaultTestingFlags) : this.defaultTestingFlags;

        for (let flag of additionalFlags) {
            this.setFlag(flag, true);
        }
    }

    private setFlag(flag:string, enable:boolean) {
        const flagRow = this.allFlagRows.first();
        const checkCircle = flagRow.$('i.fa');
        const checkMark = flagRow.$('i.f-check-circle');

        this.searchFlag(flag);

        checkMark.isPresent().then((flagIsChecked) => {
            if((flagIsChecked && !enable) || (!flagIsChecked && enable))
                clickElement(checkCircle);
        });
    }

    private searchFlag(flag:string):void {
        this.searchInput.clear();
        this.searchInput.sendKeys(flag);
        expect(this.allFlagRows.count()).toEqual(1);
    }
}
