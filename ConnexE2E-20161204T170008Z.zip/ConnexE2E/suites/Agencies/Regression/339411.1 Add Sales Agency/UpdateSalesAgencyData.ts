/// <reference path="../../../../typings/index.d.ts" />

import Promise = protractor.promise.Promise;

export default class UpdateSalesAgencyData {

    public firstName:string = 'Xyz';
    public lastName:string = 'Aaa';
    public streetAddress1:string = '127 E Washington St';
    public streetAddress2:string = '#10';
    public city:string = 'Iowa City';
    public state: string = 'Iowa';
    public county:string = 'Johnson';
    public postalCode:string = '52240';
    public phoneNumber:string = '6664445555';
    public routingNum:string = '987654321';
    public accountNum:string = '978645312';
    public vendorName:string = 'Johnny';
    public taxValue:string = '456789123';
    public note:string = 'helloabc';
}