/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import { filterElements, isActive, containingText } from '../../../modules_v3/helpers/filterElementHelpers';
import ElementArrayFinder = protractor.ElementArrayFinder;
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

export class PersonProfileMD {

    public selectOptionFromTestedDairyRepDropdown(type: string): void {
        let testedDairyRepDropdown = $('md-select[ng-model="vm.personProfile.testedDairyRep"]');
        let dropdownOption =filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(type)
            ]
        )().first();
        clickElement(testedDairyRepDropdown);
        clickElement(dropdownOption);
    }

    public selectOptionFromCertifiedCropAdvisorDropdown(type: string): void {
        let certifiedCropAdvisorDropdown = $('md-select[ng-model="vm.personProfile.certifiedCropAdvisor"]');
        let dropdownOption =filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(type)
            ]
        )().first();
        clickElement(certifiedCropAdvisorDropdown);
        clickElement(dropdownOption);
    }

    public enterValueInCCAInputContainer(cca: string): void {
        let ccaInputContainer = $('input[ng-model="vm.personProfile.ccaCpsa"]');
        ccaInputContainer.clear();
        ccaInputContainer.sendKeys(cca);
    }










}