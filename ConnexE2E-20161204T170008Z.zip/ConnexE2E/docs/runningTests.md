# [Connex E2E Documentation](/)

## Running Tests

### Webstorm

Use the run/debug configurations to select which suite/env to run desired tests.

### Command Line

#### Environment

Passing the command line argument `--Env=staging|tx` will set which environment the tests run from.

`npm run test -- --Env=staging`

#### Suite

Passing the command line argument `--suite=smoke_all` will set which suite's tests will run.

`npm run test -- --Env=staging --suite=smoke_all`

#### Grid

Passing the command line argument `--Grid=true` will enable tests to run on the [grid](/grid.html).

`npm run test -- --Env=staging --suite=smoke_all --Grid=true`