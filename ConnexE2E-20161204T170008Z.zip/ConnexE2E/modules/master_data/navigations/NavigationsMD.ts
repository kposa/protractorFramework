/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import {Element} from "./../../shared/Element";
import {Search} from "../../shared/Search";
import {Impersonate} from "../../shared/Impersonate";
import { filterElements, isActive, containingText } from '../../../modules_v3/helpers/filterElementHelpers';
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

let search = new Search();
let e = new Element();
let imp = new Impersonate();

export class NavigationsMD {
    public selectItemFromHamburgerMenu(hamburgerItem:string):void {
        clickElement($('i[ng-click="drawerVM.toggleDrawerPosition()"]'));
        var hamburgerMenuItems = $('section[name="navigationDrawer"]').$$('div.pm-navigation-item');
        e.clickDisplayedElementWithMatchingText(hamburgerMenuItems, hamburgerItem);
    }
}