/// <reference path="../../../typings/index.d.ts" />

import {Element} from "../../shared/Element";

let e = new Element();

export class ActionButton {

    public clickFloatingActionBtn() {
        let allFloatingActionButtons = $$('[at="floating-action-button"]');
        e.clickDisplayedElement(allFloatingActionButtons);
    }
}