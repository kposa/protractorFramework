/// <reference path='../../../typings/index.d.ts' />
import ElementFinder = protractor.ElementFinder;

import {clickElement} from '../../helpers/clickElementHelpers';
import {textContainsText} from "../../helpers/utilityHelpers";
import {ILoginFullView} from "../../interfaces/fullViews/ILoginFullView";
import { NotImplementedError } from '../../../common/exception/exceptions';
import { IView } from '../../interfaces/common/IView';
import Promise = protractor.promise.Promise;

export default class LoginFullView implements IView, ILoginFullView {
    private element = $('section.login');
    private usernameInput = element(by.model('user'));
    private passwordInput = element(by.model('password'));
    private submitButton = this.element.$('input[type="submit"]');
    private loginError = $('div.error');
    private maxLoginAttempts:number = 5;
    private currentLoginAttemps:number = 0 ;

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    private checkForLoginError():void {
        this.loginError.isPresent().then(isPresent => {
            if (isPresent) {
                this.loginError.getText().then(error => {
                    if (this.currentLoginAttemps < this.maxLoginAttempts && textContainsText(error, 'let you in with that information')) {
                        this.currentLoginAttemps++;
                        this.retry();
                    } else {
                        fail(`Login Failed: ${error}`);
                    }
                });
            }
        });
    }

    private retry() {
        browser.sleep(1000).then(() => this.submit());
    }

    public inputUsername(userName:string) {
        this.usernameInput.sendKeys(userName);
    }

    public inputPassword(password:string) {
        this.passwordInput.sendKeys(password);
    }

    public submit() {
        clickElement(this.submitButton);
        this.checkForLoginError();
    }

    public login(userName:string, password:string) {
        this.inputUsername(userName);
        this.inputPassword(password);
        this.submit();
    }
}