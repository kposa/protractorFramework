/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import { filterElements, isActive, containingText } from '../../../modules_v3/helpers/filterElementHelpers';
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

export class AgencyMailingMD {

    private mailingLayoutParent = $('div.ng-scope.layout-column.flex');
    private streetAddress1InputContainer = $('input[ng-model="vm.agencyAddress.street1"]');
    private streetAddress2InputContainer =  $('input[ng-model="vm.agencyAddress.street2"]');
    private cityInputContainer = $('input[ng-model="vm.agencyAddress.city"]');
    private postalCodeInputContainer = $('input[ng-model="vm.agencyAddress.postalCode"]');

    get verifyMailingPageDisplayed(): Promise<string>{
        return this.mailingLayoutParent.getText();
    }

    public verifyUnitedStatesDisplayed(): Promise<string>{
        return $('div.form-control-fixed-height.country-label')
                .$('label.ng-binding').getText();
    }

    public enterStreetAddress1(strAddress1: string): void {
        this.streetAddress1InputContainer.clear();
        this.streetAddress1InputContainer.sendKeys(strAddress1);
    }

    public enterStreetAddress2(strAddress2: string): void {
        this.streetAddress2InputContainer.clear();
        this.streetAddress2InputContainer.sendKeys(strAddress2)
    }

    public enterCity(city: string): void {
        this.cityInputContainer.clear();
        this.cityInputContainer.sendKeys(city);
    }

    public selectOptionFromStateDropdown(state: string) : void {
        let stateDropdown = $('md-select[name="region"]');
        let dropdownOption = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(state)
            ]
        )().first();
        clickElement(stateDropdown);
        clickElement(dropdownOption);
    }

    public selectCountyFromDropdown(county: string): void {
        let countyDropdown = $('md-select[ng-model="vm.agencyAddress.countyId"]');
        let selectPolkCounty = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(county)
            ]
        )().first();
        clickElement(countyDropdown);
        clickElement(selectPolkCounty);
    }

    public enterPostalCode(postalCode:string): void {
        this.postalCodeInputContainer.clear();
        this.postalCodeInputContainer.sendKeys(postalCode);
    }
    
}