/// <reference path='../../../typings/index.d.ts' />
import ElementFinder = protractor.ElementFinder;

import { NotImplementedError } from '../../../common/exception/Exceptions';
import { IView } from '../../interfaces/common/IView';
import Promise = protractor.promise.Promise;
import { clickElement } from '../../helpers/clickElementHelpers';
import { IOperationsFullView } from '../../interfaces/fullViews/IOperationsFullView';

export default class ITSupportOperationsFullView implements IView, IOperationsFullView {

    private getFirstGreenInvoiceButton(): ElementFinder {
        return $$('support-operation-invoice-button[at="support-operation-invoice-button"]').$$('a[ng-if="hasInvoice"]')
            .$$('div.button.semibold').get(0);
    }

    private getFirstGreenDeliveryButton(): ElementFinder {
        return $$('support-operation-delivery-button[has-delivery="account.deliveryExists"]').$$('a[ng-if="hasDelivery"]')
            .$$('div.button.semibold').get(0);
    }

    isViewDisplayed(): Promise<boolean> {
        throw new NotImplementedError();
    }

    openSearch():void {
        throw new NotImplementedError();
    }

    inputSearch(text:string):void {
        throw new NotImplementedError();
    }

    submitSearch():void {
        throw new NotImplementedError();
    }

    search(text:string):void {
        throw new NotImplementedError();
    }

    searchByTwoCriteria(firstCriteria:string, secondCriteria:string):void {
        throw new NotImplementedError();
    }

    clickSearchResultMatchingText(text:string):void {
        throw new NotImplementedError();
    }

    clickSearchResultContainingText(text:string):void{
        throw new NotImplementedError();
    }

    getSearchResultCount():Promise<number> {
        throw new NotImplementedError();
    }

    clickFirstGreenInvoiceButton(): void {
        clickElement(this.getFirstGreenInvoiceButton());
    }

    clickFirstGreenDeliveriesButton(): void {
        clickElement(this.getFirstGreenDeliveryButton());
    }
}