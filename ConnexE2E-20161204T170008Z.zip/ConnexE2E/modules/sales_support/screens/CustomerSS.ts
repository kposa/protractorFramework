/// <reference path="../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import Promise = webdriver.promise.Promise;
import {Element} from '../../shared/Element';
import {MaterialDesignElement} from "../../shared/MaterialDesignElement";

import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

let e = new Element();
let md = new MaterialDesignElement();

export class CustomerSS {

    public clickOperation(operationName?:string):void {
        const operations = $$(`div[ng-repeat='o in operations']`);
        clickElement(operations.first());
    }
}