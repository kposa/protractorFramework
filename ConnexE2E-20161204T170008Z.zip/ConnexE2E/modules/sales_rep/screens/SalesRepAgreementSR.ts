import {DeferredPaymentAgreementTermsSR} from "./DeferredPaymentAgreementTermsSR";
import {Element} from '../../shared/Element';
import Promise = webdriver.promise.Promise;

import SignaturePadPartialView from '../../../modules_v3/views/shared/SignaturePadPartialView';
import {clickElement} from "../../../modules_v3/helpers/clickElementHelpers";
import { isPresentAndDisplayed } from '../../../modules_v3/helpers/utilityElementHelpers';

let e = new Element();
let terms = new DeferredPaymentAgreementTermsSR();

export class SalesRepAgreementSR {
    private signaturePadPartialView = new SignaturePadPartialView();
    public signButton = $$('button[ng-click="openAgreement(currentLanguage, agreement)"]').first().$('i');

    public signBarcodeScannerAgreement():void {
        isPresentAndDisplayed(this.signButton).then(isPresent => {
            if (isPresent) {
                clickElement(this.signButton);
                terms.clickSignTa();
                this.signaturePadPartialView.strokeSignature();
                this.signaturePadPartialView.clickAgree();
            }
        });
    }

    //showAgreementPreview(agreement)

    public verifyIfAgreementIsUnderSigned():Promise<String> {
        let signedAgreement = $$('div[ng-repeat="agreement in signedAgreements"]').get(0).element(by.xpath('..'));
        let signedlabel = signedAgreement.$('div.section-header');
        return signedlabel.getText();
    }

    public showSignedAgreementPreview():void {
        let viewButton = $('button[ng-click="showAgreementPreview(agreement)"]');
        e.clickElement(viewButton);
    }

    get isSignedButtonPresent():Promise<boolean> {
        return this.signButton.isPresent();
    }
}