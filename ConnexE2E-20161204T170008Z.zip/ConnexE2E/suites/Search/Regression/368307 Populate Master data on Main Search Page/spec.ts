/// <reference path="../../../../typings/index.d.ts" />

import { bootstrap } from "../../../SharedSteps/bootstrap";
import { itw } from '../../../../modules_v3/helpers/itw';
import TestData368307 from './testData';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import MasterDataMasterSearchScreenView from '../../../../modules_v3/views/masterData/MasterDataMasterSearchFullView';

const test = new TestCase(
	'368307',
	'Populate Master data on Main Search Page',
	UserRole.MASTER_DATA,
	ApplicationFeature.SEARCH
);

describe(test.stringify, () => {
    const td = new TestData368307();
    let masterDataMasterSearchScreenView = new MasterDataMasterSearchScreenView();

    itw(test.description, () => {

        // bootstrap (load, login, reset feature flags, impersonate)
        bootstrap(td.masterDataUser);

        //should verify radio buttons count
        expect(masterDataMasterSearchScreenView.getCountOfFilters()).toEqual(10);

        //should verify [Show results for] subheader is displayed
        expect(masterDataMasterSearchScreenView.getSubheaderForFilters()).toContain('Show results for');

        //should verify radio buttons are present
        for (var i = 0; i < td.filters.length; ++i) {
            expect(masterDataMasterSearchScreenView.getFilters().get(i).getText()).toEqual(td.filters[ i ]);
        }

        //should select [Business partners] radio button
        masterDataMasterSearchScreenView.selectFilterContainingText('Business partners');

        //should verify search results for business partners displayed
        expect(masterDataMasterSearchScreenView.getSearchResultCountByContainingResultType('Business partner'))
            .toEqual(masterDataMasterSearchScreenView.getSearchResultCount());

        //should select [Operations] radio button
        masterDataMasterSearchScreenView.selectFilterContainingText('Operations');

        //should verify search results for operations displayed
        expect(masterDataMasterSearchScreenView.getSearchResultCountByContainingResultType('Operation'))
            .toEqual(masterDataMasterSearchScreenView.getSearchResultCount());

        //should select [Sales agencies] radio button
        masterDataMasterSearchScreenView.selectFilterContainingText('Sales agencies');

        //should verify search results for sales agencies displayed
        expect(masterDataMasterSearchScreenView.getSearchResultCountByContainingResultType('Sales agency'))
            .toEqual(masterDataMasterSearchScreenView.getSearchResultCount());

        //should select [Warehouses] radio button
        masterDataMasterSearchScreenView.selectFilterContainingText('Warehouses');

        //should verify search results for warehouses displayed
        expect(masterDataMasterSearchScreenView.getSearchResultCountByContainingResultType('Warehouse'))
            .toEqual(masterDataMasterSearchScreenView.getSearchResultCount());

        //should select [Territories] radio button
        masterDataMasterSearchScreenView.selectFilterContainingText('Territories');

        //should verify search results for territories displayed
        expect(masterDataMasterSearchScreenView.getSearchResultCountByContainingResultType('Territory'))
            .toEqual(masterDataMasterSearchScreenView.getSearchResultCount());

        //should select [Pooling warehouses] radio button
        masterDataMasterSearchScreenView.selectFilterContainingText('Pooling warehouses');

        //should verify search results for pooling warehouses displayed
        expect(masterDataMasterSearchScreenView.getSearchResultCountByContainingResultType('Pooling warehouse'))
            .toEqual(masterDataMasterSearchScreenView.getSearchResultCount());

        //should select [Areas] radio button
        masterDataMasterSearchScreenView.selectFilterContainingText('Areas');

        //should verify search results for areas displayed
        expect(masterDataMasterSearchScreenView.getSearchResultCountByContainingResultType('Area'))
            .toEqual(masterDataMasterSearchScreenView.getSearchResultCount());

        //should select [Commercial units] radio button
        masterDataMasterSearchScreenView.selectFilterContainingText('Commercial units');

        //should verify search results for commercial units displayed
        expect(masterDataMasterSearchScreenView.getSearchResultCountByContainingResultType('Commercial unit'))
            .toEqual(masterDataMasterSearchScreenView.getSearchResultCount());

        //should select [Organization agencies] radio button
        masterDataMasterSearchScreenView.selectFilterContainingText('Organization agencies');

        //should verify search results for organization agencies displayed
        expect(masterDataMasterSearchScreenView.getSearchResultCountByContainingResultType('Organization agency'))
            .toEqual(masterDataMasterSearchScreenView.getSearchResultCount());

        //should select [Countries] radio button
        masterDataMasterSearchScreenView.selectFilterContainingText('Countries');

        //should verify search results for countries displayed
        expect(masterDataMasterSearchScreenView.getSearchResultCountByContainingResultType('Country'))
            .toEqual(masterDataMasterSearchScreenView.getSearchResultCount());

        //should select [Operations] radio button
        masterDataMasterSearchScreenView.selectFilterContainingText('Operations');

        //should verify [Refine by territory] subheader is displayed for operations
        expect(masterDataMasterSearchScreenView.getSubheaderForRefineResults()).toContain('Refine by territory');

        //should verify [See More] button displayed
        expect(masterDataMasterSearchScreenView.isSeeMoreButtonDisplayed()).toBeTruthy();

        //should select [Sales agencies] radio button
        masterDataMasterSearchScreenView.selectFilterContainingText('Sales agencies');

        //should verify [Refine by territory] subheader is displayed for sales agencies
        expect(masterDataMasterSearchScreenView.getSubheaderForRefineResults()).toContain('Refine by territory');

        //should select [Pooling warehouses] radio button
        masterDataMasterSearchScreenView.selectFilterContainingText('Pooling warehouses');

        //should verify [Refine by territory] subheader is displayed for pooling warehouses
        expect(masterDataMasterSearchScreenView.getSubheaderForRefineResults()).toContain('Refine by territory');
    });

});