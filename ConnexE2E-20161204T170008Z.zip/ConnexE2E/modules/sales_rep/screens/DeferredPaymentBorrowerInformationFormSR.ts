/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import {Element} from "./../../shared/Element";
import {MaterialDesignElement} from "../../shared/MaterialDesignElement";

let e = new Element();
let md = new MaterialDesignElement();

export class DeferredPaymentBorrowerInformationFormSR {

    private primaryLenderField = $('section.primary-lender-field');
    private cityField = $('section.city-field');
    private stateField = $('section.state-field');

    public enterPrimaryLender():void {
        let lenderName = 'Autotest Lender';
        md.clickFormField(this.primaryLenderField);
        md.enterInputText(this.primaryLenderField, lenderName);
        this.focusOutOfAllFields();
    }

    public enterCity():void {
        let city = 'Autotest City';
        md.clickFormField(this.cityField);
        md.enterInputText(this.cityField, city);
        this.focusOutOfAllFields();
    }

    public selectStateProvince():void {
        let state = 'IA';
        let dropdownItem = this.stateField.all(by.cssContainingText('div.pm-listitem', state)).get(0);
        md.clickFormField(this.stateField);
        e.clickElement(dropdownItem);
    }
    
    public clickContinue():void {
        let continueButton = $('button[ng-click="vm.continueEntry()"]');
        e.clickElement(continueButton);
    }

    private focusOutOfAllFields():void {
        let firstSubheader = $$('div.pm-list-subheader').get(0);
        e.clickElement(firstSubheader);
    }
}