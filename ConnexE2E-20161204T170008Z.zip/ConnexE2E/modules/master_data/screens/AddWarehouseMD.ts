/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

export class AddWarehouseMD {

    private addWarehouseDialogParent = $('md-dialog.agency-add-warehouse-associate-dialog');

    public isAddWarehouseDisplayed(): Promise<string> {
        return this.addWarehouseDialogParent.$$('span').get(0).getText();
    }

    public enterName(name: string): void {
        let nameContainer = $('input[ng-model="vm.name"]');
        nameContainer.sendKeys(name);
    }

    public enterAbbreviatedName(abbreviatedName: any): void {
        let abbreviatedNameContainer = $('input[ng-model="vm.abbreviatedName"]');
        abbreviatedNameContainer.sendKeys(abbreviatedName);
    }

    public selectPrimaryContactFromDropdown(): void {
        let primaryConatactDropdown = $('md-select[name="primaryContact"]');
        let selectFirstOption = $$('md-option[ng-repeat="contact in vm.primaryContacts"]').get(0);
        clickElement(primaryConatactDropdown);
        clickElement(selectFirstOption);
    }

    public verifyCountryName(): Promise<string> {
        return $('div.form-control-fixed-height.country-label')
                .$('label.ng-binding').getText().then(function (countryname) {
                    return countryname;
        })
    }

    public verifyNameRequired(): Promise<boolean> {
        return $$('div.error-messages').get(0).$('div.ng-scope').getText().then(function (txt) {
            return txt === 'Required' ;
        })
    }

    public verifyAbreviatedNameRequred(): Promise<boolean> {
        return $$('div.error-messages').get(1).$('div.ng-scope').getText().then(function (txt) {
            return txt === 'Required' ;
        })
    }

}