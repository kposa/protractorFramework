/// <reference path="../../../../typings/index.d.ts" />

import { SearchCS } from "../../../../modules/cash_specialist/screens/SearchCS";
import { EncircaPaymentsBP_CS } from "../../../../modules/cash_specialist/screens/EncircaPaymentsBP_CS";
import { EncircaViewPaymentsCS } from "../../../../modules/cash_specialist/screens/EncircaViewPaymentsCS";
import TestData324677 from './testData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';
import { SalesSupportMasterSearchFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportMasterSearchFullView';

const test = new TestCase(
    '324677',
    'Cash App Team can view Encirca Payments',
    UserRole.CASH_APP,
    ApplicationFeature.PAYMENTS
);

describe(test.stringify, () => {
    const td = new TestData324677();
    let search = new SearchCS();
    let encircaBP = new EncircaPaymentsBP_CS();
    let encircaViewPay = new EncircaViewPaymentsCS();
    let salesSupportMasterSearchFullView = new SalesSupportMasterSearchFullView();

    itw(test.description, () => {
        // bootstrap (load, login, reset feature flags, impersonate)
        bootstrap(td.cashAppUser);

        // should assert on the search screen being displayed once the user is impersonated
        expect(search.isSearchScreenDisplayed()).toBeTruthy();

        // should select the [Encirca Payments] link from the {Hamburger] option
        salesSupportMasterSearchFullView.hamburgerMenu.selectMenuItemMatchingText('Encirca payments');

        // should select a business partner who can view payments in Encirca
        encircaBP.searchForAndSelectUserByName(td.businessPartner.name);

        // should verify if the payments are displayed correctly
        expect(encircaViewPay.arePaymentsDisplayed()).toBeTruthy();
    });
});