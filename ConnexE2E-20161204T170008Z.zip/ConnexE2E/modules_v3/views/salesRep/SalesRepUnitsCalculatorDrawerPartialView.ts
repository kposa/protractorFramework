/// <reference path='../../../typings/index.d.ts' />
import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;

import {IUnitsCalculatorDrawerPartialView} from "../../interfaces/partialViews/IUnitsCalculatorDrawerPartialView";

import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';
import { NotImplementedError } from '../../../common/exception/exceptions';
import { IView } from '../../interfaces/common/IView';
import Promise = protractor.promise.Promise;

export default class SalesRepUnitsCalculatorDrawerPartialView implements IView, IUnitsCalculatorDrawerPartialView {
    private element: ElementFinder = $('section.units-calculator-drawer');
    private acres: ElementFinder = this.element.$('input[ng-model="vm.acres"]');
    private plantingRate: ElementFinder = this.element.$('input[ng-model="vm.ratio"]');
    private quantity: ElementFinder = this.element.$('.units-calculator-line .units-calculator-quantity');
    private adjustedUnits: ElementFinder = this.element.$('.units-calculator-line .units-calculator-adjusted-units');
    private adjustButton: ElementFinder = this.element.$('button[ng-click="vm.adjustUnits()"]');
    private closeButton: ElementFinder = this.element.$('div.cancel-units-calculator-button');

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    getQuantity():protractor.promise.Promise<number> {
        return this.quantity.getText().then(text => parseInt(text));
    }

    quantityIsPopulated():protractor.promise.Promise<boolean> {
        return this.quantity.getText().then((text) => text.length > 0);
    }

    fillInputAcres(value:number):void {
        this.acres.sendKeys(value.toString());
    }

    clearInputAcres():void {
        this.acres.clear();
    }

    fillInputPlantingRate(value:number):void {
        this.plantingRate.sendKeys(value.toString());
    }

    clearInputPlantingRate():void {
        this.plantingRate.clear();
    }

    getAdjustedUnits():protractor.promise.Promise<number> {
        return this.adjustedUnits.getText().then(text => parseInt(text));
    }

    adjustedUnitsIsPopulated():protractor.promise.Promise<boolean> {
        return this.adjustedUnits.getText().then(text => text !== '--');
    }

    submit():void {
        clickElement(this.adjustButton);
    }

    close():void {
        clickElement(this.closeButton);
    }
}
