/// <reference path="../../../../typings/index.d.ts" />

import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import {
    getOperationHavingCompletedDelivery, operationHavingACompletedDeliveryResults
}
    from './SharedITSupportEllipseNavigationQueries';
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';
import { EllipseItem2 } from '../../../../modules_v3/testdata/EllipseItem';
import ITSupportInvoiceSummaryFullView from '../../../../modules_v3/views/itSupport/ITSupportInvoiceSummaryFullView';
import ITSupportDeliverySummaryFullView from '../../../../modules_v3/views/itSupport/ITSupportDeliverySummaryFullView';
import ITSupportDocumentsFullView from '../../../../modules_v3/views/itSupport/ITSupportDocumentsFullView';
import ITSupportSupportPaymentsFullView from '../../../../modules_v3/views/itSupport/ITSupportSupportPaymentsFullView';
import ITSupportActivityStatementFullView from '../../../../modules_v3/views/itSupport/ITSupportActivityStatementFullView';
import ITSupportAccountDescriptionFullView from '../../../../modules_v3/views/itSupport/ITSupportAccountDescriptionFullView';
import ITSupportGrowthAndRetentionOverviewFullView from '../../../../modules_v3/views/itSupport/ITSupportGrowthAndRetentionOverviewFullView';

export class SharedITSupportEllipseNavigationTestData extends BaseTestData {

    protected queries:(() => Promise<any>)[] = [
        this.populateUserData()
    ];

    public accountDescriptionButtonText:string;
    public ellipseItems:Array<EllipseItem2>;

    public availableEllipseItems = {
        documents: new EllipseItem2('documents', new ITSupportDocumentsFullView()),
        summary: new EllipseItem2('summary', new ITSupportInvoiceSummaryFullView()),
        deliveries: new EllipseItem2('deliveries', new ITSupportDeliverySummaryFullView()),
        payments: new EllipseItem2('payments', new ITSupportSupportPaymentsFullView()),
        activityStatement: new EllipseItem2('activity statement', new ITSupportActivityStatementFullView()),
        accountDescription: new EllipseItem2('account description', new ITSupportAccountDescriptionFullView()),
        growthAndRetentionOverview: new EllipseItem2('growth and retention overview', new ITSupportGrowthAndRetentionOverviewFullView()),
    };

    private populateUserData ():() => Promise<operationHavingACompletedDeliveryResults> {
        return () => {
            const sql = getOperationHavingCompletedDelivery(this.salesPeriod.id);
            const results = this.queryService.executeSql<operationHavingACompletedDeliveryResults[]>(sql);

            return results
                .then(data => {
                    const row = <operationHavingACompletedDeliveryResults>getRandomQueryResult(data);

                    this.operations.push({
                        id: row.operationId,
                        name: row.operationName
                    });

                    return row;
                });
        };
    }
}