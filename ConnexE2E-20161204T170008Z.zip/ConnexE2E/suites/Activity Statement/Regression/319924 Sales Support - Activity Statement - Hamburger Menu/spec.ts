/// <reference path="../../../../typings/index.d.ts" />

import {NavigationsSS} from '../../../../modules/sales_support/navigations/NavigationsSS';
import {Search} from '../../../../modules/shared/Search';
import {BalancesSS} from '../../../../modules/sales_support/screens/BalancesSS';
import TestData319924 from "./testData";
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
	'319924',
	'Sales Support - Activity Statement - Hamburger Menu',
	UserRole.SALES_SUPPORT,
	ApplicationFeature.ACTIVITY_STATEMENT
);

describe(test.stringify, () => {
    const td = new TestData319924();
    let nav = new NavigationsSS();
    let search = new Search();
    let balances = new BalancesSS();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.salesSupportUser);

            // should select customer
            search.searchByCriteria(td.businessPartner.name);
            search.selectRadioButton('Business partners');
            search.selectSearchResult(parseInt(td.businessPartner.id));

            // should select [Balances] from the hamburger
            nav.selectItemFromHamburgerMenu('Balances');

            // should go to the activity statement for the first account description in the list
            balances.goToActivityStatement(td.invoice.name);

            // should select [Balances] from the hamburger and verify the page header contains [Balances]
            nav.selectItemFromHamburgerMenu('Balances');
            expect(balances.titleText).toContain('Balances');
            browser.navigate().back();

            // should select [Invoice] from the hamburger and verify the page header contains [Products]
            nav.selectItemFromHamburgerMenu('Invoice');
            expect(balances.titleText).toContain('Products');
            browser.navigate().back();

            // should select [Payments] from the hamburger and verify the page header contains [Payments]
            nav.selectItemFromHamburgerMenu('Payments');
            expect(balances.titleText).toContain('Payments');
        }, fail);
    });
});