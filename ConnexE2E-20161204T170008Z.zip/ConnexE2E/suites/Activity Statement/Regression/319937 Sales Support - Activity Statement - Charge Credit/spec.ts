/// <reference path="../../../../typings/index.d.ts" />

import { bootstrap } from '../../../SharedSteps/bootstrap';
import { TestCase, UserRole, ApplicationFeature } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';
import { SalesRepOperationsFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationsFullView';
import {
    createAccountDescription, AccountDescriptionShare
} from '../../../SharedSteps/Sales Rep/createAccountDescription';
import { signAgreements } from '../../../SharedSteps/Sales Rep/signAgreements';
import { SalesRepInvoiceFullView } from '../../../../modules_v3/views/salesRep/SalesRepInvoiceFullView';
import { SalesSupportMasterSearchFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportMasterSearchFullView';
import { SalesSupportOperationFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportOperationFullView';
import SalesSupportNavigationMenuPartialView from '../../../../modules_v3/views/salesSupport/SalesSupportNavigationMenuPartialView';
import { SalesSupportActivityStatementPageFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportActivityStatementPageFullView';
import TestData319937 from './testData';
import { SalesRepEllipsePartialView } from '../../../../modules_v3/views/salesRep/SalesRepEllipsePartialView';
import { SalesRepChargesAndCreditsFullView } from '../../../../modules_v3/views/salesRep/SalesRepChargesAndCreditsFullView';
import { SalesRepOperationFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationFullView';
import { SalesRepInvoiceAddLineItemDrawerPartialView } from '../../../../modules_v3/views/salesRep/SalesRepInvoiceAddLineItemDrawerPartialView';

const test = new TestCase(
    '319937',
    'Sales Support - Activity Statement - Charge/Credit',
    UserRole.SALES_SUPPORT,
    ApplicationFeature.ACTIVITY_STATEMENT
);

describe(test.stringify, () => {
    const td = new TestData319937();
    let salesRepOperationsFullView = new SalesRepOperationsFullView();
    let salesRepInvoiceFullView = new SalesRepInvoiceFullView();
    let salesSupportMasterSearchFullView = new SalesSupportMasterSearchFullView();
    let salesSupportOperationFullView = new SalesSupportOperationFullView();
    let salesSupportNavigationMenuPartialView = new SalesSupportNavigationMenuPartialView();
    let salesRepEllipsePartialView = new SalesRepEllipsePartialView();
    let salesRepChargesAndCreditsFullView = new SalesRepChargesAndCreditsFullView();
    let salesSupportActivityStatementPageFullView = new SalesSupportActivityStatementPageFullView();
    let salesRepOperationFullView = new SalesRepOperationFullView();
    let salesRepInvoiceAddLineItemDrawerPartialView = new SalesRepInvoiceAddLineItemDrawerPartialView();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            //bootstrap(load, login, resetfeatureflags, impersonate)
            bootstrap(({ name: td.salesAgencies[ 0 ].name, id: td.salesAgencies[ 0 ].id }));

            //should search an operation
            salesRepOperationsFullView.search(td.operations[ 0 ].id);

            //should select an operation
            salesRepOperationsFullView.clickSearchResultMatchingText(td.operations[ 0 ].name);

            // should create new account description
            createAccountDescription({
                salesPeriod: td.salesPeriod.id,
                shares: [ new AccountDescriptionShare(td.businessPartner, '100') ]
            }, td);

            //should sign agreements for the business partner
            signAgreements({ businessPartners: td.businessPartners });

            //should click Invoiced
            browser.controlFlow().execute(()=> {
                salesRepOperationFullView.clickInvoiceButton(td.invoices[ 0 ].name);
            });

            //should add line item
            salesRepInvoiceFullView.addLineItem('Corn');

            //should add product to line item drawer
            salesRepInvoiceAddLineItemDrawerPartialView.selectFirstProduct();

            //should add subproduct to line item drawer
            salesRepInvoiceAddLineItemDrawerPartialView.selectFirstSubProduct();

            //should enter units
            salesRepInvoiceAddLineItemDrawerPartialView.fillInputUnits('50');

            //should close line item drawer
            salesRepInvoiceAddLineItemDrawerPartialView.close();

            //should open charge and credits page
            salesRepEllipsePartialView.select('charges and credits');

            //should click add button
            salesRepChargesAndCreditsFullView.clickAddButton();

            //should add adjustment
            salesRepChargesAndCreditsFullView.chargeCredditAdjustmentSection.selectItem(td.chargeAndCreditName);
            salesRepChargesAndCreditsFullView.chargeCreditUnitsSection.enterUnits('10');
            salesRepChargesAndCreditsFullView.chargeCreditLineItemSection.close();

            //store charge and credit amount in test data file
            salesRepChargesAndCreditsFullView.getRecentlyAddedChargeAndCreditAmount().then((amt)=> {
                td.chargeAndCreditAmount = amt;
            });

            //should go back to invoice page
            salesRepChargesAndCreditsFullView.clickBack();

            //should preview invoice
            salesRepInvoiceFullView.clickPreviewInvoice();
            salesRepInvoiceFullView.clickShowButtonToPreviewInvoice();

            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.salesSupportUser);

            // should search operation
            salesSupportMasterSearchFullView.search(td.operations[ 0 ].id);
            salesSupportMasterSearchFullView.selectFilterContainingText('Operations');
            salesSupportMasterSearchFullView.clickSearchResultContainingText(td.operations[ 0 ].name);

            //should select invoice
            browser.controlFlow().execute(()=> {
                salesSupportOperationFullView.selectAccountDescription(td.invoices[ 0 ].name);
            });

            //should click invoice on the toster menu
            salesSupportOperationFullView.toasterMenu.selectMenuItemContainingText('Invoice');

            //should open hamburger menu
            salesSupportNavigationMenuPartialView.openMenu();

            //should go to activity statement page
            salesSupportNavigationMenuPartialView.selectMenuItemContainingText('Activity statement');

            // should display the same charge/credit name and amount noted previously
            browser.controlFlow().execute(()=> {
                expect(salesSupportActivityStatementPageFullView.getTransactionTypeAmmountByTransactionType(td.chargeAndCreditName)).toContain(td.chargeAndCreditAmount);
            });

        }, fail);
    });
});

