/// <reference path="../../../../typings/index.d.ts" />
import Promise = protractor.promise.Promise;

import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';
import { salesRepsWithNoSignedSalesRepAgreements, salesRepsWithNoSignedSalesRepAgreementsResults } from './queries';
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';

export default class TestData359133 extends BaseTestData {
    protected queries = [
        this.populateSalesRepsWithNoSignedSalesRepAgreements()
    ];

    private populateSalesRepsWithNoSignedSalesRepAgreements (): () => Promise<salesRepsWithNoSignedSalesRepAgreementsResults> {
        return () => {
            const sql = salesRepsWithNoSignedSalesRepAgreements();
            const results = this.queryService.executeSql<salesRepsWithNoSignedSalesRepAgreementsResults>(sql);

            return results
                .then(data => {
                    const row = <salesRepsWithNoSignedSalesRepAgreementsResults>getRandomQueryResult(data);

                    this.salesRepresentatives.push({
                        id: row.salesRepId,
                        name: row.salesRepName
                    });

                    this.salesAgencies.push({
                        id: row.salesAgencyId,
                        name: row.salesAgencyName,
                        address: row.salesAgencyAddress.trim()
                    });

                    return row;
                });
        };
    }
}