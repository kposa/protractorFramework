interface DBLocalConfig {
  accounting: {
      [s: string]: string;
      tx: string;
      staging: string;
  };
  invoices: {
      [s: string]: string;
      tx: string;
      staging: string;
  };
  operations: {
      [s: string]: string;
      tx: string;
      staging: string;
  };
  payments: {
      [s: string]: string;
      tx: string;
      staging: string;
  };
  reporting: {
        [s: string]: string;
        tx: string;
        staging: string;  
  }  
}

export const dbLocalConfig: DBLocalConfig = {
    "accounting": {
        "tx": "accounting",
            "staging": "accountingdemo"
    },
    "invoices": {
        "tx": "invoices",
            "staging": "invoicesdemo"
    },
    "operations": {
        "tx": "operations",
            "staging": "operationsdemo"
    },
    "payments": {
        "tx": "payments",
            "staging": "paymentsdemo"
    },
    "reporting": {
        "tx": "FieldSales_Reporting",
        "staging": "FieldSales_ReportingDemo"
    }

};