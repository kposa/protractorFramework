/// <reference path='../../../typings/index.d.ts' />
import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;

import {IUnitsEntryDrawerPartialView} from "../../interfaces/partialViews/IUnitsEntryDrawerPartialView";

import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';
import { NotImplementedError } from '../../../common/exception/exceptions';
import Promise = protractor.promise.Promise;
import { IView } from '../../interfaces/common/IView';
import { filterElements, isActive, matchingText } from '../../helpers/filterElementHelpers';

export default class SalesRepUnitsEntryDrawerPartialView implements IView, IUnitsEntryDrawerPartialView {
    private element:ElementFinder = $$('section[at="units-drawer"]').get(0);   //TODO use the getDisplayedElement func instead
    private unitsCalculatorButton:ElementFinder = this.element.$('i.fa.fa-calculator');
    private closeButton:ElementFinder = this.element.$('i.fa.fa-chevron-right');

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    public clickUnitsCalculatorButton():void {
        clickElement(this.unitsCalculatorButton);
    }

    public fillInputUnits(units:string) {
        units.split('').forEach( digit => {
            let keypadDigit = filterElements($$('td[ng-click*="vm.keypad.addDigit"]'),[ isActive(true), matchingText(digit) ])().first();
            clickElement(keypadDigit);
        });
    }

    public close():void {
        clickElement(this.closeButton);
    }
}
