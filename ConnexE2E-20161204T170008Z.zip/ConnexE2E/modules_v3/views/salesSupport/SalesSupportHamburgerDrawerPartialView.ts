/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;
import { clickElement } from '../../helpers/clickElementHelpers';
import {
    filterElements,
    isActive,
    matchingText
} from '../../helpers/filterElementHelpers';
import { IExpandableMenuView } from '../../interfaces/common/IExpandableMenuView';
import { NotImplementedError } from '../../../common/exception/Exceptions';

export class SalesSupportHamburgerDrawerPartialView implements IExpandableMenuView {

    isViewDisplayed ():Promise<boolean> {
        return filterElements($$('section[name="navigationDrawer"]'), [ isActive(true)])().count().then(c => c > 0);
    }

    openMenu ():void {
        clickElement(filterElements($$('i[ng-click="drawerVM.toggleDrawerPosition()"]'), [ isActive(true)])().first());
    }

    selectMenuItemMatchingText (text:string):void {
        this.isViewDisplayed().then((d) => {
            if(d) this.openMenu();
        });
        clickElement(filterElements($$('div'), [ isActive(true), matchingText(text)])().first());
    }

    selectMenuItemContainingText (text:string):void {
        throw new NotImplementedError();
    }
}
