/// <reference path="../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;
import Promise = protractor.promise.Promise;
import { filterElements, isActive, containingText } from './filterElementHelpers';

// String functions

/**
 * Normalizes text for comparison.
 * Strips/trims whitespace, forces to lower case
 * @param text
 */
export function normalizeText (text:string):string {
    return text.toString().toLowerCase().replace(/\s\s+/g, ' ').trim();
}

/**
 * Tests if normalized textB matches normalized textA
 * @param textA
 * @param textB
 * @returns {boolean}
 */
export function textMatchesText (textA:string, textB:string):boolean {
    return normalizeText(textA) === normalizeText(textB);
}

/**
 * Tests if normalized textB is contained in normalized textA
 * @param textA
 * @param textB
 * @returns {boolean}
 */
export function textContainsText (textA:string, textB:string):boolean {
    return textContainsExactText(normalizeText(textA), normalizeText(textB));
}

/**
 * Tests if textB is contained in textA
 * @param textA
 * @param textB
 * @returns {boolean}
 */
export function textContainsExactText (textA:string, textB:string):boolean {
    return textA.indexOf(textB) !== -1;
}

export function textEndsWith (text:string, endsWith:string):boolean {
    return text.slice(-endsWith.length) == endsWith;
}

/**
 * Parse and return number value from currency string
 * @param text
 * @returns {number}
 */
export function parseCurrencyString (text:string):number {
    return parseFloat(text.replace(/[^0-9-.]/g, ''));
}

export function getNegativeOrPositiveCurrencyString (text:string):string {
    return parseFloat(text.replace(/[^0-9-.]/g, '')).toString();
}

export function salesPeriodSeasonToFrench (salesPeriodSeason:string):string {
    return salesPeriodSeason.substring(0, 1) == 'F' ? 'A' : 'P';
}

export function getNegativeOrPositiveCurrencyStringInFrench (text:string):string {
    text = text.replace(/[^0-9-,]/g, '');
    text = text.replace(/[,]/g, '.');
    return text;
}

export function getBalanceReportsRow (operation:string, invoice:string, businessPartner:string, salesPeriod:string):ElementFinder {
    return filterElements(
        $$('tr[ng-repeat-start]'),
        [
            isActive(true),
            containingText(operation),
            containingText(invoice),
            containingText(businessPartner),
            containingText(salesPeriod)
        ]
    )().first();
}
/**
 * Escapes string for use in regular expressions
 * https://developer.mozilla.org/en/docs/Web/JavaScript/Guide/Regular_Expressions
 * @param text
 * @returns {string}
 */
export function escapeRegExp (text:string) {
    return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

export function removeLineBreaks (text:string):string {
    return text.replace(/(\r\n|\n|\r)/gm, '');
}

/**
 * Escapes string for use in regular expressions
 * Legacy method from UtilityHelpers
 * @param regexString
 * @returns {string}
 */
export function legacyEscapeRegExp (regexString:string):string {
    return regexString.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
}

/**
 * Replaces all instances of find with replace in text
 * @param text
 * @param find
 * @param replace
 * @returns {string}
 */
export function replaceAllInText (text:string, find:string, replace:string) {
    return text.replace(new RegExp(escapeRegExp(find), 'g'), replace);
}

// Number functions

/**
 * Generates a random number in a defined range
 * @param to
 * @param from
 * @returns {number}
 */
export function randomNumberInRange (to:number, from:number):number {
    return Math.floor(Math.random() * (from - to + 1) + to);
}

// Array functions

/**
 * Returns an array representing a number range [0,1,...]
 * @param size
 * @returns {number[]}
 */
export function range (size:number):number[] {
    return <number[]>Array.apply(null, Array(size)).map((_:any, i:number) => i);
}

export function getRandomQueryResult (array:any[]):any {
    let randomItem = randomItemFromArray(array);
    console.log(`Query results: ${JSON.stringify(randomItem, null, 2)}`);
    return randomItem;
}

export function randomItemFromArray (array:any[]):any {
    return array[ randomNumberInRange(0, array.length - 1) ];
}

// Date functions

/**
 * Returns current date in various formats
 * @param format
 *      1: MM/DD/YYYY
 *      2: MMDDYYYY
 */
export function formattedDate (format:number, addSubtractDays?:number):string {
    var date = new Date();

    if (typeof addSubtractDays !== 'undefined') {
        date.setTime(date.getTime() + addSubtractDays * 86400000);
    }

    switch (format) {
        case 1:
            var month = ('0' + (date.getMonth() + 1)).slice(-2);
            var day = ('0' + date.getDate()).slice(-2);
            var year = date.getFullYear();
            return month + '/' + day + '/' + year;
        case 2:
            return formattedDate(1, addSubtractDays).replace(/\//g, '');
    }
}

// Object functions

/**
 * Returns a best guess if variable is an object literal
 * @param object
 * @returns {boolean}
 */
export function isObjectLiteral (object:any) {
    var test = object;

    if (typeof object !== 'object' || object === null) {
        return false;
    }

    return (function () {
        for (; ;) {
            if (Object.getPrototypeOf(test = Object.getPrototypeOf(test)) === null) {
                break;
            }
        }

        return Object.getPrototypeOf(object) === test;
    })();
}

/**
 * Based on polyfill for Object.assign.
 * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/assign
 * @param target
 * @param sources
 * @returns {T}
 */
export function objectAssign<T> (target:any, ...sources:any[]):T {
    if (target == null) {
        throw new TypeError('Cannot convert undefined or null to object');
    }

    const mergeObject:T & { [s:string]:any } = Object(target);

    for (let index = 0; index < sources.length; index++) {
        let source = sources[ index ];
        if (source != null) {
            for (var key in source) {
                if (Object.prototype.hasOwnProperty.call(source, key)) {
                    mergeObject[ key ] = source[ key ];
                }
            }
        }
    }

    return mergeObject;
}

/**
 * Pass a dot notation path string to access properies on an object
 * @param object
 * @param path
 * @returns {T}
 */
export function accessObjectPropertyByKeyPath<T> (object:T & { [s:string]:any }, path:string):T {
    const a = path
        .replace(/\[(\w+)\]/g, '.$1')
        .replace(/^\./, '')
        .split('.');

    for (let i = 0, n = a.length; i < n; ++i) {
        const key = a[ i ];
        if (key in object) {
            object = object[ key ];
        } else {
            return;
        }
    }

    return object;
}

// Misc functions

/**
 * Generates a guid string
 * @returns {string}
 */
export function generateGuid ():string {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
        const r = Math.random() * 16 | 0;
        const v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

export function isUndefined (x:any):boolean {
    return typeof x === 'undefined';
}

export function isTrue (x:string):boolean {
    return x === 'true';
}

/**
 * @returns {Promise<R>} remove the domain from a URL, keeping everything from the '#' and on
 */
export function getDomainStrippedUrl ():Promise<string> {
    return browser.getCurrentUrl().then((url) => {
        return url.substring(url.indexOf('#'), url.length);
    });
}

/**
 * @param urlPattern: a substring of a page url you want to verify (* is wild)
 *      verify url: http://salestx.pioneer.com/api/operation/123/customer/456
 *      urlPattern: operation / * /customer/ * /    (without spacing, IDE is buggy)
 * @returns {RegExp}
 */
export function convertPageUrlPatternToRegex (urlPattern:string):RegExp {
    urlPattern = replaceAllInText(urlPattern, `/`, `\/`); // escape forward slashes
    urlPattern = replaceAllInText(urlPattern, `*`, `.*?`); // * means match anything
    return new RegExp(urlPattern);
}

export function getRandomNumberAsString():string {
    /** Value used to full inputs in PVC form */
    return (Math.random() * 100).toFixed(1);
}

export function getRandomNumber():number {
    return (Math.random() * 100);
}

export function getDuplicates(arr:string[]):string[] {
    let uniq = arr.map((a) => {
        return { count: 1, name: a }
    }).reduce((a:any, b:any) => {
        a[ b.name ] = (a[ b.name ] || 0) + b.count;
        return a;
    }, {});
    let duplicates = Object.keys(uniq).filter((a) => uniq[ a ] > 1);
    return duplicates;
}