/// <reference path= '../../../../typings/index.d.ts'/>

export class TD {
    public myTestCustomer: any;
}