/// <reference path="../../../../typings/index.d.ts" />

import { EllipseItem2 } from '../../../../modules_v3/testdata/EllipseItem';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import SharedEllipseNavigationTestData from '../shared/SharedSalesSupportNavigationTestData';
import { SharedSalesSupportNavigationSteps } from '../shared/SharedSalesSupportNavigationSteps';

const test = new TestCase(
	'295918.2',
	'Snack Bar Menu - Invoice Option - Sales Support',
	UserRole.SALES_SUPPORT,
	ApplicationFeature.NAVIGATIONS
);

describe(test.stringify, () => {
    const sharedSteps = new SharedSalesSupportNavigationSteps();
    const td = new SharedEllipseNavigationTestData();

    const preEllipseItem:EllipseItem2 = td.availableEllipseItems.invoice;

    const ellipseItems:Array<EllipseItem2> = [
        td.availableEllipseItems.products,
        td.availableEllipseItems.documents,
        td.availableEllipseItems.chargeAndCredits,
        td.availableEllipseItems.discounts,
        td.availableEllipseItems.shares,
        td.availableEllipseItems.activityStatement,
        td.availableEllipseItems.growthAndRetentionOverview,
        td.availableEllipseItems.operation,
        td.availableEllipseItems.search
    ];

    sharedSteps.run(test.description, td , ellipseItems ,preEllipseItem);
});