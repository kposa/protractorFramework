/// <reference path="../../../../typings/index.d.ts" />

import { Helpers } from "../../../../modules/shared/Helpers";
import { AgreementsSR } from "../../../../modules/sales_rep/screens/AgreementsSR";
import SignaturePadPartialView from '../../../../modules_v3/views/shared/SignaturePadPartialView';
import { NavigationsSR } from "../../../../modules/sales_rep/navigations/NavigationsSR";
import { DeferredPaymentSR } from "../../../../modules/sales_rep/screens/DeferredPaymentSR";
import { DeferredPaymentAgreementTermsSR } from "../../../../modules/sales_rep/screens/DeferredPaymentAgreementTermsSR";
import { DeferredPaymentLoanApplicationFormSR } from "../../../../modules/sales_rep/screens/DeferredPaymentLoanApplicationFormSR";
import { DeferredPaymentAgreementTypeSelectionSR } from "../../../../modules/sales_rep/screens/DeferredPaymentAgreementTypeSelectionSR";
import { DeferredPaymentBorrowerInformationFormSR } from "../../../../modules/sales_rep/screens/DeferredPaymentBorrowerInformationFormSR";
import { DeferredPaymentBusinessConfirmationFormSR } from "../../../../modules/sales_rep/screens/DeferredPaymentBusinessConfirmationFormSR";
import { SalesRepOperationsFullView } from "../../../../modules_v3/views/salesRep/SalesRepOperationsFullView";
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { SharedDPAgreementTestData } from "./SharedDPAgreementTestData";
import { itw } from '../../../../modules_v3/helpers/itw';
import { SalesRepBusinessPartnersFullView } from '../../../../modules_v3/views/salesRep/SalesRepBusinessPartnersFullView';

let hlp = new Helpers();
let nav = new NavigationsSR();
let dp = new DeferredPaymentSR();
const businessPartnersScreenView = new SalesRepBusinessPartnersFullView();
let agreements = new AgreementsSR();
const signaturePad = new SignaturePadPartialView();
let terms = new DeferredPaymentAgreementTermsSR();
let dpForm = new DeferredPaymentLoanApplicationFormSR();
let dpTypeSelection = new DeferredPaymentAgreementTypeSelectionSR();
let borrowerInfoForm = new DeferredPaymentBorrowerInformationFormSR();
let businessConfForm = new DeferredPaymentBusinessConfirmationFormSR();
const salesRepOperationsFullView = new SalesRepOperationsFullView();

export class SharedDPAgreementSteps {
    public run (description:string, td:SharedDPAgreementTestData, pending?:string):void {
        itw(description, () => {
            td.populatePromise().then(() => {
                // bootstrap (load, login, reset feature flags, impersonate)
                browser.controlFlow().execute(() => {
                 //   bootstrap(td.salesRepresentative);
                });

                // navigate to [Operation]
                salesRepOperationsFullView.search(td.operation.name);
                salesRepOperationsFullView.clickSearchResultMatchingText(td.operation.name);

                // navigate to [Business Partners]
                nav.ellipse('business partners');

                if (td.useAlternateNavigationToDPAgreement) {
                    // should navigate to the Deferred Payment screen and click the Deferred Payment Loan Agreement sign button
                    businessPartnersScreenView.clickBalancesButtonById(td.businessPartner.id);
                    nav.ellipse('deferred payment');
                    dp.clickSignButton();
                } else {
                    // should navigate to the Deferred Payment Loan Agreement screen
                    businessPartnersScreenView.clickAgreementsButtonByName(td.businessPartner.name);
                    agreements.clickSignDeferredPaymentLoanAgreement();
                }

                // should verify the default radio button options are displayed
                expect(dpTypeSelection.areDefaultRadioButtonsDisplayed()).toBe(true);

                let radioButton = td.customerType == 1 ? 'Individual/Sole Proprietor' : 'Corporation';

                // should select the [radioButton] radio button and click [Continue]
                dpTypeSelection.selectRadioButton(td.customerType);
                dpTypeSelection.clickContinueButton();

                // should verify editable and non-editable fields
                expect(dpForm.isAddressFieldEditable()).toBe(false);
                expect(dpForm.isWorkPhoneFieldEditable()).toBe(true);
                expect(dpForm.isMobilePhoneFieldEditable()).toBe(true);
                expect(dpForm.isHomePhoneFieldEditable()).toBe(true);
                expect(dpForm.isFaxFieldEditable()).toBe(true);
                expect(dpForm.isEmailFieldEditable()).toBe(true);

                if (td.customerType == 1) {
                    expect(dpForm.isSSNFieldEditable()).toBe(true);
                    expect(dpForm.isDateOfBirthFieldEditable()).toBe(true);
                    expect(dpForm.isPreApprovedCreditLimitFieldEditable()).toBe(false);
                    expect(dpForm.isRequestedCreditLimitFieldEditable()).toBe(true);
                } else if (td.customerType == 2) {
                    expect(dpForm.isLegalFirstNameEditable()).toBe(false);
                    expect(dpForm.isLegalMiddleNameEditable()).toBe(false);
                    expect(dpForm.isLegalLastNameEditable()).toBe(false);
                }

                // should enter at least 1 phone number and verify its formatted correctly
                dpForm.enterWorkPhoneNumber();
                expect(dpForm.isWorkPhoneFormatted).toBe(true);

                // should enter an email and verify its formatted correctly
                dpForm.enterEmail();
                expect(dpForm.isEmailFormatted).toBe(true);

                if (td.customerType == 1) {
                    // should enter the SSN and verify its formatted correctly
                    dpForm.enterSSN();
                    expect(dpForm.isSSNFormatted()).toBe(true);

                    // should enter a date of birth > 18 years ago and verify its formatted correctly
                    dpForm.enterDateOfBirth();
                    expect(dpForm.isDateOfBirthFormatted).toBe(true);

                    // should get the current [Pre-Approved Credit Limit]
                    dpForm.preApprovedCreditLimitValue.then(t => {
                        const n = hlp.stringToNumber(t);
                        // should enter an amount in the [Requested Credit Limit] field that is HIGHER than the [Pre-Approved Credit Limit]
                        const m = n + 1;
                        dpForm.enterRequestedCreditLimit(m);
                        expect(dpForm.isRequestedCreditLimitFormatted).toBe(true);
                    });
                } else if (td.customerType == 2) {
                    // should select a business partner from the dropdown
                    dpForm.selectABusinessPartner();
                } else {
                    throw new Error('You must specify a customer type of 1 or 2 (Individual or Business)');
                }

                // should click the [Confirm] button
                dpForm.clickConfirm();

                if (td.customerType == 2) {    //fill out business confirmation form

                    // should enter a [Tax Id]
                    businessConfForm.enterTaxId();
                    if (!this.isCanadianForm(td.customerCultureName)) expect(businessConfForm.isTaxIdFormatted).toBe(true);

                    // should enter the [Date of Incorporation/Organization] < todays date
                    businessConfForm.enterDateOfIncorporation();

                    // should enter a [SSN]
                    businessConfForm.enterSSN();
                    expect(businessConfForm.isSSNFormatted).toBe(true);

                    // should enter the [Partner/Member/President Name]
                    businessConfForm.enterPresidentName();

                    // should enter the [Date of Birth]
                    businessConfForm.enterDateOfBirth();
                    expect(businessConfForm.isDateOfBirthFormatted).toBe(true);

                    // should get the current [Pre-Approved Credit Limit]
                    businessConfForm.preApprovedCreditLimitValue.then(t => {
                        const n = hlp.stringToNumber(t);
                        // should enter an amount in the [Requested Credit Limit] field that is HIGHER than the [Pre-Approved Credit Limit]
                        const m = n + 1;
                        dpForm.enterRequestedCreditLimit(m);
                        expect(dpForm.isRequestedCreditLimitFormatted).toBe(true);
                    });

                    // should click the [Confirm] button
                    businessConfForm.clickConfirm();

                    // should enter a primary lender name
                    borrowerInfoForm.enterPrimaryLender();

                    // should enter a city
                    borrowerInfoForm.enterCity();

                    // should select a state from the dropdown menu
                    borrowerInfoForm.selectStateProvince();

                    // should click the [Continue] button
                    borrowerInfoForm.clickContinue();

                    // should verify the [DEFERRED PAYMENT LOAN TERMS & CONDITIONS] document displays
                    expect(terms.isTermsAndConditionsDisplayed).toBe(true);

                    // should verify the [Borrower] name displays below the terms & conditions text
                    expect(terms.isBorrowerNameDisplayed).toBe(true);

                    // should click the [Sign] button
                    terms.clickSign();

                    // should verify the footer text and sign the signature pad
                    expect(signaturePad.getFooterText()).toContain('I acknowledge that I have read and understand the terms and conditions');
                    signaturePad.strokeSignature();
                    signaturePad.clickAgree();

                    // should click the [Select] button
                    signaturePad.clickSelect();

                    // should verify the footer text and sign the signature pad
                    expect(signaturePad.getFooterText()).toContain('I have witnessed said Grower reading and agreeing to the terms and conditions');
                    signaturePad.strokeSignature();
                    signaturePad.clickAgree();

                    // should verify the confirmation message displays for the submitted agreement
                    expect(terms.isSubmittedAgreementConfirmationDisplayed).toBe(true);
                    expect(terms.submittedAgreementConfirmationMessageText).toContain('Thank you for choosing PHI Financial Services for your financing needs');

                    // should click the [FINISH] button
                    terms.clickFinish();

                    // should verify the user is routed back to the [Agreements] or [Deferred Payments] screen depending where they started
                    expect(browser.getCurrentUrl()).toContain(td.useAlternateNavigationToDPAgreement ? 'financials/deferredpayments' : 'customers/agreements')
                }
            }, fail);
        }, pending);
    }

    private isCanadianForm (cultureName:string):boolean {
        return cultureName && Boolean(~cultureName.toLowerCase().indexOf('ca'));
    }

}