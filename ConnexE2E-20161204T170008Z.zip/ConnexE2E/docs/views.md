# [Connex E2E Documentation](/)

## Views

Views (same as page objects) are classes that represent views in the Connex application. They expose methods that facilitate interaction with the view (click item, fill in form input)

### Located

`./modules_v3/views`

### Full View

Full views are views that represent a page as a whole. They typically have unique urls/patterns and contain partial views.

### Partial View

Partial views are views that represent a single atomic component on that page (drawer, form).

### Element properties on a view

Elements are DOM elements present in a view and used by the view object's methods for interacting with the view. Elements should always be `private` or `protected` and not directly used in tests.
 
#### Root View Element

The top level element in a view is the root view element. All other view elements should be queried using the root view element as a bounding parameter. This tightens the scope of what elements are being pulled in to the view object.

```
class LoginFullView {
    private root = $('section.login');
    private usernameInput = this.root.$('.username');
    private passwordInput = this.root.$('.password');
    private submitButton = this.root.$('input[type="submit"]');
}
```

In this example `.username`, `.password` and `input[type="submit"]` are queried for only inside of the root element `section.login`

### Interfaces

There are two types of interfaces that apply to views.

#### View Based

The view based interfaces are interfaces implemented for a full/partial view. They are there to ensure views that span across multiple user roles are consistent.

#### Behavioural Based

The behaviroual based interfaces are very high level and describe charateristics of a full/partial view.