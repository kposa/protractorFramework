/// <reference path="../../../../typings/index.d.ts" />

import {PreviewDocumentSR} from "../../../../modules/sales_rep/screens/PreviewDocumentSR";
import {SalesRepAgreementSR} from "../../../../modules/sales_rep/screens/SalesRepAgreementSR";
import SalesRepNavigationMenuView from '../../../../modules_v3/views/salesRep/SalesRepNavigationMenuPartialView';
import TestData359129 from './testData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
	'359129',
	'Sales Rep can sign the Barcode Scanner Agreement',
	UserRole.SALES_REP,
	ApplicationFeature.AGREEMENTS
);

describe(test.stringify, () => {
    const td = new TestData359129();
    const navigationMenuView = new SalesRepNavigationMenuView();
    const pd = new PreviewDocumentSR();
    const srAgreement = new SalesRepAgreementSR();

    itw(test.description, () => {
        // bootstrap (load, login, reset feature flags, impersonate)
        bootstrap(td.salesRepresentative);

        // should click on [Barcode Scanner agreement] link from the [Hamburger]
        navigationMenuView.openMenu();
        navigationMenuView.selectMenuItemContainingText('Agreements');

        // should click on the [Sign] button next to [Barcode Scanner Agreement] (if applicable), sign and click [agree]
        srAgreement.signBarcodeScannerAgreement();

        // should verify if the signed agreement displays under signed section', ():void => {
        expect(srAgreement.verifyIfAgreementIsUnderSigned()).toEqual('Signed Agreements');

        // should click [View] button for the signed [Barcode Scanner Agreement]
        srAgreement.showSignedAgreementPreview();

        // should assert on [Email] and [Print] icons on the [Preview Agreement] page
        expect(pd.isEmailIconDisplayed()).toBeTruthy();
        expect(pd.isPrintIconDisplayed()).toBeTruthy();
    });
});