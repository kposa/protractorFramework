/// <reference path="../../../../typings/index.d.ts" />

import {
    SharedITSupportEllipseNavigationSteps
} from '../shared/SharedITSupportEllipseNavigationSteps';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { SharedITSupportEllipseNavigationTestData } from '../shared/SharedITSupportEllipseNavigationTestData';

const test = new TestCase(
    '295852.1',
    'Ellipse Menu - Invoice Summary page',
    UserRole.IT_SUPPORT,
    ApplicationFeature.NAVIGATIONS
);

describe(test.stringify, () => {
    const sharedSteps = new SharedITSupportEllipseNavigationSteps();
    const td = new SharedITSupportEllipseNavigationTestData();

    td.accountDescriptionButtonText = 'Invoice';

    td.ellipseItems = [
        td.availableEllipseItems.documents,
        td.availableEllipseItems.payments,
        td.availableEllipseItems.deliveries,
        td.availableEllipseItems.activityStatement,
        td.availableEllipseItems.accountDescription,
        td.availableEllipseItems.growthAndRetentionOverview
    ];

    sharedSteps.run(td, test.description);
});