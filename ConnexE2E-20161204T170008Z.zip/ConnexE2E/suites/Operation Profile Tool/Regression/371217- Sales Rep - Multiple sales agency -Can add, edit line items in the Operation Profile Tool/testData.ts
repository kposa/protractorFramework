/// <reference path="../../../../typings/index.d.ts" />

import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';
import { salesRepsWithMultipleAgencies, salesRepsWithMultipleAgenciesResults } from './queries';

export class TestData371217 extends BaseTestData {

    protected queries:(() => Promise<any>)[] = [
        this.getSalesRepsWithMultipleAgencies()
    ];

    private getSalesRepsWithMultipleAgencies ():() => Promise<salesRepsWithMultipleAgenciesResults> {
        return () => {
            const sql = salesRepsWithMultipleAgencies();
            const results = this.queryService.executeSql<salesRepsWithMultipleAgenciesResults[]>(sql);

            return results
                .then(data => {
                    const row = <salesRepsWithMultipleAgenciesResults>getRandomQueryResult(data);

                    this.salesRepresentatives.push({
                        id: row.salesRepId,
                        name: row.salesRepName
                    });
                    this.salesAgencies.push({
                        id: row.salesAgencyId,
                        name: row.salesAgencyName
                    });
                    return row;
                });
        };
    }
}