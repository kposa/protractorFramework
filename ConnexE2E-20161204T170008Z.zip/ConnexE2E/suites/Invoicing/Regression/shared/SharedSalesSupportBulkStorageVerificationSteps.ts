/// <reference path="../../../../typings/index.d.ts" />

import { SalesSupportMasterSearchFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportMasterSearchFullView';
import { SalesSupportSalesAgencyOperationsFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportSalesAgencyOperationsFullView';
import { SalesSupportOperationFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportOperationFullView';
import { SalesSupportInvoiceFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportInvoicePageFullView';
import { itw } from '../../../../modules_v3/helpers/itw';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { SharedBulkStorageVerificationTestData } from '../../../Proposals/Regression/shared/SharedBulkStorageVerificationTestData';

let salesSupportMasterSearchFullView = new SalesSupportMasterSearchFullView();
let salesSupportSalesAgencyOperationsFullView = new SalesSupportSalesAgencyOperationsFullView();
let salesSupportOperationFullView = new SalesSupportOperationFullView();
let salesSupportInvoiceFullView = new SalesSupportInvoiceFullView();

export function sharedSalesSupportBulkStorageVerificationSteps (td:SharedBulkStorageVerificationTestData, description:string, pending?:string) {

    itw(description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.salesSupportUser);

            // should search sales agency
            salesSupportMasterSearchFullView.search(td.salesAgency.id);
            salesSupportMasterSearchFullView.selectFilterContainingText('Sales agencies');
            salesSupportMasterSearchFullView.clickSearchResultContainingText(td.salesAgency.name);

            //should select first operation
            salesSupportSalesAgencyOperationsFullView.selectFirstOperation();

            //should select first account
            salesSupportOperationFullView.clickFirstAccount();

            //should click on invoice on the toster menu
            salesSupportOperationFullView.toasterMenu.selectMenuItemContainingText('Invoice');

            //should click add button
            salesSupportInvoiceFullView.clickAddLineItemButton();

            //should verify products line ite drawer displayed
            expect(salesSupportInvoiceFullView.salesSupportProductsLineItemDrawerSection.isViewDisplayed()).toBeTruthy();

            //should select product line
            salesSupportInvoiceFullView.salesSupportProductsLineItemDrawerSection.selectProductLine(td.product.line);

            //should select product
            salesSupportInvoiceFullView.salesSupportProductsLineItemDrawerSection.selectProduct(td.product.name);

            //should select subproduct
            salesSupportInvoiceFullView.salesSupportProductsLineItemDrawerSection.selectSubProduct(td.product.subName);

            //should verify units drawer displayed
            expect(salesSupportInvoiceFullView.salesSupportProductUnitsDrawerSection.isViewDisplayed()).toBeTruthy();

            //should enter units
            salesSupportInvoiceFullView.salesSupportProductUnitsDrawerSection.fillInputUnits('50');

            //should verify [Direct shipment] field displays if the agency has bulk storage
            expect(salesSupportInvoiceFullView.salesSupportProductsLineItemDrawerSection.isDirectShipmentFieldDisplayed())
                .toBe(td.agencyHasBulkStorage);

            //should verify the [Bulk storage] field displays if the agency does not have bulk storage
            expect(salesSupportInvoiceFullView.salesSupportProductsLineItemDrawerSection.isBulkStorageFieldDisplayed())
                .toBe(!td.agencyHasBulkStorage);

        }, fail);
    });
}