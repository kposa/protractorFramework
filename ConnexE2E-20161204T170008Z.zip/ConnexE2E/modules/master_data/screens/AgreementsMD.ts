/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import {Element} from "./../../shared/Element";
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

let e = new Element();

export class AgreementsMD {
    public selectAgreement(agreement?:string):void {
        if (agreement) {
            var busiPartnersArr = $('section.salessupport-availableagreements').$$('div.pm-listitem-primary');
            e.clickDisplayedElementWithMatchingText(busiPartnersArr, agreement);
        } else {
            clickElement($('section.salessupport-availableagreements').$$('div.pm-listitem-primary').get(0));
        }
    }

    public agreementTo(action:string):void {
        e.clickDisplayedElementWithMatchingText($$('div.pm-text-label'), 'External Id');
        var externalId = $$('input[ng-keypress="$event.stopPropagation()"]').get(0);
        externalId.sendKeys('A@2');
        var calendar = $('i[ng-class="filter-on"]');
        clickElement(calendar);
        e.clickDisplayedElementWithMatchingText($$('span'), 'NOW');
        e.clickDisplayedElementWithMatchingText($$('span'), 'SAVE');
        e.clickDisplayedElementWithMatchingText($$('div.pm-button-text'), action);
    }

    public verifyHeader():Promise<String> {
        let headerDisplay = $('div.pm-title');
        return headerDisplay.getText();

    }

    public verifyIfAgreementIsUnderSigned():Promise<String> {
        let signedAgreement = $$('div[ng-repeat="agreement in vm.signedAgreements"]').get(0).element(by.xpath('../..'));
        let signedlabel = signedAgreement.$('div.pm-list-subheader');
        //return signedlabel.isDisplayed();
        return signedlabel.getText();
    }

    public clickOnEyeballForSignedTechAgreement(customerId:number):void {
        let signedAgreementSection = $('section.salessupport-signedagreements');
        let eyeball = signedAgreementSection.$('a[href="#/masterdata/documents/customer/' + customerId + '/agreement/1"]').$('i.material-icons');
        clickElement(eyeball);
    }
}