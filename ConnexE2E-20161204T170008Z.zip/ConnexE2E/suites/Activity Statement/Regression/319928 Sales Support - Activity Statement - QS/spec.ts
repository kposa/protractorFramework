/// <reference path="../../../../typings/index.d.ts" />

import { ActivityStatementSS } from "../../../../modules/sales_support/screens/ActivityStatementSS";
import { OperationSR } from "../../../../modules/sales_rep/screens/OperationSR";
import { PreviewDocumentSR } from "../../../../modules/sales_rep/screens/PreviewDocumentSR";
import SalesSupportNavigationMenuPartialView from '../../../../modules_v3/views/salesSupport/SalesSupportNavigationMenuPartialView';
import { SalesRepOperationsFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationsFullView';
import { SalesRepOperationFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationFullView';
import { SalesSupportMasterSearchFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportMasterSearchFullView';
import SalesSupportOperationBalancesFullView from '../../../../modules_v3/views/salesSupport/SalesSupportOperationBalancesFullView';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import TestData319928 from './testData';
import { itw } from '../../../../modules_v3/helpers/itw';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { BalancesSS } from '../../../../modules/sales_support/screens/BalancesSS';

const test = new TestCase(
    '319928',
    'Sales Support - Activity Statement - QS',
    UserRole.SALES_SUPPORT,
    ApplicationFeature.ACTIVITY_STATEMENT
);

describe(test.stringify, () => {
    const td = new TestData319928();
    const salesSupportNavigationMenuPartialView = new SalesSupportNavigationMenuPartialView();
    const salesRepOperationsFullView = new SalesRepOperationsFullView();
    const salesRepOperationFullView = new SalesRepOperationFullView();
    const salesSupportMasterSearchFullView = new SalesSupportMasterSearchFullView();
    const salesSupportOperationBalancesFullView = new SalesSupportOperationBalancesFullView();
    let operationSR = new OperationSR();
    let balances = new BalancesSS();
    let activityStatement = new ActivityStatementSS();
    let previewDocumentSR = new PreviewDocumentSR();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.salesRepresentative);

            // should select [Operation]
            salesRepOperationsFullView.search(td.operation.name);
            salesRepOperationsFullView.clickSearchResultMatchingText(td.operation.name);

            // should click on Invoice button
            salesRepOperationFullView.clickInvoiceButton(td.invoice.name);

            // should click on InvoiceSummary
            operationSR.clickPreviewinvoiceIcon();
            operationSR.clickOnShowToPreviewInvoice();

            // should preview the invoice and make note of the Quantity Savings [Total] amount
            expect(previewDocumentSR.previewDocumentHasQuantitySavings('Quantity Savings')).toBeTruthy();

            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.salesSupportUser);

            // should select business partner
            salesSupportMasterSearchFullView.search(td.businessPartner.name);
            salesSupportMasterSearchFullView.selectFilterContainingText('Business Partners');
            salesSupportMasterSearchFullView.clickSearchResultContainingText(td.businessPartner.name);

            // should select [Balances] from the hamburger
            salesSupportNavigationMenuPartialView.openMenu();
            salesSupportNavigationMenuPartialView.selectMenuItemContainingText('Balances');

            // should go to the activity statement by clicking [>] on Balances Page
            //salesSupportOperationBalancesFullView.clickInvoiceByNameAndSalesPeriod(td.invoice.name,
            //`${td.salesPeriod.year} ${td.salesPeriod.season}`);
            balances.goToActivityStatement(td.invoice.name);

            // should verify a row labeled [Quantity Savings Discount] displays under todays date
            expect(activityStatement.isQuantitySavingsDiscountDisplayed()).toBe(true);

            // should the [Amount] on the row matches the Quantity Savings [Total] amount noted previously
            expect(activityStatement.verifyDiscountNameInSecondSession('Quantity Savings')).toBe(true);
        }, fail);
    });
});