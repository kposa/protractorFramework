/// <reference path='../../../typings/index.d.ts' />
import ElementFinder = protractor.ElementFinder;
import { IView } from '../../interfaces/common/IView';
import Promise = protractor.promise.Promise;
import { IExpandableMenuView } from '../../interfaces/common/IExpandableMenuView';
import { NotImplementedError } from '../../../common/exception/Exceptions';
import { filterElements, isActive, containingText } from '../../helpers/filterElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';

export class MasterDataAgencyFullView implements IView {
    public hamburgerMenu = new HamburgerMenu();

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }
}

class HamburgerMenu implements IExpandableMenuView {

    openMenu ():void {
        let hamburgerIcon = $('button[ng-click="vm.toggleMenu()"]').$('md-icon');
        clickElement(hamburgerIcon);
    }

    selectMenuItemMatchingText (text:string):void {
        throw new NotImplementedError();
    }

    selectMenuItemContainingText (text:string):void {
        let item = filterElements($$('md-list-item[role="listitem"]'), [ isActive(true), containingText(text) ])().first();
        clickElement(item);
    }
}