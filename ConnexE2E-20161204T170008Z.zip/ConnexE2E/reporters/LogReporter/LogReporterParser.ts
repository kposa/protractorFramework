///<reference path="../../typings/index.d.ts"/>

import fs = require('fs');

import {
    LogItem,
    SuiteDoneLogItem,
    SpecDoneLogItem,
    JasmineStartedLogItem, FailedExpectation, SuiteStartedLogItem
} from './LogReporterData';
import { TestResult } from './TestResult';
import { TestCase } from './testConstants';
import { testCaseIds, expectedIds } from '../../protractor.config';

export class LogReporterParser {
    private logFileData:LogItem[];
    private jasmineStarteds:JasmineStartedLogItem[];
    private suiteStarteds:SuiteStartedLogItem[];
    private suiteDones:SuiteDoneLogItem[];
    private specDones:SpecDoneLogItem[];

    constructor (fileName?:string) {
        this.logFileData = this.parseLogFileToData(fileName);
        this.jasmineStarteds = this.extractJasmineStarteds();
        this.suiteStarteds = this.extractSuiteStarteds();
        this.suiteDones = this.extractSuiteDones();
        this.specDones = this.extractSpecDones();
    }

    private parseLogFileToData (fileName:string):LogItem[] {
        return fs
            .readFileSync(fileName).toString()
            .trim()
            .split("\n")
            .map(function (line) {
                return JSON.parse(line)
            });
    }

    private extractSuiteStarteds ():SpecDoneLogItem[] {
        const specs:SpecDoneLogItem[] = [];

        function isSuiteDoneLogItem (logItem:LogItem | SuiteStartedLogItem):logItem is SuiteStartedLogItem {
            return logItem.message === "suiteStarted";
        }

        this.logFileData.forEach((logItem:LogItem | SpecDoneLogItem) => {
            if (isSuiteDoneLogItem(logItem)) {
                specs.push(logItem);
            }
        });

        return specs;
    }

    private extractSuiteDones ():SuiteDoneLogItem[] {
        const suites:SuiteDoneLogItem[] = [];

        function isSuiteDoneLogItem (logItem:LogItem | SuiteDoneLogItem):logItem is SuiteDoneLogItem {
            return logItem.message === "suiteDone";
        }

        this.logFileData.forEach((logItem:LogItem | SuiteDoneLogItem) => {
            if (isSuiteDoneLogItem(logItem)) {
                suites.push(logItem);
            }
        });

        return suites;
    }

    private extractJasmineStarteds ():JasmineStartedLogItem[] {
        const runs:JasmineStartedLogItem[] = [];

        function isJasmineStartedLogItem (logItem:LogItem | JasmineStartedLogItem):logItem is JasmineStartedLogItem {
            return logItem.message === "jasmineStarted";
        }

        this.logFileData.forEach((logItem:LogItem | JasmineStartedLogItem) => {
            if (isJasmineStartedLogItem(logItem)) {
                runs.push(logItem);
            }
        });

        return runs;
    }

    private extractSpecDones ():SpecDoneLogItem[] {
        const specs:SpecDoneLogItem[] = [];

        function isSpecDoneLogItem (logItem:LogItem | SpecDoneLogItem):logItem is SpecDoneLogItem {
            return logItem.message === "specDone";
        }

        this.logFileData.forEach((logItem:LogItem | SpecDoneLogItem) => {
            if (isSpecDoneLogItem(logItem)) {
                specs.push(logItem);
            }
        });

        return specs;
    }

    private getStatus (logItem:SpecDoneLogItem):string {
        return logItem.data.status;
    }

    private getPendingReason (logItem:SpecDoneLogItem):string {
        return logItem.data.pendingReason;
    }

    private getFailureMessage (logItem:SpecDoneLogItem):string {
        let failedExpectations = this.extractFailedExpectations(logItem);
        return failedExpectations.length ? failedExpectations[ 0 ].message : '';
    }

    private getFailureStackTrace (logItem:SpecDoneLogItem):string {
        let failedExpectations = this.extractFailedExpectations(logItem);
        return failedExpectations.length ? failedExpectations[ 0 ].stack : '';
    }

    private extractFailedExpectations (logItem:SpecDoneLogItem):Array<FailedExpectation> {
        return logItem.data.failedExpectations;
    }

    get suitesDefined ():number {
        return this.suiteDones.length;
    }

    get specsDefined ():number {
        return this.jasmineStarteds
            .map(r => r.data.totalSpecsDefined)
            .reduce((sum, count) => sum + count);
    }

    get pendingSpecs ():SpecDoneLogItem[] {
        return this.specDones
            .filter(spec => spec.data.status === "pending");
    }

    get passingSpecs ():SpecDoneLogItem[] {
        return this.specDones
            .filter(spec => spec.data.status === "passed");
    }

    get failingSpecs ():SpecDoneLogItem[] {
        return this.specDones
            .filter(spec => spec.data.status === "failed");
    }

    get allSpecs ():SpecDoneLogItem[] {
        return this.specDones;
    }

    public getTestResults ():TestResult[] {
        let testResults:Array<TestResult> = [];

        let total = expectedIds();

        total = this.getIds(total);

        let dones = this.specDones.map((e) => { return this.extractDescription(e) });

        let doneids = dones.map(function (e) { return e.id });

        let difference = this.suiteStarteds.filter((i) => {
            return doneids.indexOf(this.extractDescription(i).id) === -1;
        });

        let unknowns = total.filter((i:string) => {
            return doneids.indexOf(i) === -1;
        });

        unknowns = unknowns.filter((i:string) => {
            return difference.map((e) => { return this.extractDescription(e).id }).indexOf(i) === -1;
        });

        /*
         -Loops through each completed test case (specDone) and creates a TestResult from each
         */
        for (let d of this.specDones) {
            let testResult = new TestResult();
            testResult.status = d.data.status;

            testResult.duration = this.calculateDuration(d.data.duration);

            if (testResult.status === 'pending'){
                testResult.pendingReason = d.data.pendingReason;
                testResult.status = 'NotExecuted';
            }

            if (testResult.status === 'failed'){
                testResult.failureMessage = d.data.failedExpectations[ 0 ].message;
                testResult.failureStackTrace = d.data.failedExpectations[ 0 ].stack;
            }

            let desc = this.extractDescription(d);
            testResult = this.filltestResult(testResult, desc);

            testResults.push(testResult);
        }

        // Loops over test cases that have a spec started but no result
        for (let specStarted of difference){
            let testResult = new TestResult();
            testResult.duration = 0;
            testResult.status = 'failed';
            testResult.failureMessage = 'Node process failed to complete';
            let desc = this.extractDescription(specStarted);
            testResult = this.filltestResult(testResult, desc);
            
            testResults.push(testResult);
        }

        // Loops over test cases that never started, but are registered to have ran (usually chrome not reachable error)
        for (let specStarted of unknowns){
            console.log('Hit an unknown! ' + specStarted);
            let testResult = new TestResult();
            testResult.duration = 0;
            testResult.status = 'failed';
            testResult.failureMessage = 'Unknown error (chrome not reachable?)';

            let desc = new TestCase(specStarted, 'Check test case ID', 'Unknown', 'Unknown')
            testResult = this.filltestResult(testResult, desc);

            testResults.push(testResult);
        }

        return testResults;
    }

    private filltestResult(t:TestResult, desc:TestCase): TestResult{
        t.testCaseId = desc.id;
        t.testCaseDescription = desc.description;
        t.feature = desc.feature;
        t.userRole = desc.userRole;

        return t
    }

    private extractDescription(i:(SuiteDoneLogItem | SpecDoneLogItem | SuiteStartedLogItem)):TestCase {
        let a = i.data.fullName.match(/({.+})/);
        if (a === null){
            console.log('error on ' + i.data.fullName);
        }
        let data = JSON.parse(a[0]);
        return new TestCase(data._id, data._description, data._userRole, data._feature)
    }

    private calculateDuration(duration:string):number{
        let rawduration = duration.split(' ');
        let arraymath = new Array;
        while (rawduration.length > 0) {
            rawduration.pop();
            arraymath.push(rawduration.pop());
        }
        arraymath = arraymath.reverse();

        let finalduration = 0;
        for (let i = 0; i < arraymath.length; i++){
            finalduration += (arraymath[arraymath.length - (i+1)] * Math.pow(60, i));
        }
        return finalduration
    }

    private getIds(globs:string[]):string[] {
        globs = globs.map((s) => {
            return s.match(/\d{6,7}(\.\d{1,2})?/)[ 0 ];
        });
        return globs;
    }
}