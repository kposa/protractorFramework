var fs = require('fs');
var mssql = require('mssql');

var files = fs.readdirSync('./results').filter(function (e){
    return e.endsWith('json')
});

mssql.connect("Server=JHTRSQ01,1600;Database=Invoices;User Id=ConnexAutoTest;Password=MbWq77X35hSrwYxN;MultipleActiveResultSets=true;Async=true;Connection Timeout=600").then(
    function() {
        tablecheck().then(dbupload).then(mssql.close).catch(function(err){
            mssql.close();
        })
    }
);

function tablecheck(){
    return new Promise(function (resolve, reject){
        new mssql.Request().query("SELECT * FROM e2e.testresults;").then(
            function() {
                console.log('Table found, skipping creation...');
                resolve();
            },
            function(err) {
                if (err.toString().indexOf("Invalid object name") !== -1){
                    createTable().then(
                        function(){resolve()},
                        function(err){reject(err)}
                    );
                }
                else{
                    console.log("Error checking for table..? " + err);
                    reject(err);
                }
            }
        );
    })
}

function createTable(){
    return new Promise(
        function(resolve, reject) {
            console.log("Table not found, creating table e2e.testresults");
            new mssql.Request().query("CREATE TABLE e2e.testresults(\
            ID INT                      NOT NULL,\
            testCaseId VARCHAR(50)      NOT NULL,\
            testCaseDescription VARCHAR(50)     NOT NULL,\
            userRole VARCHAR(50)                NOT NULL,\
            feature VARCHAR(50)                 NOT NULL,\
            status VARCHAR(20)                  NOT NULL,\
            duration VARCHAR(10)                NOT NULL,\
            retry INT                           NOT NULL,\
            PRIMARY KEY (ID)\
            );").then( // Make sure it worked
                function(){
                    console.log("Table e2e.testresults created");
                    resolve();
                },
                function(err){
                    console.log("Error on table creation: " + err);
                    reject(err);
                }
            );
        }
    );
}

function dbupload(){
    return (function(){
        for (var i = 0; i < files.length; i++){
            var file = JSON.parse(fs.readFileSync("./results/" + files[i]));
            for(var j in file){
                (function(){
                        var e = i;
                        var entry = file[j];
                        p.then(function(){new mssql.Request().query("INSERT INTO e2e.testresults \
        ( testCaseId , \
            testCaseDescription , \
            userRole , \
            feature , \
            status , \
            duration , \
            retry \
        ) \
            VALUES  ( " + entry.testCaseId + " , \
            '" + entry.testCaseDescription + "' , \
            '" + entry.userRole + "' , \
            '" + entry.feature + "' , \
            '" + entry.status + "' , \
            " + entry.duration + " , \
            " + e + " \
            )")
                        })
                    }
                )();
            }
        }
    })
}
