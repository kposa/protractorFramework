/// <reference path="../../../typings/index.d.ts" />

import {IClosableView} from "../common/IClosableView";

export interface IUnitsEntryDrawerPartialView extends IClosableView {
    clickUnitsCalculatorButton():void;
    fillInputUnits(units:string):void;
}