# [Connex E2E Documentation](/)

## Grid

> Selenium-Grid allows you run your tests on different machines against different browsers in parallel. That is, running multiple tests at the same time against different machines running different browsers and operating systems. Essentially, Selenium-Grid support distributed test execution. It allows for running your tests in a distributed test execution environment.

-- [http://www.seleniumhq.org/docs/07_selenium_grid.jsp](http://www.seleniumhq.org/docs/07_selenium_grid.jsp)

### Configuration

Setting `gridIsEnabledLocally` in `./localConfig/grid.ts` to `true`

### Command Line

See [RunningTests#Grid](/runningTests.html#grid)

**Note:** Passing this argument will override local configuration settings.