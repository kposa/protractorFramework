export interface ReportingLocalConfig {
    [s:string]:boolean;
    jasmineSpecReporter:boolean;
    customJSONReporter:boolean;
    failFast:boolean;
    pauseReporter:boolean;
    screenshotReporter:boolean;
}

export const reportingLocalConfig:ReportingLocalConfig = {

    /** A jasmine reporter to output test and stack trace information to the console */
    jasmineSpecReporter: true,

    /** A Connex reporter that utilizes jasmine's specDone information to generate specific reports */
    customJSONReporter: true,

    /** Forces jasmine to stop test execution after the first failure */
    failFast: true,

    /** Forces the browser to pause on failure */
    pauseReporter: false,

    /** Takes a screenshot on test failure */
    screenshotReporter: false
};