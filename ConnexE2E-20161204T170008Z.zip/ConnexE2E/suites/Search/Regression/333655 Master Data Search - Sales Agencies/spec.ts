/// <reference path="../../../../typings/index.d.ts" />

import sharedMasterDataSearchSteps from '../shared/sharedMasterDataSearchSteps';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import TestDataMasterDataSearch from '../shared/sharedMasterDataSearchTestData';

const test = new TestCase(
	'333655',
	'Master Data Search - Sales Agencies',
    UserRole.MASTER_DATA,
    ApplicationFeature.SEARCH
);

describe(test.stringify, () => {
    const td = new TestDataMasterDataSearch('Agency', 'Sales agencies', 'Sales agency');
    sharedMasterDataSearchSteps(test.description, td);
});