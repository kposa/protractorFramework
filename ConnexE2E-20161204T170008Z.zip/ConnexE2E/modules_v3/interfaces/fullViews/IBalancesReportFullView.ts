
import Promise = webdriver.promise.Promise;

export interface IBalancesReportFullView {
    isAccountDescHeaderDisplayed ():Promise<boolean>;
    isNetInvoiceHeaderDisplayed ():Promise<boolean>;
    isBusinessPartnerHeaderDisplayed ():Promise<boolean>;
    isSalesPeriodHeaderDisplayed ():Promise<boolean>;
    isNetPaymentsHeaderDisplayed ():Promise<boolean>;
    isNetPendingPaymentsHeaderDisplayed ():Promise<boolean>;
    isPioneerBalanceHeaderDisplayed ():Promise<boolean>    
}