/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import {Element} from "./../../shared/Element";

let e = new Element();

export class DeferredPaymentAgreementTermsSR {
    
    private agreementConfirmationMessageBody = $('agreements-confirmation.show').$('div.messageBody');

    public clickSign():void {
        let signButton = $('button[ng-click="vm.toggleSignature()"]');
        e.clickElement(signButton);
    }
    public clickSignTa():void {
        let signButton = $('button[ng-click="toggleSignature()"]');
        e.clickElement(signButton);
    }

    public clickFinish():void {
        let finishButton = $('div[ng-click="vm.okClicked()"]');
        e.clickElement(finishButton);
    }

    get isTermsAndConditionsDisplayed():Promise<boolean> {
        let allTermsText = $('div.agreement-html');
        return allTermsText.getText().then(function(txt) {
            return txt.length > 500;
        });
    }

    get isBorrowerNameDisplayed():Promise<boolean> {
        let borrowerField = $('section.acknowledgement-field');
        return borrowerField.isDisplayed();
    }

    get isSubmittedAgreementConfirmationDisplayed():Promise<boolean> {
        return this.agreementConfirmationMessageBody.isDisplayed();
    }
    
    get submittedAgreementConfirmationMessageText():Promise<string> {
        return this.agreementConfirmationMessageBody.getText();
    }
}