/// <reference path="../../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;

import { SalesRepOperationsFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationsFullView';
import { SalesRepOperationFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationFullView';
import { SalesRepInvoiceFullView } from '../../../../modules_v3/views/salesRep/SalesRepInvoiceFullView';
import { SalesRepInvoiceAddLineItemDrawerPartialView } from '../../../../modules_v3/views/salesRep/SalesRepInvoiceAddLineItemDrawerPartialView';
import SalesRepUnitsEntryDrawerPartialView from '../../../../modules_v3/views/salesRep/SalesRepUnitsEntryDrawerPartialView';
import SalesRepUnitsCalculatorDrawerPartialView from '../../../../modules_v3/views/salesRep/SalesRepUnitsCalculatorDrawerPartialView';
import TestData295690 from './testData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
    '295690',
    'Invoice - Units Calculator',
    UserRole.SALES_REP,
    ApplicationFeature.INVOICING
);

describe(test.stringify, () => {
    const salesRepOperationsFullView = new SalesRepOperationsFullView();
    const salesRepOperationFullView = new SalesRepOperationFullView();
    const salesRepInvoiceFullView = new SalesRepInvoiceFullView();
    const salesRepInvoiceAddLineItemDrawerPartialView = new SalesRepInvoiceAddLineItemDrawerPartialView();
    const salesRepUnitsEntryDrawerPartialView = new SalesRepUnitsEntryDrawerPartialView();
    const salesRepUnitsCalculatorDrawerPartialView = new SalesRepUnitsCalculatorDrawerPartialView();
    const td = new TestData295690();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.salesRepresentative);

            // select [Operation]
            salesRepOperationsFullView.search(td.operation.name);
            salesRepOperationsFullView.clickSearchResultMatchingText(td.operation.name);

            // select [Invoice]
            salesRepOperationFullView.clickInvoiceButton(td.invoice.name);

            // click add [Line Item] button for [Product Line]
            salesRepInvoiceFullView.addLineItem('Corn');

            // select [Product] & [Sub Product] in [Add Line Item Drawer]
            salesRepInvoiceAddLineItemDrawerPartialView.selectProduct();
            salesRepInvoiceAddLineItemDrawerPartialView.selectSubProduct();

            // open [Units Calculator] drawer
            salesRepUnitsEntryDrawerPartialView.clickUnitsCalculatorButton();

            // fill inputs [Acres] and [Planting Rate]
            salesRepUnitsCalculatorDrawerPartialView.fillInputAcres(1000);
            salesRepUnitsCalculatorDrawerPartialView.fillInputPlantingRate(1);
            expect(salesRepUnitsCalculatorDrawerPartialView.adjustedUnitsIsPopulated()).toBeTruthy();

            // update [Planting Rate]
            salesRepUnitsCalculatorDrawerPartialView.clearInputPlantingRate();
            expect(salesRepUnitsCalculatorDrawerPartialView.adjustedUnitsIsPopulated()).toBeFalsy();
            salesRepUnitsCalculatorDrawerPartialView.fillInputPlantingRate(100);
            expect(salesRepUnitsCalculatorDrawerPartialView.adjustedUnitsIsPopulated()).toBeTruthy();

            // submit [Units Calculator Drawer]
            salesRepUnitsCalculatorDrawerPartialView.submit();

            // should close [Units Entry Edit] drawer
            salesRepUnitsEntryDrawerPartialView.close();

            // should close [Line Item Edit] drawer
            salesRepInvoiceAddLineItemDrawerPartialView.close();
        }, fail);
    });
});