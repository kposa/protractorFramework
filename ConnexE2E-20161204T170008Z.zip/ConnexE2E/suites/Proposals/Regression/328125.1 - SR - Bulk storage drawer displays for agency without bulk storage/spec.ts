/// <reference path="../../../../typings/index.d.ts" />

import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { sharedSalesRepBulkStorageVerificationSteps } from '../shared/SharedSalesRepBulkStorageVerificationSteps';
import { SharedBulkStorageVerificationTestData } from '../shared/SharedBulkStorageVerificationTestData';

const test = new TestCase(
    '328125.1',
    'Bulk storage drawer displays for agency without bulk storage',
    UserRole.SALES_REP,
    ApplicationFeature.PROPOSALS
);

describe(test.stringify, () => {
    const td = new SharedBulkStorageVerificationTestData();
    td.agencyHasBulkStorage = false;
    sharedSalesRepBulkStorageVerificationSteps(test.description, td);
});