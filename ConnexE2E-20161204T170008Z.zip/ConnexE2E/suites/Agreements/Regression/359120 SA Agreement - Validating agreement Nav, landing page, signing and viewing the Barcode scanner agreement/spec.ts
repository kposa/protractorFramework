/// <reference path="../../../../typings/index.d.ts" />

import {PreviewDocumentSR} from "../../../../modules/sales_rep/screens/PreviewDocumentSR";
import {SalesRepAgreementSR} from "../../../../modules/sales_rep/screens/SalesRepAgreementSR";
import {AgreementsSR} from "../../../../modules/sales_rep/screens/AgreementsSR";
import SalesRepNavigationMenuView from '../../../../modules_v3/views/salesRep/SalesRepNavigationMenuPartialView';
import {BarcodeScannerAgreementSR} from "../../../../modules/sales_rep/screens/BarcodeScannerAgreementSR";
import {clickElement} from "../../../../modules_v3/helpers/clickElementHelpers";
import TestData359120 from './testData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
	'359120',
	'SA Agreement - Validating agreement Nav, landing page, signing and viewing the Barcode scanner agreement',
	UserRole.SALES_REP,
	ApplicationFeature.AGREEMENTS
);

describe(test.stringify, () => {
    const td = new TestData359120();
    const navigationMenuView = new SalesRepNavigationMenuView();
    let pd = new PreviewDocumentSR();
    let ag = new AgreementsSR();
    let srAgreement = new SalesRepAgreementSR();
    let barcodeScannerAgreement = new BarcodeScannerAgreementSR();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.salesRepresentative);

            // should select the [Barcode Scanner Agreement] link from the {Hamburger] option
            navigationMenuView.openMenu();
            navigationMenuView.selectMenuItemContainingText('Agreements');

            // should verify user lands on [Agreements] page when clicking on [Barcode Scanner Agreement] 
            expect(ag.isAgreementsPagePresent()).toEqual('Agreements', 'failed to land on the [Agreements] page');

            // should verify the [Sign] button is present
            expect(srAgreement.isSignedButtonPresent).toBe(true);

            // should verify information on the Barcode Scanner Agreement
            // FIXME: Clicking elements should be in the view object not test
            clickElement(srAgreement.signButton);
            expect(barcodeScannerAgreement.isAgreementsHeaderDisplayed).toBeTruthy();
            expect(barcodeScannerAgreement.isBackButtonDisplayed).toBeTruthy();
            expect(barcodeScannerAgreement.salesRepNameDisplayed).toEqual(td.salesRepresentative.name.replace(/ /g,''));
            expect(barcodeScannerAgreement.salesRepNameDisplayed).toEqual(td.salesRepresentative.name.replace(/ /g,''));
            expect(barcodeScannerAgreement.titleDisplayed).toEqual('Barcode Scanner Agreement');
            expect(barcodeScannerAgreement.versionDisplayed).toEqual('Version 2016.1');
            expect(barcodeScannerAgreement.textInFooterDisplayed).toContain('AGENCY NAME and ADDRESS');
            expect(barcodeScannerAgreement.textInFooterDisplayed).toContain('AGENCY ID');
            expect(barcodeScannerAgreement.textInFooterDisplayed).toContain(td.salesAgency.id);
            // FIXME: This should be trimmed when populating in test data
            expect(barcodeScannerAgreement.textInFooterDisplayed).toContain(td.salesAgency.name.trim());
            expect(barcodeScannerAgreement.textInFooterDisplayed).toContain(td.salesAgency.address);
            barcodeScannerAgreement.clickBackButton();

            // should assert on the display of [Barcode Scanner Agreement]  with sign button and click sign and finish signing the agreement
            srAgreement.signBarcodeScannerAgreement();

            // should verify if the signed agreement displays under signed section', ():void => {
            expect(srAgreement.verifyIfAgreementIsUnderSigned()).toEqual('Signed Agreements');

            // should assert on clicking the [View] button for the signed Barcode Scanner agreement
            srAgreement.showSignedAgreementPreview();

            // should assert on navigating to [Preview Agreement] page when user clicks on [View] button for the signed Barcode Scanner Agreement
            expect(browser.getCurrentUrl()).toContain('documents');

            // should assert on the display of back carat button followed by agreements (Icon), Agreements (label) [Email] and [Print] icons on the [Preview Agreement] page
            expect(pd.isEmailIconDisplayed()).toBeTruthy();
            expect(pd.isPrintIconDisplayed()).toBeTruthy();
            pd.isAgreementsHeaderDisplayed();
            expect(barcodeScannerAgreement.isBackButtonDisplayed).toBeTruthy();

            // should assert on the display of [Sales Rep] and the name of Sales Rep and that signed
            pd.salesAgencyAgreementHasContent(td.salesRepresentative.name);
            pd.salesAgencyAgreementHasContent('SALES REP');

            // should assert on the display of [Agency Name and Address] with Sales Agency name and address 
            pd.salesAgencyAgreementHasContentInFooter('AGENCY NAME and ADDRESS');
            pd.salesAgencyAgreementHasContentInFooter(td.salesAgency.name);
            pd.salesAgencyAgreementHasContentInFooter(td.salesAgency.address);

            // should assert on the display of section header [Agency ID]
            pd.salesAgencyAgreementHasContentInFooter('AGENCY ID');

            // should assert on the display of Sales Agency ID in the footer
            pd.salesAgencyAgreementHasContentInFooter(td.salesAgency.id);

            // should assert on the display of [Signed On] header in the footer
            pd.salesAgencyAgreementHasContentInFooter('Signed On');

            // should assert on the display of date in the format Month DD, YYYY under [Signed On] header
            pd.verifyDocumentDate();
            
        }, fail);
    });
});