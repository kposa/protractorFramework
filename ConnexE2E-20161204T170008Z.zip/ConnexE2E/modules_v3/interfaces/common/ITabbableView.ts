/// <reference path="../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;

export interface ITabbableView {
    clickTabMatchingText(text:string):void;
    clickTabContainingText(text:string):void;
}