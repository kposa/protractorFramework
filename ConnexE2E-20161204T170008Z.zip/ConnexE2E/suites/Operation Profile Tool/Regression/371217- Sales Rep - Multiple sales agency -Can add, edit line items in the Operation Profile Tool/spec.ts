/// <reference path="../../../../typings/index.d.ts" />

import { TestData371217 } from './testData';
import { itw } from '../../../../modules_v3/helpers/itw';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { SalesRepOperationsFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationsFullView';
import SalesRepHamburgerDrawerPartialView from '../../../../modules_v3/views/salesRep/SalesRepHamburgerDrawerPartialView';
import { SalesRepOperationProfileToolFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationProfileToolFullView';
import { SalesRepOperationProfilePageFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationProfilePageFullView';

const test = new TestCase(
    '371217',
    'Sales Rep - Multiple sales agency - Can add, edit line items in the Operation Profile Tool',
    UserRole.SALES_REP,
    ApplicationFeature.OPERATION_PROFILE_TOOL
);

describe(test.stringify, () => {
    const td = new TestData371217();
    let salesRepOperations = new SalesRepOperationsFullView();
    let search = new SalesRepHamburgerDrawerPartialView();
    let operationProfileTool = new SalesRepOperationProfileToolFullView();
    let operationProfilePage = new SalesRepOperationProfilePageFullView();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            bootstrap(td.salesRepresentative);

            // should click the hamburger menu
            salesRepOperations.clickSearchBarHamburger();

            // should click 'Operation Profile Tool' from the hamburger menu
            search.clickItemFromHamburgerMenu('Operation Profile Tool');

            // should verify a hamburger icon displayed on Operation Profile Tool page
            expect(operationProfileTool.isHamburgerDisplayed()).toBeTruthy();

            // should verify that the text in the header contains 'Operation Profile Tool'
            expect(operationProfileTool.textOnOperationProfileToolPage()).toContain('Operation profile tool');

            // should verify that the text in the header contains 'Agency'
            expect(operationProfileTool.textOnOperationProfileToolPage()).toContain('Agency');

            // should verify if the label, 'Please select a sales agency is displayed'
            expect(operationProfileTool.textOnOperationProfileToolPage()).toContain('Please select a sales agency');

            // should click on the Agency drop down
            operationProfileTool.clickAgencyDropDown();

            // should select an agency from the drop down
            operationProfileTool.selectAgencyFromDropDown(td.salesAgency.name);

            // should verify that headers display correctly
            expect(operationProfileTool.isOperationHeaderDisplayed()).toBeTruthy();
            expect(operationProfileTool.isPrimaryDecisionMakerHeaderDisplayed()).toBeTruthy();
            expect(operationProfileTool.isTotalCommercialAcresHeaderDisplayed()).toBeTruthy();
            expect(operationProfileTool.isLivestockHeaderDisplayed()).toBeTruthy();
            expect(operationProfileTool.isLastUpdatedHeaderDisplayed()).toBeTruthy();

            // should verify all operation names are populated
            expect(operationProfileTool.areAllOperationNamesPopulated()).toBeTruthy();

            // should verify all primary decision maker names are populated
            expect(operationProfileTool.areAllPrimaryDecisionMakerNamesPopulated()).toBeTruthy();

            // should verify all total commercial acres are populated
            expect(operationProfileTool.areAllTotalCommercialAcresPopulated()).toBeTruthy();

            // should click on the first record
            operationProfileTool.clickTheFirstOperationRow();

            //should click on the ADD button of Dairy producer on the operation Profile page
            operationProfilePage.clickAddButtonForHeadersContainingText('Dairy producer');

            //select the Producer from the drop down
            operationProfilePage.dairyProducerDialog.selectProducerFromDropdown();

            //save the dairy producer dialog
            operationProfilePage.dairyProducerDialog.clickSave();

            //verify that you can edit the Dairy producer Line by clicking on it, changing a value and re-saving it
            operationProfilePage.clickFirstDairyProducerLineItem();
            operationProfilePage.dairyProducerDialog.enterValueIntoGradeAPermitInput();
            operationProfilePage.dairyProducerDialog.clickSave();

            //verify deleting the first dairy producer row by clicking on the trash icon at the corner of the line
            operationProfilePage.deleteFirstDairyProducerRowIfPresent();

            // should click on the back arrow on the operation profile page
            operationProfilePage.clickBackArrow();

            // should assert on going back to operation profile tool page after clicking on the back arrow
            expect(operationProfileTool.textOnOperationProfileToolPage()).toContain('Operation profile tool');

        }, fail);
    });
});