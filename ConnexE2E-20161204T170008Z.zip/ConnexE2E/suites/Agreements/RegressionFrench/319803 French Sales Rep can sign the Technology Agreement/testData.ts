/// <reference path="../../../../typings/index.d.ts" />
import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';

export default class TestData319803 extends BaseTestData {
    constructor () {
        super();

        this.salesRepresentatives.push({
            id: 'frigorem@phiext.com',
            name: 'Frigon'
        });

        this.operations.push({
            id: '12926490',
            name: 'Ferme Maxilaix SENC'
        });

        this.businessPartners.push({
            id: '17049817',
            name: 'Michel Fafard'
        });
    }
}