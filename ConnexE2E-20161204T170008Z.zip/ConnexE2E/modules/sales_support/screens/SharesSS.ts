/// <reference path="../../../typings/index.d.ts" />

import {Element} from '../../shared/Element';
import ElementFinder = protractor.ElementFinder;
import {DrawerSS} from "../shared/DrawerSS";
import Promise = webdriver.promise.Promise;
import {MaterialDesignElement} from "../../shared/MaterialDesignElement";

let e = new Element();
let dwr = new DrawerSS();
let md = new MaterialDesignElement();

export class SharesSS {

    public clickAddShareBtn():void {
        e.clickElement($('div[ng-click="vm.addShare()"]'));
    }

    public selectCustomerFromSideDrawerDropdown():void {
        let customerDropdownParent = $('section[value="vm.editedShare.name"]');
        let dropdown = md.getClickableArea(customerDropdownParent);

        e.clickElement(dropdown);
        dwr.selectListItem(customerDropdownParent, undefined, 0);
    }

    public clickSideDrawerAcceptBtnToSaveShare():void {
        let acceptButton = $('pm-flat-button[ng-click="vm.saveEditedShare()"] button');
        e.clickElement(acceptButton);
    }

    public clickSideDrawerAcceptBtnToSaveFarmManager():void {
        let acceptButton = $('div[ng-click="vm.saveDiscountAffiliate()"] button');
        e.clickElement(acceptButton);
    }

    public clickAddFarmManagerBtn():void {
        let farmManagerAddBtn = $('div[ng-click="vm.showDiscountAffiliate()"]');
        e.clickElement(farmManagerAddBtn);
    }

    public selectCompanyFromSideDrawerDropdown():void {
        let companyDropdownParent = $('section[value="vm.editedDiscountAffiliate.company"]');
        let dropdown = md.getClickableArea(companyDropdownParent);
        let dropdownListItem = companyDropdownParent.$$('div.pm-listitem').get(0);

        e.clickElement(dropdown);
        e.clickElement(dropdownListItem);
    }

    public selectFarmManagerOrBuyingAgentFromSideDrawerDropdown() {
        let farmManagerDropdownParent = $('section[label="Farm Manager or Buying Agent"]');
        let dropdown = md.getClickableArea(farmManagerDropdownParent);
        let dropdownListItem = farmManagerDropdownParent.$$('div.pm-listitem').get(0);

        e.clickElement(dropdown);
        e.clickElement(dropdownListItem);
    }

    public clickTrashcanInNavBar() {
        let trashcan = $('i[ng-click="vm.deleteAccount()"]');
        e.clickElement(trashcan);
    }

    public save():void {
        let saveBtn = $('i[ng-click="vm.singleSave()"]');
        e.clickElement(saveBtn);
    }

    public clickInactivateBtn():void {
        e.clickElement($('i[ng-click="vm.inactivateAccount()"]'));
    }

    get sideDrawerPercentage():Promise<string> {
        let percentageDisplayValue = md.getDisplayValue($('section[value="vm.editedShare.percentage"]'));
        return percentageDisplayValue.getText();
    }

    get isShareLockIconDisplayed():Promise<boolean> {
        let allLockIcons = $$('div[ng-show="vm.isLocked"]');
        return e.isAtLeast1Displayed(allLockIcons);
    }
}