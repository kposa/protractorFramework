/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;

export class WarehouseAddressMD {

    public updateStreetAddress1(streetAddress1: string): void {
        let streetAddress1InputContainer = $('input[ng-model="vm.warehouseAddress.street1"]');
        streetAddress1InputContainer.clear();
        streetAddress1InputContainer.sendKeys(streetAddress1);
    }
}