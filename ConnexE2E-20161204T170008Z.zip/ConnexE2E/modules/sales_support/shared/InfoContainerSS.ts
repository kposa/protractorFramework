/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import {Element} from "./../../shared/Element";

let e = new Element();

export class InfoContainerSS {

    public clickOnInfoIcon():void {
        e.clickElement($('invoice-information[invoice-id="vm.invoiceId"]').$('i.material-icons.md-36.md-light'));
    }

    public close():void {
        let infoContainerParent = $('div.pm-paper.z-depth-2.info-container.flex-vertical.active');
        e.clickElement($('div.pm-paper.z-depth-2.info-container.flex-vertical.active').$('i.material-icons.md-48.md-dark'));
    }

    get salesSeason():Promise<string> {
        return $('div.pm-style-body-1.subtitle').getText();
    }

    get isInfoIconDisplayed():Promise<boolean> {
        return $('i.material-icons.md-48.md-dark').isDisplayed();
    }

    get operation():Promise<string> {
        return $$('div.pm-style-body-2.name').get(0).getText();
    }

    get agency():Promise<string> {
        return $$('div.pm-style-body-2.name').get(1).getText();
    }
}