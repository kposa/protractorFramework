/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;
import { clickElement } from '../../helpers/clickElementHelpers';
import Promise = protractor.promise.Promise;
import {
    salesPeriodSeasonToFrench
} from "../../helpers/utilityHelpers";
import {
    filterElements,
    isActive,
    containingText
} from '../../helpers/filterElementHelpers';
import SalesRepBalancesReportFilterDrawerPartialView from './SalesRepBalancesReportFilterDrawerPartialView';

export default class SalesRepBalancesReportFilterDrawerPartialViewFRCA extends SalesRepBalancesReportFilterDrawerPartialView {
    clickSalesPeriodDropDown ():void {
        let salesPeriod = $('md-select[aria-label="Période de vente"]');
        clickElement(salesPeriod);
    }

    selectSalesPeriodFromDropDown (salesPeriodYear:string, salesPeriodSeason:string):void {
        salesPeriodSeason = salesPeriodSeasonToFrench(salesPeriodSeason);
        let salesPeriod = salesPeriodYear + salesPeriodSeason;
        let salesPeriodRecord = filterElements(
            $$('md-option[ng-repeat="option in vm.options"]'),
            [
                isActive(true),
                containingText(salesPeriod),
            ]
        )().first();
        clickElement(salesPeriodRecord);
    }
}
