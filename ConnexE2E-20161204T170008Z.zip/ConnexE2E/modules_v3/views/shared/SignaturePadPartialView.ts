/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;

import {ISignaturePadPartialView} from "../../interfaces/partialViews/ISignaturePadPartialView";
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';
import { filterElements, isActive } from '../../../modules_v3/helpers/filterElementHelpers';
import { NotImplementedError } from '../../../common/exception/exceptions';
import { IView } from '../../interfaces/common/IView';

export default class SignaturePadPartialView implements IView, ISignaturePadPartialView {
    private signaturePad = filterElements($$('div[class*="signature-pad"]'), [isActive(true)])().first();
    private agreeButton = this.signaturePad.$('button[ng-click="save()"]');
    private selectButton = $('button[ng-click="sign()"]');
    private agreementDescription = filterElements(this.signaturePad.$$('div.description'), [isActive(true)])().first();

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    strokeSignature():void {
        browser.actions()
            .mouseMove(this.signaturePad.$('canvas').getWebElement(), {x: 35, y: 35})
            .click()
            .perform();
    }

    clickAgree():void {
        clickElement(this.agreeButton);
    }

    //not sure where or how often you 'select' a witness - we may just create another page object for this down the road
    public clickSelect():void {
        clickElement(this.selectButton);
    }

    public getFooterText():Promise<string> {
        return this.agreementDescription.getText();
    }
}
