export interface IBalancesReportFilterDrawerPartialView {
    clickApply ():void;
}