/// <reference path="../../../../typings/index.d.ts" />

import {SharedSalesRepEllipseNavigationTestData} from '../shared/SharedSalesRepEllipseNavigationTestData';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { sharedSalesRepEllipseNavigationSteps } from '../shared/SharedSalesRepEllipseNavigationSteps';

const test = new TestCase(
	'273609',
	'Ellipse Menu - Invoice Documents Page',
	UserRole.SALES_REP,
	ApplicationFeature.NAVIGATIONS
);

describe(test.stringify, () => {
    const td = new SharedSalesRepEllipseNavigationTestData();

    td.preEllipseItem = td.availableEllipseItems.documents;

    td.ellipseItems = [
        td.availableEllipseItems.products,
        td.availableEllipseItems.discounts,
        td.availableEllipseItems.chargesAndCredits,
        td.availableEllipseItems.deliver,
        td.availableEllipseItems.accountDescription,
        td.availableEllipseItems.businessPartners,
        td.availableEllipseItems.activityStatement,
        td.availableEllipseItems.newProposal,
        td.availableEllipseItems.experiments,
        td.availableEllipseItems.growthAndRetentionOverview
    ];

    sharedSalesRepEllipseNavigationSteps(td, test.description);
});