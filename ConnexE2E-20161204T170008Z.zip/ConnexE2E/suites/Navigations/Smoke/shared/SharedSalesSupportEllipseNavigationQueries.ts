/// <reference path="../../../../typings/index.d.ts" />
const { E2EInvoicesDatabaseName } = process.env;

export interface operationHavingACompletedDeliveryAndOneShareResults {
    operationId: string
    operationName: string
}

export function getOperationHavingCompletedDeliveryAndOneShare (salesPeriodId:number): string {
    return `
   	SELECT DISTINCT TOP 100 i.operationId, o.name operationName
    FROM ${E2EInvoicesDatabaseName}.dbo.Invoice i
    JOIN ${E2EInvoicesDatabaseName}.dbo.Operation o ON o.OperationId = i.OperationId
    WHERE EXISTS (
        SELECT 1 
        FROM ${E2EInvoicesDatabaseName}.distribution.Delivery d 
        WHERE d.InvoiceId = i.InvoiceId
    )
    AND i.TerritoryId in (
    	SELECT DISTINCT dp.TerritoryId 
    	FROM ${E2EInvoicesDatabaseName}.discounts.DiscountProgram dp
		JOIN ${E2EInvoicesDatabaseName}.discounts.GrowthAndRetentionDiscountProgram gardp ON gardp.DiscountProgramId = dp.DiscountProgramId
		WHERE dp.SalesPeriodId = ${salesPeriodId}
	)
	  
	AND EXISTS (
		SELECT 1
		FROM ${E2EInvoicesDatabaseName}.dbo.OperationCustomer oc
		WHERE oc.OperationId = i.OperationId
		GROUP by oc.OperationId
		HAVING count(*) = 1
	)

    `
}