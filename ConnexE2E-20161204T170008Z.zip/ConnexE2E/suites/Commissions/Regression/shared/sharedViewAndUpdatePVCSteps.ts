/// <reference path="../../../../typings/index.d.ts" />

import MasterDataMasterSearchFullView from '../../../../modules_v3/views/masterData/MasterDataMasterSearchFullView';
import MasterDataCommissionsTabFullView from '../../../../modules_v3/views/masterData/MasterDataCommissionsTabFullView';
import { MasterDataProductValueCommissionFullView } from '../../../../modules_v3/views/masterData/MasterDataProductValueCommissionFullView';
import { sharedViewAndUpdatePVCTestData } from './sharedViewAndUpdatePVCTestData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { itw } from '../../../../modules_v3/helpers/itw';

export function sharedViewAndUpdatePVCSteps (description:string, td: sharedViewAndUpdatePVCTestData, pending?: string) {
    const masterDataMasterSearchFullView = new MasterDataMasterSearchFullView();
    const masterDataCommissionsTabFullView = new MasterDataCommissionsTabFullView();
    const masterDataProductValueCommissionFullView = new MasterDataProductValueCommissionFullView();

    itw(description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.masterDataUser);

            // search for [Commercial units] and select from [Search Results]
            masterDataMasterSearchFullView.search(td.searchText);
            masterDataMasterSearchFullView.selectFilterContainingText(td.orgUnit);

            masterDataMasterSearchFullView.clickSearchResultContainingText(td.searchText);

            // may need to add another click in the future for PVC Card once it becomes a default feature
            // the page header will also need to be verified at that point

            expect(masterDataCommissionsTabFullView.getItemCount()).toBeGreaterThan(0);
            expect(masterDataCommissionsTabFullView.hasGivenYearCommission(td.salesPeriod.year)).toBeTruthy();
            expect(masterDataCommissionsTabFullView.hasGivenYearCommission(td.salesPeriod.year - 1)).toBeTruthy();

            // click [Commission] for [Previous Year] because it has no edit permission
            masterDataCommissionsTabFullView.clickGivenYearCommission(td.salesPeriod.year - 1);

            // return to the [Product Value Commissions] screen
            masterDataProductValueCommissionFullView.clickBack();
            masterDataCommissionsTabFullView.clickGivenYearCommission(td.salesPeriod.year);

            // Input Validation

            // Clear all inputs
            masterDataProductValueCommissionFullView.clearAllInputs([
                'Acceleration Point',
                'Percent Over Acceleration Point',
                'Percent Under Acceleration Point'
            ]);

            // Acceleration Point
            // fill in with value [-1]
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Acceleration Point', `-1`);
            expect(masterDataProductValueCommissionFullView.getInputValueByLabelContainingText('Acceleration Point')).toEqual('1');
            // fill in with value [1]
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Acceleration Point',`1`);
            expect(masterDataProductValueCommissionFullView.getInputValueByLabelContainingText('Acceleration Point')).toEqual('1');
            // fill in with value [1.00]
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Acceleration Point',`1.00`);
            expect(masterDataProductValueCommissionFullView.getInputValueByLabelContainingText('Acceleration Point')).toEqual('1.0');
            // fill in with value [1000]
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Acceleration Point',`1000`);
            expect(masterDataProductValueCommissionFullView.getInputValueByLabelContainingText('Acceleration Point')).toEqual('100');

            // Percent Over Acceleration Point
            // fill in with value [-1]
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Percent Over Acceleration Point', `-1`);
            expect(masterDataProductValueCommissionFullView.getInputValueByLabelContainingText('Percent Over Acceleration Point')).toEqual('1');
            // fill in with value [1]
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Percent Over Acceleration Point', `1`);
            expect(masterDataProductValueCommissionFullView.getInputValueByLabelContainingText('Percent Over Acceleration Point')).toEqual('1');
            // fill in with value [1.00]
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Percent Over Acceleration Point', `1.00`);
            expect(masterDataProductValueCommissionFullView.getInputValueByLabelContainingText('Percent Over Acceleration Point')).toEqual('1.0');
            // fill in with value [1000]
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Percent Over Acceleration Point', `1000`);
            expect(masterDataProductValueCommissionFullView.getInputValueByLabelContainingText('Percent Over Acceleration Point')).toEqual('100');

            // Percent Under Acceleration Point
            // fill in with value [-1]
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Percent Under Acceleration Point', `-1`);
            expect(masterDataProductValueCommissionFullView.getInputValueByLabelContainingText('Percent Under Acceleration Point')).toEqual('1');
            // fill in with value [1]
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Percent Under Acceleration Point', `1`);
            expect(masterDataProductValueCommissionFullView.getInputValueByLabelContainingText('Percent Under Acceleration Point')).toEqual('1');
            // fill in with value [1.00]
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Percent Under Acceleration Point', `1.00`);
            expect(masterDataProductValueCommissionFullView.getInputValueByLabelContainingText('Percent Under Acceleration Point')).toEqual('1.0');
            // fill in with value [1000]
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Percent Under Acceleration Point', `1000`);
            expect(masterDataProductValueCommissionFullView.getInputValueByLabelContainingText('Percent Under Acceleration Point')).toEqual('100');

            // submit form
            masterDataProductValueCommissionFullView.submitForm();
            // perform a db check for records and save state?

            // Clear all inputs
            masterDataProductValueCommissionFullView.clearAllInputs([
                'Acceleration Point',
                'Percent Over Acceleration Point',
                'Percent Under Acceleration Point'
            ]);

            // fill in form
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Acceleration Point', td.randomNumberAsString);
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Percent Over Acceleration Point', td.randomNumberAsString);
            masterDataProductValueCommissionFullView.fillInputByLabelContainingText('Percent Under Acceleration Point', td.randomNumberAsString);

            // submit form
            expect(masterDataProductValueCommissionFullView.formCanBeSubmitted()).toBeTruthy();
            masterDataProductValueCommissionFullView.submitForm();
            // perform a db check for records and save state?

            // refresh page
            browser.refresh();
            expect(masterDataProductValueCommissionFullView.getInputValueByLabelContainingText('Acceleration Point')).toEqual(`${td.randomNumberAsString} %`);
            expect(masterDataProductValueCommissionFullView.getInputValueByLabelContainingText('Percent Over Acceleration Point')).toEqual(`${td.randomNumberAsString} %`);
            expect(masterDataProductValueCommissionFullView.getInputValueByLabelContainingText('Percent Under Acceleration Point')).toEqual(`${td.randomNumberAsString} %`);

            // go back to [Product Value Commissions] page
            masterDataProductValueCommissionFullView.clickBack();
            //// Clicking back a second time is required due to refreshing the page
            masterDataProductValueCommissionFullView.clickBack();

            // click [Commission] for [Previous Year], it should still be blank
            masterDataCommissionsTabFullView.clickGivenYearCommission(td.salesPeriod.year - 1);
        }, fail);
    }, pending);
}
