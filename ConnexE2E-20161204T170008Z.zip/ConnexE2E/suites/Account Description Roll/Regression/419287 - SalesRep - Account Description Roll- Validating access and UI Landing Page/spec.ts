/// <reference path="../../../../typings/index.d.ts" />

import Promise = protractor.promise.Promise;
import { itw } from '../../../../modules_v3/helpers/itw';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import {TestData419287} from './testData';
import { SalesRepOperationsFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationsFullView';
import SalesRepHamburgerDrawerPartialView from '../../../../modules_v3/views/salesRep/SalesRepHamburgerDrawerPartialView';
import { SalesRepAccountDescriptionRollFullView } from '../../../../modules_v3/views/salesRep/SalesRepAccountDescriptionRollFullView';

const test = new TestCase(
    '419287',
    'AM - Account Description Roll- Validating access and UI Landing Page',
    UserRole.ACCOUNT_MANAGER,
    ApplicationFeature.ACCOUNT_DESCRIPTION_ROLL
);

describe(test.stringify, () => {
    let td = new TestData419287();
    let salesRepOperations = new SalesRepOperationsFullView();
    let search = new SalesRepHamburgerDrawerPartialView();
    let accountDescriptionRoll = new SalesRepAccountDescriptionRollFullView();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            bootstrap(td.salesRepresentative);

            // should click the hamburger menu
            salesRepOperations.clickSearchBarHamburger();

            // should click Account Description Roll from the hamburger menu
            search.clickItemFromHamburgerMenu('Account Description Roll');

            //should verify header text
            expect(accountDescriptionRoll.getTitleText()).toContain('Account Description Roll');

            //should click on the filter icon
            accountDescriptionRoll.clickFilterIcon();

            //should verify that the filter dialog contains show removed text
            expect(accountDescriptionRoll.filterDialog.getFilterDialogText()).toContain('Show Removed');

            //should click on the background
            accountDescriptionRoll.clickBackdrop();

            //verify if 'SELECT' drop down is displayed
            expect(accountDescriptionRoll.getTextBelowHeader()).toContain('SELECT');

            //click 'SELECT' drop down
            accountDescriptionRoll.clickSelectDropDown();

            //verify if that following options are present in the 'SELECT' dropdown
            expect(accountDescriptionRoll.selectDropDownDialog.getSelectDropdownText()).toContain('Select all');
            expect(accountDescriptionRoll.selectDropDownDialog.getSelectDropdownText()).toContain('Select active');
            expect(accountDescriptionRoll.selectDropDownDialog.getSelectDropdownText()).toContain('Deselect all');

            //click on the background
            accountDescriptionRoll.clickSelectBackdrop();
            
            //verify if the following headers are present
            expect(accountDescriptionRoll.getTextBelowHeader()).toContain('Third Party');
            expect(accountDescriptionRoll.getTextBelowHeader()).toContain((td.salesPeriod.year -1)+' Activity');
            expect(accountDescriptionRoll.getTextBelowHeader()).toContain((td.salesPeriod.year)-2 +' Activity');
            expect(accountDescriptionRoll.getTextBelowHeader()).toContain(((td.salesPeriod.year)-3) +' Activity');

            //click on a check box of an operation
            accountDescriptionRoll.clickCheckBox();

            //verify the roll button is active after checking the check box
            expect(accountDescriptionRoll.isRollButtonInactive()).toBeFalsy();

            //uncheck the check box of an operation
            accountDescriptionRoll.clickCheckBox();

            //verify the roll button is inactive after unchecking the check box
            expect(accountDescriptionRoll.isRollButtonInactive()).toBeTruthy();

            //verify the format of how the business partner is displayed: BP name - ID - Share%
            accountDescriptionRoll.verifyBPsFormat().then((bpLine)=> {
                expect(bpLine[ 0 ].length).toBeGreaterThan(0);
                expect(parseFloat(bpLine[ 1 ])).toBeGreaterThan(0);
                expect(bpLine[ 2 ]).toContain('%');
            });
        }, fail);
    });
});