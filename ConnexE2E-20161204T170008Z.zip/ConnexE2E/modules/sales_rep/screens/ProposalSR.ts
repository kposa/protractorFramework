/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import {Element} from "../../shared/Element";
import ElementArrayFinder = protractor.ElementArrayFinder;

let e = new Element();

export class ProposalSR {

    private findFirstDisplayedProductUsingList(allProductsInProductDrawer:ElementArrayFinder, possibleProductNames:Array<string>) {
        return allProductsInProductDrawer.filter((elem)=> {
            return elem.$('div.product').getText().then((txt)=> {
                return Boolean(~possibleProductNames.indexOf(txt));
            });
        }).first()
    }

    // @param product_line - pass english string even if using french browser
    public clickProductLineAddBtn(product_line:string):void {
        let addButton = $('button[at="' + product_line + '"]');
        e.clickElement(addButton);
    }

    public selectProductFromSideDrawer(containingText?:string, possibleProductNames?:Array<string>):void {
        let allProductsInProductDrawer = $('section.products').$$('li[ng-click="select(product.id)"]');
        let product: ElementFinder;
        if (containingText) product = e.getDisplayedElementContainingText(allProductsInProductDrawer, containingText);
        else if (possibleProductNames) product = this.findFirstDisplayedProductUsingList(allProductsInProductDrawer, possibleProductNames);
        else product = allProductsInProductDrawer.first();
        e.clickElement(product);
    }

    public selectSubproductFromSideDrawer(containingText:string):void {
        let allSubproductsInSubproductDrawer = $('section.subproducts').$$('li[ng-click="select(subproduct.id)"]');
        let subproduct: ElementFinder;
        if (containingText) subproduct = e.getDisplayedElementContainingText(allSubproductsInSubproductDrawer, containingText);
        else subproduct = allSubproductsInSubproductDrawer.first();
        e.clickElement(subproduct);
    }

    get isBulkStorageSectionDisplayedInSideDrawer():Promise<boolean> {
        let lineitemDrawer = $('section.lineitem');
        let bulkStorageSection = lineitemDrawer.$('li[ng-click="plivm.ShowBulkStorageDrawer()"]');
        return bulkStorageSection.isPresent();  //uses ng-if
    }
}