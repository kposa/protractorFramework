/// <reference path='../../../typings/index.d.ts' />
import Promise = protractor.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;
import {
    filterElements, containingText, isActive, containingAttributeValue,
    matchingText,
} from '../../helpers/filterElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';
import { isAriaChecked, isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';

export class MasterDataOtherCommissionsFullView {
    private contentList = $$(`md-content>md-option`);
    private messages = $$(`div.md-input-message-animation`);
    private subHeaderSafeClick = $$(`div.md-subheader-inner>span.md-subheader-content`).first();

    private salesAgencyOtherCommPercentField = $$(`md-input-container>input[other-commission-percent='']`).first();
    private salesAgencyOtherCommPercentFieldLast = $$(`md-input-container>input[other-commission-percent='']`).last();
    private salesAgencyOtherCommSaveButton = $(`button[aria-label='Save']`);
    private fromRevenueAmount = $$(`input[ng-model='sr.fromRevenueAmount']`).last();
    private toRevenueAmount = $$(`input[ng-model='sr.toRevenueAmount']`).last();

    private salesAgencyOtherCommApplyToAllProductsBox = $(`md-checkbox[ng-checked='vm.allProducts()']`);
    private acreNbrField = $(`input[name='acres']`);
    private acrePercentField = $(`input[name='acresPercent']`);
    private salesAgencyOtherCommSalesYear = $(`md-select[name='salesYear']`);
    private salesAgencyOtherCommClass = $(`md-select[name='classification']`);
    private salesAgencyOtherCommMaxCommField = $(`input[name='maxCommission']`);
    private salesAgencyOtherCommProgram = $(`md-select[name='program']`);
    private salesAgencyOtherCommType = $(`md-select[name='type']`);

    verifyErrorMessageDisplays(errMsg:string):Promise<boolean> {
        return isPresentAndDisplayed(filterElements(this.messages, [isActive(true), containingText(errMsg)])().first());
    }

    verifySalesYearFieldRequired(requiredMsg:string):Promise<boolean> {
        clickElement(this.salesAgencyOtherCommSalesYear);
        browser.actions().sendKeys(protractor.Key.TAB).perform();

        return isPresentAndDisplayed(filterElements(this.messages, [isActive(true), containingText(requiredMsg)])().first());
    }

    verifyClassificationFieldRequired(requiredMsg:string):Promise<boolean> {
        clickElement(this.salesAgencyOtherCommClass);
        browser.actions().sendKeys(protractor.Key.TAB).perform();

        return isPresentAndDisplayed(filterElements(this.messages, [isActive(true), containingText(requiredMsg)])().first());
    }

    verifyProgramFieldRequired(requiredMsg:string):Promise<boolean> {
        clickElement(this.salesAgencyOtherCommProgram);
        browser.actions().sendKeys(protractor.Key.TAB).perform();

        return isPresentAndDisplayed(filterElements(this.messages, [isActive(true), containingText(requiredMsg)])().first());
    }

    verifyTypeFieldRequired(requiredMsg:string):Promise<boolean> {
        clickElement(this.salesAgencyOtherCommType);
        browser.actions().sendKeys(protractor.Key.TAB).perform();

        return isPresentAndDisplayed(filterElements(this.messages, [isActive(true), containingText(requiredMsg)])().first());
    }

    verifyAcrePercentFieldIsRequired(requiredMsg:string):Promise<boolean> {
        clickElement(this.acrePercentField);
        clickElement(this.subHeaderSafeClick);

        return isPresentAndDisplayed(filterElements(this.messages, [isActive(true), containingText(requiredMsg)])().first());
    }

    verifyAcreNumberFieldIsRequired(requiredMsg:string):Promise<boolean> {
        clickElement(this.acreNbrField);
        clickElement(this.subHeaderSafeClick);

        return isPresentAndDisplayed(filterElements(this.messages, [isActive(true), containingText(requiredMsg)])().first());
    }

    enterPercentOfAcresToGrow(acrePct:string) {
        this.acrePercentField.clear();
        this.acrePercentField.sendKeys(acrePct);
    }

    enterNumberOfAcresToGrow(acreNbr:string) {
        this.acreNbrField.clear();
        this.acreNbrField.sendKeys(acreNbr);
    }

    enterFromRevenueAmount(fromAmt:string) {
        this.fromRevenueAmount.clear();
        this.fromRevenueAmount.sendKeys(fromAmt);
    }

    enterToRevenueAmount(toAmt:string) {
        this.toRevenueAmount.clear();
        this.toRevenueAmount.sendKeys(toAmt);
    }

    getFromRevenueAmount():Promise<string> {
        return this.fromRevenueAmount.getAttribute('value');
    }

    getToRevenueAmount():Promise<string> {
        return this.toRevenueAmount.getAttribute('value');
    }

    verifyClassificationDropDownOption(containedString:string):Promise<boolean> {
        clickElement(this.salesAgencyOtherCommClass);
        let result = isPresentAndDisplayed(filterElements(this.contentList, [isActive(true), matchingText(containedString)])().first());

        browser.actions().sendKeys(protractor.Key.TAB).perform();
        return result;
    }

    verifyProgramDropDownOption(containedString:string):Promise<boolean> {
        clickElement(this.salesAgencyOtherCommProgram);
        let result = isPresentAndDisplayed(filterElements(this.contentList, [isActive(true), matchingText(containedString)])().first());

        browser.actions().sendKeys(protractor.Key.TAB).perform();
        return result;
    }

    verifyTypeDropDownOption(containedString:string):Promise<boolean> {
        clickElement(this.salesAgencyOtherCommType);
        let result = isPresentAndDisplayed(filterElements(this.contentList, [isActive(true), matchingText(containedString)])().first());

        browser.actions().sendKeys(protractor.Key.TAB).perform();
        return result;
    }

    clickCancelDeleteConfirmation(val:string) {
        let confirmBtns = $$(`button.md-primary.md-button[type='button']`);
        clickElement(filterElements(confirmBtns, [isActive(true), containingText(val)])().first());
    }

    clickButtonByAttrValue(attrType:string, attrVal:string) {
        let attrStruct = {attribute: attrType, value: attrVal};
        clickElement(filterElements($$(`button[type='button']`), [isActive(true), containingAttributeValue(attrStruct)])().first());
    }

    removeFirstCommissionRow() {
        clickElement($$('button[confirm-delete="vm.delete(data)"]').first());
    }

    editFirstCommissionRow() {
        clickElement($$('button[aria-label="edit_local"]').first());
    }

    saveAfterEdit() {
        clickElement($(`button[ng-click='vm.save()']`));
    }

    clearPercentField() {
        this.salesAgencyOtherCommPercentField.clear();
    }

    clearPercentFieldForProdLine() {
        this.salesAgencyOtherCommPercentFieldLast.clear();
    }

    addCommission (classificationChoice:string) {
        clickElement($(`button.md-fab[aria-label='add']`));
        clickElement(filterElements($$(`button.md-button[role='menuitem']`), [isActive(true), containingText(classificationChoice)])().first());
    }

    selectGrowthYear(growthYear:string) {
        let salesAgencyOtherCommGrowthYear = $(`md-select[aria-label='Growth year']`);

        clickElement(salesAgencyOtherCommGrowthYear);
        clickElement(filterElements(this.contentList, [isActive(true), containingText(growthYear)])().first())
    }

    selectSalesYear(salesYear:string) {
        clickElement(this.salesAgencyOtherCommSalesYear);
        clickElement(filterElements(this.contentList, [isActive(true), containingText(salesYear)])().first());
    }

    selectAssociateSeller(assSeller:string) {
        let salesAgencyOtherCommAssSeller = $(`md-select[name='associate seller']`);

        clickElement(salesAgencyOtherCommAssSeller);
        clickElement(filterElements(this.contentList, [isActive(true), containingText(assSeller)])().first());
    }

    selectClassification(classification:string) {
        clickElement(this.salesAgencyOtherCommClass);
        clickElement(filterElements(this.contentList, [isActive(true), containingText(classification)])().first());
    }

    selectProgram(program:string) {
        clickElement(this.salesAgencyOtherCommProgram);
        clickElement(filterElements(this.contentList, [isActive(true), containingText(program)])().first());
    }

    selectType(type:string) {
        clickElement(this.salesAgencyOtherCommType);
        clickElement(filterElements(this.contentList, [isActive(true), containingText(type)])().first());
    }

    getMaxCommissionAmount():Promise<string> {
        return this.salesAgencyOtherCommMaxCommField.getAttribute('value');
    }

    enterMaxCommission(commissionVal:string) {
        this.salesAgencyOtherCommMaxCommField.clear();
        this.salesAgencyOtherCommMaxCommField.sendKeys(commissionVal);
    }

    getPercentValue():Promise<string> {
        return this.salesAgencyOtherCommPercentField.getAttribute('value');
    }

    enterPercentValue(percent:string) {
        this.salesAgencyOtherCommPercentField.clear();
        this.salesAgencyOtherCommPercentField.sendKeys(percent);
    }

    enterPercentValueForProdLine(percent:string) {
        this.salesAgencyOtherCommPercentFieldLast.clear();
        this.salesAgencyOtherCommPercentFieldLast.sendKeys(percent);
    }

    verifyPercentFieldIsRequired(requiredMsg:string):Promise<boolean> {
        clickElement(this.salesAgencyOtherCommPercentField);
        clickElement(this.subHeaderSafeClick);

        return isPresentAndDisplayed(filterElements(this.messages, [isActive(true), containingText(requiredMsg)])().first());
    }

    verifyApplyToAllProductsIsChecked():Promise<boolean> {
        return isAriaChecked(this.salesAgencyOtherCommApplyToAllProductsBox);
    }

    toggleApplyToAllProducts() {
        clickElement(this.salesAgencyOtherCommApplyToAllProductsBox);
    }

    toggleExcludeFromPVC() {
        let salesAgencyOtherCommExcludeFromPVCBox = $(`md-checkbox[ng-model='vm.configuredData.excludeFromProductValueCommission']`);
        clickElement(salesAgencyOtherCommExcludeFromPVCBox);
    }

    toggleExcluseFromBaseRevenue() {
        let salesAgencyOtherCommExcludeFromRevenueBox = $(`md-checkbox[ng-model='vm.configuredData.excludeFromBaseRevenue']`);
        clickElement(salesAgencyOtherCommExcludeFromRevenueBox);
    }

    clickSalesAgencyOtherCommissionsSave(addOrClose:string) {
        let attrStruct = {attribute: 'innerText', value: addOrClose};

        clickElement(this.salesAgencyOtherCommSaveButton);
        clickElement(filterElements($$(`button.md-button`), [isActive(true), containingAttributeValue(attrStruct)])().first());
    }

    clickSalesAgencyOtherCommissionsCancel() {
        let salesAgencyOtherCommCancelButton = $(`button[ng-click='vm.close()']`);
        clickElement(salesAgencyOtherCommCancelButton);
    }

    addNewCommissionConfiguration() {
        clickElement($(`button.md-icon-button.md-accent.md-button[aria-label='add']`));
    }
}