/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import {Element} from "../../shared/Element";
import {DeferredPaymentAgreementTermsSS} from "./DeferredPaymentAgreementTermsSS";
import SignaturePadPartialView from '../../../modules_v3/views/shared/SignaturePadPartialView';
import {clickElement} from "../../../modules_v3/helpers/clickElementHelpers";
import {filterElements, containingText} from "../../../modules_v3/helpers/filterElementHelpers";

let e = new Element();
let terms = new DeferredPaymentAgreementTermsSS();

export class AgreementsSS {
    private signaturePadPartialView = new SignaturePadPartialView();

    public clickSignDeferredPaymentLoanAgreement():void {
        let signButton = $('button[ng-click="openLoanAgreement(operationId, customerId)"]');
        e.clickElement(signButton);
    }

   /* public clickViewForTheSignedAgreement():void {
       let technologyAgreementCard = $('')
        let viewButton = $$('button[ng-click="showAgreementPreview(agreement)"]').get(0);
        e.clickElement(viewButton);

    }*/

    public clickSignAgreementAndSignTheAgreement(agreementName : string):void {
        let availableAgreements = $('section.salessupport-availableagreements');
        let technologyAgreementCard = availableAgreements.element(by.cssContainingText('div.pm-listitem.tappable', agreementName));

          //  let signButton = technologyAgreementCard.$('button[ng-hide="agreement.paperDocument"]');
        if(technologyAgreementCard) {
            e.clickElement(technologyAgreementCard);
            terms.clickSignTa();
            this.signaturePadPartialView.strokeSignature();
            this.signaturePadPartialView.clickAgree();
            this.signaturePadPartialView.clickSelect();
            this.signaturePadPartialView.strokeSignature();
            this.signaturePadPartialView.clickAgree();
        }
    }
    public verifyHeader():Promise<String> {
        let headerDisplay = $('div.pm-title');
        return headerDisplay.getText();

    }

    public verifyIfAgreementIsUnderSigned(): Promise<String>{
        let signedAgreement = $$('div[ng-repeat="agreement in vm.signedAgreements"]').get(0).element(by.xpath('../..'));
        let signedlabel = signedAgreement.$('div.pm-list-subheader');
        //return signedlabel.isDisplayed();
        return signedlabel.getText();
    }

    public clickOnEyeballForSignedTechAgreement():void{
        let allSignedAgreements = $('section.salessupport-signedagreements').$$('div.pm-listitem');
        let signedTechnologyAgreementLine = filterElements(allSignedAgreements, [containingText('Technology Agreement (TA)')])().first();
        let eyeball = signedTechnologyAgreementLine.$('i.md-36');
        clickElement(eyeball);
    }

    public urlOfTheCurrentPage() {
        return browser.getCurrentUrl();
    }

}