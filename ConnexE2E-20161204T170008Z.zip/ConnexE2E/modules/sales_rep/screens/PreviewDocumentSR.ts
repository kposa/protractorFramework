/// <reference path="../../../typings/index.d.ts" />

import moment = require('moment');
import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import {Element} from "./../../shared/Element";

let e = new Element();
let emailIcon = $$('div[ng-click="vm.toggle(true)"]').first();
let sendButton = $$('button.pm-flat-button.primary').first();
let dialogBox = $('div.menu.flex-vertical.selected');

export class PreviewDocumentSR {
    private addAdditionalRecipientsDisplay = $$('div.entry-area-item-label.ng-binding').first();

    public isEmailIconDisplayed():Promise<boolean> {
        return emailIcon.isDisplayed();
    }

    public clickEmailIcon():void {
        e.clickElement(emailIcon);
    }

    public isPrintIconDisplayed():Promise<boolean> {
        let printIcon = $$('i[ng-click="vm.printDocument()"]').first();
        return printIcon.isDisplayed();
    }

    public isEmailIconDialogBoxDisplayed():Promise<boolean> {
        return dialogBox.isDisplayed();
    }

    public  isEmailIconDialogOpen():Promise<boolean> {
        return dialogBox.isPresent();
    }

    public verifySalesRepNameDisplayed():Promise<string> {

        return this.addAdditionalRecipientsDisplay.getText();
    }

    public verifySalesAgencyEmailDisplayed():Promise<string> {
               return this.addAdditionalRecipientsDisplay.getText();
    }

    public isAddRecipientsDialogBoxDisplayed():Promise<boolean> {
        let addAdditionalRecipientsDialog = this.addAdditionalRecipientsDisplay.element(by.xpath('..'));
        let dialogFormDisplay = addAdditionalRecipientsDialog.$('textarea[ng-model="vm.emailsEntered"]');
        return dialogFormDisplay.isDisplayed();
    }

    public isSendButtonInactive():Promise<boolean> {
        let sendButtonDisabled = $('button.pm-flat-button.disabled');
        return sendButtonDisabled.isDisplayed();
    }

    public isSendButtonEnabled():Promise<boolean> {
        return browser.sleep(1000).then(() => { //required to allow element class name to change
            return sendButton.isDisplayed();
        });
    }

    public clickSendButton():void {
        e.clickElement(sendButton);
    }

    public enterValueInEmailAddressDialog(emailAddress:string, cleared?:string):void {
        let emailAddressDialog = $$('textarea[ng-model="vm.emailsEntered"]').first();
        if (cleared === 'clear') {
            emailAddressDialog.clear();
            emailAddressDialog.sendKeys(emailAddress);
        }
        else {
            emailAddressDialog.sendKeys(emailAddress);
        }
    }

    public enterValueInStandardDisclaimerDialog(text:string):void {
        let standardDisclaimerDialog = $$('textarea[ng-model="vm.message"]').first();
        standardDisclaimerDialog.sendKeys(text);
    }

    public previewDocumentHasQuantitySavings(qs:string):Promise<boolean> {
        browser.ignoreSynchronization = true;
        browser.driver.switchTo().frame('viewDocumentInFrame');
        const text = $('td[at="Quantity Savings"]').getText();
        browser.driver.switchTo().defaultContent();
        browser.ignoreSynchronization = false;
        return text.then(t => qs == t);
    }

    public previewDocumentHasEarlyPaySavings(eps:string):any {
        browser.ignoreSynchronization = true;
        browser.driver.switchTo().frame('viewDocumentInFrame');
        const text = $('td[at="Early Pay Savings"]').getText();
        browser.driver.switchTo().defaultContent();
        browser.ignoreSynchronization = false;
        return text.then(t => eps == t);
    }

    public salesAgencyAgreementHasContent(value: string):any {
        browser.ignoreSynchronization = true;
        browser.driver.switchTo().frame('viewDocumentInFrame');
        let footerArea = $$('table.tablewidth100').get(0);
        footerArea.getText().then(function (text) {
            expect(text).toContain(value);
        });

        browser.driver.switchTo().defaultContent();
        browser.ignoreSynchronization = false;
    }

    public salesAgencyAgreementHasContentInFooter(value: string):any {
        browser.ignoreSynchronization = true;
        browser.driver.switchTo().frame('viewDocumentInFrame');
        let footerArea = $$('table.tablewidth100').get(1);
        footerArea.getText().then(function (text) {
            expect(text).toContain(value);
        });

        browser.driver.switchTo().defaultContent();
        browser.ignoreSynchronization = false;
    }

    public isAgreementsHeaderDisplayed():void {
        let AgreementSignHeader = $('div[ng-click="vm.back()"]');
        AgreementSignHeader.getText().then(function (text) {
            expect(text).toContain('agreements', 'Agreements is not displayed');
        })
    }

    // TODO: Replace usages with getDocumentSignedDate
    public verifyDocumentDate():void {
        browser.ignoreSynchronization = true;
        browser.driver.switchTo().frame('viewDocumentInFrame');
        let dateArea = $$('table.tablewidth100').get(1).$$('tr').get(1).$('td.tdwidth20');
        dateArea.getText().then(function (date) {
            expect(date).toEqual(moment().format("MMMM D, YYYY"));
        });
        browser.driver.switchTo().defaultContent();
        browser.ignoreSynchronization = false;
    }

    public getDocumentSignedDate():Promise<string> {
        browser.ignoreSynchronization = true;
        browser.driver.switchTo().frame('viewDocumentInFrame');
        let dateArea = $$('table.tablewidth100').get(1).$$('tr').get(1).$('td.tdwidth20');
        const signedDateText = dateArea.getText();
        browser.driver.switchTo().defaultContent();
        browser.ignoreSynchronization = false;
        return signedDateText;
    }

    public isMonthCorrect(month: string) {
        var monthNames = ["January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"];
        for (var i = 0; i < monthNames.length; i++) {
            if (monthNames[i] == month) {
                return month;
            }
        }
    }

    public isPreviewDocumentPagePresent():Promise<boolean> {
        let pageTitle = $('section.document-preview.flex-vertical.flex-expand');
        return pageTitle.isDisplayed();
    }
}


