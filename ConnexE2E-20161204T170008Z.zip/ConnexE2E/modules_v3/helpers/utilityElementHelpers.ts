/// <reference path="../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;
import Promise = protractor.promise.Promise;

import { filterElements, isActive } from './filterElementHelpers';

export const aria_disabled:string = 'aria-disabled';
export const aria_required:string = 'aria-required';
export const aria_invalid:string = 'aria-invalid';
export const aria_checked:string = 'aria-checked';
const disabled:string = 'disabled';

export function hasDisplayedElement (elements:ElementArrayFinder):Promise<boolean> {
    return filterElements(elements, [ isActive(true) ])().count().then(c => c > 0);
}

export function isPresentAndDisplayed (elem:ElementFinder):Promise<boolean> {
    return protractor.promise.all([ elem.isPresent(), elem.isDisplayed() ]).then(results => {
        const [present, displayed] = results;
        return present && displayed;
    }, () => {
        return false;
    });
}

export function isDisabled (elem:ElementFinder):Promise<boolean> {
    return elem.getAttribute(disabled).then((val) => {
        return val === 'true';
    });
}

export function isAriaDisabled (elem:ElementFinder):Promise<boolean> {
    return elem.getAttribute(aria_disabled).then((val) => {
        return val === 'true';
    });
}

export function isAriaEnabled (elem:ElementFinder):Promise<boolean> {
    return elem.getAttribute(aria_disabled).then((val) => {
        return val === 'false';
    });
}

export function isAriaChecked (elem:ElementFinder):Promise<boolean> {
    return elem.getAttribute(aria_checked).then((val) => {
        return val === 'true';
    });
}

export function isAriaUnchecked (elem:ElementFinder):Promise<boolean> {
    return elem.getAttribute(aria_checked).then((val) => {
        return val === 'false';
    });
}

export function isAriaRequired (elem:ElementFinder):Promise<boolean> {
    return elem.getAttribute(aria_required).then((val) => {
        return val === 'true';
    });
}

export function isAriaValid (elem:ElementFinder):Promise<boolean> {
    return elem.getAttribute(aria_invalid).then((val) => {
        return val === 'false';
    });
}

export function hasClass (elem:ElementFinder, className:string):Promise<boolean> {
    return elem.getAttribute('class').then((classes)=> {
        return classes && classes.split(' ').indexOf(className) !== -1;
    });
}