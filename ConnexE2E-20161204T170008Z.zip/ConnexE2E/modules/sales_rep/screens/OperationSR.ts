/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import {Element} from "./../../shared/Element";

let e = new Element();

export class OperationSR {
    
    public clickPropose(acctDescName:string):void {
        var proposeButton = this.getAccountDescriptionCard(acctDescName).$$('li.stage').get(0).$('div.circle');
        e.clickElement(proposeButton);
    }

    public clickInvoice(acctDescName:string):void {
        var invoiceButton = this.getAccountDescriptionCard(acctDescName).$$('li.stage').get(1).$('div.circle');
        e.clickElement(invoiceButton);
    }

    public clickPreviewinvoiceIcon():void {
        var previewinvoiceIcon = $('i[ng-hide="vm.previewMenu.loading()"]');
        e.clickElement(previewinvoiceIcon);
    }

    public clickOnShowToPreviewInvoice():void {

        var showButtonToPreviewInvoice = $('button.pm-flat-button.primary').$('div.pm-button-text');
        e.clickElement(showButtonToPreviewInvoice);
    }
    
    
    public clickAddAnotherProposalBtn():void {
        var addAnotherProposalBtn = this.getDisplayedAddAnotherProposalButton();
        e.clickElement(addAnotherProposalBtn);
    }

    private getAccountDescriptionCard(acctDescName:string):ElementFinder {
        var allAccountDescriptionCards = $$('li.account');
        return allAccountDescriptionCards.filter(function (elem, index) {
            return elem.$('label.account-name').getText().then(function (acctDescNameOnCard) {
                return acctDescNameOnCard === acctDescName;
            });
        }).get(0);
    }
    
    private getDisplayedAddAnotherProposalButton():ElementFinder {
        var allAddAnotherProposalLines = $$('li.add-proposal');
        return allAddAnotherProposalLines.filter(function (elem, index) {
            return elem.isDisplayed().then(function (isDisplayed) {
                return isDisplayed;
            });
        }).get(0).$('button');
    }
}