/// <reference path="../../../../typings/index.d.ts" />

import { SharedSalesRepEllipseNavigationTestData } from '../shared/SharedSalesRepEllipseNavigationTestData';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { sharedSalesRepEllipseNavigationSteps } from '../shared/SharedSalesRepEllipseNavigationSteps';

const test = new TestCase(
    '397811',
    'Ellipse Menu - Invoice Activity Statement Page',
    UserRole.SALES_REP,
    ApplicationFeature.NAVIGATIONS
);

describe(test.stringify, () => {
    const td = new SharedSalesRepEllipseNavigationTestData();

    td.preEllipseItem = td.availableEllipseItems.activityStatement;

    td.ellipseItems = [
        td.availableEllipseItems.products,
        td.availableEllipseItems.discounts,
        td.availableEllipseItems.chargesAndCredits,
        td.availableEllipseItems.deliver,
        td.availableEllipseItems.accountDescription,
        td.availableEllipseItems.businessPartners,
        td.availableEllipseItems.documents,
        td.availableEllipseItems.newProposal,
        td.availableEllipseItems.experiments,
        td.availableEllipseItems.growthAndRetentionOverview
    ];

    sharedSalesRepEllipseNavigationSteps(td, test.description);
});