/// <reference path="../../../../typings/index.d.ts" />

import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import sharedSalesRepPreviewSteps from '../shared/sharedSalesRepPreviewSteps';
import { sharedSalesRepTestData } from '../shared/sharedSalesRepPreviewTestData';

const test = new TestCase(
    '273594',
    'Preview Icon - Discounts',
    UserRole.SALES_REP,
    ApplicationFeature.INVOICING
);

describe(test.stringify, () => {
    const td = new sharedSalesRepTestData();
    td.invoiceAbsent = false;
    td.screen = 'discounts';
    sharedSalesRepPreviewSteps(test.description, td);
});