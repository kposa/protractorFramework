interface BaseUrlLocalConfig {
    [s: string]: string;
    tx: string;
  //  staging: string;
}

export const baseUrlLocalConfig: BaseUrlLocalConfig = {
    tx: `https://salestx.pioneer.com/`,
   staging: `https://salesstagingtx.pioneer.com/`
};