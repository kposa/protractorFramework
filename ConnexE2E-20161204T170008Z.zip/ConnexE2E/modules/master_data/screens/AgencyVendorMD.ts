/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

export class AgencyVendorMD {

    public verifyVendorIdDisplayed(): Promise<string> {
        return $('md-list-item[ng-repeat="vendor in vm.agencyVendorList"]')
                .$('div[flex="100"]').$$('span.ng-binding').get(0)
                    .getText();
    }

    public clickAddNewButton(): void {
        let addNewButton = $('button[aria-label="Add New"]');
        clickElement(addNewButton);
    }

    public clickAddExistingButton(): void {
        let editExistingButton = $('button[aria-label="Add Existing"]');
        clickElement(editExistingButton);
    }

    public clickEditVendorButton(): void {
        let editButton = $('button[aria-label="Settings"]');
        clickElement(editButton);
    }

}