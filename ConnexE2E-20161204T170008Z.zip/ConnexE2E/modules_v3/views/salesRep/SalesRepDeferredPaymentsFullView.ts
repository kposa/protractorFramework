/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;
import { IView } from '../../interfaces/common/IView';
import Promise = protractor.promise.Promise;
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';
import { filterElements, isActive, containingText, matchingText } from '../../helpers/filterElementHelpers';
import { IClosableView } from '../../interfaces/common/IClosableView';
import { IBackNavigableView } from '../../interfaces/common/IBackNavigableView';

export class SalesRepDeferredPaymentsFullView implements IView,IBackNavigableView {

    public paymentKeypadSection = new PaymentKeypadSection();

    isViewDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('section.deferredpayments'));
    }

    private getInvoiceRowByName (invoiceName:string):ElementFinder {
        return filterElements($$('li[ng-repeat*="lineItem in paymentLineItems | orderBy:"]')
            , [ isActive(true), containingText(invoiceName, e => e.$('div.account-description').$('label')) ])().first();
    }

    enterAmountInPaymentField (amt:string, invoiceName:string) {
        let paymentField = this.getInvoiceRowByName(invoiceName).$('button.payment-amount');
        clickElement(paymentField);
        this.paymentKeypadSection.fillInputUnits(amt);
    }

    getInvoiceBalance (invoiceName:string):Promise<string> {
        return this.getInvoiceRowByName(invoiceName).$('div.balance-amount').getText();
    }

    clickPayAllButton () {
        clickElement($('button[ng-click="payAll()"]'));
    }

    clickFinishButton () {
        clickElement($('button[ng-click="finishPayment()"]'));
    }

    clickBack () {
        clickElement($('div[ng-click="vm.back()"]'));
    }

}

class PaymentKeypadSection implements IClosableView {

    fillInputUnits (units:string) {
        units.split('').forEach(digit => {
            let keypadDigit = filterElements($$('td[ng-click*="keypad.addDigit"]'), [ isActive(true), matchingText(digit) ])().first();
            clickElement(keypadDigit);
        });
    }

    close () {
        clickElement(filterElements($$('div[ng-click="close()"]'), [ isActive(true) ])().first());
    }

}