/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;

export interface IAgreementsFullView {
    clickSignButtonByName (agreementName:string):void;
    clickViewButtonByName(agreementName:string):void;
}