/// <reference path="../../../../typings/index.d.ts" />

import { SharedSalesRepEllipseNavigationTestData } from '../shared/SharedSalesRepEllipseNavigationTestData';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { sharedSalesRepEllipseNavigationSteps } from '../shared/SharedSalesRepEllipseNavigationSteps';

const test = new TestCase(
    '273615',
    'Ellipse Menu - New Proposal Page',
    UserRole.SALES_REP,
    ApplicationFeature.NAVIGATIONS
);

describe(test.stringify, () => {
    const td = new SharedSalesRepEllipseNavigationTestData();

    td.preEllipseItem = td.availableEllipseItems.newProposal;

    td.ellipseItems = [
        td.availableEllipseItems.proposalDiscounts,
        td.availableEllipseItems.invoice,
        td.availableEllipseItems.accountDescription,
    ];

    sharedSalesRepEllipseNavigationSteps(td, test.description);
});