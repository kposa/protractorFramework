export interface associateSellersWithPioneerBalanceNonZeroPriorSalesPeriodResults {
    salesRepId:string,
    salesRepName:string,
    operationId:string,
    operationName:string,
    salesAgencyName:string,
    salesAgencyId:string,
}

export function associateSellersWithPioneerBalanceNonZeroPriorSalesPeriod (salesPeriodId:number) {
    const { E2EInvoicesDatabaseName } = process.env;

    return `

    select distinct TOP 10
           u.userId salesRepId,
           u.name salesRepName,
           o.operationId operationId,
           o.name operationName,           
           osa.salesAgencyId salesAgencyId,
           sa.name salesAgencyName
          
    from ${E2EInvoicesDatabaseName}.dbo.UserOperation as uo
    join ${E2EInvoicesDatabaseName}.dbo.SalesPeriod as sp on sp.SalesPeriodId = uo.SalesPeriodId
    join ${E2EInvoicesDatabaseName}.dbo.[User] as u on u.UserId = uo.UserId
    join ${E2EInvoicesDatabaseName}.dbo.Operation as o on o.OperationId = uo.OperationId
    join ${E2EInvoicesDatabaseName}.dbo.OperationSalesAgency as osa on osa.OperationId = uo.OperationId
    join ${E2EInvoicesDatabaseName}.dbo.SalesAgency as sa on sa.SalesAgencyId = osa.SalesAgencyId
  
    where sp.salesperiodId = ${salesPeriodId}
    and uo.roleId = 11
    and uo.userId LIKE '%phiext.com'

    `;
}