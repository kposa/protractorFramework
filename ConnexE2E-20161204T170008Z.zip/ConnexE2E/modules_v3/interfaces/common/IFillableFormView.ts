/// <reference path="../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;

export interface IFillableFormView {
    getInputByLabelMatchingText(text:string):ElementFinder;
    getInputByLabelContainingText(text:string):ElementFinder;
    getInputValueByLabelMatchingText(text:string):Promise<string>;
    getInputValueByLabelContainingText(text:string):Promise<string>;
    fillInputByLabelMatchingText(text:string, inputText:string):void;
    fillInputByLabelContainingText(text:string, inputText:string):void;
    clearInputByLabelMatchingText(text:string):void;
    clearInputByLabelContainingText(text:string):void;
    blurInputByLabelMatchingText(text:string):void;
    blurInputByLabelContainingText(text:string):void;
    submitForm():void;
    formCanBeSubmitted():Promise<boolean>;
}