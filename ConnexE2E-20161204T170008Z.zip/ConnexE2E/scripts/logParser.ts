///<reference path="../typings/index.d.ts"/>

const argv = require('optimist').argv;
import { LogReporterParser } from '../reporters/LogReporter';

function formatToPercent (value: number): number {
    return Math.round(value * 1000) / 10;
}

const p = new LogReporterParser(argv.file);

console.log(JSON.stringify(p.getTestResults()));