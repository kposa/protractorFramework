/// <reference path="../../../../typings/index.d.ts" />

import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
	'312159',
	'View Invoice and Documents as a sales support',
	UserRole.SALES_SUPPORT,
	ApplicationFeature.INVOICING
);

describe(test.stringify, () => {

	itw(test.description, () => {

	}, 'Needs re-write');
});