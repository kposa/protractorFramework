/// <reference path='../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import { IView } from '../../interfaces/common/IView';
import { NotImplementedError } from '../../../common/exception/Exceptions';
import { clickElement } from '../../helpers/clickElementHelpers';

export class AccountManagerOperationsFullView implements IView {

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    clickSearchBarHamburger ():void {
        let searchBarHamburger = $('div[ng-click="showNav()"]');
        clickElement(searchBarHamburger);
    }
}