/**
 * Enable or disable running on the grid when running tests locally
 * @type {boolean}
 */
export const gridIsEnabledLocally = false;