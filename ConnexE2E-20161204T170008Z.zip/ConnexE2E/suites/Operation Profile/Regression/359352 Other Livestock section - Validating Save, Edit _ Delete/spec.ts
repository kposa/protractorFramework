/// <reference path="../../../../typings/index.d.ts" />

import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { TestData359352 } from './testData';
import { itw } from '../../../../modules_v3/helpers/itw';
import { SalesRepOperationsFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationsFullView';
import { SalesRepEllipsePartialView } from '../../../../modules_v3/views/salesRep/SalesRepEllipsePartialView';
import { SalesRepOperationProfilePageFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationProfilePageFullView';

const test = new TestCase(
    '359352',
    'Other Livestock section - Validating Save, Edit & Delete',
    UserRole.SALES_REP,
    ApplicationFeature.OPERATION_PROFILE
);

describe(test.stringify, () => {
    const td = new TestData359352();
    const salesRepOperationsFullView = new SalesRepOperationsFullView();
    const ellipse = new SalesRepEllipsePartialView();
    const operationProfilePage = new SalesRepOperationProfilePageFullView();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            bootstrap(td.salesRepresentative);

            //search for an operation and click on it
            salesRepOperationsFullView.search(td.operation.name);
            salesRepOperationsFullView.clickSearchResultContainingText(td.operation.name);

            //select operation profile link from the ellipse to navigate to the operation profile page
            ellipse.select('operation profile');

            //delete the first row if the Add button is disabled
            operationProfilePage.deleteFirstOtherLivestockRowIfAddButtonDisabled();

            //should click on the ADD button of other livestock on the operation Profile page
            operationProfilePage.clickAddButtonForHeadersContainingText('Other livestock');

            //select the livestock type from the drop down
            operationProfilePage.otherLivestockDialog.selectLivestockTypeFromDropdown();

            //verify that the save button is disabled
            expect(operationProfilePage.otherLivestockDialog.isSaveButtonDisabled()).toBeTruthy();

            //select Producer from the drop down
            operationProfilePage.otherLivestockDialog.selectProducerFromDropdown('Yes');

            //save the other livestock dialog
            operationProfilePage.otherLivestockDialog.clickSave();

            //get number of other livestock lines present
            let originalOtherLivestockLines = operationProfilePage.getNumberOfOtherLivestockLines();

            //verify that you can edit the other livestock Line by clicking on it, changing a value and re-saving it
            operationProfilePage.clickFirstOtherLivestockLineItem();
            operationProfilePage.otherLivestockDialog.selectProducerFromDropdown('No');
            operationProfilePage.otherLivestockDialog.clickSave();

            //verify deleting the first other livestock row by clicking on the trash icon at the corner of the line
            operationProfilePage.deleteFirstOtherLivestockRow();

            //verify that the line was deleted after clicking on the trash icon
            operationProfilePage.getNumberOfOtherLivestockLines().then((newLines) => {
                originalOtherLivestockLines.then((oldLines) => {
                    expect(newLines).toEqual(oldLines - 1);
                });
            });
        }, fail);
    });
});