///<reference path="../../typings/index.d.ts"/>

import { isTrue } from '../../modules_v3/helpers/utilityHelpers';
const mkdirp = require('mkdirp');
const fileExists = require('fs-exists-sync');
const fs = require('fs');
const path = require('path');
const { E2EGridIsEnabled } = process.env;

const screenshotsDir = path.join(__dirname, '../../../Screenshots');

export class ScreenshotReporter {
    public specDone (specDone:any):void {
        if (specDone.status === 'failed') {
            let testCaseId = JSON.parse(specDone.fullName.match(/({.+})/)[ 0 ])._id;
            takeScreenshot(testCaseId);
        }
    }
}

export function takeScreenshot (uniqueId:string, appendNumber?:number) {
    browser.controlFlow().execute(() => {
        createScreenshotDirectory(screenshotsDir);

        let filePath = getFilePath(uniqueId, appendNumber);
        if (fileExists(filePath)) {
            console.log(`A screenshot already exists @ ${filePath}`);
            if(!appendNumber) appendNumber = 0;
            takeScreenshot(uniqueId, appendNumber + 1);
        } else {
            browser.takeScreenshot().then(data => {
                fs.writeFileSync(filePath, data, { encoding: 'base64' });
                console.log(`Screenshot taken @ ${filePath}`);
            }).then(() => {
                if(!isTrue(E2EGridIsEnabled)) browser.pause();
            });
        }
    });
}

export function createScreenshotDirectory (dir:string) {
    try {
        fs.accessSync(dir, fs.F_OK);
    } catch (e) {
        mkdirp.sync(dir);
    }
}

function getFilePath (uniqueId:string, appendNumber?:number) {
    let filePath:string = path.join(screenshotsDir, uniqueId);
    if (appendNumber) filePath += `_${appendNumber}.png`;
    else filePath += `.png`;
    return filePath;
}