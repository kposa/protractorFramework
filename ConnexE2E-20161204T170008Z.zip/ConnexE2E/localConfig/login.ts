interface LoginLocalConfig {
    [s: string]: string;
    username: string;
    password: string;
}

export const loginLocalConfig: LoginLocalConfig = {
    username: 'tfstctrl',
    password: '6T5RdfEr4#$#eM'
};