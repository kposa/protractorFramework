/// <reference path="../../../../typings/index.d.ts" />

import BalancesReportFullView from '../../../../modules_v3/views/salesRep/SalesRepBalancesReportFullView';
import { SalesRepOperationsFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationsFullView';
import balancesReportFilterDrawerPartialView from '../../../../modules_v3/views/salesRep/SalesRepBalancesReportFilterDrawerPartialView';
import TestData349463 from './testData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { itw } from '../../../../modules_v3/helpers/itw';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import SalesRepHamburgerDrawerPartialView from '../../../../modules_v3/views/salesRep/SalesRepHamburgerDrawerPartialView';

const test = new TestCase(
    '349463',
    'Sales Rep - Verify information displays correctly on the Balances Report',
    UserRole.SALES_REP,
    ApplicationFeature.REPORTING
);

describe(test.stringify, () => {
    const td = new TestData349463();
    let search = new SalesRepHamburgerDrawerPartialView();
    let balancesReport = new BalancesReportFullView();
    let salesRepOperations = new SalesRepOperationsFullView();
    let filterDrawer = new balancesReportFilterDrawerPartialView();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            bootstrap(td.salesRepresentative);

            //should click on filter by agency if filter by agency button is displayed
            salesRepOperations.filterBySalesAgencyIfAgencyButtonDisplayed(td.salesAgency.id);

            //should click on the hamburger
            salesRepOperations.clickSearchBarHamburger();

            // should click Reports from the hamburger menu
            search.clickItemFromHamburgerMenu('Reports');

            // should click on Balances Report
            search.selectReport('Balances Report');

            //should verify operation Header is displayed on [Balances Report]
            expect(balancesReport.isOperationHeaderDisplayed()).toBeTruthy();

            //should verify Account Description Header is displayed on [Balances Report]
            expect(balancesReport.isAccountDescHeaderDisplayed()).toBeTruthy();

            //should verify business Partner header is displayed on [Balances Report]
            expect(balancesReport.isBusinessPartnerHeaderDisplayed()).toBeTruthy();

            //should verify Sales period Header is displayed on [Balances Report]
            expect(balancesReport.isSalesPeriodHeaderDisplayed()).toBeTruthy();

            //should verify Net invoice Header is displayed on [Balances Report]
            expect(balancesReport.isNetInvoiceHeaderDisplayed()).toBeTruthy();

            //should verify Net payments Header is displayed on [Balances Report]
            expect(balancesReport.isNetPaymentsHeaderDisplayed()).toBeTruthy();

            //should verify Net pending payments Header is displayed on [Balances Report]
            expect(balancesReport.isNetPendingPaymentsHeaderDisplayed()).toBeTruthy();

            //should verify Pioneer balance Header is displayed on [Balances Report]
            expect(balancesReport.isPioneerBalanceHeaderDisplayed()).toBeTruthy();

            //should verify DP balance Header is displayed on [Balances Report]
            expect(balancesReport.isDPBalanceHeaderDisplayed()).toBeTruthy();

            //should verify that the net Invoice displayed on [Balances Report] is equal to the value in the database
            expect(balancesReport.netInvoiceValueDisplayed(td.operation.name, td.invoice.name, td.businessPartner.name, td.salesPeriodYear, td.salesPeriodSeason)).toEqual(td.netInvoice);

            //should verify that the net Payments displayed on [Balances Report] is equal to the value in the database
            expect(balancesReport.netPaymentsDisplayed(td.operation.name, td.invoice.name, td.businessPartner.name, td.salesPeriodYear, td.salesPeriodSeason)).toEqual(td.netPayments);

            //should verify that the net Pending payments displayed on [Balances Report] is equal to the value in the database
            expect(balancesReport.netPendingPaymentsDisplayed(td.operation.name, td.invoice.name, td.businessPartner.name, td.salesPeriodYear, td.salesPeriodSeason)).toEqual(td.netPending);

            //should verify that the pioneer balance displayed on [Balances Report] is equal to the value in the database
            expect(balancesReport.pioneerBalanceDisplayed(td.operation.name, td.invoice.name, td.businessPartner.name, td.salesPeriodYear, td.salesPeriodSeason)).toEqual(td.pioneerBalance);

            //should click on filter icon
            balancesReport.clickFilterIcon();

            //should click on sales period from the drawer displayed
            filterDrawer.clickSalesPeriodDropDown();

            //should select a prior sales period from the filter drawer
            filterDrawer.selectSalesPeriodFromDropDown(td.salesPeriodYear, td.salesPeriodSeason);

            //should click on the dropback to close the sales period selection
            filterDrawer.clickDropBack();

            //should click apply on the filter drawer for your selection to apply to the [balances report]
            filterDrawer.clickApply();

            //should verify that all the pioneer balances displayed for the prior sales period are non zero
            expect(balancesReport.areAllPioneerBalancesNonZero()).toBe(true);

        }, fail);
    });
});