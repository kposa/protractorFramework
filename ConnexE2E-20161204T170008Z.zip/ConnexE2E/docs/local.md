# [Connex E2E Documentation](/)

## Local vs Not

The defining difference between running the tests locally vs octopus is the presence of the `Env` command line argument. If it is present then it is assumed the tests are running locally (webstorm, command line, ect...) and will pull config values from `./localConfig`. If it isn't present then config values are pulled from command line arguments which Octopus passes in.