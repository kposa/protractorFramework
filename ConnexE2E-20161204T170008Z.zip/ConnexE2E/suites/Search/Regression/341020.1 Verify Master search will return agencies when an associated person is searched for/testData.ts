/// <reference path='../../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';
import { query341020, query341020Results } from './queries';

export default class TestData341020 extends BaseTestData {

    public agencyId: string;
    public personFirstName: string;
    public personLastName: string;
    public personType: string;

    protected queries = [
        this.getResultFor341020()
    ];

    private getResultFor341020 (): () => Promise<query341020Results> {
        return () => {
            const sql = query341020();
            const results = this.queryService.executeSql<query341020Results[]>(sql);

            return results
                .then(data => {
                    const row = <query341020Results>getRandomQueryResult(data);

                    this.agencyId = row.agencyId;
                    this.personFirstName = row.personFirstName;
                    this.personLastName = row.personLastName;
                    this.personType = row.personType;

                    return row;
                });
        };
    }

}