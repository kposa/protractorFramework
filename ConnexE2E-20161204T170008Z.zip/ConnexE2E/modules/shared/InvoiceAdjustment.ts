/// <reference path="../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import {Element} from "./Element";

let e = new Element();

export class InvoiceAdjustment {

    get titletext(): Promise<string>{
        return $('div.title').getText();
    }
}