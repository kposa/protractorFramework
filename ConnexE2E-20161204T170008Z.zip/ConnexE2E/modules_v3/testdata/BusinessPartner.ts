/// <reference path="../../typings/index.d.ts" />

import { Entity } from './Entity';

export interface BusinessPartner extends Entity {}

export type CustomerCulture = 'en-us' | 'en-ca' | 'fr-ca';