/// <reference path="../../../../typings/index.d.ts" />

import { bootstrap } from '../../../SharedSteps/bootstrap';
import { EllipseItem2 } from '../../../../modules_v3/testdata/EllipseItem';
import { itw } from '../../../../modules_v3/helpers/itw';
import SharedEllipseNavigationTestData from './SharedSalesSupportNavigationTestData';
import { SalesSupportOperationFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportOperationFullView';
import SalesSupportNavigationMenuPartialView from '../../../../modules_v3/views/salesSupport/SalesSupportNavigationMenuPartialView';
import { SalesSupportMasterSearchFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportMasterSearchFullView';

const salesSupportOperationFullView = new SalesSupportOperationFullView();
const salesSupportMasterSearchFullView = new SalesSupportMasterSearchFullView();
const salesSupportNavigationMenuPartialView = new SalesSupportNavigationMenuPartialView();

export class SharedSalesSupportNavigationSteps {
    public run (description:string, td:SharedEllipseNavigationTestData, ellipseItems:Array<EllipseItem2>,
                preEllipseItem?:EllipseItem2, pending?:string) {
        itw(description, () => {
            td.populatePromise().then(() => {
                // bootstrap (load, login, reset feature flags, impersonate)
                bootstrap(td.salesSupportUser);

                // should search operation
                salesSupportMasterSearchFullView.search(td.operation.id);
                salesSupportMasterSearchFullView.selectFilterContainingText('Operations');
                salesSupportMasterSearchFullView.clickSearchResultContainingText(td.operation.name);

                // should verify the application navigated to the operation page
                expect(browser.getCurrentUrl()).toContain('#/sales-support/operation/',
                    'the wrong page was displayed after selecting operation from main search result');

                // should navigate to the page with the ellipse we want to test
                salesSupportOperationFullView.clickFirstAccount();

                if (preEllipseItem.name === 'invoice') {

                    // should select item from the toaster menu
                    salesSupportOperationFullView.toasterMenu.selectMenuItemContainingText('Invoice');

                    // should verify the application navigated to the correct page
                    expect(preEllipseItem.targetView.isViewDisplayed()).toBeTruthy();
                }

                if (preEllipseItem.name === 'documents') {

                    //should select item from the toaster menu
                    salesSupportOperationFullView.toasterMenu.selectMenuItemContainingText('Documents');

                    // should verify the application navigated to the correct page
                    expect(preEllipseItem.targetView.isViewDisplayed()).toBeTruthy();
                }

                if (preEllipseItem.name === 'shares') {

                    //should select item from the toaster menu
                    salesSupportOperationFullView.toasterMenu.selectMenuItemContainingText('Shares');

                    // should verify the application navigated to the correct page
                    expect(preEllipseItem.targetView.isViewDisplayed()).toBeTruthy();
                }

                if (preEllipseItem.name === 'Charges and credits') {

                    //should select item from the toaster menu
                    salesSupportOperationFullView.toasterMenu.selectMenuItemContainingText('Invoice');

                    //should open navigation menu
                    salesSupportNavigationMenuPartialView.openMenu();

                    // should select the given item from the menu
                    salesSupportNavigationMenuPartialView.selectMenuItemContainingText('Charges and credits');

                    // should verify the application navigated to the correct page
                    expect(preEllipseItem.targetView.isViewDisplayed()).toBeTruthy();
                }

                if (preEllipseItem.name === 'discounts') {

                    //should select item from the toaster menu
                    salesSupportOperationFullView.toasterMenu.selectMenuItemContainingText('Invoice');

                    //should open navigation menu
                    salesSupportNavigationMenuPartialView.openMenu();

                    // should select the given item from the menu
                    salesSupportNavigationMenuPartialView.selectMenuItemContainingText('Discounts');

                    // should verify the application navigated to the correct page
                    expect(preEllipseItem.targetView.isViewDisplayed()).toBeTruthy();
                }

                browser.getCurrentUrl().then((lastUrl)=> {
                    ellipseItems.forEach(i => {

                        //should open menu
                        salesSupportNavigationMenuPartialView.openMenu();

                        // should select the given item from the menu
                        salesSupportNavigationMenuPartialView.selectMenuItemContainingText(i.name);

                        // should verify the application redirected the user to the correct page
                        expect(i.targetView.isViewDisplayed()).toBeTruthy();

                        browser.get(lastUrl);
                    });
                });

            }, fail);
        });
    }
}