/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;
import { IView } from '../../interfaces/common/IView';
import { isPresentAndDisplayed, isAriaEnabled, hasClass } from '../../helpers/utilityElementHelpers';
import { filterElements, isActive, containingText, matchingAttributeValue } from '../../helpers/filterElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';
import { NotImplementedError } from '../../../common/exception/Exceptions';
import { parseCurrencyString } from '../../helpers/utilityHelpers';

export class SalesSupportEPaymentFullView implements IView {

    public paymentInformationSectionUS = new PaymentInformationSection();
    public datepicker = new DatePicker();

    isViewDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('section.epayment'));
    }

    enterAmountInPaymentField (amt:string, invoiceName:string) {
        let paymentField = this.getInvoiceRowByName(invoiceName).$('input[ng-model="paymentLine.amount"]');
        clickElement(paymentField);
        paymentField.clear();
        paymentField.sendKeys(amt);
    }

    getDatepickerInputValue (invoiceName:string) {
        return this.getInvoiceRowByName(invoiceName).$('input.md-datepicker-input').getAttribute('value');
    }

    clickContinueButton () {
        clickElement($('button[ng-click="vm.continue()"]'));
    }

    clickPayAllSlider () {
        let payAllSlider = $('md-switch[ng-click="vm.payAll()"]').$('div.md-thumb');
        clickElement(payAllSlider);
    }

    clickCalendarIcon (acctDescName:string) {
        let expandIcon = this.getInvoiceRowByName(acctDescName).$('button.md-datepicker-button');
        clickElement(expandIcon);
    }

    getSumOfAllPaymentLineAmounts ():Promise<number> {
        let sum = 0;
        return browser.controlFlow().execute(() => {
            $$('input[ng-model="paymentLine.amount"]').each((e) => {
                return e.getAttribute('value').then((paymentAmount:string) => {
                    sum += parseCurrencyString(paymentAmount);
                });
            })
        }).then(() => {
            return parseFloat(sum.toFixed(2));
        });
    }

    private getInvoiceRowByName (invoiceName:string):ElementFinder {
        return filterElements($$('div[ng-repeat*="paymentLine in salesPeriodGroupedPayments.payments"]'), [
            isActive(true),
            containingText(invoiceName, e => e.$(`div.listitem-primary`))
        ])().first()
    }
}

class PaymentInformationSection {

    private section = $('bank-information');
    private acceptButton = this.section.$('button[ng-click="vm.acceptClicked()"]');
    private paymentAmount = this.section.$$('span.label').first();

    // should just return the dollar amount
    getPaymentAmount ():Promise<number> {
        return this.paymentAmount.getText().then((txt) => {
            return parseCurrencyString(txt.split(':')[ 1 ].trim());
        });
    }

    blurField () {
        clickElement(this.paymentAmount);
    }

    getBankName ():Promise<string> {
        return this.section.$('input[ng-model="vm.bankName"]').getAttribute('value');
    }

    enterRoutingNumber (number:string) {
        let routingNumberInputContainer = $('input[name="routingNumber"]');
        clickElement(routingNumberInputContainer);
        routingNumberInputContainer.sendKeys(number);
    }

    enterAccountNumber (number:string) {
        let accountNumberInputContainer = $('input[name="accountNumber1"]');
        clickElement(accountNumberInputContainer);
        accountNumberInputContainer.sendKeys(number);
    }

    confirmAccountNumber (number:string) {
        let confirmAccountumberInputContainer = $('input[name="accountNumber2"]');
        clickElement(confirmAccountumberInputContainer);
        confirmAccountumberInputContainer.sendKeys(number);
    }

    enterConfirmationEmail (email:string) {
        let confirmationEmailInputContainer = $('input[ng-model="vm.customeremail"]');
        confirmationEmailInputContainer.clear();
        clickElement(confirmationEmailInputContainer);
        confirmationEmailInputContainer.sendKeys(email);
    }

    isFirstRadioButtonSelected ():Promise<boolean> {
        let firstRadioButton = this.section.$$('div.pm-selection-icon').first();
        return hasClass(firstRadioButton, 'is-checked');
    }

    isAcceptButtonEnabled ():Promise<boolean> {
        return isAriaEnabled(this.acceptButton);
    }

    clickAcceptButton () {
        clickElement(this.acceptButton);
    }
}

class DatePicker implements IView {

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    // Sunday November 2 2016
    selectDayByDate (date:string) {
        clickElement(this.getDayByDate(date));
    }

    // Sunday November 2 2016
    isDayDisabled (date:string):Promise<boolean> {
        return hasClass(this.getDayByDate(date), 'md-calendar-date-disabled');
    }

    // Sunday November 2 2016
    getDateOfCurrentlySelectedDay ():Promise<string> {
        return this.getDisplayedDatePicker().$('td.md-calendar-selected-date').getAttribute('aria-label');
    }

    selectTodaysDate () {
        clickElement(this.getDisplayedDatePicker().$('td.md-calendar-date-today'));
    }

    private getDayByDate (date:string):ElementFinder {
        return filterElements(this.getDisplayedDatePicker().$$('td.md-calendar-date'), [
            isActive(true),
            matchingAttributeValue({ attribute: 'aria-label', value: date })
        ])().first();
    }

    private getDisplayedDatePicker ():ElementFinder {
        return filterElements($$('div.md-datepicker-calendar'), [ isActive(true) ])().first();
    }
}