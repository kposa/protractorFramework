/// <reference path="../../../typings/index.d.ts" />

import {Element} from '../../shared/Element';
import Promise = webdriver.promise.Promise;

let e = new Element();

export class SearchCS {

    private searchField = $('input[placeholder="SearchCS"]');

    public searchBarHamburger = $('i[ng-click="drawerVM.toggleDrawerPosition()"]');
    public searchBarHamburgerMenuParent = $('section[name="navigationDrawer"]');

    public clickSearchBarHamburger():void {
        e.clickElement(this.searchBarHamburger);
    }
    
    public isSearchScreenDisplayed(): Promise<boolean> {
        let searchScreen = $('div.search-container');
        return searchScreen.isDisplayed();
    }

    public selectSearchBarHamburgerOption(option:string):void {
        let menuOption = this.searchBarHamburgerMenuParent.all(by.cssContainingText('span', option)).get(0);    //span inside of span - should matter which is clicked
        e.clickElement(menuOption);
    }

    public searchForAndSelectCriteria(criteria:string):void {
        this.searchField.sendKeys(criteria);
    }

    public searchByCriteria(criteria:string):void {
        let searchField = element(by.model('criteria'));
        searchField.clear();
        searchField.sendKeys(criteria);
        searchField.sendKeys(protractor.Key.ENTER);
    }

    public selectRadioButton(name:string):void {
        var radioButton = element(by.cssContainingText('div.pm-selection-label', name));
        e.clickElement(radioButton);
    }

    public selectSearchResult(title?:string, otherTextOnCard?:string):void {
        let allResults = $$('div.pm-card');
        allResults.filter(function (elem, index) {
            return elem.getText().then(function (cardText) {
                if (title && otherTextOnCard) {
                    return cardText.indexOf(title) > -1 && cardText.indexOf(otherTextOnCard) > -1;
                } else if (title) {
                    return cardText.indexOf(title) > -1;
                } else {
                    return true;
                }
            });
        }).then(function (filteredElems) {
            e.clickElement(filteredElems[0]);
        });
    }
}