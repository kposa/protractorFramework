/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;
import { filterElements, isActive, containingText } from '../../../modules_v3/helpers/filterElementHelpers';
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

export class AgencyMD {

    private cardHeaderRowParent = $$('div.card-header.grey-text.layout-align-start-center.layout-row');

    get salesAgencyId(): any {
        return $('side-nav-item[icon-name="swap_horiz"]').getAttribute('agency-id');
    }

    public isSalesAgencyIdDisplayedOnBlueRibbon(): Promise<string>{
        return $$('md-toolbar.md-toolbar-tools.flex')
            .get(0).$('agency-header[agency-id]').getText();
    }

    public isHamburgerMenuDisplayed(): Promise<boolean> {
        let hamburgerMenu = $('button[ng-click="vm.toggleMenu()"]');
        return hamburgerMenu.isDisplayed();
    }

    public getCardsAndIconsText(): ElementArrayFinder {
        let allResults = $$('div.card-header.grey-text').$$('span');
        return allResults;
    }

    public selectGeneralCard(): void {
        let generalCard = this.cardHeaderRowParent.get(0);
        clickElement(generalCard);
    }

    public selectTerritoryCard(): void {
        let territoryCard = this.cardHeaderRowParent.get(1);
        clickElement(territoryCard);
    }

    public selectMailingAddressCard(): void {
        let mailingAddressCard = this.cardHeaderRowParent.get(2);
        clickElement(mailingAddressCard);
    }

    public selectStreetAddressCard(): void {
        let streetAddressCard = this.cardHeaderRowParent.get(3);
        clickElement(streetAddressCard);
    }

    public selectPhoneNumbersCard(): void {
        let phoneNumbersCard = this.cardHeaderRowParent.get(4);
        clickElement(phoneNumbersCard);
    }

    public selectStatusCard(): void {
        let statusCard = this.cardHeaderRowParent.get(5);
        clickElement(statusCard);
    }

    public selectFinancialCard(): void {
        let financialCard = this.cardHeaderRowParent.get(6);
        clickElement(financialCard);
    }

    public selectVendorCard(): void {
        let vendorCard = this.cardHeaderRowParent.get(7);
        clickElement(vendorCard);
    }

    public selectNotesCard(): void {
        let notesCard = this.cardHeaderRowParent.get(8);
        clickElement(notesCard);
    }

    public selectTab(tabName: string): void {
        let tab = filterElements(
            $$('md-tab-item'),
            [
                isActive(true),
                containingText(tabName)
            ]
        )().first();
        clickElement(tab);
    }

    public selectGeneralCardForProfile(): void {
        let generalCard = $('md-card[ng-click="vm.navigateToGeneral()"]');
        clickElement(generalCard);
    }

    public selectMittCard(): void {
        let mittCard = $('md-card[ng-click="vm.navigateToMitt()"]');
        clickElement(mittCard);
    }

    public selctPersonalComputersCard(): void {
        let personalComputersCard = $('md-card[ng-click="vm.navigateToPersonalComputers()"]');
        clickElement(personalComputersCard);
    }
}