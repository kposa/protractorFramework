/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;
import { IView } from '../../interfaces/common/IView';
import Promise = protractor.promise.Promise;
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';
import { filterElements, isActive, containingText } from '../../helpers/filterElementHelpers';

export class ITSupportEllipsePartialView implements IView {

    private ellipseSection = $('.actions');

    isViewDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed(this.ellipseSection);
    }

    select (ellipseMenuItem:string) {
        this.openEllipseIfClosed();
        clickElement(filterElements(this.ellipseSection.$$('div.action'), [
                isActive(true),
                containingText(ellipseMenuItem)
            ])().first(),
            `Could not find '${ellipseMenuItem}' in the ellipse`);
    }

    private openEllipseIfClosed() {
        let ellipsis = $('div.fa.fa-ellipsis-v');
        isPresentAndDisplayed(this.ellipseSection).then((d) => {
            if(!d) clickElement(ellipsis);
        })
    }
}