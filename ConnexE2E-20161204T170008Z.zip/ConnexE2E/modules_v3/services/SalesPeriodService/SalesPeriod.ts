import { SalesPeriodService } from './';
import * as ConfigService from '../ConfigService';

const config = ConfigService.getInstance();

export class SalesPeriod {
    private _id: number;
    private _year: number;
    private _season: "Fall" | "Spring";

    constructor (
        id: number = config.data.DefaultSalesPeriodId,
        year: number = config.data.DefaultSalesPeriodYear,
        season: "Fall" | "Spring" = config.data.DefaultSalesPeriodSeason
    ) {
        this._id = id;
        this._year = year;
        this._season = season;
    }

    public setTo (salesPeriodId: number) {
        const updatedSalesPeriod = SalesPeriodService.updateSalesPeriodId(this, salesPeriodId);

        this._id = updatedSalesPeriod.id;
        this._year = updatedSalesPeriod.year;
        this._season = updatedSalesPeriod.season;
    }

    public get id () {
        return this._id;
    }

    public get year () {
        return this._year;
    }

    public get season () {
        return this._season;
    }

    public get name () {
        return `${this._year} ${this._season}`;
    }
}