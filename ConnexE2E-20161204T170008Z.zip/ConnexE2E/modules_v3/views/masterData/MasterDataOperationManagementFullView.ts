/// <reference path='../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import { NotImplementedError } from '../../../common/exception/Exceptions';
import { IView } from '../../interfaces/common/IView';
import { clickElement } from '../../helpers/clickElementHelpers';
import { filterElements, isActive, containingText } from '../../helpers/filterElementHelpers';
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';

export class MasterDataOperationManagementFullView implements IView {

    isViewDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('section.with-paper.operationmanagement-operation'));
    }

    clickFirstIndividualBPCard () {
        clickElement($$('master-data-individual-partner-card').first());
    }

    clickIndividualBpCardsTab (tab:string) {
        clickElement(filterElements($$('md-tab-item'), [
                isActive(true),
                containingText(tab)
            ])().first(),
            `Could not find the '${tab}'`);
    }
}