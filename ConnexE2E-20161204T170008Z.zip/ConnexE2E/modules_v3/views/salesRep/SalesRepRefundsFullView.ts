/// <reference path='../../../typings/index.d.ts' />
import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;
import { IView } from '../../interfaces/common/IView';
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';
import { filterElements, isActive, containingText, matchingText } from '../../helpers/filterElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';
import { IClosableView } from '../../interfaces/common/IClosableView';

export class SalesRepRefundsFullView implements IView {

    public paymentKeypadSection = new PaymentKeypadSection();

    isViewDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('section.refunds'));
    }

    private getInvoiceRowByName (invoiceName:string):ElementFinder {
        return filterElements($$('li[ng-repeat*="lineItem in refundLineItems | orderBy:"]')
            , [ isActive(true), containingText(invoiceName, e => e.$('div.account-description').$('label'))])().first();
    }

    enterAmountInPaymentField (amt:string, invoiceName:string) {
        let paymentField = this.getInvoiceRowByName(invoiceName).$('button.refund-amount');
        clickElement(paymentField);
        this.paymentKeypadSection.fillInputUnits(amt);
    }

    clickIssueRefund(){
        clickElement($('button[ng-click="issueRefund()"]'));
    }

}

class PaymentKeypadSection implements IClosableView {

    fillInputUnits (units:string) {
        units.split('').forEach(digit => {
            let keypadDigit = filterElements($$('td[ng-click*="keypad.addDigit"]'), [ isActive(true), matchingText(digit) ])().first();
            clickElement(keypadDigit);
        });
    }

    close () {
        clickElement(filterElements($$('div[ng-click="close()"]'), [ isActive(true) ])().first());
    }

}