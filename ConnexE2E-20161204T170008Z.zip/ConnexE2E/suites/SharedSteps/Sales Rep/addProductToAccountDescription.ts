/// <reference path="../../../typings/index.d.ts" />

import { SalesRepOperationFullView } from '../../../modules_v3/views/salesRep/SalesRepOperationFullView';
import { SalesRepInvoiceFullView } from '../../../modules_v3/views/salesRep/SalesRepInvoiceFullView';
import { SalesRepInvoiceAddLineItemDrawerPartialView } from '../../../modules_v3/views/salesRep/SalesRepInvoiceAddLineItemDrawerPartialView';
import BaseTestData from '../../../modules_v3/testdata/BaseTestData';

const salesRepOperationFullView = new SalesRepOperationFullView();
const salesRepInvoiceFullView = new SalesRepInvoiceFullView();
const salesRepInvoiceAddLineItemDrawerPartialView = new SalesRepInvoiceAddLineItemDrawerPartialView();

export function addProductToAccountDescription (options:AddProductToAccountDescriptionOptions, td:BaseTestData):void {

    //should click Invoiced
    browser.controlFlow().execute(()=> {
        salesRepOperationFullView.clickInvoiceButton(td.invoices[0].name);
    });

    //should add line item
    salesRepInvoiceFullView.addLineItem(options.productLine);

    //should add product to line item drawer
    salesRepInvoiceAddLineItemDrawerPartialView.selectProduct(options.product);

    //should add subproduct to line item drawer
    salesRepInvoiceAddLineItemDrawerPartialView.selectSubProduct(options.subProduct);

    //should enter units
    salesRepInvoiceAddLineItemDrawerPartialView.fillInputUnits(options.units);

    //should close line item drawer
    salesRepInvoiceAddLineItemDrawerPartialView.close();

}

export interface AddProductToAccountDescriptionOptions {
    productLine?:string;
    product?:string;
    subProduct?:string;
    units:string;
}