/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import {Element} from "./../../shared/Element";
import {MaterialDesignElement} from "../../shared/MaterialDesignElement";
import {Helpers} from "../../shared/Helpers";

let e = new Element();
let md = new MaterialDesignElement();
let hlp = new Helpers();

export class DeferredPaymentLoanApplicationFormSR {

    private addressField = $('section[value="vm.displayAddress()"]');
    private workPhoneField = $('section[value="vm.customerContactInfo.workPhone"]');
    private mobilePhoneField = $('section[value="vm.customerContactInfo.mobilePhone"]');
    private homePhoneField = $('section[value="vm.customerContactInfo.alternatePhone"]');
    private faxField = $('section[value="vm.customerContactInfo.fax"]');
    private emailField = $('section[value="vm.customerContactInfo.email"]');
    private ssnField = $('section[value="vm.customerTaxIdNumber"]');
    private legalFirstNameField = $('section[value="vm.displayLegalFirstName()"]');
    private legalMiddleNameField = $('section[value="vm.displayLegalMiddleInitial()"]');
    private legalLastNameField = $('section[value="vm.displayLegalLastName()"]');
    private businessPartnerField = $('section[value="vm.selectedCustomerName"]');
    public dateOfBirthField = $('section[value="vm.dateOfBirth"]');
    private preApprovedCreditLimitField = $('section[value="vm.toCurrency(vm.customerCreditLimitPreApproved)"]');
    private requestedCreditLimitField = $('section[value="vm.customerCreditLimitRequestedAmount"]');

    public enterWorkPhoneNumber(number?:string):void {
        if (!number) number = '5150000000';
        md.clickFormField(this.workPhoneField);
        md.enterInputText(this.workPhoneField, number);
        this.focusOutOfAllFields();
    }

    public enterSSN(ssn?:string):void {
        if (!ssn) ssn = '123456789';
        md.clickFormField(this.ssnField);
        md.enterInputText(this.ssnField, ssn);
        this.focusOutOfAllFields();
    }

    //19 years ago
    public enterDateOfBirth():void {
        md.clickFormField(this.dateOfBirthField);   //not sure why 2 clicks were needed for this one
        md.clickFormField(this.dateOfBirthField);
        md.enterInputText(this.dateOfBirthField, hlp.getFormattedDate(2, -19 * 365));
        this.focusOutOfAllFields();
    }

    public enterEmail(email?:string):void {
        if (!email) email = 'automation@test.com';
        md.clickFormField(this.emailField);
        md.enterInputText(this.emailField, email);
        this.focusOutOfAllFields();
    }

    public enterRequestedCreditLimit(val:number):void {
        let creditLimit = val.toString();
        md.clickFormField(this.requestedCreditLimitField);
        md.enterInputText(this.requestedCreditLimitField, creditLimit);
        this.focusOutOfAllFields();
    }

    public clickConfirm():void {
        let confirmButton = $('button[ng-click="vm.continueEntry()"]');
        e.clickElement(confirmButton);
    }

    public selectABusinessPartner():void {
        let dropdownItem = this.businessPartnerField.$$('div.pm-listitem').get(0);
        md.clickFormField(this.businessPartnerField);
        e.clickElement(dropdownItem);
    }

    public focusOutOfAllFields():void {
        let firstSubheader = $$('div.pm-list-subheader').get(0);
        e.clickElement(firstSubheader);
    }

    public dateIsFormatted(date:string):boolean {
        let numberOfForwardSlashes = date.match(/\//g).length;
        return date.length == 10 && numberOfForwardSlashes == 2;
    }

    public ssnIsFormatted(ssn:string):boolean {
        let numberOfDashes = ssn.match(/-/g).length;
        return ssn.length == 11 && numberOfDashes == 2;
    }

    private sectionIsFocused(section:ElementFinder):Promise<boolean> {
        return e.hasClass(section, 'is-focused');
    }

    private isPhoneFieldFormatted(section:ElementFinder):Promise<boolean> {
        return md.getDisplayValue(section).getText().then(function (phoneNumber) {
            return Boolean(~phoneNumber.indexOf('(') && ~phoneNumber.indexOf(')') && ~phoneNumber.indexOf('-'));
        });
    }
    
    private isCurrencyFieldFormatted(elem:ElementFinder):Promise<boolean> {
        return elem.getText().then(function (currencyText) {
             return Boolean(~currencyText.indexOf('$') && ~currencyText.indexOf('.'));
        });
    }

    public isAddressFieldEditable():Promise<boolean> {
        md.clickFormField(this.addressField);
        return this.sectionIsFocused(this.addressField);
    }

    public isWorkPhoneFieldEditable():Promise<boolean> {
        md.clickFormField(this.workPhoneField);
        return this.sectionIsFocused(this.workPhoneField);
    }

    public isMobilePhoneFieldEditable():Promise<boolean> {
        md.clickFormField(this.mobilePhoneField);
        return this.sectionIsFocused(this.mobilePhoneField);
    }

    public isHomePhoneFieldEditable():Promise<boolean> {
        md.clickFormField(this.homePhoneField);
        return this.sectionIsFocused(this.homePhoneField);
    }

    public isFaxFieldEditable():Promise<boolean> {
        md.clickFormField(this.faxField);
        return this.sectionIsFocused(this.faxField);
    }

    public isEmailFieldEditable():Promise<boolean> {
        md.clickFormField(this.emailField);
        return this.sectionIsFocused(this.emailField);
    }

    public isSSNFieldEditable():Promise<boolean> {
        md.clickFormField(this.ssnField);
        return this.sectionIsFocused(this.ssnField);
    }

    public isLegalFirstNameEditable():Promise<boolean> {
        md.clickFormField(this.legalFirstNameField);
        return this.sectionIsFocused(this.legalFirstNameField);
    }

    public isLegalMiddleNameEditable():Promise<boolean> {
        md.clickFormField(this.legalMiddleNameField);
        return this.sectionIsFocused(this.legalMiddleNameField);
    }

    public isLegalLastNameEditable():Promise<boolean> {
        md.clickFormField(this.legalLastNameField);
        return this.sectionIsFocused(this.legalLastNameField);
    }

    public isDateOfBirthFieldEditable():Promise<boolean> {
        md.clickFormField(this.dateOfBirthField);
        return this.sectionIsFocused(this.dateOfBirthField);
    }

    public isPreApprovedCreditLimitFieldEditable():Promise<boolean> {
        md.clickFormField(this.preApprovedCreditLimitField);
        return this.sectionIsFocused(this.preApprovedCreditLimitField);
    }

    public isRequestedCreditLimitFieldEditable():Promise<boolean> {
        md.clickFormField(this.requestedCreditLimitField);
        return this.sectionIsFocused(this.requestedCreditLimitField);
    }

    get isWorkPhoneFormatted():Promise<boolean> {
        return this.isPhoneFieldFormatted(this.workPhoneField);
    }

    public isSSNFormatted():Promise<boolean> {
        return md.getDisplayValue(this.ssnField).getText().then((ssn) => {
            return this.ssnIsFormatted(ssn);
        });
    }

    get isDateOfBirthFormatted():Promise<boolean> {
        return md.getDisplayValue(this.dateOfBirthField).getText().then((dob)=> {
            return this.dateIsFormatted(dob);
        });
    }

    get isEmailFormatted():Promise<boolean> {
        return md.getDisplayValue(this.emailField).getText().then(function (email) {
            return hlp.validateEmail(email);
        });
    }

    get isRequestedCreditLimitFormatted():Promise<boolean> {
        return this.isCurrencyFieldFormatted(this.requestedCreditLimitField);
    }

    get preApprovedCreditLimitValue():Promise<string> {
        return md.getDisplayValue(this.preApprovedCreditLimitField).getText();
    }
}