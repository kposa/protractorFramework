/// <reference path="../../../../typings/index.d.ts" />

const { E2EInvoicesDatabaseName } = process.env;

export interface territoriesWithGrowthAndRetentionProgramsResults {
    salesRepId: string,
    salesRepName: string,
    operationId: string,
    operationName: string,
    customerId: string,
    customerName: string,
    salesAgencyId: string,
    salesAgencyName: string,
    territoryId: string,
    territoryName: string
}

/**
 * Unless the operation is in a territory that has growth and retention programs,
 * the [growth and retention overview] ellipse menu item will not display.
 * Dale said this will be most often be available - just test without that ellipse item if no query results
 * @param salesPeriodId
 * @returns {string}
 */
export function territoriesWithGrowthAndRetentionPrograms (salesPeriodId:number): string {
    return `
    select DISTINCT TOP 25
           uo.userId as salesRepId,
           u.name as salesRepName,
           o.operationId,
           o.name as operationName,
           c.customerId,
           c.name customerName,
           sa.salesAgencyId,
           sa.name as salesAgencyName,
           sat.territoryId,
           t.name as territoryName
    from ${E2EInvoicesDatabaseName}.dbo.OperationSalesAgency as osa
    join ${E2EInvoicesDatabaseName}.dbo.SalesAgencyTerritory as sat on sat.SalesAgencyId = osa.SalesAgencyId
    join ${E2EInvoicesDatabaseName}.dbo.Territory t on t.territoryid = sat.territoryid
    join ${E2EInvoicesDatabaseName}.dbo.SalesAgency as sa on sa.SalesAgencyId = osa.SalesAgencyId
    join ${E2EInvoicesDatabaseName}.dbo.Operation as o on o.OperationId = osa.OperationId
    join ${E2EInvoicesDatabaseName}.dbo.OperationCustomer as oc on oc.OperationId = o.OperationId
    join ${E2EInvoicesDatabaseName}.dbo.Customer as c on c.CustomerId = oc.CustomerId
    join ${E2EInvoicesDatabaseName}.dbo.UserOperation as uo on uo.OperationId = o.OperationId
    join ${E2EInvoicesDatabaseName}.dbo.[User] as u on u.UserId = uo.UserId
    where uo.SalesPeriodId = ${salesPeriodId}
    and uo.SalesPeriodId = osa.SalesPeriodId
    and sat.SalesPeriodId = osa.SalesPeriodId
    and uo.RoleId = 10
    and uo.UserId like '%phiext.com'
    and ltrim(rtrim(u.Name)) <> ''
    and exists (
        select 1
        from invoicesdemo.dbo.Invoice as i
        join invoicesdemo.dbo.LineItem as li on li.InvoiceId = i.InvoiceId
        where i.SalesPeriodId = ${salesPeriodId}
        and i.OperationId = osa.OperationId
    )
    AND sat.TerritoryId in (
    	SELECT DISTINCT dp.TerritoryId 
    	FROM discounts.DiscountProgram dp
		JOIN discounts.GrowthAndRetentionDiscountProgram gardp ON gardp.DiscountProgramId = dp.DiscountProgramId
		WHERE dp.SalesPeriodId = ${salesPeriodId}
	)  
    `
}