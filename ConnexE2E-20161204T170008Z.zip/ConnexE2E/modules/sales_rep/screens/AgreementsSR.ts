/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;
import ElementArrayFinder = protractor.ElementArrayFinder;
import ElementFinder = protractor.ElementFinder;

import {Element} from "../../shared/Element";
import {DeferredPaymentAgreementTermsSR} from "./DeferredPaymentAgreementTermsSR";

import SignaturePadPartialView from '../../../modules_v3/views/shared/SignaturePadPartialView';

let e = new Element();
let terms = new DeferredPaymentAgreementTermsSR();
let signBtn = $('button[ng-hide="agreement.paperDocument"]');

export class AgreementsSR {
    private signaturePadPartialView = new SignaturePadPartialView();

    public clickSignDeferredPaymentLoanAgreement():void {
        let signButton = $('button[ng-click="openLoanAgreement(operationId, customerId)"]');
        e.clickElement(signButton);
    }

    public clickViewForTheSignedAgreement():void {
        let viewButton = $('button[id="view1"]');
        e.clickElement(viewButton);
    }

    public clickViewForTheSignedUAVAgreement():void {
        let viewButton = $('button[id="view88"]');
        e.clickElement(viewButton);
    }

    public clickSignAgreementAndSignTheAgreement():void {
        let signButton = $('button[id="sign1"]');
        signButton.isPresent().then(isPresent => {
            if (isPresent) {
                e.clickElement(signButton);
                terms.clickSignTa();

                this.signaturePadPartialView.strokeSignature();
                this.signaturePadPartialView.clickAgree();
                this.signaturePadPartialView.clickSelect();
                this.signaturePadPartialView.strokeSignature();
                this.signaturePadPartialView.clickAgree();
            }
        });
    }

    public clickSignUAVAgreement():void {
        let signButton = $('button[id="sign88"]');
        signButton.isPresent().then(isPresent => {
            if (isPresent) {
                e.clickElement(signButton);
                terms.clickSignTa();

                this.signaturePadPartialView.strokeSignature();
                this.signaturePadPartialView.clickAgree();
                this.signaturePadPartialView.clickSelect();
                this.signaturePadPartialView.strokeSignature();
                this.signaturePadPartialView.clickAgree();
            }
        });
    }

    public isAgreementsPagePresent():Promise<string> {
        let pageTitle = $('span[ng-if="!loading"]');
        return pageTitle.getText();
    }
}