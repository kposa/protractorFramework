/// <reference path="../../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import {Drawer} from "../../shared/DrawerCS";
import {Element} from "../../../shared/Element";
import {Helpers} from "../../../shared/Helpers";

let hlp = new Helpers();
let dwr = new Drawer();
let e = new Element();

export class LineItemDrawer {

    public selectProductLine(productLine?:string):void {
        let productLineDrawerParent = $('section.salessupport-products-productline');
        dwr.selectListItem(productLineDrawerParent, productLine);
    }

    public selectProduct(product_name?:string):void {
        let productDrawerParent = $('section.salessupport-products-product');
        dwr.selectListItem(productDrawerParent, product_name);
    }

    public selectSubproduct(subproduct_name?:string):void {
        let productDrawerParent = $('section.salessupport-products-subproduct');
        dwr.selectListItem(productDrawerParent, subproduct_name);
    }

    public enterUnits(units?:string | number):void {
        if (!units) units = hlp.getRandomIntBetween(5, 200);
        units = units.toString();

        let unitsDrawerParent = $('section.salessupport-product-units');
        dwr.enterUnits(unitsDrawerParent, <string> units);   //type assertion
        this.closeUnitsKeypad();
    }

    public selectWarehouse(warehouse_name?:string):void {   //only if displayed - this is temporary to create a product detail line
        let warehouseDrawerParent = $('section.salessupport-products-warehouse');
        warehouseDrawerParent.isDisplayed().then(function (iD) {
            if (iD) dwr.selectListItem(warehouseDrawerParent, warehouse_name);
        })
    }

    public holdTrashcanToDelete():void {
        var trashCan = $('div[ng-mousedown="dab.start()"]');
        dwr.holdToDelete(trashCan);
    }

    public closeUnitsKeypad() {
        dwr.close();
    }

    public clickDirectShipmentSection() {
        let directShipmentSection = $('div.direct-ship').$('div.pm-text-label');
        e.clickElement(directShipmentSection);
    }

    public clickSaveButton() {
        e.clickElement($('div[ng-click="livm.close()"]'));
    }
}