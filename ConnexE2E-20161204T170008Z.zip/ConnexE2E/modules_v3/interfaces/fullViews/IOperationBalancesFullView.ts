/// <reference path="../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import Promise = webdriver.promise.Promise;

export interface IOperationBalancesFullView {
    getInvoiceByNameAndSalesPeriod (invoiceName:string, salesperiodName:string):ElementFinder;
    getBalanceForInvoiceByInvoiceNameAndSalesPeriod (invoiceName:string, salesperiodName:string):Promise<number>;
    clickInvoiceByNameAndSalesPeriod (invoiceName:string, salesperiodName:string):void;
}