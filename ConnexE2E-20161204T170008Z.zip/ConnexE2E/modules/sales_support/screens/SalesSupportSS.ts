/// <reference path="../../../typings/index.d.ts" />

//FIXME - remove this file - we dont want an entire p.o. for the sales support role

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import {Element} from "../../shared/Element";


let elem = new Element();

export class SalesSupportSS {
    
    private allCards = $$('div.pm-card');
    private side_drawer_parent_productLines = $('section.salessupport-products-productline');
    private side_drawer_parent_products = $('section.salessupport-products-product');
    private side_drawer_parent_subproducts = $('section.salessupport-products-subproduct');
    private side_drawer_parent_warehouses = $('section.salessupport-products-warehouse');

    public searchByCriteria(criteria:string):void {
        const searchField = element(by.model('criteria'));
        searchField.clear();
        searchField.sendKeys(criteria);
        searchField.sendKeys(protractor.Key.ENTER);
    }

    public selectRadioButton(radioBtn:string):void {
        var radioButton = element(by.cssContainingText('div.pm-selection-label', radioBtn));
        elem.clickElement(radioButton);
    }

    public selectCardFromSearchResults(title:string, otherTextOnCard?:string):void {
        this.allCards.filter(function (elem, index) {
            return elem.getText().then(function (cardText) {
                if (title && otherTextOnCard) {
                    return cardText.indexOf(title) > -1 && cardText.indexOf(otherTextOnCard) > -1;
                } else if (title) {
                    return cardText.indexOf(title) > -1;
                } else {
                    return false;
                }
            });
        }).then(function (filteredElems) {
            if (filteredElems.length) {
                elem.clickElement(filteredElems[0]);
            } else {
                elem.clickElement(this.allCards.get(0));
            }
        });
    }


    public clickOnItem(tag:string, text:string):void {
        var itemToClick = element(by.cssContainingText(tag, text));
        elem.clickElement(itemToClick);
    }

    public selectItemFromExpandedBottomMenu(item:string):void {
        var expandedBottomMenuItem = $('div.list.expandedbottommenu').all(by.cssContainingText('span', item)).get(0);
        elem.clickElement(expandedBottomMenuItem);
    }

    public selectProductLineFromSideDrawer(prodLine?:string):void {
        var productLineInSideDrawer: ElementFinder;
        if (prodLine) {
            productLineInSideDrawer = this.side_drawer_parent_productLines.element(by.cssContainingText('div.pm-listitem-primary', prodLine));
            elem.clickElement(productLineInSideDrawer);
        } else {
            this.side_drawer_parent_productLines.$$('div.pm-listitem-primary').filter(function (elem, index) {
                return elem.isDisplayed().then(function (isDisplayed) {
                    return isDisplayed === true;
                });
            }).then(function (filteredElems) {
                productLineInSideDrawer = filteredElems[Math.floor(Math.random() * filteredElems.length)];
                elem.clickElement(productLineInSideDrawer);
            });
        }
    }

    public selectProductFromSideDrawerIfDisplayed(product?:string):void {
        this.side_drawer_parent_products.isDisplayed().then((iD) => {
            if (iD) {
                var productInSideDrawer: ElementFinder;
                if (product) {
                    productInSideDrawer = this.side_drawer_parent_products.element(by.cssContainingText('div.pm-listitem', product));
                    elem.clickElement(productInSideDrawer);
                } else {
                    this.side_drawer_parent_products.$$('div.pm-listitem').filter((elem, index) => {
                        return elem.isDisplayed().then((isDisplayed) => {
                            return isDisplayed === true;
                        });
                    }).then((filteredElems) => {
                        productInSideDrawer = filteredElems[Math.floor(Math.random() * filteredElems.length)];
                        elem.clickElement(productInSideDrawer);
                    });
                }
            }
        }, () => {
        });
    }

    public selectSubproductFromSideDrawerIfDisplayed(subProd?:string):void {
        this.side_drawer_parent_subproducts.isDisplayed().then((iD) => {
            if (iD) {
                var subproductInSideDrawer: ElementFinder;
                if (subProd) {
                    subproductInSideDrawer = this.side_drawer_parent_subproducts.element(by.cssContainingText('li.pm-listitem', subProd));
                    elem.clickElement(subproductInSideDrawer);
                } else {
                    this.side_drawer_parent_subproducts.$$('li.pm-listitem').filter((elem, index) => {
                        return elem.isDisplayed().then((isDisplayed) => {
                            return isDisplayed === true;
                        });
                    }).then((filteredElems) => {
                        subproductInSideDrawer = filteredElems[Math.floor(Math.random() * filteredElems.length)];
                        elem.clickElement(subproductInSideDrawer);
                    });
                }
            }
        }, () => {
        });
    }

    public selectWarehouseFromSideDrawerIfDisplayed(ind?:number, warehouseName?:string):void {
        if (!ind) {
            ind = 0;
        }
        this.side_drawer_parent_warehouses.isDisplayed().then((iD) => {
            if (iD) {
                var warehouseInSideDrawer: ElementFinder;
                if (warehouseName) {
                    warehouseInSideDrawer = this.side_drawer_parent_warehouses.element(by.cssContainingText('div.pm-listitem', warehouseName));
                    elem.clickElement(warehouseInSideDrawer);
                } else {
                    this.side_drawer_parent_warehouses.$$('div.pm-listitem').filter((elem, index) => {
                        return elem.isDisplayed().then((isDisplayed) => {
                            return isDisplayed === true;
                        });
                    }).then((filteredElems) => {
                        warehouseInSideDrawer = filteredElems[ind];
                        elem.clickElement(warehouseInSideDrawer);
                    });
                }
            }
        }, function () {
        });

    }

    get pageHeaderProducts():Promise<string> {
        return $('div.pm-title').getText();
    }

    get prodLine():Promise<string> {
        return $$('div.header-title').get(0).getText();
    }

    get product():Promise<string> {
        //TODO when we get the API calls working. the soybeans part should be deleted as we would have only onw account desc card that we willl work with!
        return element(by.cssContainingText('div.header-title', 'Soybeans')).element(by.xpath('..')).$('div.listitem-primary.line').$$('div').get(0).getText();
    }

    get subproduct():Promise<string> {
        return element(by.cssContainingText('div.header-title', 'Soybeans')).element(by.xpath('..')).$('div.listitem-primary.line').$$('div').get(1).getText();
    }

    get units():Promise<string> {
        return element(by.cssContainingText('div.header-title', 'Soybeans')).element(by.xpath('..')).$('div.listitem-primary.line').$$('div').get(2).getText();
    }

    get salesSeasonFromInfoCard():Promise<string> {
        return $('div.pm-style-body-1.subtitle').getText();
    }

    get isInfoIconFromInfoCardDisplayed():Promise<boolean> {
        return $('i.material-icons.md-48.md-dark').isDisplayed();
    }

    /*    get operation():Promise<string> {
     return $$('div.pm-style-body-2.name').get(0).getText();
     }

     get agency():Promise<string> {
     return $$('div.pm-style-body-2.name').get(1).getText();
     }*/

    get pageHeaderDocuments():Promise<string> {
        return $('div.pm-title').getText();
    }


}