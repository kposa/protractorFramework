export interface accountManagersAndActiveInactiveAgenciesResults {
    salesRepId:string,
    salesRepName:string,
    salesAgencyName:string,
    salesAgencyId:string
}

export function accountManagersAndActiveInactiveAgencies (salesPeriodId:number) {
    const { E2EInvoicesDatabaseName } = process.env;

    return `
    SELECT DISTINCT TOP 20
        u.Name salesRepName, 
        u.UserId salesRepId, 
        sa.SalesAgencyId salesAgencyId,
        sa.Name salesAgencyName
    FROM ${E2EInvoicesDatabaseName}.dbo.UserOperation uo
        JOIN ${E2EInvoicesDatabaseName}.dbo.[User] u on u.UserId = uo.UserId 
        JOIN ${E2EInvoicesDatabaseName}.dbo.OperationSalesAgency osa on uo.OperationId = osa.OperationId
            and uo.SalesPeriodId = osa.SalesPeriodId
        JOIN ${E2EInvoicesDatabaseName}.dbo.SalesAgency sa on osa.SalesAgencyId = sa.SalesAgencyId
    WHERE uo.UserId like '%phibred.com%' and uo.SalesPeriodId = ${salesPeriodId}
        AND u.UserId in (select distinct UserId from ${E2EInvoicesDatabaseName}.dbo.UserOperation where roleId = 15)
  `;
}