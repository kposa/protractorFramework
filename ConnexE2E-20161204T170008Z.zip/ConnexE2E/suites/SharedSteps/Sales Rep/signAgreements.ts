/// <reference path="../../../typings/index.d.ts" />

import ActionMenuPartialView from '../../../modules_v3/views/shared/ActionMenuPartialView';
import { SalesRepBusinessPartnersFullView } from '../../../modules_v3/views/salesRep/SalesRepBusinessPartnersFullView';
import { SalesRepAgreementsFullView } from '../../../modules_v3/views/salesRep/SalesRepAgreementsFullView';
import { BusinessPartner } from '../../../modules_v3/testdata/BusinessPartner';

const actionMenuPartialView = new ActionMenuPartialView();
const salesRepBusinessPartnersFullView = new SalesRepBusinessPartnersFullView();
const salesRepAgreementsFullView = new SalesRepAgreementsFullView();

export function signAgreements (options:SignAgreementsOptions):void {

    // should open ellipsis menu
    actionMenuPartialView.openMenu();

    //should select item from the ellipsis menu
    actionMenuPartialView.selectMenuItemContainingText('business partners');

    //should click the agreements button (only capable of signing 1 business partner's agreements right now)
    salesRepBusinessPartnersFullView.clickAgreementsButtonByName(options.businessPartners[0].name);

    //should sign all unsigned agreements
    salesRepAgreementsFullView.signAllUnsignedAgreements(options);

    //should go back to business partner screen
    salesRepAgreementsFullView.clickBack();

    //should go back to operation screen
    salesRepBusinessPartnersFullView.clickBack();

}

export interface SignAgreementsOptions {
    businessPartners:BusinessPartner[];
    techAgreementOnly?:boolean;
}