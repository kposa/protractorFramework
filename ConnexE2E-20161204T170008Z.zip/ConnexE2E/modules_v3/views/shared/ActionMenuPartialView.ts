/// <reference path='../../../typings/index.d.ts' />

import { IActionPartialView } from "../../interfaces/partialViews/IActionMenuPartialView";
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';
import {
    filterElements,
    isActive,
    containingText,
    matchingText
} from '../../../modules_v3/helpers/filterElementHelpers';
import { IView } from '../../interfaces/common/IView';
import { NotImplementedError } from '../../../common/exception/exceptions';
import Promise = protractor.promise.Promise;

export default class ActionMenuPartialView implements IView, IActionPartialView {
    private menuButton = $(`div[class*='fa-ellipsis']`);
    private menuItems = $(`.actions`).$$(`a`);

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    public openMenu ():void {
        clickElement(this.menuButton);
    }

    selectMenuItemMatchingText (text:string):void {
        clickElement(filterElements(this.menuItems, [ isActive(true), matchingText(text) ])().first());
    }

    selectMenuItemContainingText (text:string):void {
        clickElement(filterElements(this.menuItems, [ isActive(true), containingText(text) ])().first());
    }
}
