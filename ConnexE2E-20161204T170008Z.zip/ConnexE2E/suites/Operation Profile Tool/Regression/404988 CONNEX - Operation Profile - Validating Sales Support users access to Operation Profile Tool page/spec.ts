/// <reference path="../../../../typings/index.d.ts" />

import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { SalesSupportMasterSearchFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportMasterSearchFullView';
import { TestData404988 } from './testData';
import { SalesSupportOperationProfileToolFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportOperationProfileToolFullView';
import { itw } from '../../../../modules_v3/helpers/itw';
import { SalesSupportOperationProfilePageFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportOperationProfilePageFullView';
import { SalesSupportSalesAgencyOperationsFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportSalesAgencyOperationsFullView';

const test = new TestCase(
    '404988',
    'Operation Profile - Validating Sales Support users access to [Operation Profile Tool] page',
    UserRole.SALES_SUPPORT,
    ApplicationFeature.OPERATION_PROFILE_TOOL
);

describe(test.stringify, () => {
    const td = new TestData404988();
    let search = new SalesSupportMasterSearchFullView();
    let salesAgencyPage = new SalesSupportSalesAgencyOperationsFullView();
    let operationProfileTool = new SalesSupportOperationProfileToolFullView();
    let operationProfilePage = new SalesSupportOperationProfilePageFullView();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            bootstrap(td.salesSupportUser);

            //search for a sales agency using the id
            search.search(td.salesAgency.id);

            //click on the agency result
            search.clickSearchResultContainingText(td.salesAgency.id);

            //Click n the hamburger icon on the Agency page
            salesAgencyPage.hamburgerMenu.openMenu();

            //click on the operation Profile tool link from the hamburger
            salesAgencyPage.hamburgerMenu.selectMenuItemContainingText('Operation Profile Tool');

            // should verify a hamburger icon displayed on Operation Profile Tool page
            expect(operationProfileTool.isHamburgerDisplayed()).toBeTruthy();

            // should verify that the text in the header contains 'Operation Profile Tool'
            expect(operationProfileTool.textOnOperationProfileToolHeader()).toContain('Operation profile tool');

            // should verify that the text in the header contains the name  of the sales Agency
            expect(operationProfileTool.textOnOperationProfileToolHeader()).toContain(td.salesAgency.name);

            // should verify that headers display correctly
            expect(operationProfileTool.isOperationHeaderDisplayed()).toBeTruthy();
            expect(operationProfileTool.isPrimaryDecisionMakerHeaderDisplayed()).toBeTruthy();
            expect(operationProfileTool.isTotalCommercialAcresHeaderDisplayed()).toBeTruthy();
            expect(operationProfileTool.isLivestockHeaderDisplayed()).toBeTruthy();
            expect(operationProfileTool.isLastUpdatedHeaderDisplayed()).toBeTruthy();

            // should verify all operation names are populated
            expect(operationProfileTool.areAllOperationNamesPopulated()).toBeTruthy();

            // should verify all primary decision maker names are populated
            expect(operationProfileTool.areAllPrimaryDecisionMakerNamesPopulated()).toBeTruthy();

            // should verify all total commercial acres are populated
            expect(operationProfileTool.areAllTotalCommercialAcresPopulated()).toBeTruthy();

            // should click on the first record
            operationProfileTool.clickTheFirstOperationRow();

            //should assert on the display of the current year in the header
            expect(operationProfilePage.textOnOperationProfileHeader()).toContain(td.salesPeriod.year);

        }, fail);
    });
});
