/// <reference path="../../../../typings/index.d.ts" />

import {NavigationsSR} from "../../../../modules/sales_rep/navigations/NavigationsSR";
import TestData361491 from './testData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
	'361491',
	'Sales Rep can access Reference Materials and Help Links on Operations page',
	UserRole.SALES_REP,
	ApplicationFeature.NAVIGATIONS
);

describe(test.stringify, () => {
    const td = new TestData361491();
    let nav = new NavigationsSR();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.salesRepresentative);

            // should select [Help] link from the {Hamburger] option
            browser.ignoreSynchronization = true;
            nav.selectItemFromHamburgerMenu('Help');

            browser.getAllWindowHandles().then(function (handles) {
                var newWindowHandle = handles[1];

                browser.sleep(2000);    //allow for page redirect
                browser.switchTo().window(newWindowHandle).then(function () {
                    if (td.salesAgency.country == 'US') {
                        expect(browser.getCurrentUrl()).toContain('https://nasweb.pioneer.com/');
                        expect(browser.getCurrentUrl()).toContain('connex-US.html');
                    }
                    else if (td.salesAgency.country == 'CA') {
                        expect(browser.getCurrentUrl()).toContain('https://nasweb.pioneer.com/');
                        expect(browser.getCurrentUrl()).toContain('connex-CAN.html');
                    }
                    browser.close();
                    browser.switchTo().window(handles[0]).then(function () {
                        expect(browser.getCurrentUrl()).toContain('#/field/operations/');
                    });
                });
            });
        }, fail);
    });
});