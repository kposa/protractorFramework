/// <reference path='../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import { NotImplementedError } from '../../../common/exception/Exceptions';
import { IView } from '../../interfaces/common/IView';
import { filterElements, containingText, isActive, matchingExactText } from '../../helpers/filterElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';
import { randomNumberInRange } from '../../helpers/utilityHelpers';
import { isAriaDisabled, isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';

export class SalesRepOperationProfilePageFullView implements IView {

    public commercialAcresDialog = new CommercialAcresDialog();
    public competitiveCommercialAcresDialog = new CompetitiveCommercialAcresDialog();
    public dairyProducerDialog = new DairyProducerDialog();
    public otherLivestockDialog = new OtherLivestockDialog();
    public otherDialog = new OtherDialog();
    public seedProductionAcresDialog = new SeedProductionAcresDialog();
    private allCommercialAcreLines = $$('md-list[ng-repeat="commercial in vm.commercialAcres"]');
    private allCompetitiveCommercialAcreLines = $$('md-list[ng-repeat="competitiveCommercial in vm.competitiveCommercialAcres"]');
    private allSeedProductionAcreLines = $$('md-list[ng-repeat="seedProductionAcre in vm.seedProductionAcres"]');
    private allDairyProducerLines = $$('md-list[ng-repeat="dairy in vm.dairyProducers"]');
    private allOtherLivestockLines = $$('md-list[ng-repeat="otherLivestockProducer in vm.otherLivestockProducers"]');
    private allOtherLines = $$('md-list[ng-repeat="other in vm.profileOthers"]');

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    getDisplayedHeaders ():Promise<string[]> {
        return $$('div.section-header').getText();
    }

    clickAddButtonForHeadersContainingText (headerText:string) {
        let header = filterElements($$('div.section-header'), [
            isActive(true),
            matchingExactText(headerText)
        ])().first();
        clickElement(header.element(by.xpath('..')).$('i.md-24'));
    }

    clickAddButtonForSeedProductionAcres () {
        clickElement($('button[ng-click="vm.addSeedProductionAcre()"]').$('div.material-icons'));
    }

    clickBackArrow () {
        let backArrow = $('div.fa-chevron-left');
        clickElement(backArrow);
    }

    deleteFirstCommercialAcresRow () {
        clickElement(this.allCommercialAcreLines.first().$('md-icon.delete-icon'));
    }

    clickFirstCommercialAcresLineItem () {
        clickElement(this.allCommercialAcreLines.first());
    }

    getNumberOfCommercialAcreLines ():Promise<number> {
        return filterElements(this.allCommercialAcreLines, [ isActive(true) ])().count();
    }

    deleteFirstCompetitiveCommercialAcresRow () {
        clickElement(this.allCompetitiveCommercialAcreLines.first().$('md-icon.delete-icon'));
    }

    clickFirstCompetitiveCommercialAcresLineItem () {
        clickElement(this.allCompetitiveCommercialAcreLines.first());
    }

    getNumberOfCompetitiveCommercialAcreLines ():Promise<number> {
        return filterElements(this.allCompetitiveCommercialAcreLines, [ isActive(true) ])().count();
    }

    deleteFirstDairyProducerRowIfPresent () {
        isPresentAndDisplayed(this.allDairyProducerLines.first()).then((dairyProducerRow) => {
            if (dairyProducerRow)
                clickElement(this.allDairyProducerLines.first().$('md-icon.delete-icon'));
        });
    }

    clickFirstDairyProducerLineItem () {
        clickElement((this.allDairyProducerLines).first());
    }

    getNumberOfDairyProducerLines ():Promise<number> {
        return filterElements(this.allDairyProducerLines, [ isActive(true) ])().count();
    }

    isDairyProducerAddButtonDisabled ():Promise<boolean> {
        return isAriaDisabled($('button[ng-click="vm.dairyProducerDialogVisible=true;vm.isNew=true;"]'));
    }

    deleteFirstOtherLivestockRow () {
        clickElement(this.allOtherLivestockLines.first().$('md-icon.delete-icon'));
    }

    clickFirstOtherLivestockLineItem () {
        clickElement(this.allOtherLivestockLines.first());
    }

    deleteFirstOtherLivestockRowIfAddButtonDisabled () {
        isAriaDisabled($('button[ng-click="vm.otherLivestockEditDialogVisible=true; vm.otherLivestockId=0"]')).then((dairyProducerRow) => {
            if (dairyProducerRow) {
                this.deleteFirstOtherLivestockRow();
            }
        });
    }

    getNumberOfOtherLivestockLines ():Promise<number> {
        return filterElements(this.allOtherLivestockLines, [ isActive(true) ])().count();
    }

    clickFirstOtherLineItem () {
        clickElement(this.allOtherLines.first());
    }

    getNumberOfOtherLines ():Promise<number> {
        return filterElements(this.allOtherLines, [ isActive(true) ])().count();
    }

    deleteOtherRowIfPresent () {
        isPresentAndDisplayed(this.allOtherLines.first()).then((otherRow) => {
            if (otherRow)
                clickElement(this.allOtherLines.first().$('md-icon.delete-icon'));
        });
    }

    getNumberOfSeedProductionAcreLines ():Promise<number> {
        return filterElements(this.allSeedProductionAcreLines, [ isActive(true) ])().count();
    }

    deleteFirstSeedProductionAcresRow () {
        clickElement(this.allSeedProductionAcreLines.first().$('md-icon.delete-icon'));
    }

    clickFirstSeedProductionAcresLineItem () {
        clickElement(this.allSeedProductionAcreLines.first());
    }
}

class CommercialAcresDialog {

    private confirmationDialog = $('form.save-confirmation-dialog');
    private saveButton = $('button[save-confirmation-dialog="vm.saveCommercialAcres(vm.commercialAcre)"]')

    clickProductLineDropdown () {
        let section = $('section.commercial-acres-dialog.visible');
        clickElement(section.$('md-select[ng-model="vm.commercialAcre.productLine"]'));
    }

    selectProductLineFromDropdown (productLine?:string):void {
        this.clickProductLineDropdown();
        let filterFunctions = [ isActive(true) ];

        if (productLine) filterFunctions.push(containingText(productLine));

        clickElement(filterElements(
            $$('md-option[ng-repeat="option in vm.pruneProductLines(vm.commercialAcre.productLine)"]'),
            filterFunctions
        )().first());
    }

    enterValueIntoDrylandAcresInput (value?:number) {
        value = value ? value : randomNumberInRange(0, 100);
        let dryLandAcresField = $('input[ng-model="vm.commercialAcre.drylandAcres"]');
        clickElement(dryLandAcresField);
        dryLandAcresField.clear();
        dryLandAcresField.sendKeys(value.toString());
    }

    enterValueIntoIrrigatedAcresInput (value?:number) {
        value = value ? value : randomNumberInRange(0, 100);
        let irrigatedAcresField = $('input[ng-model="vm.commercialAcre.irrigatedAcres"]');
        clickElement(irrigatedAcresField);
        irrigatedAcresField.clear();
        irrigatedAcresField.sendKeys(value.toString());
    }

    enterValueIntoPioneerAcresInput (value?:number) {
        value = value ? value : randomNumberInRange(0, 100);
        let pioneerAcresField = $('input[ng-model="vm.commercialAcre.pioneerAcres"]');
        clickElement(pioneerAcresField);
        pioneerAcresField.clear();
        pioneerAcresField.sendKeys(value.toString());
    }

    enterValueIntoCompetitiveBrandAcresInput (value?:number) {
        value = value ? value : randomNumberInRange(0, 100);
        let competitiveBrandAcresField = $('input[ng-model="vm.commercialAcre.competitiveBrandAcres"]');
        clickElement(competitiveBrandAcresField);
        competitiveBrandAcresField.clear();
        competitiveBrandAcresField.sendKeys(value.toString());
    }

    verifyTotalAcresDisplayed ():Promise<string> {
        return $('label.total-acres-value').getText();
    }

    isSaveButtonDisabled ():Promise<boolean> {
        return isAriaDisabled(this.saveButton);
    }

    clickSave ():void {
        clickElement(this.saveButton.$$('span').first());
    }

    isConfirmationDialogDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed(this.confirmationDialog);
    }

    clickCancelConfirmationDialog () {
        clickElement(this.confirmationDialog.$('md-dialog-actions').$('button[ng-click="cancel()"]'));
    }

    isInvalidMessageDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('div[ng-messages="commercialAcresForm.irrigatedAcres.$error"]'));
    }

    clickDelete ():void {
        clickElement($('button[ng-click="vm.deleteCommercialAcres(vm.commercialAcre)"]').$$('span').first())
    }
}

class CompetitiveCommercialAcresDialog {

    private competitiveCommercialAcresSection = $('section.competitive-commercial-acres-dialog');
    private saveButton = $('button[save-confirmation-dialog="vm.saveCompetitiveCommercialAcres(vm.competitiveCommercialAcre)"]');

    clickProductLineDropdown () {
        clickElement(this.competitiveCommercialAcresSection.$('md-select[ng-model="vm.competitiveCommercialAcre.productLineId"]'));
    }

    selectProductLineFromDropdown (productLine?:string):void {
        this.clickProductLineDropdown();
        let filterFunctions = [ isActive(true) ];

        if (productLine) filterFunctions.push(containingText(productLine));

        clickElement(filterElements(
            $$('md-option[ng-repeat="productLine in vm.productLines"]'),
            filterFunctions
        )().first());
    }

    clickBrandDropdown () {
        clickElement(this.competitiveCommercialAcresSection.$('md-select[ng-model="vm.competitiveCommercialAcre.brandName"]'));
    }

    enterValueIntoAcresInput (value?:number) {
        value = value ? value : randomNumberInRange(0, 100);
        let pioneerAcresField = $('input[ng-model="vm.competitiveCommercialAcre.acres"]');
        clickElement(pioneerAcresField);
        pioneerAcresField.clear();
        pioneerAcresField.sendKeys(value.toString());
    }

    selectBrandFromDropdown (brand?:string):void {
        this.clickBrandDropdown();
        let filterFunctions = [ isActive(true) ];

        if (brand) filterFunctions.push(containingText(brand));

        clickElement(filterElements(
            $$('md-option[ng-repeat="brand in vm.brands | orderBy: \'brandName\'"]'),
            filterFunctions
        )().first());
    }

    clickHybridDropdown () {
        clickElement(this.competitiveCommercialAcresSection.$('md-select[ng-model="vm.competitiveCommercialAcre.hybridVariety"]'));
    }

    clickSave ():void {
        clickElement(this.saveButton.$$('span').first());
    }

    clickCancelConfirmationDialog () {
        clickElement($('form.save-confirmation-dialog').$('md-dialog-actions').$('button[ng-click="cancel()"]'));
    }

    isInvalidMessageDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('div[ng-messages="competitiveCommercialAcresForm.acres.$error"]'));
    }

    clickDelete ():void {
        clickElement($('button[ng-click="vm.deleteCompetitiveCommercialAcres(vm.competitiveCommercialAcre)"]').$$('span').first())
    }

    isSaveButtonDisabled ():Promise<boolean> {
        return isAriaDisabled(this.saveButton);
    }
}

class DairyProducerDialog {

    private dairyProducerSection = $('section.dairy-producer-dialog');
    private saveButton = $('button[ng-click="vm.saveDairyProducer(vm.dairyProducer)"]');

    clickProducerDropdown () {
        clickElement(this.dairyProducerSection.$('md-select[ng-model="vm.dairyProducer.producer"]'));
    }

    selectProducerFromDropdown (producer?:string):void {
        this.clickProducerDropdown();
        let filterFunctions = [ isActive(true) ];

        if (producer) filterFunctions.push(containingText(producer));

        clickElement(filterElements(
            $$('md-option[ng-repeat="option in vm.yesNoOptions"]'),
            filterFunctions
        )().first());
    }

    clickHerdSizeDropdown () {
        clickElement(this.dairyProducerSection.$('md-select[ng-model="vm.dairyProducer.herdSize"]'));
    }

    enterValueIntoGradeAPermitInput (value?:number) {
        value = value ? value : randomNumberInRange(0, 100);
        let gradeAPermitField = $('input[ng-model="vm.dairyProducer.gradeAPermit"]');
        clickElement(gradeAPermitField);
        gradeAPermitField.clear();
        gradeAPermitField.sendKeys(value.toString());
    }

    selectHerdSizeFromDropdown (herdSize?:string):void {
        this.clickHerdSizeDropdown();
        let filterFunctions = [ isActive(true) ];

        if (herdSize) filterFunctions.push(containingText(herdSize));

        clickElement(filterElements(
            $$('md-option[ng-repeat="herdSize in vm.herdSize"]'),
            filterFunctions
        )().first());
    }

    clickGrowFeedDropdown () {
        clickElement(this.dairyProducerSection.$('md-select[ng-model="vm.dairyProducer.growFeed"]'));
    }

    selectGrowFeedFromDropdown (growFeed?:string):void {
        this.clickGrowFeedDropdown();
        let filterFunctions = [ isActive(true) ];

        if (growFeed) filterFunctions.push(containingText(growFeed));

        clickElement(filterElements(
            $$('md-option[ng-repeat="option in vm.yesNoOptions"]'),
            filterFunctions
        )().first());
    }

    clickReplacementHerdSizeDropdown () {
        clickElement(this.dairyProducerSection.$('md-select[ng-model="vm.dairyProducer.replacementAnimals"]'));
    }

    selectReplacementHerdSizeFromDropdown (replacementHerdSize?:string):void {
        this.clickReplacementHerdSizeDropdown();
        let filterFunctions = [ isActive(true) ];

        if (replacementHerdSize) filterFunctions.push(containingText(replacementHerdSize));

        clickElement(filterElements(
            $$('md-option[ng-repeat="replacementAnimals in vm.herdSize"]'),
            filterFunctions
        )().first());
    }

    clickGrowFeedForReplacementsDropdown () {
        clickElement(this.dairyProducerSection.$('md-select[ng-model="vm.dairyProducer.growFeedReplacements"]'));
    }

    selectGrowFeedForReplacementsFromDropdown (growFeedForReplacements?:string):void {
        this.clickGrowFeedForReplacementsDropdown();
        let filterFunctions = [ isActive(true) ];

        if (growFeedForReplacements) filterFunctions.push(containingText(growFeedForReplacements));

        clickElement(filterElements(
            $$('md-option[ng-repeat="option in vm.yesNoOptions"]'),
            filterFunctions
        )().first());
    }

    clickSave ():void {
        clickElement(this.saveButton.$$('span').first());
    }

    isInvalidMessageDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('div[ng-messages="dairyProducerForm.gradeAPermit.$error"]'));
    }

    clickDelete ():void {
        clickElement($('button[ng-click="vm.deleteDairyProducer(vm.dairyProducer)"]').$$('span').first())
    }

    isSaveButtonDisabled ():Promise<boolean> {
        return isAriaDisabled(this.saveButton);
    }
}

class OtherLivestockDialog {

    private otherLivestockSection = $('section.livestock-edit-dialog');
    private saveButton = $('button[ng-click="vm.saveOtherLivestock()"]');

    clickLivestockTypeDropdown () {
        clickElement(this.otherLivestockSection.$('md-select[ng-model="vm.otherLivestockProducer.producerType"]'));
    }

    selectLivestockTypeFromDropdown (livestocktype?:string):void {
        this.clickLivestockTypeDropdown();
        let filterFunctions = [ isActive(true) ];

        if (livestocktype) filterFunctions.push(containingText(livestocktype));

        clickElement(filterElements(
            $$('md-option[ng-repeat="producer in vm.filteredProducerTypes"]'),
            filterFunctions
        )().first());
    }

    clickProducerDropdown () {
        clickElement(this.otherLivestockSection.$('md-select[ng-model="vm.otherLivestockProducer.isProducer"]'));
    }

    selectProducerFromDropdown (isProducer?:string):void {
        this.clickProducerDropdown();
        let filterFunctions = [ isActive(true) ];

        if (isProducer) filterFunctions.push(containingText(isProducer));

        clickElement(filterElements(
            $$('md-option[ng-repeat="option in vm.yesNoOptions | orderBy: [\'displayOrder\']"]'),
            filterFunctions
        )().first());
    }

    clickDelete ():void {
        clickElement($('button[ng-click="vm.deleteOtherLivestockProducer();"]').$$('span').first())
    }

    clickSave ():void {
        clickElement(this.saveButton.$$('span').first());
    }

    isSaveButtonDisabled ():Promise<boolean> {
        return isAriaDisabled(this.saveButton);
    }
}

class OtherDialog {

    private otherSection = $('section.profile-other-edit-dialog ');
    private saveButton = $('button[save-confirmation-dialog="vm.saveProfileOther()"]');

    clickYieldMappingCapabilityDropdown () {
        clickElement(this.otherSection.$('md-select[ng-model="vm.profileOther.yieldMappingCapability"]'));
    }

    enterValueIntoHaylageUseInput (value?:number) {
        value = value ? value : randomNumberInRange(0, 100);
        let haylageUse = $('input[ng-model="vm.profileOther.haylageUse"]');
        clickElement(haylageUse);
        haylageUse.clear();
        haylageUse.sendKeys(value.toString());
    }

    enterValueIntoCornSilageUseInput (value?:number) {
        value = value ? value : randomNumberInRange(0, 100);
        let cornSilageUse = $('input[ng-model="vm.profileOther.cornSilageUse"]');
        clickElement(cornSilageUse);
        cornSilageUse.clear();
        cornSilageUse.sendKeys(value.toString());
    }

    selectYieldMappingCapabilityFromDropdown (yieldMappingCapability?:string):void {
        this.clickYieldMappingCapabilityDropdown();
        let filterFunctions = [ isActive(true) ];

        if (yieldMappingCapability) filterFunctions.push(containingText(yieldMappingCapability));

        clickElement(filterElements(
            $$('md-option[ng-repeat="option in vm.yesNoOptions"]'),
            filterFunctions
        )().first());
    }

    clickVariableRateSeedingCapabilityDropdown () {
        clickElement(this.otherSection.$('md-select[ng-model="vm.profileOther.variableRateSeedingCapability"]'));
    }

    selectVariableRateSeedingCapabilityFromDropdown (variableRateSeedingCapability?:string):void {
        this.clickVariableRateSeedingCapabilityDropdown();
        let filterFunctions = [ isActive(true) ];

        if (variableRateSeedingCapability) filterFunctions.push(containingText(variableRateSeedingCapability));

        clickElement(filterElements(
            $$('md-option[ng-repeat="option in vm.yesNoOptions"]'),
            filterFunctions
        )().first());
    }

    clickSave ():void {
        clickElement(this.saveButton.$$('span').first());
    }

    isSaveButtonDisabled ():Promise<boolean> {
        return isAriaDisabled(this.saveButton);
    }

    clickDelete ():void {
        clickElement($('button[ng-click="vm.deleteProfileOther()"]').$$('span').first())
    }
}

class SeedProductionAcresDialog {

    private seedProductionAcresSection = $('section.seed-production-acres-dialog');
    private saveButton = $('button[save-confirmation-dialog="vm.saveSeedProductionAcres(vm.seedProductionAcre)"]');

    clickProductLineDropdown () {
        clickElement(this.seedProductionAcresSection.$('md-select[ng-model="vm.seedProductionAcre.productLineId"]'));
    }

    selectProductLineFromDropdown (productLine?:string):void {
        this.clickProductLineDropdown();
        let filterFunctions = [ isActive(true) ];

        if (productLine) filterFunctions.push(containingText(productLine));

        clickElement(filterElements(
            $$('md-option[ng-repeat="option in vm.filteredProductLines"]'),
            filterFunctions
        )().first());
    }

    enterValueIntoPioneerSeedProductionAcresInput (value?:number) {
        value = value ? value : randomNumberInRange(0, 100);
        let pioneerSeedProductionAcresField = $('input[ng-model="vm.seedProductionAcre.pioneerSeedProductionAcres"]');
        clickElement(pioneerSeedProductionAcresField);
        pioneerSeedProductionAcresField.clear();
        pioneerSeedProductionAcresField.sendKeys(value.toString());
    }

    enterValueIntoCompetitiveBrandProductionAcresInput (value?:number) {
        value = value ? value : randomNumberInRange(0, 100);
        let competitiveBrandProductionAcresField = $('input[ng-model="vm.seedProductionAcre.competitiveProductionBrandAcres"]');
        clickElement(competitiveBrandProductionAcresField);
        competitiveBrandProductionAcresField.clear();
        competitiveBrandProductionAcresField.sendKeys(value.toString());
    }

    isSaveButtonDisabled ():Promise<boolean> {
        return isAriaDisabled(this.saveButton);
    }

    isInvalidMessageDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('div[ng-messages="seedProductionAcreForm.productionAcres.$error"]'));
    }

    clickSave ():void {
        clickElement(this.saveButton.$$('span').first());
    }

    clickDelete ():void {
        clickElement($('button[ng-click="vm.deleteSeedProductionAcres(vm.seedProductionAcre)"]').$$('span').first())
    }

    clickCancelConfirmationDialog () {
        clickElement($('form.save-confirmation-dialog').$('md-dialog-actions').$('button[ng-click="cancel()"]'));
    }
}

