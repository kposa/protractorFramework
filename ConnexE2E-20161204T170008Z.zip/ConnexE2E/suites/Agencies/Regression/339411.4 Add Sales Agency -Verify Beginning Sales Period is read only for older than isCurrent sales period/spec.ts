/// <reference path="../../../../typings/index.d.ts" />

import { SearchMD2 } from "../../../../modules/master_data/screens/SearchMD2";
import { AgencyMD } from "../../../../modules/master_data/screens/AgencyMD";
import { bootstrap } from "../../../SharedSteps/bootstrap";
import { AgencyStatusMD } from '../../../../modules/master_data/screens/AgencyStatusMD';
import TestDataForBeginningSalesPeriodDropdown from './testData';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
	'339411.4',
	'Add Sales Agency - Verify Beginning Sales Period is read only for older than isCurrent sales period',
	UserRole.MASTER_DATA,
	ApplicationFeature.AGENCIES
);

describe(test.stringify, () => {
    const td = new TestDataForBeginningSalesPeriodDropdown();
    let searchMD = new SearchMD2();
    let agencyMD = new AgencyMD();
    let agencyStatusMD = new AgencyStatusMD();

    itw(test.description, () => {
        td.populatePromise().then(() => {

            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.masterDataUser);

            //should select sales agency
            searchMD.searchByCriteria(td.agencyId);
            searchMD.selectSearchResultByResultType('Sales agency');

            //should select status card
            agencyMD.selectStatusCard();

            //should verify beginning sales period drop down is read only
            expect(agencyStatusMD.verifyBeginningSalesPeriodDropdownDisabled()).toBeTruthy();
        }, fail);
    });
});

// It checks if Beginning Sales Period section is read only for older than isCurrent sales period
