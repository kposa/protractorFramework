/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';
import {
    filterElements,
    isActive,
    containingText
} from '../../../modules_v3/helpers/filterElementHelpers';
import { NotImplementedError } from '../../../common/exception/Exceptions';
import { IView } from '../../interfaces/common/IView';

export default class AssociateSellerOperationsFullView implements IView {
    private filterByAgencyButton = $('button[ng-click="vm.viewAgencyList()"]');
    private searchBarHamburger = $('div[ng-click="showNav()"]');

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    clickSearchBarHamburger ():void {
        clickElement(this.searchBarHamburger);
    }

    filterBySalesAgencyIfAgencyButtonDisplayed (agencyId:string):void {
        this.filterByAgencyButton.isDisplayed().then((id) => {
            if (id) {
                this.clickFilterByAgencyButton();
                this.selectAgencyById(agencyId)
            }
        });
    }

    private clickFilterByAgencyButton ():void {
        clickElement(this.filterByAgencyButton);
    }

    selectAgencyById (id:string):void {
        let agencyName = filterElements(
            $$('li[ng-click="vm.selectAgency(a)"]'),
            [
                isActive(true),
                containingText(id)
            ]
        )().first();
        clickElement(agencyName);
    }

}