/// <reference path='../../typings/index.d.ts' />

/**
 * This class covers the login process into Connex.
 * It also provides functionality to reset all feature flags to their default state and set optional flags if they are given
 */

import ElementFinder = protractor.ElementFinder;
import {Element} from './Element';
import {Search} from './Search';
import LoginFullView from "../../modules_v3/views/shared/LoginFullView";

let e = new Element();
let search = new Search();
let loginFullView = new LoginFullView();

export class Login {

    private usernameField = element(by.model('user'));
    private passwordField = element(by.model('password'));
    private signInButton = $('input[type="submit"]');
    private resetMyFlags = $('button[ng-click="reset()"]');
    private loginError = $('div.error');

    public loginToConnex(optionalUserFeatureFlags?:Array<String>):void {
        browser.get(process.env.E2EBaseUrl);
        loginFullView.login(
            process.env.E2EUsername,
            process.env.E2EPassword
        );
        this.resetFeatureFlags(optionalUserFeatureFlags);
    }

    private checkForLoginError():void {
        var self = this;
        self.loginError.isDisplayed().then(function (loginErrorDisplayed) {
            if (loginErrorDisplayed) {
                self.loginError.getText().then(function (errorText) {
                    expect(true).toBe(false, 'login error: ' + errorText);
                })
            }
        }, function () {
        });
    }

    private resetFeatureFlags(optionalUserFeatureFlags?:Array<String>):void {
        search.clickSearchBarHamburger();
        search.selectFeatureFlagsFromHamburger();
        e.clickElement(this.resetMyFlags);
        this.setAnyOptionalUserFlags(optionalUserFeatureFlags);
        browser.navigate().back();
    }

    private setAnyOptionalUserFlags(optionalUserFeatureFlags?:Array<String>):void {
        let globalErrorDetailFlag = 'ShowGlobalErrorDetail';

        if (!optionalUserFeatureFlags) optionalUserFeatureFlags = [globalErrorDetailFlag];
        else optionalUserFeatureFlags.push(globalErrorDetailFlag);

        let self = this;
        let output = '\nUser feature flags turned on: ';
        optionalUserFeatureFlags.forEach(function (flagName:string) {
            output = output + '\n    ' + flagName;
            var flagParent = $('section.featureFlags').element(by.cssContainingText('li', flagName));
            var checkbox = flagParent.$('div.enabled').$('i');
            self.clickFlagUntilSet(true, checkbox);
        });
        console.log(output);

    }

    private clickFlagUntilSet(flagShouldBeOn:boolean, checkbox:ElementFinder) {
        let self = this;
        var classNameWhenFlagEnabled = 'fa-check-circle';
        checkbox.getAttribute('class').then(function (classes) {
            var flagIsEnabled = classes.split(' ').indexOf(classNameWhenFlagEnabled) > -1;
            if ((flagIsEnabled && !flagShouldBeOn) || (!flagIsEnabled && flagShouldBeOn)) {
                e.clickElement(checkbox);
                self.clickFlagUntilSet(flagShouldBeOn, checkbox);
            }
        });
    }
}
