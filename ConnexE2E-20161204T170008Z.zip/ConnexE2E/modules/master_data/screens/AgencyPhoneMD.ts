/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import { filterElements, isActive, containingText } from '../../../modules_v3/helpers/filterElementHelpers';
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

export class AgencyPhoneMD {

    private numberInputContainer = $$('input[ng-model="ph.phoneNumber"]');
    private typeDropdown = $('md-select[ng-model="ph.phoneNumberTypeId"]');

    public isMobileDisplayedInTypeDropdown():Promise<boolean> {
        let typeDropdown = $$('md-select[ng-model="ph.phoneNumberTypeId"]').get(1);
        let mobileDropdownOption =
            $$('md-option[ng-repeat="pt in vm.phoneNumberTypes | filterPhoneType : vm.phoneTypesToRestrict: ' +
                'ph.phoneNumberTypeId : vm.agencyPhoneNumbers"]').get(3);
        clickElement(typeDropdown);
        return mobileDropdownOption.isDisplayed();
    }

    public enterNumber(phoneNumber: string): void {
        this.numberInputContainer.clear();
        this.numberInputContainer.sendKeys(phoneNumber);
    }

    public enterAnotherNumber(phoneNumber:string): void {
        this.numberInputContainer.get(1).sendKeys(phoneNumber);
    }

    public selectOptionFromTypeDropdown(type: string): void {
        let dropdownOption =filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(type)
            ]
        )().first();
        clickElement(this.typeDropdown);
        clickElement(dropdownOption);
    }

    public clickAddIcon(): void {
        let addIcon = $('button.md-fab');
        clickElement(addIcon);
    }

    public clickDeleteIcon(): void {
        let deleteIcon = $$('button[aria-label="delete"]').get(1);
        clickElement(deleteIcon);
    }

}