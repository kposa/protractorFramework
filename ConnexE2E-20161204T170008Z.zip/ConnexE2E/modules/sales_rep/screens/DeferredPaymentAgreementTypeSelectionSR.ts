/// <reference path="../../../typings/index.d.ts" />

// This screen allows the user to select from 5 radio buttons (Individual vs Business customer types)

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import {Element} from "../../shared/Element";

let e = new Element();

export class DeferredPaymentAgreementTypeSelectionSR {

    private allRadioButtons = $$('div[ng-repeat*="entityType"]');

    public selectRadioButton(customerType: number): void {
        let radioButton = this.getRadioButton(customerType);
        e.clickElement(radioButton);
    }

    public clickContinueButton(): void {
        let continueButton = $('button[ng-click="vm.navigateToNameAddressEntry()"]');
        e.clickElement(continueButton);
    }

    public areDefaultRadioButtonsDisplayed(expectedNumRadioButtons?: number): Promise<boolean> {
        if (typeof expectedNumRadioButtons === 'undefined') expectedNumRadioButtons = 5;

        return e.getDisplayedElemsCount(this.allRadioButtons).then((numRadioButtonsDisplayed) => {
            return numRadioButtonsDisplayed === expectedNumRadioButtons;
        });
    }

    // id="{{entityType.customerEntityTypeId}}"
    private getRadioButton(customerType: number): ElementFinder {
        return this.allRadioButtons.filter((elem, index) => {
            return elem.getAttribute('id').then((id) => {
                if (id == null) return false;
                return id === customerType.toString();
            });
        }).get(0);
    }
}