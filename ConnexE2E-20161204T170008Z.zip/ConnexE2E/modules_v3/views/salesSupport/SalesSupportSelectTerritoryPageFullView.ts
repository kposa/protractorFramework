/// <reference path='../../../typings/index.d.ts' />
import ElementFinder = protractor.ElementFinder;

import { IView } from '../../interfaces/common/IView';
import Promise = protractor.promise.Promise;
import { filterElements, containingText, isActive } from '../../helpers/filterElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';

export class SalesSupportSelectTerritoryPageFullView implements IView {

    isViewDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('section.refinement-popup'));
    }

    selectTerritory(territoryName: string): void {
        let territory = filterElements( $$('span[data-ng-click="vm.select(item)"]'),
            [
                isActive(true), containingText(territoryName)
            ])().first();
        clickElement(territory);
    }

}
