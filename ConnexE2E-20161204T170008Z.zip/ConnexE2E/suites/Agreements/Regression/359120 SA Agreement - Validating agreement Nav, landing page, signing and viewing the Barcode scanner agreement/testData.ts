/// <reference path="../../../../typings/index.d.ts" />
import Promise = protractor.promise.Promise;

import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';
import { salesRepsWithNoSignedSalesRepAgreements, salesRepsWithNoSignedSalesRepAgreementsResults } from './queries';
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';

export default class TestData359120 extends BaseTestData {
    protected queries = [
        this.populateSalesRepsWithNoSignedSalesRepAgreements()
    ];

    private populateSalesRepsWithNoSignedSalesRepAgreements (): () => Promise<salesRepsWithNoSignedSalesRepAgreementsResults> {
        return () => {
            const sql = salesRepsWithNoSignedSalesRepAgreements();
            const results = this.queryService.executeSql<salesRepsWithNoSignedSalesRepAgreementsResults>(sql);

            return results
                .then(data => {
                    const row = <salesRepsWithNoSignedSalesRepAgreementsResults>getRandomQueryResult(data);

                    this.salesRepresentatives.push({
                        id: row.salesRepId.toString().trim(),
                        name: row.salesRepName.toString().trim()
                    });

                    this.salesAgencies.push({
                        id: row.salesAgencyId.toString().trim(),
                        name: row.salesAgencyName.toString().trim(),
                        address: row.salesAgencyAddress.toString().trim()
                    });

                    return row;
                });
        };
    }
}