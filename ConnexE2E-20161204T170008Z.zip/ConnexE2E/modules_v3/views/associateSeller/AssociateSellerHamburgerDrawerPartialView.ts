/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;
import { clickElement } from '../../helpers/clickElementHelpers';
import {
    filterElements,
    isActive,
    containingText
} from '../../helpers/filterElementHelpers';
import { IHamburgerMenuPartialView } from '../../interfaces/partialViews/IHamburgerMenuPartialView';
import { IView } from '../../interfaces/common/IView';
import { NotImplementedError } from '../../../common/exception/Exceptions';

export default class AssociateSellerHamburgerDrawerPartialView implements IView, IHamburgerMenuPartialView {

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    clickItemFromHamburgerMenu (itemName:string):void {
        let hamburgerMenuItem = filterElements(
            $('div.box-content.palette-c').$$('span'),
            [
                isActive(true),
                containingText(itemName)
            ]
        )().first();
        clickElement(hamburgerMenuItem);
    }

    selectReport (name:string):void {
        let dropdownOption = filterElements(
            $$('li[ng-repeat="report in vm.reports"]'),
            [
                isActive(true),
                containingText(name)
            ]
        )().first();
        clickElement(dropdownOption);
    }
}