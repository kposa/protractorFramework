/// <reference path='../../../typings/index.d.ts' />
import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;
import { IView } from '../../interfaces/common/IView';
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';
import { filterElements, isActive, containingText, matchingText } from '../../helpers/filterElementHelpers';
import { IClosableView } from '../../interfaces/common/IClosableView';

export class SalesSupportInvoiceFullView implements IView {

    public salesSupportProductsLineItemDrawerSection = new SalesSupportProductsLineItemDrawerSection();
    public salesSupportProductUnitsDrawerSection = new SalesSupportProductUnitsDrawerSection();

    isViewDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('section.salessupport-products'));
    }

    clickAddLineItemButton () {
        clickElement($('div[ng-click="vm.addLineItem()"]'));
    }

}

class SalesSupportProductsLineItemDrawerSection implements IView {

    private productLineInputContainer = $('input[name="productline"]');
    private productInputContainer = $('input[name="product"]');
    private subProductInputContainer = $('input[name="subproduct"]');
    private dropdownItems = $$('li[md-virtual-repeat="item in $mdAutocompleteCtrl.matches"]');

    isViewDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('section.salessupport-products-lineitem-v2'));
    }

    private enterProductLine (productLineName:string):void {
        this.productLineInputContainer.sendKeys(productLineName);
    }

    private enterProduct (productId:string):void {
        clickElement(this.productInputContainer);
        this.productInputContainer.sendKeys(productId);
    }

    private enterSubProduct (subProductId:string):void {
        clickElement(this.subProductInputContainer);
        this.subProductInputContainer.sendKeys(subProductId);
    }

    selectProductLine (productLineName:string):void {
        this.enterProductLine(productLineName);
        let productLine = filterElements(this.dropdownItems, [ isActive(true), containingText(productLineName) ])().first();
        clickElement(productLine);
    }

    selectProduct (productId:string):void {
        this.enterProduct(productId);
        let product = filterElements(this.dropdownItems, [ isActive(true), containingText(productId) ])().first();
        clickElement(product);
    }

    selectSubProduct (subProductId:string):void {
        this.enterSubProduct(subProductId);
        let subProduct = filterElements(this.dropdownItems, [ isActive(true), containingText(subProductId) ])().first();
        clickElement(subProduct);
    }

    isDirectShipmentFieldDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('section[label="Direct shipment"]'));
    }

    isBulkStorageFieldDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('input[name="bulkstorage"]'));
    }

}

class SalesSupportProductUnitsDrawerSection implements IView, IClosableView {

    isViewDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('section.salessupport-product-units'));
    }

    fillInputUnits (units:string) {
        units.split('').forEach(digit => {
            let keypadDigit = filterElements($$('div[ng-click*="unitsvm.drawer.keypad.addDigit"]'), [ isActive(true), matchingText(digit) ])().first();
            clickElement(keypadDigit);
        });
    }

    close ():void {
        clickElement($('div[ng-click="unitsvm.close()"]'));
    }

}
