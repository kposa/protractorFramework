/// <reference path="../../../typings/index.d.ts" />

//right now this page only works with the first payment row
//the test case I wrote sorts the list by created date first - then works with the first row
//if we use this screen - maybe we want to clear out any existing payments for a customer and then just always work with 1 row

import ElementFinder = protractor.ElementFinder;
import Promise = webdriver.promise.Promise;
import {Element} from "../../shared/Element";

let e = new Element();

import {filterElements, isActive} from '../../../modules_v3/helpers/filterElementHelpers';

export class PaymentSummarySS {

    private paymentListParent = $('section#sales-support-payment-list-body');
    private sortByCreatedOnButton = $('div[ng-click="vm.order(\'createdOn\')"]');
    private epaymentEditModal = $('section.epayment-edit');
    private paymentRows = this.paymentListParent.$$('div[ng-repeat="payment in vm.payments"]');
    private firstRow = this.paymentRows.first();

    public sortByCreatedOn():void {
        e.clickElement(this.sortByCreatedOnButton);
    }

    public clickEditPencil():void {
        let displayedElementPencils = filterElements(this.paymentListParent.$$('i[ng-click="vm.editPayment($event, payment)"]'), [
            isActive(true)
        ])();
        e.clickElement(displayedElementPencils.first());
        expect(this.epaymentEditModal.isDisplayed()).toBe(true);
    }

    public selectReasonFromDropdown():void {
        let reasonDropdown = $('md-select.epayment-edit-reason');
        let dropdownParent = $('div#select_container_2');
        let firstDropdownOption = dropdownParent.$$('div.md-text').get(0);
        e.clickElement(reasonDropdown);
        e.clickElement(firstDropdownOption);
    }

    public enterComment():void {
        let textarea = $('textarea.epayment-edit-comment');
        e.clickElement(textarea);
        textarea.sendKeys('Automation comment');
    }

    public clickCancelPayment():void {
        let cancelPaymentButton = $('button[ng-click="vm.cancelClicked()"]');
        e.clickElement(cancelPaymentButton);
        expect(this.epaymentEditModal.isPresent()).toBe(false);
    }

    get isCreatedOnColumnDescending():Promise<boolean> {
        return this.sortByCreatedOnButton.$('i.sort-icon').getText().then(function (txt) {
            return txt === 'arrow_drop_down';
        });
    }

    get isStatusProcessed():Promise<boolean> {
        return this.firstRow.getText().then(function (txt) {
            return Boolean(~txt.indexOf('Processed'));   //the capital P should fail if the row is 'Unprocessed'
        });
    }

    get isAmountZero():Promise<boolean> {
        return this.firstRow.getText().then(function (txt) {
            return Boolean(~txt.indexOf('$0.00'));
        });
    }

}
