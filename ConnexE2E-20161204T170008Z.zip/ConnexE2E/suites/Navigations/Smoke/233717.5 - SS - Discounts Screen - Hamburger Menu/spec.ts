/// <reference path="../../../../typings/index.d.ts" />

import { EllipseItem2 } from '../../../../modules_v3/testdata/EllipseItem';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import SharedEllipseNavigationTestData from '../shared/SharedSalesSupportNavigationTestData';
import { SharedSalesSupportNavigationSteps } from '../shared/SharedSalesSupportNavigationSteps';

const test = new TestCase(
	'233717.5',
	'SS - Discounts Screen - Checks hamburger menu items on discounts screen redirected to correct page',
	UserRole.SALES_SUPPORT,
	ApplicationFeature.NAVIGATIONS
);

describe(test.stringify, () => {
    const sharedSteps = new SharedSalesSupportNavigationSteps();
    const td = new SharedEllipseNavigationTestData();

    const preEllipseItem:EllipseItem2 = td.availableEllipseItems.discounts;

    const ellipseItems:Array<EllipseItem2> = [
        td.availableEllipseItems.products,
        td.availableEllipseItems.documents,
        td.availableEllipseItems.chargeAndCredits,
        td.availableEllipseItems.shares,
        td.availableEllipseItems.activityStatement,
        td.availableEllipseItems.growthAndRetentionOverview,
        td.availableEllipseItems.operation,
        td.availableEllipseItems.search
    ];

    sharedSteps.run(test.description, td , ellipseItems ,preEllipseItem);
});