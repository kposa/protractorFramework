/// <reference path='../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';
import { NotImplementedError } from '../../../common/exception/Exceptions';
import { IView } from '../../interfaces/common/IView';

export class MasterDataOperationProfileToolFullView implements IView {

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    isHamburgerDisplayed ():Promise<boolean> {
        let operationProfileToolHamburger = $('button[aria-label="Menu"]');
        return isPresentAndDisplayed(operationProfileToolHamburger);
    }

    textOnOperationProfileToolHeader ():Promise<string> {
        return $('md-toolbar.md-toolbar-tools').getText();
    }
}
