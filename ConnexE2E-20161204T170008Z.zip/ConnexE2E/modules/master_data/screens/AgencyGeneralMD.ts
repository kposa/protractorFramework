/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';
import { filterElements, isActive, containingText } from '../../../modules_v3/helpers/filterElementHelpers';
import { isAriaDisabled, isAriaChecked } from '../../../modules_v3/helpers/utilityElementHelpers';

export class AgencyGeneralMD {

    private generalLayoutParent = $('div.ng-scope.layout-column.flex');
    private exclusiveRadioButton = $$('md-radio-button[ng-model="vm.isExclusive"]').get(0);
    private reportToInputContainer = $('input[aria-label="Reports To"]');

    private clearReportsToContainer(): void {
        this.reportToInputContainer.clear();
    }

    get verifyGeneralPageDisplayed(): Promise<string> {
        return this.generalLayoutParent.getText();
    }

    public getCheckboxDisplayedForContractAgency(): ElementArrayFinder {
        let allResults = $$('div[ng-repeat="type in vm.agencyAgencyTypes"]').
                            $$('div.md-label').$$('span.ng-binding');
        return allResults;
    }

    public verifyExclusiveRadioButtonChecked(): Promise<boolean> {
        return isAriaChecked(this.exclusiveRadioButton);
    }

    public selectOptionFromAgencySubtypeDropdown(subType: string): void {
        let agencySubtypeDropdown = $('md-select[ng-model="vm.subtypeId.Value"]');
        let dropdownOption = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(subType)
            ]
        )().first();
        clickElement(agencySubtypeDropdown);
        clickElement(dropdownOption);
    }

    public updateFirstName(firstname: string): void {
        let firstNameInputContainer = $('input[ng-model="vm.firstName"]');
        firstNameInputContainer.clear();
        firstNameInputContainer.sendKeys(firstname);
    }

    public updateLastName(lastname: string): void {
        let lastNameInputContainer = $('input[ng-model="vm.lastName"]');
        lastNameInputContainer.clear();
        lastNameInputContainer.sendKeys(lastname)
    }

    public updateSuffix(suffix: string): void {
        let suffixDropdown = $('md-select[ng-model="vm.suffix.Value"]');
        let dropdownOption = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(suffix)
            ]
        )().first();
        clickElement(suffixDropdown);
        clickElement(dropdownOption);
    }


    public updateCountry(country:string): void {
        let coumtryDropdown = $('md-select[ng-model="vm.countryId"]');
        let dropdownOption = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(country)
            ]
        )().first();
        clickElement(coumtryDropdown);
        clickElement(dropdownOption);
    }

    public updateAgencySubtypeToReplacement(): void {
        let agencySubtypeDropdown = $('md-select[ng-model="vm.subtypeId.Value"]');
        let replacementOption = $('md-option[value="2"]');
    }

    public selectCheckbox(chkbox: string): void {
        let checkbox = filterElements(
            $$('md-checkbox'),
            [
                isActive(true),
                containingText(chkbox)
            ]
        )().first();
        clickElement(checkbox);
    }

    public selectNonExclusiveRadioButton(): void {
        let nonExclusiveRadioButton = $$('md-radio-button[ng-model="vm.isExclusive"]').get(1);
        clickElement(nonExclusiveRadioButton);
    }

    public selectExclusiveRadioButton(): void {
        clickElement(this.exclusiveRadioButton);
    }

    public verifyReportsToInputContainerByEnteringValue(num:string): void {
        this.reportToInputContainer.sendKeys(num);
        let agencyToBeReported = filterElements(
            $$('li[md-virtual-repeat="item in $mdAutocompleteCtrl.matches"]'),
            [
                isActive(true),
            ]
        )().first();
        clickElement(agencyToBeReported);
        this.clearReportsToContainer();
    }

    private getCheckbox(chkbox: string): ElementFinder {
        return filterElements(
            $$('md-checkbox'),
            [
                isActive(true),
                containingText(chkbox)
            ]
        )().first();
    }

    public isCheckboxChecked(chkbox: string): Promise<boolean> {
        return isAriaChecked(this.getCheckbox(chkbox));
    }

    public isCheckboxDisabled(chkbox: string): Promise<boolean> {
        return isAriaDisabled(this.getCheckbox(chkbox));
    }

}