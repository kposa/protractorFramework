/// <reference path="../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import Promise = webdriver.promise.Promise;
import {Element} from '../../shared/Element';
import {MaterialDesignElement} from "../../shared/MaterialDesignElement";
import {Helpers} from "../../shared/Helpers";
import {clickElement} from "../../../modules_v3/helpers/clickElementHelpers";
import {filterElements, isActive, matchingText, containingText} from "../../../modules_v3/helpers/filterElementHelpers";

let e = new Element();
let md = new MaterialDesignElement();
let hlp = new Helpers();

export class EPaymentSS {

    private paymentLineInputLocator = 'input[ng-model="paymentLine.amount"]';
    private paymentSectionParent = $('div.list');

    public enterPaymentAmount(acctDescName:string, amount:number):void {
        let paymentAmountInput = this.getPaymentInputBox(acctDescName);
        this.expandAnySalesPeriodLists();
        clickElement(paymentAmountInput);
        paymentAmountInput.clear();
        paymentAmountInput.sendKeys(amount.toString());
        this.focusOutOfAllFields();
    }

    //return: Wednesday May 11 2016
    public selectedDatepickerDate(acctDescName:string):Promise<string> {
        this.openCalendar(acctDescName);
        let datePickerSelectedDate = this.getDisplayedDatePickerCalendar().$('td.md-calendar-selected-date').getAttribute('aria-label');
        this.closeCalendar();
        return datePickerSelectedDate;
    }

    public clickContinue():void {
        let continueButton = $('button[ng-click="vm.continue()"]');
        clickElement(continueButton);
    }

    public clickPayAllSlider():void {
        let payAllSlider = $('md-switch[ng-click="vm.payAll()"]').$('div.md-thumb');
        clickElement(payAllSlider);
    }

    public sumAllPaymentAmounts():Promise<string> {
        let sumOfAllBalances = 0;
        return browser.controlFlow().execute(() => {
            let allPaymentAmountInputs = $$(this.paymentLineInputLocator);
            allPaymentAmountInputs.each((paymentAmountInput) => {
                return paymentAmountInput.getAttribute('value').then((amt) => {
                    amt = hlp.removeEverythingButNumbersAndDecimals(amt);
                    if (amt) sumOfAllBalances += parseFloat(amt);
                });
            })
        }).then(() => {
            return sumOfAllBalances.toFixed(2);
        });
    }

    public verifyAFutureDateCanBeSelected(acctDescName:string):void {
        let self = this;
        this.openCalendar(acctDescName);
        let initiallySelectedDate = this.getDisplayedDatePickerCalendar().$('td.md-calendar-selected-date');
        initiallySelectedDate.getAttribute('aria-label').then(function (aria_label) {
            let nearestParentTBody = initiallySelectedDate.element(by.xpath('ancestor::tbody[contains(@class, "md-calendar-month")][1]'));
            let nextTBody = nearestParentTBody.element(by.xpath('following-sibling::tbody[1]'));
            let firstDayOfNextMonth = nextTBody.$$('span.md-calendar-date-selection-indicator').get(0);
            clickElement(firstDayOfNextMonth);

            self.openCalendar(acctDescName);
            initiallySelectedDate = self.getDisplayedDatePickerCalendar().$('td[aria-label="' + aria_label + '"]');
            clickElement(initiallySelectedDate);
        });
    }

    private getDisplayedDatePickerCalendar() {
        return e.getDisplayedElement($$('div.md-datepicker-calendar'));
    }

    private closeCalendar():void {
        let calendarLayover = $('div.md-scroll-mask');
        clickElement(calendarLayover);
    }

    private openCalendar(acctDescName:string):void {
        let expandIcon = this.getPaymentLine(acctDescName).$$('button[ng-click="ctrl.openCalendarPane($event)"]').get(0);
        clickElement(expandIcon);
    }

    private getPaymentInputBox(acctDescName:string):ElementFinder {
        return this.getPaymentLine(acctDescName).$(this.paymentLineInputLocator);
    }

    //this locator needs .ng-scope to tell the difference between the header listitem vs the real listitems
    private getPaymentLine(acctDescName:string):ElementFinder {
        let allPaymentLines = this.paymentSectionParent.$$('div.listitem.ng-scope');
        return filterElements(allPaymentLines, [
            isActive(true),
            containingText(acctDescName)
        ])().first();
    }

    private focusOutOfAllFields():void {
        let headerbar = $('div.header-bar');
        clickElement(headerbar);
    }

    private expandAnySalesPeriodLists():void {
        let allExpandDownCaretIcons = filterElements(this.paymentSectionParent.$$('i.material-icons'), [
            isActive(true),
            matchingText('expand_more')
        ])();

        allExpandDownCaretIcons.each(function (elem) {
            clickElement(elem);
        });
    }
}