/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;
import { IBalancesReportFullView } from "../../interfaces/fullViews/IBalancesReportFullView";
import { IView } from '../../interfaces/common/IView';
import { clickElement } from '../../helpers/clickElementHelpers';
import { NotImplementedError } from '../../../common/exception/exceptions';
import Promise = protractor.promise.Promise;
import {
    getNegativeOrPositiveCurrencyString,
    getBalanceReportsRow
} from "../../helpers/utilityHelpers";

export default class SalesRepBalancesReportFullView implements IView, IBalancesReportFullView {
    private tableThatContainsHeaders = $('table.clone');

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    public isOperationHeaderDisplayed ():Promise<boolean> {
        let operationHeader = this.tableThatContainsHeaders.$('th[md-order-by="operationName"]');
        return operationHeader.isDisplayed();
    }

    public isAccountDescHeaderDisplayed ():Promise<boolean> {
        let accountDescHeader = this.tableThatContainsHeaders.$('th[md-order-by="accountDescription"]');
        return accountDescHeader.isDisplayed();
    }

    public isBusinessPartnerHeaderDisplayed ():Promise<boolean> {
        let businessPartnerHeader = this.tableThatContainsHeaders.$('th[md-order-by="businessPartnerName"]');
        return businessPartnerHeader.isDisplayed();
    }

    public isSalesPeriodHeaderDisplayed ():Promise<boolean> {
        let salesPeriodHeader = this.tableThatContainsHeaders.$('span[at="sales-period"]');
        return salesPeriodHeader.isDisplayed();
    }

    public isNetInvoiceHeaderDisplayed ():Promise<boolean> {
        let netInvoiceHeader = this.tableThatContainsHeaders.$('span[at="net-invoice-value"]');
        return netInvoiceHeader.isDisplayed();
    }

    public isNetPaymentsHeaderDisplayed ():Promise<boolean> {
        let netPaymentsHeader = this.tableThatContainsHeaders.$('span[at="net-payments"]');
        return netPaymentsHeader.isDisplayed();
    }

    public isNetPendingPaymentsHeaderDisplayed ():Promise<boolean> {
        let netPendingPaymentsHeader = this.tableThatContainsHeaders.$('span[at="net-pending-payments"]');
        return netPendingPaymentsHeader.isDisplayed();
    }

    public isPioneerBalanceHeaderDisplayed ():Promise<boolean> {
        let pioneerBalanceHeader = this.tableThatContainsHeaders.$('span[at="pioneer-balance"]');
        return pioneerBalanceHeader.isDisplayed();
    }

    public isDPBalanceHeaderDisplayed ():Promise<boolean> {
        let dpBalanceHeader = this.tableThatContainsHeaders.$('span[at="dp-balance"]');
        return dpBalanceHeader.isDisplayed();
    }

    public netInvoiceValueDisplayed (operation:string, invoice:string, businessPartner:string, salesPeriodYear:string, salesPeriodSeason:string):Promise<string> {
        let salesPeriod = salesPeriodYear + salesPeriodSeason.substring(0, 1);
        return getBalanceReportsRow(operation, invoice, businessPartner, salesPeriod).$('td[at="net-invoice-value"]').getText().then((price) => {
            return getNegativeOrPositiveCurrencyString(price);
        });
    }

    public netPaymentsDisplayed (operation:string, invoice:string, businessPartner:string, salesPeriodYear:string, salesPeriodSeason:string):Promise<string> {
        let salesPeriod = salesPeriodYear + salesPeriodSeason.substring(0, 1);
        return getBalanceReportsRow(operation, invoice, businessPartner, salesPeriod).$('td[at="net-payments"]').getText().then((price) => {
            return getNegativeOrPositiveCurrencyString(price);
        });
    }

    public netPendingPaymentsDisplayed (operation:string, invoice:string, businessPartner:string, salesPeriodYear:string, salesPeriodSeason:string):Promise<string> {
        let salesPeriod = salesPeriodYear + salesPeriodSeason.substring(0, 1);
        return getBalanceReportsRow(operation, invoice, businessPartner, salesPeriod).$('td[at="net-pending-payments"]').getText().then((price) => {
            return getNegativeOrPositiveCurrencyString(price);
        });
    }

    public pioneerBalanceDisplayed (operation:string, invoice:string, businessPartner:string, salesPeriodYear:string, salesPeriodSeason:string):Promise<string> {
        let salesPeriod = salesPeriodYear + salesPeriodSeason.substring(0, 1);
        return getBalanceReportsRow(operation, invoice, businessPartner, salesPeriod).$('td[at="pioneer-balance"]').getText().then((price) => {
            return getNegativeOrPositiveCurrencyString(price);
        });
    }

    public clickFilterIcon ():void {
        let filterIcon = $('balances-report-filter').$('button');
        clickElement(filterIcon);
    }

    public areAllPioneerBalancesNonZero ():Promise<boolean> {
        let pioneerBalances = $$('div.pioneer-balance-column');
        let nonZeroes:boolean = true;
        return browser.controlFlow().execute(() => {
            pioneerBalances.each((elem) => {
                elem.getText().then((displayedText) => {
                    if (displayedText == "$0.00") {
                        nonZeroes = false;
                    }
                });
            });
        }).then(() => {
            return nonZeroes;
        });
    }
}
