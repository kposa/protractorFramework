# [Connex E2E Documentation](/)

## Configuration

Configuration is a combination of local config files and command line arguments compiled by [`ConfigService`](/services/ConfigService.html) and exposed as [environmental variables](/envVars.html)

### Environmental Variables

All config data is injected in to `process.env` as environmental variables prefixed with the string `E2E`. This happens in `./protractor.config.ts` as part of initialization. This should be the preferred method of accessing config data (vs. the `ConfigService` directly).

### Local vs Octopus

See [Local](/local.html)

### Grid vs Not

See [Grid#Configuration](/grid.html#configuration)

### Protractor

All protractor related configuration is located in `./protractor.config.ts`