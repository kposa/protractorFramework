/// <reference path="../../typings/index.d.ts" />

import LoginFullView from "../../modules_v3/views/shared/LoginFullView";
import SalesSupportNavigationMenuPartialView from "../../modules_v3/views/salesSupport/SalesSupportNavigationMenuPartialView";
import SalesRepNavigationMenuPartialView from "../../modules_v3/views/salesRep/SalesRepNavigationMenuPartialView";
import FeatureFlagsFullView from "../../modules_v3/views/shared/FeatureFlagsFullView";
import ImpersonationFullView from "../../modules_v3/views/shared/ImpersonationFullView";
import { User } from "../../modules_v3/testdata/User";
import { randomNumberInRange } from '../../modules_v3/helpers/utilityHelpers';

const loginFullView = new LoginFullView();
const salesSupportNavigationMenuPartialView = new SalesSupportNavigationMenuPartialView();
const salesRepNavigationMenuPartialView = new SalesRepNavigationMenuPartialView();
const featureFlagsFullView = new FeatureFlagsFullView();
const impersonationFullView = new ImpersonationFullView();

export function loadConnex ():void {
    browser.get(process.env.E2EBaseUrl).then(() => {
        console.log(`
Loading Connex...
${process.env.E2EBaseUrl}
        `);
    });
}

export function login ():void {
    loginFullView.login(process.env.E2EUsername, process.env.E2EPassword);
}

export function resetFeatureFlags ():void {
    let menuItemString:string;

    switch (process.env.E2ELocale) {
        case 'en-us':
            menuItemString = 'Feature flags';
            break;
        case 'fr-ca':
            menuItemString = 'Marqueurs de fonctionnalité';
    }

    salesSupportNavigationMenuPartialView.openMenu();
    salesSupportNavigationMenuPartialView.selectMenuItemContainingText(menuItemString);
    featureFlagsFullView.resetAllFlags();
}

export function impersonate (user:User):void {
    let menuItemString:string;

    switch (process.env.E2ELocale) {
        case 'en-us':
            menuItemString = 'impersonate';
            break;
        case 'fr-ca':
            menuItemString = 'Usurpation d’identité';
    }

    salesRepNavigationMenuPartialView.openMenu();
    salesRepNavigationMenuPartialView.selectMenuItemMatchingText(menuItemString);
    impersonationFullView.search(user.name);
    impersonationFullView.clickSearchResultContainingText(user.id);
}

export function bootstrap (user:User) {
    loadConnex();
    login();
    randomWaitTime();
    resetFeatureFlags();
    impersonate(user);
}

//avoid the violate primary key oops failures on grid
function randomWaitTime () {
    if (process.env.E2EGridIsEnabled) {
        browser.sleep(randomNumberInRange(1, 12000));
    }
}