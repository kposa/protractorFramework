/// <reference path='../../../typings/index.d.ts' />
import ElementFinder = protractor.ElementFinder;

import { IBalancesReportFilterDrawerPartialView } from "../../interfaces/partialViews/IBalancesReportFilterDrawerPartialView";
import Promise = protractor.promise.Promise;
import { clickElement } from '../../helpers/clickElementHelpers';
import {
    filterElements,
    isActive,
    containingText
} from '../../helpers/filterElementHelpers';
import { IView } from '../../interfaces/common/IView';
import { NotImplementedError } from '../../../common/exception/Exceptions';

export default class SalesRepBalancesReportFilterDrawerPartialView implements IView, IBalancesReportFilterDrawerPartialView {

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }
    
    clickSalesPeriodDropDown ():void {
        let salesPeriod = $('md-select[aria-label="Sales period"]');
        clickElement(salesPeriod);
    }

    clickApply ():void {
        let applyButton = $('button[ng-click="vm.applyFilters()"]').$('span');
        clickElement(applyButton);

    }

    clickDropBack ():void {
        let backDrop = $('md-backdrop.md-select-backdrop');
        clickElement(backDrop);
    }

    selectSalesPeriodFromDropDown (salesPeriodYear:string, salesPeriodSeason:string):void {
        let salesPeriod = salesPeriodYear + salesPeriodSeason.substring(0, 1);
        let salesPeriodRecord = filterElements(
            $$('md-option[ng-repeat="option in vm.options"]'),
            [
                isActive(true),
                containingText(salesPeriod),
            ]
        )().first();
        clickElement(salesPeriodRecord);
    }
}