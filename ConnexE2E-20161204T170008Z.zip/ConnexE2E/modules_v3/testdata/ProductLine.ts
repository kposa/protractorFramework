import {Entity} from "./Entity";
export interface ProductLine extends Entity {

}