/// <reference path="../../../../typings/index.d.ts" />

import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import { existingData } from '../../../../modules_v3/testdata/sharedQueries/existingData/index';

export class TestData359289 extends BaseTestData {

    public dryLandAcresValue:number = 10;
    public irrigatedAcresValue:number = 20;
    public totalAcres:number = this.dryLandAcresValue + this.irrigatedAcresValue;

    protected queries:(() => Promise<any>)[] = [
        existingData(this.queryService, this)
    ];
}