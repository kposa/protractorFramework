/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;

export class AgreementsAddCommentMD {

   public verifyCommentContainerMaximumCharacterLength(): Promise<string> {
       return $('textarea[name="comment"]').getAttribute('maxlength');
   }

}