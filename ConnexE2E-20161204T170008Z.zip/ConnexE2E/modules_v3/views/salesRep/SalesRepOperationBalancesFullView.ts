/// <reference path='../../../typings/index.d.ts' />
import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;

import {IOperationBalancesFullView} from '../../interfaces/fullViews/IOperationBalancesFullView';

import { filterElements, isActive, matchingText } from '../../helpers/filterElementHelpers';
import { parseCurrencyString } from '../../helpers/utilityHelpers';
import { NotImplementedError } from '../../../common/exception/exceptions';
import Promise = protractor.promise.Promise;
import { IView } from '../../interfaces/common/IView';

export default class SalesRepOperationBalancesFullView implements IView, IOperationBalancesFullView {
    private element:ElementFinder = $('section.field-balances');
    private balances:ElementArrayFinder = this.element.$$(`li.line-item`);

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    clickInvoiceByNameAndSalesPeriod(invoiceName:string, salesperiodName:string):void {
        throw new NotImplementedError();
    }

    public getInvoiceByNameAndSalesPeriod(invoiceName:string, salesperiodName:string):protractor.ElementFinder {
        return filterElements(this.balances, [
            isActive(true),
            matchingText(invoiceName, e => e.$(`div.account-description`)),
            matchingText(salesperiodName, e => e.$(`div.sales-period`))
        ])().first();
    }

    public getBalanceForInvoiceByInvoiceNameAndSalesPeriod(invoiceName:string, salesperiodName:string):webdriver.promise.Promise<number> {
        const invoice = this.getInvoiceByNameAndSalesPeriod(invoiceName, salesperiodName);
        const balance = invoice.$('div.balance-amount');
        return balance.getText().then(text => {
            return Math.floor(Math.abs(parseCurrencyString(text)));
        });
    }
}
