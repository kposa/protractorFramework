/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';
import ElementArrayFinder = protractor.ElementArrayFinder;

export class ProfileMittMD {

    private mittCardContent = $('div.layout-margin.flex');
    private addScannerButton = $('button[aria-label="Add Agency MITT Scanner"]');
    private allTrashCans:ElementArrayFinder = $$('button[aria-label="delete"]');

    private clickFirstTrashCan(): void {
        clickElement(this.allTrashCans.get(0));
    }

    public addAgencyScanner(): void {
        clickElement(this.addScannerButton);
    }

    public enterSerialNumber(serialNumber: string): void {
        let serialNumberContainer = $('input[name="serialNumber"]');
        serialNumberContainer.sendKeys(serialNumber)
    }

    public selectTodaysDateFromDatePicker(): void {
        let datePickerButton = $('button.md-datepicker-triangle-button');
        let todaysDate = $('td.md-calendar-date.md-calendar-date-today');
        clickElement(datePickerButton);
        clickElement(todaysDate);
    }

    public verifyRequiredDisplays(): Promise<string> {
        return this.mittCardContent.getText();
    }

    public removeAllAgencyScanners(): void {
        this.clickFirstTrashCan();
        this.allTrashCans.count().then((cnt) => {
            if(cnt > 0) this.removeAllAgencyScanners();
        })
    }
}