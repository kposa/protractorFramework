/// <reference path='../../../typings/index.d.ts' />
import Promise = protractor.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;

import {IOperationBalancesFullView} from '../../interfaces/fullViews/IOperationBalancesFullView';

import { filterElements, isActive, containingText } from '../../helpers/filterElementHelpers';
import { parseCurrencyString } from '../../helpers/utilityHelpers';
import {clickElement} from "../../helpers/clickElementHelpers";
import { IView } from '../../interfaces/common/IView';
import { NotImplementedError } from '../../../common/exception/exceptions';

export default class SalesSupportOperationBalancesFullView implements IView, IOperationBalancesFullView {
    private element = $(`section.sales-support-balances`);
    private balances = $$(`div[ng-repeat*="item in vm.paymentLineItems | orderBy:['-isCurrentSalesPeriod',"]`);

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    public getInvoiceByNameAndSalesPeriod(invoiceName:string, salesperiodName:string):ElementFinder {
        return filterElements(this.balances, [
            isActive(true),
            containingText(invoiceName),
            containingText(salesperiodName)
        ])().first();
    }

    getBalanceForInvoiceByInvoiceNameAndSalesPeriod(invoiceName:string, salesperiodName:string):Promise<number> {
        const invoice = this.getInvoiceByNameAndSalesPeriod(invoiceName, salesperiodName);
        const balance = invoice.$('div.balance-amount');
        return balance.getText().then(text => {
            return Math.floor(Math.abs(parseCurrencyString(text)));
        });
    }

    clickInvoiceByNameAndSalesPeriod(invoiceName:string, salesperiodName:string):void {
        clickElement(this.getInvoiceByNameAndSalesPeriod(invoiceName, salesperiodName).$(`i[ng-click="vm.goToActivityStatement(item)"]`));
    }
}
