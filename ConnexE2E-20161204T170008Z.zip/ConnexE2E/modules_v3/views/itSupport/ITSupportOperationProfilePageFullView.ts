/// <reference path='../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import { NotImplementedError } from '../../../common/exception/Exceptions';
import { IView } from '../../interfaces/common/IView';

export class ITSupportOperationProfilePageFullView implements IView {

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    textOnOperationProfileHeader () {
        return $('div.pm-title').getText();
    }
}