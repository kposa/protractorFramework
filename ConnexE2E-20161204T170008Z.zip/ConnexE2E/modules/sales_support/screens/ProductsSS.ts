/// <reference path="../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import {Element} from '../../shared/Element';
import {ActionButtonSS} from "../shared/ActionButtonSS";
import all = protractor.promise.all;

let e = new Element();
let actionButton = new ActionButtonSS();

export class ProductsSS {
    
    public clickAddLineItemButton():void {
        actionButton.clickFloatingActionBtn();
    }

    //right now this just selects the first one
    public selectDetailLine() {
        let allDetailLines = $('section.salessupport-products').$$('li.listitem');
        e.clickElement(allDetailLines.get(0));
    }
}