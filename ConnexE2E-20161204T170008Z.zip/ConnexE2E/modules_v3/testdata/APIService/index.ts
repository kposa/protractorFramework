/*
/// <reference path="../../../typings/index.d.ts" />

import Promise = protractor.promise.Promise;
import request = require("request");
import qs = require("qs");
import {isUndefined} from "../../helpers/UtilityHelpers";
import {AccountDescriptionPayload} from "../../../testdata/api/payloads/AccountDescriptionPayload";

/!**
 * The API service is responsible for making API calls to the Connex API
 *!/
export default class APIService {

    private cookiejar: any;

    private authCookieHasNotBeenSet():boolean {
        return isUndefined(this.cookiejar);
    }

    public request(options:DefaultOptions):Promise<any> {
        if (this.authCookieHasNotBeenSet) {
            return this.setAuthCookie().then(() => {
                let j = this.cookiejar;
                return this.requestWrapper(options);
            });
        } else
            return this.requestWrapper(options);
    }

    public requestWrapper(options:DefaultOptions):Promise<any> {
        let defer = protractor.promise.defer();

        if (!this.cookiejar) this.cookiejar = request.jar();
        options.jar = this.cookiejar;

        request(options, function (error, response, body) {
            this.cookiejar = this['_jar'];
            if (error) defer.reject(error);
            else defer.fulfill(body);
        });
        return defer.promise;
    }

    public setAuthCookie():Promise<any> {
        let options = new DefaultOptions();
        options.url = 'account/processlogin';
        options.headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
        options.body = qs.stringify(browser.params.login);
        return this.requestWrapper(options);
    }

    public getInvoiceDetails(invoiceId:string):Promise<any> {
        let options = new DefaultOptions();
        options.url = 'api/invoice/v2';
        options.qs = {invoice: invoiceId};
        options.method = 'GET';
        return this.request(options);
    }

    public createAccountDescription (payload:AccountDescriptionPayload):Promise<any> {
        let options = new DefaultOptions();
        options.url = 'api/account/v2';
        options.qs = payload;
        return this.request(options);
    }

}

class DefaultOptions {
    public baseUrl = browser.params.baseUrl;
    public proxy = 'http://jhproxy1.phibred.com:8080';
    public json = true;
    public method = 'POST';
    public headers = {};
    public jar;
    public url;
    public body;
    public qs;
}*/
