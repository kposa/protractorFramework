moment = require('moment');

var fs = require('fs')
    , TRX = require('node-trx')
    , TestRun = TRX.TestRun
    , UnitTest = TRX.UnitTest
    , computerName = 'testname'
    , user = 'testuser'
    , run;

run = new TestRun({
    name: 'Sample TRX Import',
    runUser: user,
    times: {
        creation: '2015-08-10T00:00:00.000Z',
        queuing: '2015-08-10T00:00:00.000Z',
        start: '2015-08-10T00:00:00.000Z',
        finish: '2015-08-10T00:00:01.500Z'
    }
});

files = fs.readdirSync('./results').filter(function (e){
    return e.endsWith('json')
});

totalfiles = files.length;

for (var i = 0; i < totalfiles; i++){
    var file = JSON.parse(fs.readFileSync("./results/" + files.pop()).toString());
    var keepNegative = (i == 0);

    file.forEach(function(cur, i, arr){
        status = cur.status.charAt(0).toUpperCase() + cur.status.slice(1);
        if (cur.status != 'failed' || keepNegative){
            run.addResult({
                test: new UnitTest({
                    name: cur.testCaseDescription,
                    methodName: cur.testCaseId,
                    methodCodeBase: 'testing-framework',
                    methodClassName: cur.testCaseId,
                    description: ''
                }),
                computerName: computerName,
                outcome: status,
                output: cur.testCaseId,
                errorMessage: cur.failureMessage || cur.pendingReason,
                duration: moment("2015-01-01").startOf('day')
                    .seconds(parseInt(cur.duration))
                    .format('H:mm:ss'),
                errorStacktrace: cur.failureStackTrace
            })
        }
    });
}

fs.writeFileSync('./results/example.trx', run.toXml());