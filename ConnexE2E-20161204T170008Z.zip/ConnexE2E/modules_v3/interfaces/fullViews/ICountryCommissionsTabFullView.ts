/// <reference path="../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;

import {ITabbableView} from '../common/ITabbableView';
import {IListableView} from '../common/IListableView';

export interface ICountryCommissionsTabFullView extends IListableView {
    hasGivenYearCommission(givenYear: number):Promise<boolean>;
    clickGivenYearCommission(givenYear: number):void;
}