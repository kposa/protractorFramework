export interface Product {
    line?:string;
    name?: string;
    subName?: string;
    units?: number;
    price?: number;
}