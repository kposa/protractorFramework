/// <reference path="../../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import Promise = webdriver.promise.Promise;

export class UnitsEntryDrawer {
    private element:ElementFinder = $('section[at="units-drawer"]');
    private unitsCalculatorButton:ElementFinder = this.element.$('i.fa.fa-calculator');
    private closeButton:ElementFinder = this.element.$('i.fa.fa-chevron-right');

    public isDisplayed():Promise<boolean> {
        return this.element.isDisplayed();
    }

    public clickUnitsCalculatorButton():void {
        this.unitsCalculatorButton.click();
    }

    public close():void {
        this.closeButton.click();
    }
}