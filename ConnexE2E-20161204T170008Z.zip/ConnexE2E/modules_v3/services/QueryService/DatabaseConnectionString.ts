export default class DatabaseConnectionString {
    constructor(
        public database: string,
        public server: string = 'JHTRSQ01,1600',
        public userId: string = 'ConnexAutoTest',
        public password: string = 'MbWq77X35hSrwYxN',
        public multipleActiveResultSets: boolean = true,
        public async: boolean = true,
        public timeout: number = 15000
    ) {}

    public toString ():string {
        return [
            `Server=${this.server}`,
            `Database=${this.database}`,
            `User Id=${this.userId}`,
            `Password=${this.password}`,
            `MultipleActiveResultSets=${this.multipleActiveResultSets}`,
            `Async=${this.async}`,
            `Connection Timeout=${this.timeout}`
        ].join(`;`);
    }
}