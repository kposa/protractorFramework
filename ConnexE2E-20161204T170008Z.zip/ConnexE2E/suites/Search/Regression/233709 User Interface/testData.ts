/// <reference path="../../../../typings/index.d.ts" />

import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';

export default class TestData233709 extends BaseTestData {

    public text:string = 'Sky';
    public operationName:string = 'Prairie Sky Game Ranch & Guest Lodge LLC';
}