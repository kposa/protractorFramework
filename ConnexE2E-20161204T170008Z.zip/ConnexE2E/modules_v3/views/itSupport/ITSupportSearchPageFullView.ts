/// <reference path='../../../typings/index.d.ts' />
import ElementFinder = protractor.ElementFinder;
import { IView } from '../../interfaces/common/IView';
import Promise = protractor.promise.Promise;
import { clickElement } from '../../helpers/clickElementHelpers';
import { filterElements, containingText, isActive } from '../../helpers/filterElementHelpers';
import ElementArrayFinder = protractor.ElementArrayFinder;

export default class ITSupportSearchPageFullView implements IView {

    private searchInput:ElementFinder = $(`input[data-ng-model='criteria']`);
    private searchResults:ElementArrayFinder = $$(`div[ng-repeat="item in vm.itemList"]`);

    isViewDisplayed ():Promise<boolean> {
        return $('section.support-operation').isDisplayed();
    }

    clickSearchBarHamburger ():void {
        let searchBarHamburger = $('i[ng-click="drawerVM.toggleDrawerPosition()"]');
        clickElement(searchBarHamburger);
    }

    search (text:string):void {
        this.openSearch();
        this.inputSearch(text);
        this.submitSearch();
    }

    openSearch ():void {
        clickElement(this.searchInput);
    }

    inputSearch (text:string):void {
        clickElement(this.searchInput);
        this.searchInput.clear();
        this.searchInput.sendKeys(text);
    }

    submitSearch ():void {
        clickElement(this.searchInput);
        this.searchInput.sendKeys(protractor.Key.ENTER);
    }

    clickSearchResultContainingText (text:string):void {
        clickElement(filterElements(this.searchResults, [ isActive(true), containingText(text) ])().first());
    }
}