/// <reference path="../../../../typings/index.d.ts" />

import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { TestData405058 } from './testData';
import { itw } from '../../../../modules_v3/helpers/itw';
import MasterDataMasterSearchFullView from '../../../../modules_v3/views/masterData/MasterDataMasterSearchFullView';
import { MasterDataCustomerFullView } from '../../../../modules_v3/views/masterData/MasterDataCustomerFullView';
import { MasterDataOperationManagementFullView } from '../../../../modules_v3/views/masterData/MasterDataOperationManagementFullView';
import { MasterDataOperationManagementCommunicationsFullView } from '../../../../modules_v3/views/masterData/MasterDataOperationManagementCommunicationsFullView';

const test = new TestCase(
    '405058',
    'Master Data users have the write access to turn off communication',
    UserRole.MASTER_DATA,
    ApplicationFeature.OPERATION_MANAGEMENT
);

describe(test.stringify, () => {
    const td = new TestData405058();
    let search = new MasterDataMasterSearchFullView();
    let bp = new MasterDataCustomerFullView();
    let opManagement = new MasterDataOperationManagementFullView();
    let commPref = new MasterDataOperationManagementCommunicationsFullView();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            bootstrap(td.masterDataUser);

            //select Business partner radio button
            search.selectFilterContainingText('Business partners');

            //click on the first result
            search.clickSearchResultContainingText('Business partner');

            //click on the customers first operation
            bp.selectFirstOperation();

            //click on the first individual BP card on the operation management page
            opManagement.clickFirstIndividualBPCard();

            //click on the communications Tab of the opened card
            opManagement.clickIndividualBpCardsTab('Communications');

            //Accept the communications-opt-in if the accept button is displayed
            commPref.clickAcceptIfDisplayed();

            //Verify that the two communication modes are Postal mail and Email
            commPref.documentsCommunicationModes().then((modesDisplayed) => {
                expect(modesDisplayed[ 0 ]).toContain('Postal mail');
                expect(modesDisplayed[ 1 ]).toEqual('Email');
            });

            //verify that the user can turn the 'send required documents via' switch On and OFF.
            commPref.isSendReqDocsViaButtonOn().then(buttonOn=> {          // verifying if the button is OFF or ON as soon as you are on the page
                if (buttonOn == true) {
                    commPref.clickSendReqDocViaButton();
                    expect(commPref.isSendReqDocsViaButtonOn()).toBeFalsy();
                }
                else {
                    commPref.clickSendReqDocViaButton();
                    expect(commPref.isSendReqDocsViaButtonOn()).toBeTruthy();
                }
            });
        }, fail);
    });
});