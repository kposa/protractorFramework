/// <reference path="../../typings/index.d.ts" />

export interface Entity {
    id:string;
    name:string;
}