/// <reference path="../../../../typings/index.d.ts" />

import {AgreementsMD} from "../../../../modules/master_data/screens/AgreementsMD";
import {NavigationsMD} from "../../../../modules/master_data/navigations/NavigationsMD";
import {SearchMD2} from "../../../../modules/master_data/screens/SearchMD2";
import TestData304264 from './testData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';
import MasterDataMasterSearchFullView from '../../../../modules_v3/views/masterData/MasterDataMasterSearchFullView';

const test = new TestCase(
	'304264',
	'Verify Master Data User can sign and refuse to sign an Agreement',
	UserRole.MASTER_DATA,
	ApplicationFeature.AGREEMENTS
);

describe(test.stringify, () => {
    const td = new TestData304264();
    let agr = new AgreementsMD();
    let nav = new NavigationsMD();
    let mds = new SearchMD2();  //fixme should be using the shared search file here

    itw(test.description, () => {
        // bootstrap (load, login, reset feature flags, impersonate)
        bootstrap(td.masterDataUser);

        // should select business partners option
        mds.clickCategory('Business partners');

        // should select a business partner
        mds.selectBusinessPartnerCard(td.businessPartner.name);   //TODO just change the business partner to target a guy who has unsigned agreements

        // should select [agreements] from the hamburger menu
        nav.selectItemFromHamburgerMenu('Agreements');

        // should select select an agreement and [sign] it
        agr.selectAgreement();
        agr.agreementTo('SIGN');

        // should select select an agreement and [refuse to sign] it
        agr.selectAgreement();
        agr.agreementTo('REFUSED TO SIGN');

        // should navigate to [business partner] from the hamburger
        nav.selectItemFromHamburgerMenu('Business partner');

        // should navigate to [Payment Summary] from the hamburger
        nav.selectItemFromHamburgerMenu('Payment Summary');
    }, 'Old test, needs to be looked into / modified / re-written');
});