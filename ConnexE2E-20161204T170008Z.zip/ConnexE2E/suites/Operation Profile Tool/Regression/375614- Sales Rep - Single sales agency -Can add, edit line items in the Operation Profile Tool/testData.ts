/// <reference path="../../../../typings/index.d.ts" />

import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';
import { salesRepsWithASingleAgency, salesRepsWithASingleAgencyResults } from './queries';

export class TestData375614 extends BaseTestData {

    protected queries:(() => Promise<any>)[] = [
        this.getSalesRepsWithASingleAgency()
    ];

    private getSalesRepsWithASingleAgency ():() => Promise<salesRepsWithASingleAgencyResults> {
        return () => {
            const sql = salesRepsWithASingleAgency();
            const results = this.queryService.executeSql<salesRepsWithASingleAgencyResults[]>(sql);

            return results
                .then(data => {
                    const row = <salesRepsWithASingleAgencyResults>getRandomQueryResult(data);

                    this.salesRepresentatives.push({
                        id: row.salesRepId,
                        name: row.salesRepName
                    });
                    this.salesAgencies.push({
                        id: row.salesAgencyId,
                        name: row.salesAgencyName
                    });
                    return row;
                });
        };
    }
}