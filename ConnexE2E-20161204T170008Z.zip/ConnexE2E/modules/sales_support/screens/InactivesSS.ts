/// <reference path="../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import Promise = webdriver.promise.Promise;
import {Element} from '../../shared/Element';

let e = new Element();

export class InactivesSS {

    get isInactiveAccountDisplayed():Promise<boolean> {
        var allInactiveAccountCards = $$('div.pm-paper');
        return e.isAtLeast1Displayed(allInactiveAccountCards);
    }
}