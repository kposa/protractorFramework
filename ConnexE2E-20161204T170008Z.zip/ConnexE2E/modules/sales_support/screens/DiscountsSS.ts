/// <reference path="../../../typings/index.d.ts" />
import ElementFinder = protractor.ElementFinder;
import Promise = webdriver.promise.Promise;

import {textContainsText} from "../../../modules_v3/helpers/utilityHelpers";

export class DiscountsSS {
    private discountsSSParent = $('div.pm-scrollable-content');

    get cpaTypeText():Promise<string> {
        return $('li[ng-click="cpavm.edit(election)"]').$('div.pm-listitem-primary').getText();
    }
    
    public isGrowthDiscountDisplayed(discountName: string):Promise<boolean> {
        return this.discountsSSParent
            .getText()
            .then(text => {
                return textContainsText(text, discountName);
            });
    }

}
