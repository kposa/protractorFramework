/// <reference path="../../../../typings/index.d.ts" />
import Promise = protractor.promise.Promise;

import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import { orgUnitResults, pvcRowRemoval, orgUnitFinder } from './queries';
import { getRandomNumberAsString } from '../../../../modules_v3/helpers/utilityHelpers';
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';

export class TestData364767 extends BaseTestData {
    /** Value used to full inputs in PVC form */
    public randomAreaVal = getRandomNumberAsString();
    public randomParent = getRandomNumberAsString();
    public randomSalesAgencyVal = getRandomNumberAsString();

    public randArea:string;
    public randSalesAgencyId:string;
    public randTerritory:string;

    protected queries: (() => Promise<any>)[] = [
        this.findOrgUnits(),
        this.removeDesignatedPVCRows()
    ];

    private findOrgUnits ():() => Promise<orgUnitResults> {
        return () => {
            const sql = orgUnitFinder(this.salesPeriod.id);
            const results = this.queryService.executeSql<orgUnitResults[]>(sql);

            return results.then(data => {
                const row = <orgUnitResults>getRandomQueryResult(data);

                this.randSalesAgencyId = row.salesAgencyId;
                this.randTerritory = row.territory;
                this.randArea = row.area;

                return row;
            });
        };
    }

    private removeDesignatedPVCRows ():() => Promise<any> {
        return () => {
            const sql = pvcRowRemoval(this);
            return this.queryService.executeSql<any[]>(sql, true);
        }
    }
}