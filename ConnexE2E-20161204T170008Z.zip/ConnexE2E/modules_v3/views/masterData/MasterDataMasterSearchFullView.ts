/// <reference path='../../../typings/index.d.ts' />
import Promise = protractor.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;

import { IMasterSearchFullView } from "../../interfaces/fullViews/IMasterSearchFullView";
import { filterElements, matchingText, containingText, isActive } from '../../helpers/filterElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';
import { NotImplementedError } from '../../../common/exception/exceptions';
import { IView } from '../../interfaces/common/IView';

export default class MasterDataMasterSearchFullView implements IView, IMasterSearchFullView {
    private searchInput:ElementFinder = $(`input[ng-model='vm.criteria']`);
    private filterList:ElementFinder = $(`md-card.search-refinement`);
    private filters:ElementArrayFinder = this.filterList.$$(`div[ng-repeat*="category in vm.categories"]`);
    private searchResults:ElementArrayFinder = $$(`div[ng-repeat='searchResult in vm.searchResults']`);

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    search (text:string):void {
        this.openSearch();
        this.inputSearch(text);
        this.submitSearch();
    }

    searchByTwoCriteria (firstCriteria:string, secondCriteria:string):void {
        this.openSearch();
        this.searchInput.clear();
        this.searchInput.sendKeys(firstCriteria);
        this.searchInput.sendKeys(protractor.Key.SPACE);
        this.searchInput.sendKeys(secondCriteria);
        this.searchInput.sendKeys(protractor.Key.ENTER);
    }

    openSearch ():void {
        clickElement(this.searchInput);
    }

    inputSearch (text:string):void {
        clickElement(this.searchInput);
        this.searchInput.clear();
        this.searchInput.sendKeys(text);
    }

    submitSearch ():void {
        clickElement(this.searchInput);
        this.searchInput.sendKeys(protractor.Key.ENTER);
    }

    selectAllFilter ():void {
        clickElement(this.filterList.$(`md-radio-button[aria-label="All"]`));
    }

    selectFilterMatchingText (text:string):void {
        clickElement(filterElements(this.filters, [ isActive(true), matchingText(text) ])().first().$(`md-radio-button`));
    }

    selectFilterContainingText (text:string):void {
        clickElement(filterElements(this.filters, [ isActive(true), containingText(text) ])().first().$(`md-radio-button`));
    }

    getCountOfFilters ():Promise<number> {
        return this.filters.count();
    }

    getFilters ():ElementArrayFinder {
        return this.filters.$$('div.md-label').$$('div.ng-binding');
    }

    getCountOfFilterContainingText (text:string):Promise<number> {
        return filterElements(this.filters, [ isActive(true), containingText(text) ])()
            .first()
            .$(`div.count`)
            .getText()
            .then(text => parseInt(text));
    }

    getCountOfFilterMatchingText (text:string):Promise<number> {
        return filterElements(this.filters, [ isActive(true), matchingText(text) ])()
            .first()
            .$(`div.count`)
            .getText()
            .then(text => parseInt(text));
    }

    clickSearchResultMatchingText (text:string):void {
        clickElement(filterElements(this.searchResults, [ isActive(true), matchingText(text) ])().first());
    }

    clickSearchResultContainingText (text:string):void {
        clickElement(filterElements(this.searchResults, [ isActive(true), containingText(text) ])().first());
    }

    clickBusinessPartnerSearchResult (businessPartnerId:string):void {
        throw new NotImplementedError();
    }

    getSearchResultCount ():Promise<number> {
        return this.searchResults.count();
    }

    getSearchResultCountByMatchingResultType (resultType:string):Promise<number> {
        return filterElements(this.searchResults, [
            isActive(true),
            matchingText(resultType, e => e.$$('p.search-result-type').first())
        ])().count();
    }

    getSearchResultsCountByContainingResultType (resultType:string):Promise<number> {
        return filterElements(this.searchResults, [
            isActive(true),
            containingText(resultType, e => e.$$('p.search-result-type').first())
        ])().count();
    }

    getSearchResultsByContainingResultType (resultType:string):ElementArrayFinder {
        return filterElements(this.searchResults, [
            isActive(true),
            containingText(resultType, e => e.$$('p.search-result-type').first())
        ])();
    }

    getSearchResultCountByContainingResultType (headline:string):Promise<number> {
        return this.getSearchResultsByContainingResultType(headline).count();
    }

    getSearchResultsByContainingHeadline (headline:string):ElementArrayFinder {
        return filterElements(this.searchResults, [
            isActive(true),
            containingText(headline, e => e.$(`div.md-headline`))
        ])();
    }

    getSearchResultContentByContainingHeadline (headline:string):Promise<string> {
        return this.getSearchResultsByContainingHeadline(headline).first().getText();
    }

    public getSubheaderForFilters ():Promise<string> {
        return $$('div.md-primary.md-no-sticky.md-subheader').get(0).$('span.ng-scope').getText();
    }

    public getSubheaderForRefineResults ():Promise<string> {
        return $$('div.md-primary.md-no-sticky.md-subheader').get(1).$('span.ng-binding.ng-scope').getText();
    }

    public isSeeMoreButtonDisplayed ():Promise<boolean> {
        return $('button[aria-label="See more"]').isPresent();
    }

    public selectOptionFromHamburgerMenu (option:string):void {
        let hamBurgerMenu = $('button[ng-click="vm.toggleMenu()"]');
        let selectOption = filterElements(
            $$('md-list-item'),
            [
                isActive(true),
                containingText(option)
            ]
        )().first();
        clickElement(hamBurgerMenu);
        clickElement(selectOption);
    }
}
