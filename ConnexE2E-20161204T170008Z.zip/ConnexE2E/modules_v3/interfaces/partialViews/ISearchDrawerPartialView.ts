/// <reference path="../../../typings/index.d.ts" />

import {ISearchableView} from "../common/ISearchableView";

export interface ISearchDrawerPartialView extends ISearchableView {

}