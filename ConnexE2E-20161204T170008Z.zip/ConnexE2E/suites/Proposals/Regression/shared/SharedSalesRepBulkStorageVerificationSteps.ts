/// <reference path="../../../../typings/index.d.ts" />

import { bootstrap } from '../../../SharedSteps/bootstrap';
import { itw } from '../../../../modules_v3/helpers/itw';
import {
    createAccountDescription,
    AccountDescriptionShare
} from '../../../SharedSteps/Sales Rep/createAccountDescription';
import { SalesRepOperationsFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationsFullView';
import { SalesRepOperationFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationFullView';
import { SalesRepProposalFullView } from '../../../../modules_v3/views/salesRep/SalesRepProposalFullView';
import { SharedBulkStorageVerificationTestData } from './SharedBulkStorageVerificationTestData';

export function sharedSalesRepBulkStorageVerificationSteps (description:string, td:SharedBulkStorageVerificationTestData) {

    const salesRepOperationsFullView = new SalesRepOperationsFullView();
    const salesRepOperationFullView = new SalesRepOperationFullView();
    const salesRepProposalFullView = new SalesRepProposalFullView();

    itw(description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.salesRepresentative);

            // navigate to [Operation]
            salesRepOperationsFullView.search(td.operation.name);
            salesRepOperationsFullView.clickSearchResultContainingText(td.operation.name);

            createAccountDescription({
                salesPeriod: td.salesPeriod.id,
                shares: [ new AccountDescriptionShare(td.businessPartner, '100') ]
            }, td);

            // should go to the proposal screen
            browser.controlFlow().execute(() => {
                salesRepOperationFullView.clickProposeButton(td.invoice.name);
            });

            // should click the [+ Add] button for the specified product line
            salesRepProposalFullView.clickProductLineAddButton(td.product.line);

            // should select a product and subproduct from the side drawer that require bulk storage
            salesRepProposalFullView.productSideDrawer.selectProduct(td.product.name);
            salesRepProposalFullView.productSideDrawer.selectSubProduct(td.product.subName);

            // should verify the bulk storage section displays if the agency does not have bulk storage equipment
            expect(salesRepProposalFullView.productSideDrawer.isBulkStorageSectionDisplayed())
                .toBe(!td.agencyHasBulkStorage);
        }, fail);
    });
}