/// <reference path="../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;

import {ITabbableView} from '../common/ITabbableView';
import {IListableView} from '../common/IListableView';

// represents the landing page after clicking a search result as a masterdata user
export interface ICommissionsTabFullView extends IListableView {
    hasGivenYearCommission(givenYear: number):Promise<boolean>;
    clickGivenYearCommission(givenYear: number):void;
}