/// <reference path="../../../../typings/index.d.ts" />

export interface customerWithSignedTechAgreementResults {
    salesRepId: string;
    salesRepName: string;
    operationId: string;
    operationName: string;
    customerId: string;
    customerName: string;
}

export function customerWithSignedTechAgreement (salesPeriodId: number): string {
    const { E2EInvoicesDatabaseName } = process.env;
    
    return `
    select top 5
           u.userid as salesRepId,
           u.name as salesRepName,
           uo.operationid as operationId,
           o.name as operationName,
           c.customerid as customerId,
           c.name as customerName
    from ${E2EInvoicesDatabaseName}.dbo.useroperation as uo
    join ${E2EInvoicesDatabaseName}.dbo.[user] as u on u.userid = uo.userid
    join ${E2EInvoicesDatabaseName}.dbo.operation as o on o.operationid = uo.operationid
    join ${E2EInvoicesDatabaseName}.dbo.salesperiod as sp on sp.salesperiodid = uo.salesperiodid
    join ${E2EInvoicesDatabaseName}.dbo.operationcustomer as oc on oc.operationid = uo.operationid
    join ${E2EInvoicesDatabaseName}.dbo.customer as c on c.customerid = oc.customerid
    where sp.salesperiodid = ${salesPeriodId}
    and uo.roleid = 10
    and uo.userid like '%phiext.com'
    and exists (
        select 1
        from ${E2EInvoicesDatabaseName}.compliance.customeragreement as ca
        where ca.version like '2016%'
        and ca.signed = 1
        and ca.enteredinconnex = 1
        and ca.customerid = c.customerid
    )
    `;
}
