/// <reference path="../../../../typings/index.d.ts" />

import { bootstrap } from '../../../SharedSteps/bootstrap';
import { SalesSupportMasterSearchFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportMasterSearchFullView';
import { itw } from '../../../../modules_v3/helpers/itw';
import { SharedITSupportEllipseNavigationTestData } from './SharedITSupportEllipseNavigationTestData';
import { EllipseItem2 } from '../../../../modules_v3/testdata/EllipseItem';
import ITSupportOperationFullView from '../../../../modules_v3/views/itSupport/ItSupportOperationFullView';
import { ITSupportEllipsePartialView } from '../../../../modules_v3/views/itSupport/ITSupportEllipsePartialView';

const itSupportOperationFullView = new ITSupportOperationFullView();
const salesSupportMasterSearchFullView = new SalesSupportMasterSearchFullView();
const ellipse = new ITSupportEllipsePartialView();

export class SharedITSupportEllipseNavigationSteps {

    public run (td:SharedITSupportEllipseNavigationTestData, description:string, pending?:string) {

        itw(description, () => {
            td.populatePromise().then(() => {
                // bootstrap (load, login, reset feature flags, impersonate)
                bootstrap(td.itSupportUser);

                // should search operation
                salesSupportMasterSearchFullView.search(td.operation.id);
                salesSupportMasterSearchFullView.selectFilterContainingText('Operations');
                salesSupportMasterSearchFullView.clickSearchResultContainingText(td.operation.name);

                // should verify the application navigated to the IT Support operation page
                expect(browser.getCurrentUrl()).toContain('#/support/operation/');

                // should click the first enabled Invoice or Deliveries Button
                itSupportOperationFullView
                    .clickFirstActiveAccountDescriptionButtonContainingText(td.accountDescriptionButtonText);

                browser.getCurrentUrl().then((lastUrl)=> {
                    for (let i = 0; i < td.ellipseItems.length; i++) {
                        (function (ellipseItem:EllipseItem2) {

                            // should select the given menu item from the ellipse
                            ellipse.select(ellipseItem.name);

                            // should verify the application redirected the user to the correct page
                            expect(ellipseItem.targetView.isViewDisplayed()).toBeTruthy(
                                `The incorrect page displayed after selecting [${ellipseItem.name}] from the ellipse`);

                            // should navigate back to the page containing the ellipse we are testing
                            browser.get(lastUrl);

                        })(td.ellipseItems[ i ]);
                    }
                });
            }, fail);
        }, pending);
    }
}