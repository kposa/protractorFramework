/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import { isAriaChecked } from '../../../modules_v3/helpers/utilityElementHelpers';
import { filterElements, isActive, containingText } from '../../../modules_v3/helpers/filterElementHelpers';
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

export class WarehouseMD {


    public isWarehouseNameDisplayedOnCard(): Promise<string> {
        return $('div.warehouse-name').getText();
    }

    public isEditWarehouseButtonDisplayedOnCard(): Promise<boolean> {
        return $$('button.md-accent.md-button.md-ink-ripple').get(0).isDisplayed();
    }

    public verifyPrimaryRadioButtonChecked(): Promise<boolean> {
        return isAriaChecked($('md-radio-button[name="isPrimary"]'));
    }

    public selectCard(cardName: string): void {
        let card = filterElements(
            $$('md-card'), [ isActive(true), containingText(cardName) ])().first();
        clickElement(card);
    }
}