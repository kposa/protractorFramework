/// <reference path='../../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';
import { agenciesForOlderThanIsCurrentSalesPeriodResults, agenciesForOlderThanIsCurrentSalesPeriod } from './queries';

export default class TestDataForBeginningSalesPeriodDropdown extends BaseTestData {

    public agencyId: string;

    protected queries = [
        this.getAgenciesForOlderThanIsCurrentSalesPeriod()
    ];

    private getAgenciesForOlderThanIsCurrentSalesPeriod (): () => Promise<agenciesForOlderThanIsCurrentSalesPeriodResults> {
        return () => {
            const sql = agenciesForOlderThanIsCurrentSalesPeriod();
            const results = this.queryService.executeSql<agenciesForOlderThanIsCurrentSalesPeriodResults[]>(sql);

            return results
                .then(data => {
                    const row = <agenciesForOlderThanIsCurrentSalesPeriodResults>getRandomQueryResult(data);
                    this.agencyId = row.agencyId;
                    return row;
                });
        };
    }

}