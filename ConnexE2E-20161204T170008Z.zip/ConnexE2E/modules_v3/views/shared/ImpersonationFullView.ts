/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;

import {IImpersonationFullView} from "../../interfaces/fullViews/IImpersonationFullView";
import {ISearchDrawerPartialView} from "../../interfaces/partialViews/ISearchDrawerPartialView";
import SearchDrawerView from "./SearchDrawerPartialView";

import { filterElements, matchingText, containingText, isActive } from '../../helpers/filterElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';
import { NotImplementedError } from '../../../common/exception/exceptions';
import { IView } from '../../interfaces/common/IView';

export default class ImpersonationFullView implements IView, IImpersonationFullView {
    private element = $(`section.impersonate`);
    private searchDrawer:ISearchDrawerPartialView = new SearchDrawerView();
    private searchResults = this.element.$$(`li[data-ng-repeat='user in users']`);

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    search(text:string):void {
        this.searchDrawer.search(text);
    }

    searchByTwoCriteria(firstCriteria:string, secondCriteria:string):void {
        throw new NotImplementedError();
    }

    openSearch():void {
        this.searchDrawer.openSearch();
    }

    inputSearch(text:string):void {
        this.searchDrawer.inputSearch(text);
    }

    submitSearch():void {
        this.searchDrawer.submitSearch();
    }

    clickSearchResultMatchingText(text:string):void {
        clickElement(filterElements(this.searchResults, [isActive(true), matchingText(text)])().first());
    }

    clickSearchResultContainingText(text:string):void {
        clickElement(filterElements(this.searchResults, [isActive(true), containingText(text)])().first());
    }

    getSearchResultCount():webdriver.promise.Promise<number> {
        throw new NotImplementedError();
    }
}
