/// <reference path='../../../typings/index.d.ts' />
import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;
import { IView } from '../../interfaces/common/IView';
import { IBackNavigableView } from '../../interfaces/common/IBackNavigableView';
import { clickElement } from '../../helpers/clickElementHelpers';
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';
import { filterElements, isActive, containingText } from '../../helpers/filterElementHelpers';

export class SalesSupportCustomersPageFullView implements IView, IBackNavigableView {

    isViewDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('sales-support-customer-list[list="vm.customerList"]'));
    }

    clickBack ():void {
        clickElement($('section.app-bar-back-button'));
    }

    getHeaderTitle ():Promise<string> {
        return $('section.pm-app-bar.pm-background-primary-500').$('div.pm-title').getText();
    }

    private getCustomerLineByName (customerName:string):ElementFinder {
        return filterElements($$('div[ng-repeat="customer in list"]')
            , [ isActive(true), containingText(customerName, e => e.$(`div.pm-listitem-primary`)) ])().first();
    }

    clickCustomerLine (customerName:string) {
        clickElement(this.getCustomerLineByName(customerName));
    }

}
