/// <reference path="../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import Promise = webdriver.promise.Promise;

export interface ITransferMoneyFullView {
    selectTransferFromByInvoiceNameAndSalesPeriodName (invoiceName:string, salesperiodName:string):void;
    selectTransferToByInvoiceNameAndSalesPeriodName (invoiceName:string, salesperiodName:string):void;
    enterAmount (amount:number):void;
    clickTransferButton():void;
}