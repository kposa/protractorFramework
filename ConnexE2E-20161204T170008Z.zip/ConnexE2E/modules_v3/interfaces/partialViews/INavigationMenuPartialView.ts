/// <reference path="../../../typings/index.d.ts" />

import {IExpandableMenuView} from "../common/IExpandableMenuView";

export interface INavigationMenuPartialView extends IExpandableMenuView {
}