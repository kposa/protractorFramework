/// <reference path="../../../../typings/index.d.ts" />

import associateSellerOperationsFullView from '../../../../modules_v3/views/associateSeller/AssociateSellerOperationsFullView';
import TestData416677 from './testData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { itw } from '../../../../modules_v3/helpers/itw';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import AssociateSellerHamburgerDrawerPartialView from '../../../../modules_v3/views/associateSeller/AssociateSellerHamburgerDrawerPartialView';

const test = new TestCase(
	'416677',
	'Balances Report displays for an Associate seller',
	UserRole.SALES_REP,
	ApplicationFeature.NAVIGATIONS
);

describe(test.stringify, () => {
    const td = new TestData416677();
    let associateSellerOperations = new associateSellerOperationsFullView();
    let hamburgerDrawer = new AssociateSellerHamburgerDrawerPartialView();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            bootstrap(td.salesRepresentative);
            associateSellerOperations.filterBySalesAgencyIfAgencyButtonDisplayed(td.salesAgency.id);

            //should click on the hamburger
            associateSellerOperations.clickSearchBarHamburger();

            // should click Reports from the hamburger menu
            hamburgerDrawer.clickItemFromHamburgerMenu('Reports');

            // should click on Balances Report
            hamburgerDrawer.selectReport('Balances Report');

        }, fail);
    });
});