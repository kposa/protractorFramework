/// <reference path="../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import Promise = webdriver.promise.Promise;

export interface IHamburgerMenuPartialView {
    clickItemFromHamburgerMenu(itemName:string):void;
  
}