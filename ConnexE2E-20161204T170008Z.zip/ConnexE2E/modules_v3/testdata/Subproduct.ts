
export interface Subproduct {
    id: string;
    name?: string;
}