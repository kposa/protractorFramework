/// <reference path="../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import {Element} from '../../shared/Element';
import {ActionButtonSS} from "../shared/ActionButtonSS";

let e = new Element();
let actionButton = new ActionButtonSS();

export class OperationSS {

    public selectAccountDescription(acctDescName:string):void {
        let accountDescription = this.getAccountDescription(acctDescName);
        e.clickElement(accountDescription);
    }

    private getAccountDescription(acctDescName:string):ElementFinder {
        let allAccountDescriptionNames = $$('div.pm-listitem-primary');
        return allAccountDescriptionNames.filter(function (elem, index) {
            return elem.getText().then(function (acctDescTitle) {
                return acctDescTitle == acctDescName;
            });
        }).get(0);
    }

    public toasterMenu_selectInvoice():void {
        e.clickElement($('div[ng-click="abm.goToInvoices()"]'));
    }

    public toasterMenu_selectDocuments():void {
        e.clickElement($('div[ng-click="abm.goToDocuments()"]'));
    }

    public toasterMenu_selectShares():void {
        e.clickElement($('div[ng-click="abm.goToShares()"]'));
    }
    
    public clickAddAccountDescriptionBtn():void {
        actionButton.clickFloatingActionBtn();
    }
}