/// <reference path='../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';
import { NotImplementedError } from '../../../common/exception/Exceptions';
import { IView } from '../../interfaces/common/IView';
import { isDisabled } from '../../helpers/utilityElementHelpers';

export class AccountManagerAccountDescriptionRollFullView implements IView {

    public filterDialog = new FilterDialog();
    public selectDropDownDialog = new SelectDropDownDialog();
    
    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    getTitleText ():Promise<string> {
        return $('div.pm-title').getText();
    }

    clickFilterIcon () {
        clickElement($('i.fa-filter'));
    }

    clickBackdrop () {
        clickElement($('div.pm-backdrop.visible'));
    }

    clickSelectBackdrop () {
        clickElement($('md-backdrop.md-menu-backdrop'));
    }

    getTextBelowHeader ():Promise<string> {
        return $$('div.flex-horizontal.layout-row').first().getText();
    }

    clickSelectDropDown () {
        clickElement($('md-icon.menu-button'));
    }

    clickCheckBox () {
        clickElement($$('div[md-ink-ripple-checkbox]').first());
    }

    isRollButtonInactive ():Promise<boolean> {
        return isDisabled($('button.rollButton'));
    }

    verifyBPsFormat () : Promise<string[]> {
        return $$('div.invoiceTemplateDetails').$$('div').first().getText().then((text) => {
            return text.split('-');
        });
    }
}

class FilterDialog {
    
    getFilterDialogText ():Promise<string> {
        return $$('div.filter-sub-menu-item').first().getText();
    }
}

class SelectDropDownDialog {
    
    getSelectDropdownText () {
        return $('div.md-whiteframe-z2.md-active').getText();
    }
}