/// <reference path="../../../../typings/index.d.ts" />

import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import TestDataMasterDataSearch from '../shared/sharedMasterDataSearchTestData';
import sharedMasterDataSearchSteps from '../shared/sharedMasterDataSearchSteps';

const test = new TestCase(
	'333395',
	'Master Data Search - Areas',
	UserRole.MASTER_DATA,
	ApplicationFeature.SEARCH
);

describe(test.stringify, () => {
    const td = new TestDataMasterDataSearch('Area', 'Areas', 'Area');
    sharedMasterDataSearchSteps(test.description, td);
});