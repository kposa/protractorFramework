/// <reference path="../../../../typings/index.d.ts" />

import { SharedSalesRepEllipseNavigationTestData } from '../shared/SharedSalesRepEllipseNavigationTestData';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { sharedSalesRepEllipseNavigationSteps } from '../shared/SharedSalesRepEllipseNavigationSteps';

const test = new TestCase(
    '273602',
    'Ellipse Menu - Invoice Discounts Page',
    UserRole.SALES_REP,
    ApplicationFeature.NAVIGATIONS
);

describe(test.stringify, () => {
    const td = new SharedSalesRepEllipseNavigationTestData();

    td.preEllipseItem = td.availableEllipseItems.discounts;

    td.ellipseItems = [
        td.availableEllipseItems.products,
        td.availableEllipseItems.chargesAndCredits,
        td.availableEllipseItems.deliver,
        td.availableEllipseItems.accountDescription,
        td.availableEllipseItems.businessPartners,
        td.availableEllipseItems.activityStatement,
        td.availableEllipseItems.documents,
        td.availableEllipseItems.newProposal,
        td.availableEllipseItems.experiments,
        td.availableEllipseItems.growthAndRetentionOverview
    ];

    sharedSalesRepEllipseNavigationSteps(td, test.description);
});