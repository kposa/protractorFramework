/// <reference path="../../../../typings/index.d.ts" />

import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import {
    getOperationHavingCompletedDeliveryAndOneShare, operationHavingACompletedDeliveryAndOneShareResults
}from './SharedSalesSupportEllipseNavigationQueries';
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';
import { EllipseItem2 } from '../../../../modules_v3/testdata/EllipseItem';
import { SalesSupportOperationFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportOperationFullView';
import { SalesSupportMasterSearchFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportMasterSearchFullView';
import { SalesSupportInvoiceFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportInvoicePageFullView';
import { SalesSupportDocumentsPageFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportDocumentsPageFullView';
import { SalesSupportChargeAndCreditsPageFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportChargeAndCreditsPageFullView';
import { SalesSupportDiscountsPageFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportDiscountsPageFullView';
import { SalesSupportSharesPageFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportSharesPageFullView';
import { SalesSupportActivityStatementPageFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportActivityStatementPageFullView';
import { SalesSupportGrowthAndRetentionOverviewPageFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportGrowthAndRetentionOverviewPageFullView';
import { SalesSupportDeletedChargesAndCreditsPageFullView } from '../../../../modules_v3/views/salesSupport/SalesSupportDeletedChargesAndCreditsPageFullView';

export default class SharedEllipseNavigationTestData extends BaseTestData {
    protected queries:(() => Promise<any>)[] = [
        this.populateUserData()
    ];

    public availableEllipseItems = {

        invoice: new EllipseItem2(
            'invoice',
            new SalesSupportInvoiceFullView()
        ),
        products: new EllipseItem2(
            'products',
            new SalesSupportInvoiceFullView()
        ),
        documents: new EllipseItem2(
            'documents',
            new SalesSupportDocumentsPageFullView()
        ),
        deletedChargesAndCredits: new EllipseItem2(
            'Deleted Charges and Credits',
            new SalesSupportDeletedChargesAndCreditsPageFullView()
        ),
        chargeAndCredits: new EllipseItem2(
            'Charges and credits',
            new SalesSupportChargeAndCreditsPageFullView()
        ),
        discounts: new EllipseItem2(
            'discounts',
            new SalesSupportDiscountsPageFullView()
        ),
        shares: new EllipseItem2(
            'shares',
            new SalesSupportSharesPageFullView()
        ),
        operation: new EllipseItem2(
            'operation',
            new SalesSupportOperationFullView()
        ),
        search: new EllipseItem2(
            'search',
            new SalesSupportMasterSearchFullView()
        ),
        activityStatement: new EllipseItem2(
            'activity statement',
            new SalesSupportActivityStatementPageFullView()
        ),
        growthAndRetentionOverview: new EllipseItem2(
            'Growth and retention overview',
            new SalesSupportGrowthAndRetentionOverviewPageFullView()
        ),
    };

    private populateUserData ():() => Promise<operationHavingACompletedDeliveryAndOneShareResults> {
        return () => {
            const sql = getOperationHavingCompletedDeliveryAndOneShare(this.salesPeriod.id);
            const results = this.queryService.executeSql<operationHavingACompletedDeliveryAndOneShareResults[]>(sql);

            return results
                .then(data => {
                    const row = <operationHavingACompletedDeliveryAndOneShareResults>getRandomQueryResult(data);

                    this.operations.push({
                        id: row.operationId,
                        name: row.operationName
                    });

                    return row;
                });
        };
    }
}