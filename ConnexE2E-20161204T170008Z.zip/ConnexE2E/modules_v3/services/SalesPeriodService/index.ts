import { range } from '../../helpers/utilityHelpers';
import { SalesPeriod } from './SalesPeriod';

export { SalesPeriod } from './SalesPeriod';

export class SalesPeriodService {
    static createSalesPeriod (): SalesPeriod {
        return new SalesPeriod();
    }

    static incrementSalesPeriod (salesPeriod: SalesPeriod, amount: number = 1): SalesPeriod {
        if (amount < 0) {
            throw new Error(`Argument 'amount' must be a positive number`);
        }

        // Generate a range array to increment over [0,1,...]
        return range(amount)
            .reduce((previousSalesPeriod) => {
                const incrementedId = previousSalesPeriod.id + 1;
                let incrementedYear: number;
                let incrementedSeason: "Fall" | "Spring";

                switch (previousSalesPeriod.season) {
                    case "Spring":
                        incrementedSeason = "Fall";
                        break;
                    case "Fall":
                        incrementedSeason = "Spring";
                        incrementedYear = previousSalesPeriod.year + 1;
                        break;
                }

                return new SalesPeriod(incrementedId, incrementedYear, incrementedSeason);
            }, salesPeriod);
    }

    static decrementSalesPeriod (salesPeriod: SalesPeriod, amount: number = 1): SalesPeriod {
        if (amount < 0) {
            throw new Error(`Argument 'amount' must be a positive number`);
        }

        // Generate a range array to increment over [0,1,...]
        return range(amount)
            .reduce((previousSalesPeriod) => {
                const incrementedId = previousSalesPeriod.id - 1;
                let decrementedYear: number;
                let decrementedSeason: "Fall" | "Spring";

                switch (previousSalesPeriod.season) {
                    case "Spring":
                        decrementedSeason = "Fall";
                        decrementedYear = previousSalesPeriod.year - 1;
                        break;
                    case "Fall":
                        decrementedSeason = "Spring";
                        break;
                }

                return new SalesPeriod(incrementedId, decrementedYear, decrementedSeason);
            }, salesPeriod);
    }

    static updateSalesPeriodId (salesPeriod: SalesPeriod, toSalesPeriodId: number): SalesPeriod {
        const delta = toSalesPeriodId - salesPeriod.id;
        const absDelta = Math.abs(delta);

        switch(true) {
            case (delta === 0):
                return salesPeriod;
            case (delta < 0):
                return this.decrementSalesPeriod(salesPeriod, absDelta);
            case (delta > 0):
                return this.incrementSalesPeriod(salesPeriod, absDelta);
        }
    }
}