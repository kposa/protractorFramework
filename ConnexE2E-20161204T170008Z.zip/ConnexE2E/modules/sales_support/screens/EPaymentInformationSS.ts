/// <reference path="../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import Promise = webdriver.promise.Promise;
import {Element} from '../../shared/Element';
import {Helpers} from "../../shared/Helpers";
import { isAriaEnabled } from '../../../modules_v3/helpers/utilityElementHelpers';

let e = new Element();
let hlp = new Helpers();

export class EPaymentInformationSS {

    private parent = $('bank-information[show="vm.showBankInformation"]');  //because its a modal on top of another page
    private acceptButton = this.parent.$('button[ng-click="vm.acceptClicked()"]');

    public enterUSRoutingNumber(routingNumber:string):void {
        let routingNumberInput = this.parent.$('input[ng-model="vm.routingNumber"]');
        this.enterTextIntoInput(routingNumberInput, routingNumber);
    }

    public enterCARoutingNumber(routingNumber:string):void {
        let transitnumber = routingNumber.substring(4, 9);
        let institutionNumber = routingNumber.substring(1, 4);
        let transitNumberInput = this.parent.$('input[ng-model="vm.transitNumber"]');
        let institutionNumberInput = this.parent.$('input[ng-model="vm.institutionNumber"]');
        this.enterTextIntoInput(transitNumberInput, transitnumber);
        this.enterTextIntoInput(institutionNumberInput, institutionNumber);
    }

    public enterAccountNumber(accountNumber?:string):string {
        if (!accountNumber) accountNumber = hlp.guid(14, true);
        let accountNumberInput = this.parent.$('input[ng-model="vm.accountNumber1"]');
        this.enterTextIntoInput(accountNumberInput, accountNumber);
        return accountNumber;   //save to td to use again for the confirm account number
    }

    public enterConfirmAccountNumber(accountNumber:string):void {
        let confirmAccountNumberInput = this.parent.$('input[ng-model="vm.accountNumber2"]');
        this.enterTextIntoInput(confirmAccountNumberInput, accountNumber);
    }

    public enterConfirmationEmailIfNeeded():void {
        let self = this;
        let confirmationEmailInput = this.parent.$('input[ng-model="vm.customeremail"]');
        confirmationEmailInput.getAttribute('value').then(function (email) {
            if (!email) self.enterTextIntoInput(confirmationEmailInput, 'automation@test.com');
        });
    }

    public clickAccept():void {
        e.clickElement(this.acceptButton);
        expect(this.isDisplayed).toBe(false);
    }

    private enterTextIntoInput(input:ElementFinder, value:string):void {
        e.clickElement(input);
        input.sendKeys(value);
        this.focusOutOfAllfields();
    }

    private focusOutOfAllfields():void {
        let firstHeader = this.parent.$$('div.messageHeader').get(0);
        e.clickElement(firstHeader);
    }

    get paymentAmount():Promise<string> {
        return this.parent.element(by.binding('vm.amount | currency')).getText().then(function (amt) {
            return hlp.removeEverythingButNumbersAndDecimals(amt);
        });
    }

    //the 'value' attribute doesn't show in the markup - have to look in chrome tools properties for the input
    get bankName():Promise<string> {
        let bankNameInput = this.parent.$('input[ng-model="vm.bankName"]');
        return bankNameInput.getAttribute('value');
    }

    get isFirstRadioButtonSelected():Promise<boolean> {
        let firstRadioButton = this.parent.$$('div[ng-click="vm.selectConfirmationDeliveryMethod(method)"]').get(0);
        return firstRadioButton.$('div.pm-selection-icon.is-checked').isDisplayed();
    }

    get isAcceptButtonEnabled():Promise<boolean> {
        return isAriaEnabled(this.acceptButton);
    }

    get isDisplayed():Promise<boolean> {
        return this.parent.$('div.bankinfo').isDisplayed();
    }
}