/// <reference path='../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import { clickElement } from '../../helpers/clickElementHelpers';
import { filterElements, isActive, matchingText } from '../../helpers/filterElementHelpers';
import { NotImplementedError } from '../../../common/exception/exceptions';
import { IView } from '../../interfaces/common/IView';
import { IAddLineItemDrawerPartialView } from '../../interfaces/partialViews/IAddLineItemDrawerPartialView';
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';

export class SalesRepProposalFullView implements IView {

    public productSideDrawer = new ProductSideDrawer();

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    clickProductLineAddButton (productLineName:string):void {
        clickElement($(`button[at="${productLineName}"]`));
    }
}

class ProductSideDrawer implements IAddLineItemDrawerPartialView {

    selectProductLine (productLineName?:string) {
        throw new NotImplementedError();
    }

    // only try to select the product from the drawer if the product wasn't already auto-selected
    selectProduct (productName:string) {
        let displayedProductDrawer = $('section.expandedproduct');
        isPresentAndDisplayed(displayedProductDrawer).then((d) => {
            if (d) {
                let allProducts = displayedProductDrawer.$$('div.product');
                clickElement(filterElements(allProducts, [ isActive(true), matchingText(productName) ])().first());
            }
        });

    }

    // only try to select the subproduct from the drawer if the subproduct wasn't already auto-selected
    selectSubProduct (subproductName:string) {
        let displayedSubproductDrawer = $('section.expandedsubproduct');
        isPresentAndDisplayed(displayedSubproductDrawer).then((d) => {
            if (d) {
                let allProducts = displayedSubproductDrawer.$$('div.subproduct');
                clickElement(filterElements(allProducts, [ isActive(true), matchingText(subproductName) ])().first());
            }
        });

    }

    fillInputUnits (units:string) {
        units.split('').forEach((digit) =>
            clickElement($('expandedunits').$(`td[ng-click="keypad.addDigit(${digit})"]`)));
    }

    close () {
        clickElement($('section.expandedlineitem').$('div.drawer-close-header').$('i.fa-chevron-right'));
    }

    isBulkStorageSectionDisplayed():Promise<boolean> {
        let displayedGreenDrawer = $('section.expandedlineitem');
        return isPresentAndDisplayed(displayedGreenDrawer.$('li[at="lineitem-dwr-bulk-storage"]'));
    }
}