/// <reference path="../../typings/index.d.ts" />

import { Entity } from './Entity';

export interface RoutingNumber {
    country:string;
    routingNumber: string;
    bank: string;
}