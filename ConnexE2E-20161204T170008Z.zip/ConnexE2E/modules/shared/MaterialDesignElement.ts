/// <reference path="../../typings/index.d.ts" />

/**
 * This class should be used as a helper for common elements used in material design
 * Other non-material design element helpers should be in the Element class
 */

import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;
import Promise = webdriver.promise.Promise;
import {Element} from "./Element";

let e = new Element();

export class MaterialDesignElement {

    public getDisplayValue(parent:ElementFinder):ElementFinder {
        return parent.$('div.pm-text-display-value');
    }

    public getLabel(parent:ElementFinder):ElementFinder {
        return parent.$('div.pm-text-label');
    }

    public getClickableArea(parent:ElementFinder):ElementFinder {
        return parent.$('div.pm-text-clickable-area');
    }

    public enterInputText(parent:ElementFinder, text:string):void {
        parent.$('input.pm-text-input').sendKeys(text);
    }

    public clickFormField(section:ElementFinder):void {
        e.clickElement(this.getLabel(section));
    }

    public clickListItem(allListItems:ElementArrayFinder, primaryListitemText?:string):void {
        let firstFilteredListItem = this.getFirstListItem(allListItems, primaryListitemText);
        e.clickElement(firstFilteredListItem);
    }

    //should work with any listitem having 'listitem-primary' as a part of a child class name
    public getFirstListItem(allListItems:ElementArrayFinder, primaryListitemText?:string):ElementFinder {
        return allListItems.filter(function (elem) {
            return elem.$('div[class*="listitem-primary"]').getText().then(function (displayedPrimaryListItemText) {
                if(primaryListitemText) return displayedPrimaryListItemText === primaryListitemText;
                return true;
            });
        }).get(0);
    }
}