/// <reference path='../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import { INavigationMenuPartialView } from "../../interfaces/partialViews/INavigationMenuPartialView";
import { filterElements, matchingText, containingText, isActive } from '../../helpers/filterElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';
import { IView } from '../../interfaces/common/IView';
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';

export default class SalesSupportNavigationMenuPartialView implements IView, INavigationMenuPartialView {
    private element = $(`section[name='navigationDrawer']`);
    private menuButton = $(`i[ng-click='drawerVM.toggleDrawerPosition()']`);
    private menuItems = this.element.$$(`div.pm-navigation-item`);

    isViewDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('section[name="navigationDrawer"]'));
    }

    openMenu ():void {
        clickElement(this.menuButton);
    }

    selectMenuItemMatchingText (text:string):void {
        clickElement(filterElements(this.menuItems, [ isActive(true), matchingText(text) ])().first());
    }

    selectMenuItemContainingText (text:string):void {
        clickElement(filterElements(this.menuItems, [ isActive(true), containingText(text) ])().first());
    }
}
