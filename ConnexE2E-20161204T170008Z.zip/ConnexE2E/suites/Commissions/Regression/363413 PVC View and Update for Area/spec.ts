/// <reference path="../../../../typings/index.d.ts" />

import { sharedViewAndUpdatePVCSteps } from '../shared/sharedViewAndUpdatePVCSteps';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { sharedViewAndUpdatePVCTestData } from '../shared/sharedViewAndUpdatePVCTestData';

const test = new TestCase(
    '363413',
    'PVC View and Update for Area',
    UserRole.MASTER_DATA,
    ApplicationFeature.COMMISSIONS
);

describe(test.stringify, () => {
    const td = new sharedViewAndUpdatePVCTestData('AF', 'Area');
    sharedViewAndUpdatePVCSteps(test.description, td);
});