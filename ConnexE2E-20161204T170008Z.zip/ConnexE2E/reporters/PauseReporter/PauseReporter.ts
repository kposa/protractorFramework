///<reference path="../../typings/index.d.ts"/>

import { isTrue } from '../../modules_v3/helpers/utilityHelpers';

const { E2EUseScreenshotReporter } = process.env;

export class PauseReporter {
    public specDone (specDone:any):void {
        if (specDone.status === 'failed') {
            console.warn(specDone.failedExpectations[ 0 ].message);
            console.warn(specDone.failedExpectations[ 0 ].stack);
            if (!isTrue(E2EUseScreenshotReporter)) {
                browser.pause();
            }
        }
    }
}