/// <reference path="../../typings/index.d.ts" />

export interface SalesPeriod {
    id:number;
    year:number;
    season: "Spring" | "Fall";
    name?:string;
}