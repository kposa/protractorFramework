/// <reference path="../../../typings/index.d.ts" />

import Promise = protractor.promise.Promise;
import optimist = require('optimist');
import { result } from '../../testdata/sharedQueries/existingData/index';

const mssql = require('mssql');

/**
 * The query service is responsible for executing queries/procs in the database
 */
export default class QueryService {
    constructor (private databaseName:string = 'invoices',
                 private connectionString:string) {
    }

    /**
     * Runs the passed thenables in sequence
     * @param queries
     * @returns {Promise<any>}
     */
    // TODO: Move this in to a helper function
    public runThenablesInSequence (...queries:(() => Promise<any>)[]):Promise<any> {
        const flow = protractor.promise.controlFlow();
        const firstQuery = queries.shift();
        return queries.reduce((last:Promise<any>, next:() => Promise<any>) => {
            return last.then(() => {
                return next();
            });
        }, flow.execute(firstQuery));
    }

    /**
     * Execute a SQL query string
     * If the query is a delete statement one can pass an optional boolean
     * parameter to bypass the undefined response result
     * @param sql
     * @returns {Promise<T>}
     */
    public executeSql<T> (sql:string, isDeleteStmnt?:boolean):Promise<T[]> {
        console.log(sql);
        let defer = protractor.promise.defer();

        mssql.connect(this.connectionString).then(() => {
            new mssql.Request().query(sql).then((res:any) => {
                if (!isDeleteStmnt && res.length === 0) defer.reject('No results returned from sql query');
                else defer.fulfill(isDeleteStmnt ? res : this.trimResults(res));
            }).catch((err:any) => {
                defer.reject('Query error: ' + err);
            });
        }).catch((err:any) => {
            defer.reject('Connection error: ' + err);
        });

        return defer.promise;
    }

    /**
     * Execute a stored procedure by name
     * @param procName
     * @param optionalParameters
     * @returns {Promise<T>}
     */
    public executeProc<T> (procName:string, optionalParameters:any = {}):Promise<T[]> {
        let defer = protractor.promise.defer();

        mssql.connect(this.connectionString).then(() => {
            let req = new mssql.Request();

            for (let stuff in optionalParameters) {
                req.input(stuff, optionalParameters[ stuff ]);
            }
            req.execute(procName).then((res:any) => {
                if (res.length === 0) defer.reject('No results returned from sql proc query');
                else defer.fulfill(this.trimResults(res));
            }).catch((err:any) => {
                defer.reject("Query proc error: " + err);
            });
        }).catch((err:any) => {
            defer.reject("Connection error: " + err);
        });

        return defer.promise;
    }

    private trimResults(results: result[]): result[]{
        for (var i = 0; i < results.length; i++){
            let r = results[i];
            Object.keys(r).forEach((k,_i) => {if (typeof(r[k]) === 'string') { r[k] = r[k].trim() } });
        }
        return results;
    }

    // TODO: Convert this to a shared query to testdata/sharedQueries
    public createAccountDescription (salesAgencyId:string,
                                     territoryId:string,
                                     operationId:string,
                                     customerId:string,
                                     salesPeriodId:number):Promise<CreateAccountDescriptionResults[]> {
        return this
            .executeProc<CreateAccountDescriptionResults>('e2e.usp_AccountDescription_Create', {
                salesAgencyId,
                territoryId,
                operationId,
                customerId,
                salesPeriodId
            });
    }

    // TODO: Convert this to a shared query to testdata/sharedQueries
    public addProductToAccountDescription (invoiceId:string):Promise<AddProductToAccountDescriptionResults[]> {
        return this.executeProc<AddProductToAccountDescriptionResults>('e2e.usp_ProductLine_Create', { invoiceId });
    }
}

export interface CreateAccountDescriptionResults {
    invoiceId:string,
    name:string
}

export interface AddProductToAccountDescriptionResults {
    productLineId:string,
    productLine:string,
    product:string,
    subproduct:string,
    units:number,
    price:number
}