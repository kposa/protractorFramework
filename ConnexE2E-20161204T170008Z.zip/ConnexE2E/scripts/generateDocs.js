const glob = require('glob');
const fs = require('fs');
const path = require('path');
const showdown = require('showdown');
const mkdirp = require('mkdirp');

function buildJavascript (files) {
    return files.map(function (file) {
        const filePath = path.join('docs', 'main.js');
        const fileJavascript = fs.readFileSync(filePath, 'UTF-8');
        return '<script type="text/javascript">'+fileJavascript+'</script>';
    });
}

function buildCss (files) {
    return files.map(function (file) {
        const filePath = path.join('docs', file);
        const fileCss = fs.readFileSync(filePath, 'UTF-8');
        return '<style>'+fileCss+'</style>';
    });
}

glob('./docs/**/*.md', {}, function (err, files) {
    if (err) throw err;

    // Markdown converter initialization and configuration
    const converter = new showdown.Converter();
    converter.setOption('tables', true);
    converter.setOption('literalMidWordUnderscores', true);

    const css = buildCss(['main.css']);
    const js = buildJavascript(['main.js']);

    files
        .forEach(function (file) {
            const buildPath = path.join('build', file.slice(0, -3) + '.html');
            const markdown = fs.readFileSync(file, 'UTF-8');
            const html = converter.makeHtml(markdown);

            // Create build path if it doesn't exist
            mkdirp.sync(path.dirname(buildPath));

            // Compose css, js and html together
            fs.writeFileSync(buildPath, [css, js, html].join("\n"));
        });
});