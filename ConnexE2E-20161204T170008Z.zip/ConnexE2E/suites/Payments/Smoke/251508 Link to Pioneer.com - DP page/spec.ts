/// <reference path="../../../../typings/index.d.ts" />

import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';
import { testData } from './testData';
import { SalesRepOperationsFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationsFullView';
import { SalesRepEllipsePartialView } from '../../../../modules_v3/views/salesRep/SalesRepEllipsePartialView';
import { SalesRepBusinessPartnersFullView } from '../../../../modules_v3/views/salesRep/SalesRepBusinessPartnersFullView';
import { isPresentAndDisplayed } from '../../../../modules_v3/helpers/utilityElementHelpers';

const test = new TestCase(
    '324677',
    'Link to Pioneer.com - DP page',
    UserRole.SALES_REP,
    ApplicationFeature.PAYMENTS
);

describe(test.stringify, () => {
    const td = new testData();
    const salesRepOperations = new SalesRepOperationsFullView();
    const salesRepEllipse = new SalesRepEllipsePartialView();
    const salesRepBusiness = new SalesRepBusinessPartnersFullView();


    itw(test.description, () => {
        td.populatePromise().then(() => {
            bootstrap(td.salesRepresentative);

            salesRepOperations.search(td.operation.name);

            salesRepOperations.clickSearchResultContainingText(td.operation.name);

            salesRepEllipse.select('business partners');

            salesRepBusiness.clickFirstBalancesButton();

            salesRepEllipse.select('view loans at pioneer.com');

            browser.getAllWindowHandles().then(function (handles) {
                browser.switchTo().window(handles[1]);
            });

            expect(isPresentAndDisplayed($('tr.loanresults')));
        });
    });
});