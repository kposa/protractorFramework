///<reference path="../../typings/index.d.ts"/>

import Winston = require('winston');
import { LogReporterParser } from './LogReporterParser';
import moment = require('moment');
import { LoggerInstance } from 'winston';
import Promise = protractor.promise.Promise;
import { TestResult } from './TestResult';
import { removeLineBreaks, textEndsWith, getDuplicates } from '../../modules_v3/helpers/utilityHelpers';

const fs = require('fs');
const path = require('path');
const mkdirp = require('mkdirp');
const Table = require('easy-table');

let winston:LoggerInstance;

export class LogReporter {

    constructor () {
        winston = this.getWinstonInstance();
    }

    private testResultFilePath:string = path.join(__dirname, `../../../results.json`);
    private jasmineResultFilePath:string = path.join(__dirname, `./jasmine_results.json`);

    public writeTestResultsToFile () {
        fs.writeFileSync(
            this.testResultFilePath,
            JSON.stringify(new LogReporterParser(this.jasmineResultFilePath).getTestResults())
        );
        console.log(`\nResults saved to: ${this.testResultFilePath}\n`);
    }

    public printResultsToConsole () {
        let resultFileContents:Array<TestResult> = JSON.parse(fs.readFileSync(this.testResultFilePath).toString().trim());

        resultFileContents = resultFileContents.sort((a:TestResult, b:TestResult):number => {
            return a.status.localeCompare(b.status);
        });

        let t = new Table();
        resultFileContents.forEach((tr:TestResult) => {
            t.cell('Status', removeLineBreaks(tr.status ? tr.status : ''));
            t.cell('ID', removeLineBreaks(tr.testCaseId ? tr.testCaseId : ''));
            t.cell('Description', removeLineBreaks(tr.testCaseDescription ? tr.testCaseDescription.substr(0, 40) : ''));
            t.cell('Feature', removeLineBreaks(tr.feature ? tr.feature.substr(0, 20) : ''));
            t.cell('User Role', removeLineBreaks(tr.userRole ? tr.userRole.substr(0, 15) : ''));
            if (tr.status === 'disabled') tr.duration = 0;
            t.cell('Time', tr.duration ? `${tr.duration}sec` : '');
            t.cell('Failure Message', removeLineBreaks(tr.failureMessage ? tr.failureMessage.substring(0, 70) : ''));
            t.cell('Pending Reason', removeLineBreaks(tr.pendingReason ? tr.pendingReason.substring(0, 60) : ''));
            t.newRow()
        });
        console.log(t.toString());
    }

    private getWinstonInstance ():LoggerInstance {
        return new Winston.Logger({
            level: `debug`,
            transports: [
                new (Winston.transports.File)({ filename: this.jasmineResultFilePath })
            ]
        });
    }

    public extractIdsFromExistingTestCases (testCaseFilePaths:string[]):string[] {
        let results:string[] = [];
        for (let filePath of testCaseFilePaths) {
            if (textEndsWith(filePath, 'spec.js')) {
                let testCaseId = filePath.match(/\d{6,7}(\.\d{1,2})?/)[ 0 ];
                results.push(testCaseId);
            }
        }
        let duplicates = getDuplicates(results);
        if(duplicates.length) throw new Error(`Duplicate test cases found: ${duplicates.toString()}`);
        return results;
    }

    public jasmineStarted (data:any):void {
        winston.debug(`jasmineStarted`, { data });
    }

    public suiteStarted (data:any):void {
        winston.debug(`suiteStarted`, { data });
    }

    public specStarted (data:any):void {
        winston.debug(`specStarted`, { data });
    }

    public specDone (data:any):void {
        winston.debug(`specDone`, { data });
    }

    public suiteDone (data:any):void {
        winston.debug(`suiteDone`, { data });
    }

    public jasmineDone (data:any):void {
        winston.debug(`jasmineDone`, { data });
    }
}
