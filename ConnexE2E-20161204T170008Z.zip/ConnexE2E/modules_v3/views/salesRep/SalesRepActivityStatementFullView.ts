/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;
import { IView } from '../../interfaces/common/IView';
import Promise = protractor.promise.Promise;
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';

export class SalesRepActivityStatementFullView implements IView  {

    isViewDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('section.field-activity-statement'));
    }
}