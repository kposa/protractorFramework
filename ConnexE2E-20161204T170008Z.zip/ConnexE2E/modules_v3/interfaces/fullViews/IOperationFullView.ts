/// <reference path="../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;

export interface IOperationFullView {
    clickProposeButton(acctDescName:string):void;
    clickInvoiceButton(acctDescName:string):void;
    clickDeliveryButton(accountDescriptionName:string):void;
    clickAddAccountDescriptionButton():void;
}