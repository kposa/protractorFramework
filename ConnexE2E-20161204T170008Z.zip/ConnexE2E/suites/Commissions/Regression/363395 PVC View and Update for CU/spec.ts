/// <reference path="../../../../typings/index.d.ts" />

import { sharedViewAndUpdatePVCSteps } from '../shared/sharedViewAndUpdatePVCSteps';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { sharedViewAndUpdatePVCTestData } from '../shared/sharedViewAndUpdatePVCTestData';

const test = new TestCase(
    '363395',
    'PVC View and Update for CU',
    UserRole.MASTER_DATA,
    ApplicationFeature.COMMISSIONS
);

describe(test.stringify, () => {
    const td = new sharedViewAndUpdatePVCTestData('CU5', 'Commercial units');
    sharedViewAndUpdatePVCSteps(test.description, td);
});