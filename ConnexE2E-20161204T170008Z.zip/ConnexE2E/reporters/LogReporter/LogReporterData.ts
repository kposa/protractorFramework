export type LoggerDataTypes = JasmineStartedData | JasmineDoneData | SuiteDoneData | SpecDoneData | SuiteStartedData;

export interface LogItem {
    message:string;
    timestamp:string;
    data:LoggerDataTypes;
}

// -----------------------------------------------------------------------------

export interface JasmineStartedData {
    totalSpecsDefined:number;
}

export interface JasmineStartedLogItem extends LogItem {
    data:JasmineStartedData;
}

export interface JasmineDoneData {
    order:{
        random:boolean;
        seed:string;
    }
}

export interface JasmineDoneLogItem extends LogItem {
    data:JasmineDoneData;
}

// -----------------------------------------------------------------------------

export interface SuiteDoneData {
    id:string;
    description:string;
    fullName:string;
    failedExpectations:any[];
    status:string;
}

export interface SuiteDoneLogItem extends LogItem {
    data:SuiteDoneData;
}

// -----------------------------------------------------------------------------

export interface SpecDoneData {
    id:string;
    description:string;
    fullName:string;
    failedExpectations:FailedExpectation[];
    pendingReason:string;
    status:string;
    duration:string;
}

export interface FailedExpectation {
    matcherName:string;
    message:string;
    stack:string;
    passed:string;
    expected:string;
    actual:string;
}

export interface SpecDoneLogItem extends LogItem {
    data:SpecDoneData;
}

// -----------------------------------------------------------------------------

export interface SuiteStartedData {
    id:string;
    description:string;
    fullName:string;
    failedExpectations:FailedExpectation[];
}

export interface SuiteStartedLogItem extends LogItem {
    data:SuiteStartedData;
}