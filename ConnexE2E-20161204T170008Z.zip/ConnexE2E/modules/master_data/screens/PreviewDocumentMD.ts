/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

let emailIcon = $('div[ng-click="vm.showEmail()"]');
let sendButtonEnabled = $('button.pm-flat-button.primary');
let dialogBox = $('div.pm-expand.pm-vertical.email-entry-area');

export class PreviewDocumentMD {
    private messageSection = $('section.pm-expand.pm-text');
    private messageLabel = this.messageSection.$('div.pm-text-label');

    public isEmailIconDisplayed():Promise<boolean> {
        return emailIcon.isDisplayed();
    }

    public clickEmailIcon():void {
        clickElement(emailIcon);
    }

    public isPrintIconDisplayed():Promise<boolean> {
        let printIcon = $('div[ng-click="vm.printDocument()"]');
        return printIcon.isDisplayed();
    }

    public isEmailIconDialogBoxDisplayed():Promise<boolean> {
        return dialogBox.isDisplayed();
    }


    public isAddRecipientsDialogBoxDisplayed():Promise<boolean> {
        let addAdditionalRecipientsDisplay = $('div.entry-area-item-label.ng-binding').element(by.xpath('..'));
        let dialogFormDisplay = addAdditionalRecipientsDisplay.$('textarea[ng-model="vm.emailsEntered"]');
        return dialogFormDisplay.isDisplayed();
    }

    /* public isSendButtonInactive():Promise<boolean> { //TODO if test case needs it
     let sendButtonDisabled = $('button.pm-flat-button.disabled');
     return sendButtonDisabled.isDisplayed();
     }*/

    public isSendButtonEnabled():Promise<boolean> {
        return sendButtonEnabled.isDisplayed();
    }

    public clickSendButton():void {
        clickElement(sendButtonEnabled);
    }

    public verifyMessageLabel():Promise<String> {
        return this.messageLabel.getText();
    }

    public enterValueInStandardDisclaimerDialog(text:string):void {
        clickElement(this.messageLabel);
        let standardDisclaimerDialog = this.messageSection.$('textarea[ng-model="vm.value"]');
        standardDisclaimerDialog.sendKeys(text);
    }
}