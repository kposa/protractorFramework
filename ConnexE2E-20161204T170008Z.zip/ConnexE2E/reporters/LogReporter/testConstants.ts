import { testCaseIds } from '../../protractor.config';
export class TestCase {
    private _id:string;
    private _description:string;
    private _userRole:string;
    private _feature:string;

    constructor(id:string, description:string, userRole:string, feature:string) {
        this._id = this.verifyId(id);
        this._description = description;
        this._userRole = userRole;
        this._feature = feature;
    }

    public set id (value:string) {
        if(!/^\d{6,7}(?:\.\d{1,2})?$/.test(value)) {
            throw new Error(`Invalid test case id: ${value}. 
            Id must be 6-7 characters in length with an optional decimal point value`);
        }
        this._id = value;
    }

    public get id ():string {
        return this._id;
    }

    public get description ():string {
        return this._description;
    }

    public set description (value:string) {
        if(!/.{3,70}/.test(value))
            throw new Error(`Test case description must be between 3 and 70 characters in length`);
        this._description = value;
    }

    public set userRole (value:string) {
        this._userRole = value;
    }

    public get userRole ():string {
        return this._userRole;
    }

    public set feature (value:string) {
        this._feature = value;
    }

    public get feature ():string {
        return this._feature;
    }

    get stringify():string {
        return JSON.stringify(this);
    }

    private verifyId(id:string):string {
        if(testCaseIds.indexOf(id) < 0) {
            throw new Error(`Test case id was ${id}, but no test case exists with that id`);
        }
        return id;
    }
}

export class UserRole {
    public static CASH_APP:string = 'Cash App';
    public static IT_SUPPORT:string = 'IT Support';
    public static MASTER_DATA:string = 'Master Data';
    public static PROMOTER:string = 'Promoter';
    public static SALES_REP:string = 'Sales Representative';
    public static SALES_SUPPORT:string = 'Sales Support';
    public static ACCOUNT_MANAGER:string = 'Account Manager'
}

export class ApplicationFeature {
    public static ACTIVITY_STATEMENT:string = 'Activity Statement';
    public static AGENCIES:string = 'Agencies';
    public static AGREEMENTS:string = 'Agreements';
    public static COMMISSIONS:string = 'Commissions';
    public static DELIVERIES:string = 'Deliveries';
    public static DISCOUNTS:string = 'Discounts';
    public static EPAYMENTS:string = 'E-payments';
    public static INVOICING:string = 'Invoicing';
    public static NAVIGATIONS:string = 'Navigations';
    public static OPERATIONS:string = 'Operations';
    public static PAYMENTS:string = 'Payments';
    public static PROPOSALS:string = 'Proposals';
    public static REPORTING:string = 'Reporting';
    public static SEARCH:string = 'Search';
    public static SETTLEMENT:string = 'Settlement';
    public static OPERATION_PROFILE_TOOL:string = 'Operation Profile Tool';
    public static ACCOUNT_DESCRIPTION_ROLL:string = 'Account Description Roll';
    public static OPERATION_PROFILE:string = 'Operation Profile';
    public static OPERATION_MANAGEMENT:string = 'Operation management';
}