/// <reference path="../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import Promise = webdriver.promise.Promise;
import {Element} from '../../shared/Element';
import {Helpers} from "../../shared/Helpers";
import {filterElements, isActive, containingText } from "../../../modules_v3/helpers/filterElementHelpers";
import {textContainsText, formattedDate} from "../../../modules_v3/helpers/utilityHelpers";

let e = new Element();
let hlp = new Helpers();

export class ActivityStatementSS {

    private activityStatementParent = $('div.pm-list');
    private transactionRowsParent = $('ul.transaction-dates');
    private transactionDateRows = this.transactionRowsParent
        .$$('li[ng-repeat="balance in asvm.transactionDateBalances"]');

    private currentDateTransactionRow = filterElements(this.transactionDateRows, [
        isActive(true),
        containingText(formattedDate(1))
    ])().first();

    private currentDateTransactionTypes = this.currentDateTransactionRow
        .$(`ul.transaction-types-container`)
        .$$(`li[ng-repeat="type in balance.transactionTypeBalance"]`);

    private firstTransactionRow = this.transactionRowsParent.$('div[ng-click="asvm.balanceIsClicked(balance)"]');
    private transactionTypesContainer = $('ul.transaction-types-container');
    private rowItem = 'div.row-item';

    public collapseTransactionRow():void {
        e.clickElement(this.firstTransactionRow);
    }

    public expandTransactionRow():void {
        e.clickElement(this.firstTransactionRow);
    }

    public expandRetailValueRow():void {
        let retailValueRow = this.transactionRowsParent.$$('div.type-chevron').get(0);
        e.clickElement(retailValueRow);
    }

    public isQuantitySavingsDiscountDisplayed():Promise<boolean> {
        return this.activityStatementParent
            .getText()
            .then(text => {
                return textContainsText(text, "Quantity Savings Discount");
            });
    }

    public isEarlyPaySavingsDiscountDisplayed():Promise<boolean> {
        return this.activityStatementParent
            .getText()
            .then(text => {
                return textContainsText(text, "Early Pay Savings");
            });
    }


    public quantitySavingsDiscountAmountStore():string {
        let quantitySavingsDiscountRow = this.transactionRowsParent.$$('div[ng-click="asvm.typeIsClicked(type)"]').get(1);
        let quantitySavingsDiscountAmount = quantitySavingsDiscountRow.$$(this.rowItem).get(0);
        return quantitySavingsDiscountAmount.getText().toString();
    }

    public verifyDiscountNameInSecondSession(discountName: string):Promise<boolean> {
        return filterElements(this.currentDateTransactionTypes, [isActive(true), containingText(discountName)])()
            .count()
            .then(c => c === 1);
    }

    public isRowLabeledCPATypeExist(pv: string): Promise<boolean> {
        let competitivePriceAdjustmentType = this.transactionTypesContainer.$('div.flex-vertical.flex-expand').$$('div.name.semibold.flex-expand').get(0);
        return competitivePriceAdjustmentType.getText().then(function (txt) {
            txt = hlp.removeEverythingButLetters(txt);
            pv = hlp.removeEverythingButLetters(pv);
            return txt === pv;
        })
    }

    get is1RowContainsTodaysDate():Promise<boolean> {
        let firstDate = this.transactionRowsParent.$('div.date');
        return firstDate.getText().then(function (txt) {
            return txt === hlp.getFormattedDate(1);
        });
    }

    get isTransactionRowCollapsed():Promise<boolean> {
        return e.hasClass(this.firstTransactionRow, 'collapse');
    }

    get isTransactionRowHasValidAmountValue():Promise<boolean> {
        let transactionAmount = this.firstTransactionRow.$$(this.rowItem).get(0);
        return transactionAmount.getText().then(function (amt) {
            return hlp.validateAmountValue(amt);
        });
    }

    get isRetailValueRowHasValidAmountValue():Promise<boolean> {
        let retailValueRow = this.transactionRowsParent.$$('div[ng-click="asvm.typeIsClicked(type)"]').get(0);
        let retailValueAmount = retailValueRow.$$(this.rowItem).get(0);
        return retailValueAmount.getText().then(function (amt) {
            return hlp.validateAmountValue(amt);
        });
    }

    get isTransactionRowHasValidRunningBalanceValue():Promise<boolean> {
        let runningBal = this.firstTransactionRow.$$(this.rowItem).get(1);
        return runningBal.getText().then(function (amt) {
            return hlp.validateAmountValue(amt);
        });
    }

    get isSampleDiscountDisplayed():Promise<boolean> {
        let sampleDiscount = $('ul.transaction-types-container').$$('div.type').get(1);
        return sampleDiscount.getText().then(function (txt) {
            return txt === 'Sample Discount - 100.0%';
        })
    }

    get isSampleExistAfterRetailValueRowExpanded():Promise<boolean> {
        let sample = this.transactionRowsParent.$$('div.transaction-detail-row').get(1).$$('div.text').get(3);
        return sample.getText().then(function (txt) {
            return txt === 'Sample';
        })
    }

    get isSampleRetailValueEqualsSampleDiscountValue():Promise<boolean> {
        let sampleRetailValue = this.transactionRowsParent.$$('div.transaction-detail-row').get(1).$$('div.numeric').get(1);
        let sampleDiscountValue = this.transactionRowsParent.$$('div[ng-click="asvm.typeIsClicked(type)"]').get(1).$$('div.row-item').get(0);
        return sampleRetailValue.getText().then(function (srv) {
            return sampleDiscountValue.getText().then(function (sdv) {
                srv = hlp.removeEverythingButNumbersAndDecimals(srv);
                sdv = hlp.removeEverythingButNumbersAndDecimals(sdv);
                return srv === sdv;
            });
        });
    }

    get isRetailValueRowHasProductLineColumnWhenExpanded():Promise<boolean> {
        let productLine = this.transactionRowsParent.$('div.transaction-type-detail-header').$$('div.text').get(0);
        return productLine.getText().then(function (txt) {
            return txt === 'Product Line';
        });
    }

    get isRetailValueRowHasProductColumnWhenExpanded():Promise<boolean> {
        let product = this.transactionRowsParent.$('div.transaction-type-detail-header').$$('div.text').get(1);
        return product.getText().then(function (txt) {
            return txt === 'Product';
        });
    }

    get isRetailValueRowHasSubProductWhenExpanded():Promise<boolean> {
        let subProduct = this.transactionRowsParent.$('div.transaction-type-detail-header').$$('div.text').get(2);
        return subProduct.getText().then(function (txt) {
            return txt === 'Subproduct';
        });
    }

    get isRetailValueRowHasUnitsColumnWhenExpanded(): Promise<boolean>{
        let retailValue = this.transactionRowsParent.$('div.transaction-type-detail-header').$$('div.numeric').get(0);
        return retailValue.getText().then(function (txt) {
            return txt === 'Units';
        });
    }

    get isRetailValueRowHasRetailValueColumnWhenExpanded(): Promise<boolean>{
        let retailValue = this.transactionRowsParent.$('div.transaction-type-detail-header').$$('div.numeric').get(1);
        return retailValue.getText().then(function (txt) {
            return txt === 'Retail Value';
        });
    }

    get isRetailValueRowHasUpdatedByColumnWhenExpanded(): Promise<boolean>{
        let updatedBy = this.transactionRowsParent.$('div.transaction-type-detail-header').$$('div.text').get(4);
        return updatedBy.getText().then(function (txt) {
            return txt === 'Updated By';
        });
    }


    get isAmountValueEqualRunningBalance():Promise<boolean> {
        let amtValue = this.transactionRowsParent.$('div[ng-click="asvm.balanceIsClicked(balance)"]').$$(this.rowItem).get(0);
        let runningBal = this.transactionRowsParent.$('div[ng-click="asvm.balanceIsClicked(balance)"]').$$(this.rowItem).get(1);

        return amtValue.getText().then(function (amtValue) {
            return runningBal.getText().then(function (runningBal) {
                return amtValue === runningBal;
            });
        });
    }

    get isTransactionAmountEqualSumOfAllTransactionTypeAmounts():Promise<boolean> {
        let transactionAmount = this.firstTransactionRow.$$(this.rowItem).get(0);
        let retailValueAmount = this.transactionRowsParent
            .$$('div[ng-click="asvm.typeIsClicked(type)"]').first()
            .$$(this.rowItem).first();
        let epsAmount = this.transactionRowsParent
            .$$('div[ng-click="asvm.typeIsClicked(type)"]').get(1)
            .$$(this.rowItem).first();
        let quantitySavingsDiscountAmount = this.transactionRowsParent
            .$$('div[ng-click="asvm.typeIsClicked(type)"]').get(2)
            .$$(this.rowItem).get(0);

        return protractor.promise
            .all([
                transactionAmount.getText(),
                retailValueAmount.getText(),
                epsAmount.getText(),
                quantitySavingsDiscountAmount.getText()
            ])
            .then(results => {
                const [ totalAmount, retailValue, espValue, qsdValue ] = results
                    .map(value => value.replace(/[^0-9.]/g, ''))
                    .map(value => parseFloat(value));

                return totalAmount === (retailValue - espValue - qsdValue);
            });
    }
}