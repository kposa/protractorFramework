/// <reference path="../../../../typings/index.d.ts" />

import MasterDataMasterSearchFullView from '../../../../modules_v3/views/masterData/MasterDataMasterSearchFullView';
import MasterDataCommissionsTabFullView from '../../../../modules_v3/views/masterData/MasterDataCommissionsTabFullView';
import { MasterDataOtherCommissionsFullView } from '../../../../modules_v3/views/masterData/MasterDataOtherCommissionsFullView';
import { MasterDataProductValueCommissionFullView } from '../../../../modules_v3/views/masterData/MasterDataProductValueCommissionFullView';
import { sharedOtherCommissionTestData } from '../shared/sharedOtherCommissionTestData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
    '440848',
    'Add-Upd-Del Other Commissions w/Classification for YOY Acre Growth',
    UserRole.MASTER_DATA,
    ApplicationFeature.COMMISSIONS
);

describe(test.stringify, () => {
    const masterDataMasterSearchFullView = new MasterDataMasterSearchFullView();
    const masterDataCommissionsTabFullView = new MasterDataCommissionsTabFullView();
    const masterDataOtherCommissionsFullView = new MasterDataOtherCommissionsFullView();
    const masterDataPVCFullView = new MasterDataProductValueCommissionFullView();
    const td = new sharedOtherCommissionTestData();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.masterDataUser);

            // select a random sales agency
            masterDataMasterSearchFullView.search(td.randSalesAgencyId);
            masterDataMasterSearchFullView.selectFilterContainingText('Sales agencies');
            masterDataMasterSearchFullView.clickSearchResultContainingText(td.randSalesAgencyId);

            // navigate to the sales agency Other Commission screen
            masterDataCommissionsTabFullView.clickTabContainingText('Commission');
            masterDataCommissionsTabFullView.clickCardContainingText('Other Commission');

            // add a new commission with classification
            masterDataOtherCommissionsFullView.addCommission('With classification');

            // select a sales year
            masterDataOtherCommissionsFullView.selectSalesYear(td.salesPeriod.year.toString());

            // select a classification
            masterDataOtherCommissionsFullView.selectClassification('C1');

            // select a program
            masterDataOtherCommissionsFullView.selectProgram('SAM');

            // select a type
            masterDataOtherCommissionsFullView.selectType('YOY Acre Growth');

            // verify negative numbers are not allowed in percent field
            masterDataOtherCommissionsFullView.enterPercentValue('-1');
            expect(masterDataOtherCommissionsFullView.getPercentValue()).toEqual('1');

            // verify that the required message appears when the field is selected and then deselected
            masterDataOtherCommissionsFullView.clearPercentField();

            // expecting the required message, but it doesn't appear for Revenue Growth
            expect(masterDataOtherCommissionsFullView.verifyPercentFieldIsRequired('Required')).toBeTruthy();

            // verify only 2 decimal places are allowed
            masterDataOtherCommissionsFullView.enterPercentValue('12.345');
            expect(masterDataOtherCommissionsFullView.getPercentValue()).toEqual('12.34');

            // attempt to enter 0 as a percent
            masterDataOtherCommissionsFullView.enterPercentValue('0');

            // verify number of acres to grow is required
            masterDataOtherCommissionsFullView.verifyAcreNumberFieldIsRequired('Required');

            // verify 0% is not allowed
            expect(masterDataOtherCommissionsFullView.getPercentValue()).toEqual('');

            // enter a valid percent
            masterDataOtherCommissionsFullView.enterPercentValue(td.randomValue);

            // enter a valid number of acres to grow
            masterDataOtherCommissionsFullView.enterNumberOfAcresToGrow(td.randomValueTwo);

            // select product line
            masterDataPVCFullView.selectItemFromProductLineDropDownAcreGrowth('010 - Corn');

            // click Save & Add
            masterDataOtherCommissionsFullView.clickSalesAgencyOtherCommissionsSave('Save & Add');

            // configure a second commission
            masterDataOtherCommissionsFullView.selectSalesYear(td.salesPeriod.year.toString());
            masterDataOtherCommissionsFullView.selectClassification('C2');
            masterDataOtherCommissionsFullView.selectProgram('SAM');
            masterDataOtherCommissionsFullView.selectType('YOY Acre Growth');
            masterDataOtherCommissionsFullView.enterPercentValue(td.randomValueTwo);
            masterDataOtherCommissionsFullView.enterNumberOfAcresToGrow(td.randomValue);
            masterDataPVCFullView.selectItemFromProductLineDropDownAcreGrowth('050 - Soybeans');

            // save the new commissions
            masterDataOtherCommissionsFullView.clickSalesAgencyOtherCommissionsSave('Save & Close');

            // attempt to delete the first commission row then cancel
            masterDataOtherCommissionsFullView.removeFirstCommissionRow();
            masterDataOtherCommissionsFullView.clickCancelDeleteConfirmation('Cancel');

            // delete the commission
            masterDataOtherCommissionsFullView.removeFirstCommissionRow();
            masterDataOtherCommissionsFullView.clickCancelDeleteConfirmation('Delete');

            // edit the remaining commission row
            masterDataOtherCommissionsFullView.editFirstCommissionRow();
            masterDataOtherCommissionsFullView.selectProgram('Accelerated');

            // save the changes
            masterDataOtherCommissionsFullView.saveAfterEdit();

            // delete the remaining commission row
            masterDataOtherCommissionsFullView.removeFirstCommissionRow();
            masterDataOtherCommissionsFullView.clickCancelDeleteConfirmation('Delete');
        }, fail);
    });
});