/// <reference path="../../../../typings/index.d.ts" />

import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
	'291321',
	'FCT- SSS - Account Description 100% - Shares Locked and Inactive Account description',
	UserRole.SALES_SUPPORT,
	ApplicationFeature.INVOICING
);

describe(test.stringify, () => {

	itw(test.description, () => {

	}, 'Test case needs to be looked into. Either need to sit down and figure out CPA or trash this test');
});