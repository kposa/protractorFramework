/// <reference path="../../typings/index.d.ts" />

const fs = require('fs');
const path = require('path');

export function getAllFilePathsWithinDirectory (dir:string):string[] {
    var results:string[] = [];
    var list = fs.readdirSync(dir);
    for(let file of list) {
        file = path.join(dir, file);
        var stat = fs.statSync(file);
        if (stat && stat.isDirectory()) results = results.concat(getAllFilePathsWithinDirectory(file));
        else results.push(file);
    }
    return results;
}
