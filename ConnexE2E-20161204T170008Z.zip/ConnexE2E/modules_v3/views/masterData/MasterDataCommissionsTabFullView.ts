/// <reference path='../../../typings/index.d.ts' />
import Promise = protractor.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;

import {ICommissionsTabFullView} from "../../interfaces/fullViews/ICommissionsTabFullView";
import { filterElements, matchingText, containingText, isActive } from '../../helpers/filterElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';
import { IView } from '../../interfaces/common/IView';
import { NotImplementedError } from '../../../common/exception/exceptions';

export default class MasterDataCommissionsTabFullView implements IView, ICommissionsTabFullView {
    private items = $$(`md-list-item[ng-repeat='item in vm.commissionList']`);
    private tabs = $$(`md-tab-item[ng-repeat='tab in $mdTabsCtrl.tabs']`);
    private cards = $$(`md-card.md-whiteframe-z2[ui-sref^='commissions']`);

    /**
     * Returns if current year commission exists on the page
     * @returns {Promise<boolean>}
     */

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    /**
     * Returns if given year commission exists on the page
     * the current, previous and next methods seem redundant may need to remove
     * @returns {Promise<boolean>}
     */
    hasGivenYearCommission(givenYear: number):Promise<boolean> {
        const matchingPreviousYear = containingText(givenYear.toString(10), e => e.$(`div.md-list-item-text`));
        return filterElements(this.items, [matchingPreviousYear])().count().then(c => c > 0);
    }

    /**
     * Click given year commission
     */
    clickGivenYearCommission(givenYear: number):void {
        const strGivenYear = givenYear.toString();
        const matchingGivenYear = containingText(strGivenYear, e => e.$(`div.md-list-item-text`));
        clickElement(filterElements(this.items, [matchingGivenYear])().first());
    }

    getItemCount():Promise<number> {
        return this.items.count();
    }

    getItemMatchingText(text:string):ElementFinder {
        return filterElements(this.items, [isActive(true), matchingText(text)])().first();
    }

    getItemContainingText(text:string):ElementFinder {
        return filterElements(this.items, [isActive(true), containingText(text)])().first();
    }

    clickItemMatchingText(text:string):void {
        clickElement(filterElements(this.items, [isActive(true), matchingText(text)])().first());
    }

    clickItemContainingText(text:string):void {
        clickElement(filterElements(this.items, [isActive(true), containingText(text)])().first());
    }

    clickTabMatchingText(text:string):void {
        clickElement(filterElements(this.tabs, [isActive(true), matchingText(text)])().first());
    }

    clickTabContainingText(text:string):void {
        clickElement(filterElements(this.tabs, [isActive(true), containingText(text)])().first());
    }

    clickCardMatchingText(text:string):void {
        clickElement(filterElements(this.cards, [isActive(true), matchingText(text)])().first());
    }

    clickCardContainingText(text:string):void {
        clickElement(filterElements(this.cards, [isActive(true), containingText(text)])().first());
    }
}