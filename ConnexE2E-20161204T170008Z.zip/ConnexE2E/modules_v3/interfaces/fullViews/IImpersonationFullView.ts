/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;
import {ISearchableWithResultsView} from "../common/ISearchableWithResultsView";

export interface IImpersonationFullView extends ISearchableWithResultsView {
}