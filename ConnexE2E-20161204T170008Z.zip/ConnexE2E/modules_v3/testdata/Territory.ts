import {Entity} from "./Entity";
export interface Territory extends Entity {

}