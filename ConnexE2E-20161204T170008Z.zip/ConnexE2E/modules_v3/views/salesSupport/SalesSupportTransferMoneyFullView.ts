/// <reference path='../../../typings/index.d.ts' />
import ElementFinder = protractor.ElementFinder;

import {ITransferMoneyFullView} from '../../interfaces/fullViews/ITransferMoneyFullView';

import { clickElement } from '../../helpers/clickElementHelpers';
import { filterElements, isActive, matchingText } from '../../helpers/filterElementHelpers';
import { NotImplementedError } from '../../../common/exception/exceptions';
import Promise = protractor.promise.Promise;
import { IView } from '../../interfaces/common/IView';

export default class SalesSupportTransferMoneyFullView implements IView, ITransferMoneyFullView {
    private element:ElementFinder = $('section.transfer-money');
    private transferFromDropdown:ElementFinder = this.element.$('transfer-from');
    private transferToDropdown:ElementFinder = this.element.$('transfer-to');
    private amount:ElementFinder = this.element.$(`section[value='vm.transferAmount']`).$(`div.pm-text-clickable-area`);
    private transferButton:ElementFinder = this.element.$(`button[ng-click='vm.transferMoney()']`);

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    selectTransferFromByInvoiceNameAndSalesPeriodName(invoiceName:string, salesperiodName:string):void {
        clickElement(this.transferFromDropdown);

        const salesperiod = filterElements(this.transferFromDropdown.$$(`div[ng-repeat='group in vm.salesPeriods']`), [
            isActive(true),
            matchingText(salesperiodName, e => e.$(`span.subheader`))
        ])().first();

        const invoice = filterElements(salesperiod.$$(`div[ng-repeat='from in vm.fromBySalesPeriod(group)']`), [
            isActive(true),
            matchingText(invoiceName, e => e.$(`div.pm-listitem-primary`))
        ])().first();

        clickElement(invoice);
    }

    selectTransferToByInvoiceNameAndSalesPeriodName(invoiceName:string, salesperiodName:string):void {
        clickElement(this.transferToDropdown);

        const salesperiod = filterElements(this.transferToDropdown.$$(`div[ng-repeat='group in vm.salesPeriods']`), [
            isActive(true),
            matchingText(salesperiodName, e => e.$(`span.subheader`))
        ])().first();

        const invoice = filterElements(salesperiod.$$(`div[ng-repeat='to in vm.toBySalesPeriod(group)']`), [
            isActive(true),
            matchingText(invoiceName, e => e.$(`div.pm-listitem-primary`))
        ])().first();

        clickElement(invoice);
    }

    enterAmount(amount:number):void {
        clickElement(this.amount);

        this.amount.getText().then(text => {
            const backspaces = Array(text.length).join(protractor.Key.BACK_SPACE);
            browser.actions().mouseMove(this.amount.$(`input`).getWebElement()).sendKeys(backspaces).perform();
        });

        browser.actions().mouseMove(this.amount.$(`input`).getWebElement()).sendKeys(amount.toString(10)).perform();
    }

    clickTransferButton():void {
        clickElement(this.transferButton);
    }

}