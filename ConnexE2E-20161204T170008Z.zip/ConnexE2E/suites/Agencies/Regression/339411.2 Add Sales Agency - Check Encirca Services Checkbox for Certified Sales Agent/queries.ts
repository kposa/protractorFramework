export interface agenciesWithCertifiedSalesAgentResults {
    agencyId: string
}

export function agenciesWithCertifiedSalesAgent () {
    const {E2EOperationsDatabaseName} = process.env;
    return `
    
select agencyId from ${E2EOperationsDatabaseName}.masterdata.AgencyPerson where IsCertifiedSalesAgent = 1 

`;
}


