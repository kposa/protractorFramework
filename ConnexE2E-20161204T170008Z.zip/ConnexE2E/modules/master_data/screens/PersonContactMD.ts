/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import { filterElements, isActive, containingText } from '../../../modules_v3/helpers/filterElementHelpers';
import ElementArrayFinder = protractor.ElementArrayFinder;
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';
import { isAriaChecked } from '../../../modules_v3/helpers/utilityElementHelpers';

export class PersonContactMD {

    private numberTypeDropdown = $('md-select[ng-model="ph.phoneNumberTypeId"]');
    private allTrashCans:ElementArrayFinder = $$('button[aria-label="Delete Person Phone Number"]');

    public clickSameAsAgencyPhoneButton(): void {
        let sameAsAgencyPhone = $('button[ng-click="vm.assignAgencyPhoneNumber()"]');
        clickElement(sameAsAgencyPhone);
    }

    public clickGenerateButton(): void {
        let generateButton = $('button[ng-click="vm.generateUserId()"]');
        clickElement(generateButton);
    }

    private clickFirstTrashCan(): void {
        clickElement(this.allTrashCans.get(0));
    }

    public removeAllNumbers(): void {
        this.clickFirstTrashCan();
        this.allTrashCans.count().then((cnt) => {
            if(cnt > 0) this.removeAllNumbers();
        })
    }

    public getNumberTypeDropdownOptions(): ElementArrayFinder {
        let allResults = $$('md-option[ng-repeat="pt in vm.phoneNumberTypes | filterPhoneType : ' +
            'vm.phoneTypesToRestrict: ph.phoneNumberTypeId : vm.personPhoneNumbers"]')
            .$$('div.md-text');
        return allResults;
    }

    public clickAddButton(): void {
        let addButton = $('button[aria-label="Add Person Phone Number"]');
        clickElement(addButton);
    }

    public updateAgencyEmailId(emailId: string): void {
        let agencyEmailInputContainer = $('input[ng-model="vm.email"]');
        agencyEmailInputContainer.clear();
        agencyEmailInputContainer.sendKeys(emailId);
    }

    public enterNumber(phoneNumber: string): void {
        let numberInputContainer = $$('input[ng-model="ph.phoneNumber"]').get(0);
        numberInputContainer.clear();
        numberInputContainer.sendKeys(phoneNumber);
    }

    public clickNumberTypeDropdown(): void {
        clickElement(this.numberTypeDropdown);
    }

    public selectOptionFromTypeDropdown(type: string): void {
        let dropdownOption =filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(type)
            ]
        )().first();
        clickElement(dropdownOption);
    }

    public isPrimaryRadioButtonChecked(): Promise<boolean> {
        return isAriaChecked($('md-radio-button[name="isPrimary"]'));
    }

}