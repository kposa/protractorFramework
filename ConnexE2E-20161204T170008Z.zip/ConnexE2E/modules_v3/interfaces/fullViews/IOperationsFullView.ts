/// <reference path="../../../typings/index.d.ts" />

import {ISearchableWithResultsView} from "../common/ISearchableWithResultsView";

export interface IOperationsFullView extends ISearchableWithResultsView {
    clickFirstGreenInvoiceButton(): void;
    clickFirstGreenDeliveriesButton(): void;
}