/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

export class ButtonMD {

    public clickAddIcon(): void {
        let addIcon = $('button.md-fab');
        clickElement(addIcon);
    }
    
    public clickBackButton(): void {
        let backButton = $('md-icon.back-button');
        clickElement(backButton);
    }

    public clickPreviousButton(): void {
        let previousButton = $('div[ng-if="vm.showPreviousLink"]');
        clickElement(previousButton);
    }

    public clickSaveButton(): void {
        let saveButton = $('button[ng-if="vm.showSave"]');
        clickElement(saveButton);
    }

    public clickNextButton(): void {
        let nextButton = $('button[ng-if="vm.showNextLink"]');
        clickElement(nextButton);
    }

    public clickDeleteIcon(): void {
        let deleteIcon = $$('div.material-icons.md-24.delete-icon').get(1);
        clickElement(deleteIcon);
    }

    public clickAddButton(): void {
        let addButton = $('button[ng-click="vm.setSubmitAttempted()"]');
        clickElement(addButton);
    }

    public clickClearButton(): void {
        let clearButton = $('button[ng-click="vm.clear()"]');
        clickElement(clearButton);
    }
}