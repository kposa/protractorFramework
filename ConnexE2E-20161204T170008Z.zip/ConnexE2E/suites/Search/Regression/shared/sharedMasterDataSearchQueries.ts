/// <reference path="../../../../typings/index.d.ts" />

const { E2EInvoicesDatabaseName, E2EOperationsDatabaseName } = process.env;

export interface organizationalUnitResults {
    searchTerm: string;
}

export function organizationalUnit (salesPeriodId: number, organizationalUnitId: string) {
    // Business Partners are queried from a different table
    if (organizationalUnitId === 'BP') {
        return `
        select distinct top 100
               c.name as searchTerm
        from ${E2EInvoicesDatabaseName}.dbo.customer as c
        `;
    }

    return `
    select distinct
           ou.name as searchTerm
    from ${E2EOperationsDatabaseName}.masterdata.organizationalunit as ou
    join ${E2EOperationsDatabaseName}.dbo.salesperiod as sp on sp.salesperiodid = ${salesPeriodId}
    where ou.organizationalunittypeid = '${organizationalUnitId}'
    and ou.timeperiodid = sp.salesperiodid
    `;
}