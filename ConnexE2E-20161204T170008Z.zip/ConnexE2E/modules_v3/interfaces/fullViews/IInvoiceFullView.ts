/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;

export interface IInvoiceFullView {
    addLineItem():void;
    clickPreviewInvoice():void;
    clickShowButtonToPreviewInvoice():void;
}