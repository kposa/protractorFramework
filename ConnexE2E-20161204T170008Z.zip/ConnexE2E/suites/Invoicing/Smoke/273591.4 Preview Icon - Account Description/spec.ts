/// <reference path="../../../../typings/index.d.ts" />

import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import sharedSalesRepPreviewSteps from '../shared/sharedSalesRepPreviewSteps';
import { sharedSalesRepTestData } from '../shared/sharedSalesRepPreviewTestData';

const test = new TestCase(
    '273591.4',
    'Preview Icon - Account Description',
    UserRole.SALES_REP,
    ApplicationFeature.INVOICING
);

describe(test.stringify, () => {
    const td = new sharedSalesRepTestData();
    td.invoiceAbsent = true;
    td.screen = 'account description';
    sharedSalesRepPreviewSteps(test.description, td);
});