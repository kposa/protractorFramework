/// <reference path="../../../typings/index.d.ts" />

import Promise = protractor.promise.Promise;
import {IClosableView} from "../common/IClosableView";

export interface IUnitsCalculatorDrawerPartialView extends IClosableView {
    getQuantity():Promise<number>;
    quantityIsPopulated():Promise<boolean>;
    fillInputAcres(value: number):void;
    clearInputAcres():void;
    fillInputPlantingRate(value: number):void;
    clearInputPlantingRate():void;
    getAdjustedUnits():Promise<number>;
    adjustedUnitsIsPopulated():Promise<boolean>;
    submit():void;
}