/// <reference path="../../../../typings/index.d.ts" />

import { SearchMD2 } from "../../../../modules/master_data/screens/SearchMD2";
import { bootstrap } from "../../../SharedSteps/bootstrap";
import { ButtonMD } from '../../../../modules/master_data/shared/ButtonMD';
import { WarehouseMD } from '../../../../modules/master_data/screens/WarehouseMD';
import { WarehouseAddressMD } from '../../../../modules/master_data/screens/WarehouseAddressMD';
import { itw } from '../../../../modules_v3/helpers/itw';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import TestData382287 from '../382287 Warehouse Master Data Warehouse Publish includes agency name/testData';

const test = new TestCase(
	'341360.1',
	'Search Remove match on address from main search result for Warehouse',
	UserRole.MASTER_DATA,
	ApplicationFeature.SEARCH
);

describe(test.stringify, () => {
    const td = new TestData382287();
    let searchMD = new SearchMD2();
    let warehouseMD = new WarehouseMD();
    let warehouseAddressMD = new WarehouseAddressMD();
    let buttonMD = new ButtonMD();

    itw(test.description, () => {
        td.populatePromise().then(() => {

            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.masterDataUser);

            //should search warehouse by warehouse name
            searchMD.searchByCriteria(td.warehouseName);
            searchMD.clickCategory('Warehouses');

            //should check if search result includes warehouse details
            expect(searchMD.getSearchResultContentByContainingHeadline(td.warehouseName)).toContain('Warehouse');
            expect(searchMD.getSearchResultContentByContainingHeadline(td.warehouseName)).toContain(td.street1);
            expect(searchMD.getSearchResultContentByContainingHeadline(td.warehouseName)).toContain(td.city);
            expect(searchMD.getSearchResultContentByContainingHeadline(td.warehouseName)).toContain(td.postalCode);

            // should select the Warehouse
            searchMD.selectSearchResultByResultType('Warehouse');

            //should go the address page and update street address 1
            warehouseMD.selectCard('Warehouse Address');
            warehouseAddressMD.updateStreetAddress1(td.warehouseName);
            buttonMD.clickSaveButton();

            // should go to the search page
            buttonMD.clickBackButton();

            //should search warehouse by its name
            searchMD.searchByCriteria(td.warehouseName);
            searchMD.clickCategory('Warehouses');

            //Should verify if user searches warehouse by its name which matches with street address 1
            // then warehouse details should be displayed
            expect(searchMD.getSearchResultContentByContainingHeadline(td.warehouseName)).toContain('Warehouse');
            expect(searchMD.getSearchResultContentByContainingHeadline(td.warehouseName)).toContain(td.city);
            expect(searchMD.getSearchResultContentByContainingHeadline(td.warehouseName)).toContain(td.postalCode);

            // should enter the original street address 1
            searchMD.selectSearchResultByResultType('Warehouse');
            warehouseMD.selectCard('Warehouse Address');
            warehouseAddressMD.updateStreetAddress1(td.street1);
            buttonMD.clickSaveButton();

        }, fail);
    });
});