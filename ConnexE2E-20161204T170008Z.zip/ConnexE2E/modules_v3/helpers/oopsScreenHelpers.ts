/// <reference path="../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;
import Promise = protractor.promise.Promise;
import { filterElements, isActive } from './filterElementHelpers';
import filter = webdriver.promise.filter;
import QueryService from '../services/QueryService/index';

export function checkForOopsScreen ():void {
    const oopsScreens = $$('span.global-exception-icon');
    filterElements(oopsScreens, [ isActive(true) ])().count().then(c => {
        if (c > 0) handleOopsScreen();
    });
}

function handleOopsScreen ():void {
    browser.executeScript(`return sessionStorage.getItem('telemetry-session');`).then((sessionId:string) => {
        queryTelemetry(sessionId).then((telemetry) => {
            throw new Error(`Oops: ${sessionId} ${telemetry}`);
        });
    });
    closeOopsScreen();
}

function closeOopsScreen ():void {
    const closeButtons = $$('section.modal').$$('div.close-button');
    filterElements(closeButtons, [ isActive(true) ])().first().click();
}

export function closePopupNotifications ():void {
    let allNotificationItems = $$('div.notifications-popup').$$('p.notification-text');
    filterElements(allNotificationItems, [ isActive(true) ])().count().then(c => {
        if (c > 0) {
            closeNotificationBackDropIfDisplayed();
        }
    });
}

function closeNotificationBackDropIfDisplayed ():void {
    const allBackdrops = filterElements($$('div[ng-click="vm.toggleNotificationsListDisplay()"]'), [ isActive(true) ])();

    allBackdrops.count().then(c => {
        if (c === 1) {
            allBackdrops.first().click();
        }
    });
}

interface telemetryResults {
    description:string;
    stack:string;
}

function queryTelemetry (sessionId:string):Promise<string> {
    const sql = `
    use telemetry
    select top 100 * from dbo.WebServiceError 
    where SessionId = '${sessionId}' 
    order by OccurredOn desc`;

    const { E2EInvoicesDatabaseName, E2EInvoicesDBConnection } = process.env;
    let qs = new QueryService(E2EInvoicesDatabaseName, E2EInvoicesDBConnection);
    const results = qs.executeSql<telemetryResults>(sql);

    console.log(`\nAn Oops screen occurred: ${sessionId}`);

    return results
        .then(data => {
            console.log(`Telemetry: ${JSON.stringify(data, null, 2)}`);
            return data.map((row) => {
                return row.description
            }).join(' | ');
        }, (e) => {
            return `Telemetry found no results. ${e}`;
        });
}