/// <reference path="../../../../typings/index.d.ts" />

import { sharedViewAndUpdatePVCSteps } from '../shared/sharedViewAndUpdatePVCSteps';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { sharedViewAndUpdatePVCTestData } from '../shared/sharedViewAndUpdatePVCTestData';

const test = new TestCase(
	'332654',
	'PVC View and Update for Countries',
	UserRole.MASTER_DATA,
	ApplicationFeature.COMMISSIONS
);

describe(test.stringify, () => {
    const td = new sharedViewAndUpdatePVCTestData('USA Sales', 'Countries');
    sharedViewAndUpdatePVCSteps(test.description, td);
});