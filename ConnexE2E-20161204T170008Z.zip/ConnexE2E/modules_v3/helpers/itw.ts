///<reference path="../../typings/index.d.ts"/>

/**
 * Wrapper for jasmine's it function
 * Allows for easy pending of it blocks
 * @param description
 * @param fn
 * @param pending
 */
export function itw (description: string, fn: (done?: () => void) => void, pending?: string) {
    pending ? xit(description, fn).pend(pending) : it(description, fn);
}