/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;
import { IView } from '../../interfaces/common/IView';
import Promise = protractor.promise.Promise;
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';
import { clickElement } from '../../helpers/clickElementHelpers';
import { filterElements, isActive, containingText, matchingText } from '../../helpers/filterElementHelpers';
import { IClosableView } from '../../interfaces/common/IClosableView';
import { IBackNavigableView } from '../../interfaces/common/IBackNavigableView';

export class SalesRepChargesAndCreditsFullView implements IView, IBackNavigableView {

    public chargeCreditLineItemSection = new ChargeCreditLineItemSection();
    public chargeCredditAdjustmentSection = new ChargeCredditAdjustmentSection();
    public chargeCreditUnitsSection = new ChargeCreditUnitsSection();

    isViewDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('section.chargesandcredits'));
    }

    clickBack () {
        clickElement($('div[ng-click="vm.back()"]'));
    }

    clickAddButton () {
        clickElement($('button[ng-click="sharevm.add()"]'));
    }

    getRecentlyAddedChargeAndCreditAmount ():Promise<string> {
        return $('div.lineitem-amount.semibold').getText();
    }
}

class ChargeCreditLineItemSection implements IView, IClosableView {

    private section = $('section.chargecreditlineitem');

    isViewDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed(this.section);
    }

    close () {
        clickElement(this.section.$('div[data-ng-click="lineItemVM.close()"]'));
    }

}

class ChargeCredditAdjustmentSection implements IView {

    private section = $('section.chargecreditadjustment');

    isViewDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed(this.section);
    }

    selectItem (item:string):void {
        this.section.isDisplayed().then((y)=> {
            if (y) clickElement(filterElements($$('li[ng-repeat*="item in adjustmentvm.list"]'), [ isActive(true), containingText(item, e => e.$(`div.program`)) ])().first());
        });
    }

}

class ChargeCreditUnitsSection implements IView, IClosableView {

    private section = $('section.chargecreditunits');

    isViewDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed(this.section);
    }

    close () {
        clickElement(this.section.$('div[ng-click="unitsvm.close()"]'));
    }

    enterUnits (units:string) {
        units.split('').forEach(digit => {
            let keypadDigit = filterElements($$('td[ng-click*="unitsvm.drawer.keypad.addDigit"]'), [ isActive(true), matchingText(digit) ])().first();
            clickElement(keypadDigit);
        });
        this.close();
    }

}