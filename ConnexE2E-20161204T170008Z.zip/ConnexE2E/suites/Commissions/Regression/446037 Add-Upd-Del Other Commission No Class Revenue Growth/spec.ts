/// <reference path="../../../../typings/index.d.ts" />

import MasterDataMasterSearchFullView from '../../../../modules_v3/views/masterData/MasterDataMasterSearchFullView';
import MasterDataCommissionsTabFullView from '../../../../modules_v3/views/masterData/MasterDataCommissionsTabFullView';
import { MasterDataOtherCommissionsFullView } from '../../../../modules_v3/views/masterData/MasterDataOtherCommissionsFullView';
import { sharedOtherCommissionTestData } from '../shared/sharedOtherCommissionTestData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
    '446037',
    'Add-Upd-Del Other Commissions w/out Classification for Revenue Growth',
    UserRole.MASTER_DATA,
    ApplicationFeature.COMMISSIONS
);

describe(test.stringify, () => {
    const masterDataMasterSearchFullView = new MasterDataMasterSearchFullView();
    const masterDataCommissionsTabFullView = new MasterDataCommissionsTabFullView();
    const masterDataOtherCommissionsFullView = new MasterDataOtherCommissionsFullView();
    const td = new sharedOtherCommissionTestData();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.masterDataUser);

            // select a random sales agency
            masterDataMasterSearchFullView.search(td.randSalesAgencyId);
            masterDataMasterSearchFullView.selectFilterContainingText('Sales agencies');
            masterDataMasterSearchFullView.clickSearchResultContainingText(td.randSalesAgencyId);

            // navigate to the sales agency Other Commission screen
            masterDataCommissionsTabFullView.clickTabContainingText('Commission');
            masterDataCommissionsTabFullView.clickCardContainingText('Other Commission');

            // add a new commission with classification
            masterDataOtherCommissionsFullView.addCommission('Without classification');

            // configure a Revenue Growth commission
            masterDataOtherCommissionsFullView.selectSalesYear(td.salesPeriod.year.toString());
            masterDataOtherCommissionsFullView.selectProgram('Exclusivity');
            masterDataOtherCommissionsFullView.selectType('Revenue Growth');

            // check the exclude boxes
            masterDataOtherCommissionsFullView.toggleExcludeFromPVC();
            masterDataOtherCommissionsFullView.toggleExcluseFromBaseRevenue();

            // verify negative numbers are not allowed in percent field
            masterDataOtherCommissionsFullView.enterPercentValue('-1');
            expect(masterDataOtherCommissionsFullView.getPercentValue()).toEqual('1');

            // verify that the required message appears when the field is selected and then deselected
            masterDataOtherCommissionsFullView.clearPercentField();

            // expecting the required message, but it doesn't appear for Revenue Growth
            //expect(masterDataOtherCommissionsFullView.verifyPercentFieldIsRequired('Required')).toBeTruthy();

            // verify only 2 decimal places are allowed
            masterDataOtherCommissionsFullView.enterPercentValue('12.345');
            expect(masterDataOtherCommissionsFullView.getPercentValue()).toEqual('12.34');

            // attempt to enter 0 as a percent
            masterDataOtherCommissionsFullView.enterPercentValue('0');

            // select a growth year
            masterDataOtherCommissionsFullView.selectGrowthYear((td.salesPeriod.year - 1).toString());

            // verify 0% is not allowed
            expect(masterDataOtherCommissionsFullView.getPercentValue()).toEqual('');

            // enter a valid percent value
            masterDataOtherCommissionsFullView.enterPercentValue(td.randomValue);

            // click Save & Add
            masterDataOtherCommissionsFullView.clickSalesAgencyOtherCommissionsSave('Save & Add');

            // configure a second Revenue Growth commission
            masterDataOtherCommissionsFullView.selectSalesYear(td.salesPeriod.year.toString());
            masterDataOtherCommissionsFullView.selectProgram('Rep Retention');
            masterDataOtherCommissionsFullView.selectType('Revenue Growth');

            // check the exclude boxes
            masterDataOtherCommissionsFullView.toggleExcludeFromPVC();
            masterDataOtherCommissionsFullView.toggleExcluseFromBaseRevenue();

            // enter a valid percent value for the second commission
            masterDataOtherCommissionsFullView.enterPercentValue(td.randomValueTwo);

            // select a growth year
            masterDataOtherCommissionsFullView.selectGrowthYear((td.salesPeriod.year - 1).toString());

            // click Save & Close
            masterDataOtherCommissionsFullView.clickSalesAgencyOtherCommissionsSave('Save & Close');

            // start to delete the first row then cancel
            masterDataOtherCommissionsFullView.removeFirstCommissionRow();
            masterDataOtherCommissionsFullView.clickCancelDeleteConfirmation('Cancel');

            // actually delete the first row
            masterDataOtherCommissionsFullView.removeFirstCommissionRow();
            masterDataOtherCommissionsFullView.clickCancelDeleteConfirmation('Delete');

            // open one of the remaining rows for editing
            masterDataOtherCommissionsFullView.editFirstCommissionRow();

            // change the program drop down selection
            masterDataOtherCommissionsFullView.selectProgram('Other');

            // save the change
            masterDataOtherCommissionsFullView.saveAfterEdit();

            // actually delete a second row
            masterDataOtherCommissionsFullView.removeFirstCommissionRow();
            masterDataOtherCommissionsFullView.clickCancelDeleteConfirmation('Delete');
        }, fail);
    }, 'The Revenue Growth option for the type drop down menu is behind a feature flag for the moment. Once it has been included in salesstagingtx, this can be removed and the test will be complete. ');
});