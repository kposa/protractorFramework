/// <reference path="../../../../typings/index.d.ts" />

import {isUndefined} from "../../../../modules_v3/helpers/utilityHelpers";

export interface sharedDPAgreementQueryResults {
    salesRepName:string,
    salesRepId:string,
    operationName:string,
    operationId:string,
    customerId:string,
    customerName:string
}

export function sharedDPAgreementQuery(
    salesPeriodId:number,
    customerType:number,
    isRaboBank:boolean,
    customerCultureName?:string,
    customerHasMissingCreditLimit?:boolean,
    customerHasMissingAgreement?:boolean,
    excludeCustomerRegion?:string
): string {
    const { E2EInvoicesDatabaseName, E2EPaymentsDatabaseName, E2EOperationsDatabaseName } = process.env;
    return `
    select distinct top 1 
           ltrim(rtrim(u.UserId)) salesRepId, 
           ltrim(rtrim(u.Name)) salesRepName,
           o.operationId,
           o.name operationName,
           c.Name customerName,
           c.customerId
    from ${E2EInvoicesDatabaseName}.dbo.[User] u 
    join ${E2EInvoicesDatabaseName}.dbo.UserOperation uo on uo.UserId = u.UserId
    join ${E2EInvoicesDatabaseName}.dbo.Operation o on o.OperationId = uo.OperationId
    join ${E2EInvoicesDatabaseName}.dbo.OperationCustomer oc on oc.OperationId = uo.OperationId
    join ${E2EOperationsDatabaseName}.dbo.Customer c2 on oc.CustomerId = c2.CustomerId 
    join ${E2EPaymentsDatabaseName}.dbo.CreditLimitMessage clm on c2.CustomerId = clm.CustomerId 
    join ${E2EInvoicesDatabaseName}.dbo.CustomerLoanDisclaimerInfo cldi on cldi.CustomerId = clm.CustomerId 
    join ${E2EInvoicesDatabaseName}.dbo.Customer c on cldi.CustomerId = c.CustomerId
    where uo.RoleId = 10
    and uo.UserId like '%phiext.com' 
    and u.Name <> ''
    and u.UserId <> ''
    and uo.SalesPeriodId = ${salesPeriodId}
    and c2.CustomerTypeId = ${customerType}  
    and cldi.isRaboBank = ${isRaboBank ? 1 : 0}
    ${isUndefined(customerCultureName) ?
        '' : 'and c.cultureName = \'' + customerCultureName + '\''
        }
    ${isUndefined(customerHasMissingCreditLimit) ?
        '' : 'and clm.MissingCreditLimit = ' + (customerHasMissingCreditLimit ? 1 : 0)
    }
    ${isUndefined(customerHasMissingAgreement) ?
        '' : 'and clm.MissingAgreement = ' + (customerHasMissingAgreement ? 1 : 0)
    }
    ${isUndefined(excludeCustomerRegion) ?
        '' : 'and c.region <> \'' + excludeCustomerRegion + '\''
    }
    `
}