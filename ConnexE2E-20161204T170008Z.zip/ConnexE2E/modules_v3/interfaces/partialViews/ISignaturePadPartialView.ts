/// <reference path="../../../typings/index.d.ts" />

import ElementFinder = protractor.ElementFinder;
import Promise = webdriver.promise.Promise;

export interface ISignaturePadPartialView {
    strokeSignature():void;
    clickAgree():void;
}