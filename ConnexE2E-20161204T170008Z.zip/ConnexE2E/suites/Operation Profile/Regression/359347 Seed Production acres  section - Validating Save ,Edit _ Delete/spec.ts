/// <reference path="../../../../typings/index.d.ts" />

import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { TestData359347 } from './testData';
import { itw } from '../../../../modules_v3/helpers/itw';
import { SalesRepOperationsFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationsFullView';
import { SalesRepEllipsePartialView } from '../../../../modules_v3/views/salesRep/SalesRepEllipsePartialView';
import { SalesRepOperationProfilePageFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationProfilePageFullView';

const test = new TestCase(
    '359347',
    'Seed Production acres  section - Validating Save, Edit & Delete',
    UserRole.SALES_REP,
    ApplicationFeature.OPERATION_PROFILE
);

describe(test.stringify, () => {
    const td = new TestData359347();
    const salesRepOperationsFullView = new SalesRepOperationsFullView();
    const ellipse = new SalesRepEllipsePartialView();
    const operationProfilePage = new SalesRepOperationProfilePageFullView();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            bootstrap(td.salesRepresentative);

            //search for an operation and click on it
            salesRepOperationsFullView.search(td.operation.name);
            salesRepOperationsFullView.clickSearchResultContainingText(td.operation.name);

            //select operation profile link from the ellipse to navigate to the operation profile page
            ellipse.select('operation profile');

            //should click on the add button for seed production acres
            operationProfilePage.clickAddButtonForSeedProductionAcres();

            //select the product line in the seed production acres Dialog box
            operationProfilePage.seedProductionAcresDialog.selectProductLineFromDropdown();

            //verify that the save button is disabled
            expect(operationProfilePage.seedProductionAcresDialog.isSaveButtonDisabled()).toBeTruthy();

            //enter invalid value into pioneer seed production acres input
            operationProfilePage.seedProductionAcresDialog.enterValueIntoPioneerSeedProductionAcresInput(12.5);

            //verify that an error message is displayed
            expect(operationProfilePage.seedProductionAcresDialog.isInvalidMessageDisplayed()).toBeTruthy();

            //verify that the save button is disabled
            expect(operationProfilePage.seedProductionAcresDialog.isSaveButtonDisabled()).toBeTruthy();

            //enter valid value into pioneer seed production acres input
            operationProfilePage.seedProductionAcresDialog.enterValueIntoPioneerSeedProductionAcresInput();

            //click save to save seed production acres Dialog box
            operationProfilePage.seedProductionAcresDialog.clickSave();

            //click on Cancel button of the confirmation box
            operationProfilePage.seedProductionAcresDialog.clickCancelConfirmationDialog();

            //enter value into competitive brand seed production acres Dialog box
            operationProfilePage.seedProductionAcresDialog.enterValueIntoCompetitiveBrandProductionAcresInput();

            //click save to save seed production acres Dialog box
            operationProfilePage.seedProductionAcresDialog.clickSave();

            //store the number of seed production acres Lines displayed
            let originalSeedProductionAcreLines = operationProfilePage.getNumberOfSeedProductionAcreLines();

            //verify that you can edit the seed production acre Line by clicking on it, changing a value and re-saving it
            operationProfilePage.clickFirstSeedProductionAcresLineItem();
            operationProfilePage.seedProductionAcresDialog.enterValueIntoPioneerSeedProductionAcresInput();
            operationProfilePage.seedProductionAcresDialog.clickSave();

            //verify deleting the first seed production acre row by clicking on the trash icon at the corner of the line
            operationProfilePage.deleteFirstSeedProductionAcresRow();

            //verify that the line was deleted after clicking on the trash icon
            operationProfilePage.getNumberOfSeedProductionAcreLines().then((newLines) => {
                originalSeedProductionAcreLines.then((oldLines) => {
                    expect(newLines).toEqual(oldLines - 1);
                });
            });
        }, fail);
    });
});
