///<reference path="./typings/index.d.ts"/>

import * as ConfigService from './modules_v3/services/ConfigService';
import path = require('path');
import fs = require('fs');
import { isTrue, textContainsText } from './modules_v3/helpers/utilityHelpers';
import { LogReporter } from './reporters/LogReporter/LogReporter';
import { PauseReporter } from './reporters/PauseReporter/PauseReporter';
import { ScreenshotReporter } from './reporters/ScreenshotReporter/ScreenshotReporter';
import { getAllFilePathsWithinDirectory } from './modules_v3/helpers/utilityFileHelpers';

import Promise = protractor.promise.Promise;
import optimist = require('optimist');
const argv = optimist.argv;
const glob = require('glob');
const env = process.env;

// Inject config data as env variables for use in tests
const config = ConfigService.getInstance();
const { Locale, GridIsEnabled } = config.data;
config.injectIntoEnv();

/**
 * Suite patterns
 */
const suites = {

    // all
    all_en: "suites/**/!(*French*)/**/*spec.js",
    all_en_smoke:"suites/**/Smoke/**/*spec.js",
    all_en_reg:"suites/**/Regression/**/*spec.js",
    all_fr:"suites/**/+(*French)/**/*spec.js",
    all_fr_smoke:"suites/**/SmokeFrench/**/*spec.js",
    all_fr_reg:"suites/**/RegressionFrench/**/*spec.js",

    // by feature
    act_statement_en: "suites/Activity Statement/!(*French)/**/*spec.js",
    adRoll_en: "suites/Account Description Roll/!(*French)/**/*spec.js",
    adRoll_fr: "suites/Account Description Roll/+(*French)/**/*spec.js",
    agencies_en: "suites/Agencies/!(*French)/**/*spec.js",
    agreements_en: "suites/Agreements/!(*French)/**/*spec.js",
    agreements_fr: "suites/Agreements/+(*French)/**/*spec.js",
    commissions_en: "suites/Commissions/!(*French)/**/*spec.js",
    deliveries_en: "suites/Deliveries/!(*French)/**/*spec.js",
    discounts_en: "suites/Discounts/!(*French)/**/*spec.js",
    epayments_en: "suites/Epayments/!(*French)/**/*spec.js",
    invoicing_en: "suites/Invoicing/!(*French)/**/*spec.js",
    navigations_en: "suites/Navigations/!(*French)/**/*spec.js",
    operations_en: "suites/Operations/!(*French)/**/*spec.js",
    opManagement_en: "suites/Operation Management/!(*French)/**/*spec.js",
    opProfile_en: "suites/Operation Profile/!(*French)/**/*spec.js",
    opProfile_fr: "suites/Operation Profile/+(*French)/**/*spec.js",
    opt_en: "suites/Operation Profile Tool/!(*French)/**/*spec.js",
    payments_en: "suites/Payments/!(*French)/**/*spec.js",
    proposals_en: "suites/Proposals/!(*French)/**/*spec.js",
    reporting_en: "suites/Reporting/!(*French)/**/*spec.js",
    reporting_fr: "suites/Reporting/+(*French)/**/*spec.js",
    search_en: "suites/Search/!(*French)/**/*spec.js",
    settlement_en: "suites/Settlement/!(*French)/**/*spec.js",

    // only targets previously failed tests
    failed: env.failureGlob
};

export const expectedIds = ():string[] => {
    let suite = suites[argv.suite].replace('spec.js', 'spec.*s');
    let ids = glob.sync(suite);

    return ids;
};

/**
 * Function called at the start of a test run
 */
const onPrepare = (() => {
    function setupReporters() {

        if (isTrue(env.E2EUseJasmineSpecReporter)) {
            const SpecReporter = require("jasmine-spec-reporter");
            const specReporter = new SpecReporter({
                displayStacktrace: "all",
                displayPendingSpec: true,
                displaySpecDuration: true
            });
            jasmine.getEnv().addReporter(specReporter);
        }

        if (isTrue(env.E2EUseCustomJSONReporter)) {
            jasmine.getEnv().addReporter(<any>new LogReporter());
        }

        if (isTrue(env.E2EUseFailFastReporter)) {
            jasmine.getEnv().addReporter(require('jasmine-fail-fast').init());
        }

        if (isTrue(env.E2EUseScreenshotReporter)) {
            jasmine.getEnv().addReporter(<any>new ScreenshotReporter());
        }

        if (isTrue(env.E2EUsePauseReporter) && !isTrue(env.E2EGridIsEnabled)) {
            jasmine.getEnv().addReporter(<any>new PauseReporter());
        }
    }

    return () => {
        setupReporters();
    };
})();

const afterLaunch = (() => {
    function writeTestResultsToFile () {
        let logReporter = new LogReporter();
        logReporter.writeTestResultsToFile();
        logReporter.printResultsToConsole();
    }

    return () => {
        if (isTrue(env.E2EUseCustomJSONReporter)) writeTestResultsToFile();
    };
})();

const getSeleniumFilePath = (fileNameContains:Array<string>):string => {
    const seleniumDir = path.join(__dirname, '../node_modules/protractor/node_modules/webdriver-manager/selenium');
    const seleniumFile = fs.readdirSync(seleniumDir).filter((file) => {
            return fs.lstatSync(path.join(seleniumDir, file)).isFile() &&
                fileNameContains.every(f => {
                    return textContainsText(file.toString(), f);
                })
        }
    )[ 0 ];
    return path.join(seleniumDir, seleniumFile);
};

/**
 * Exported object loaded by protractor
 */
module.exports = {
    config: {
        suites: suites,
        onPrepare: onPrepare,
        afterLaunch: afterLaunch,
        params: {},
        directConnect: false,
        capabilities: {
            browserName: 'chrome',
            chromeOptions: {
                'args': [ 'incognito', '--disable-cache', '--disable-extensions', '--start-maximized' ],
                prefs: {
                    intl: {
                        accept_languages: Locale
                    }
                }
            },
            shardTestFiles: GridIsEnabled,
            maxInstances: GridIsEnabled ? 20 : 0
        },
        // old grid: http://us-vw01096.phibred.com:4444/wd/hub
        // new grid: http://10.250.130.106:80/wd/hub
        seleniumAddress: GridIsEnabled ? 'http://us-vw01096.phibred.com:4444/wd/hub' : '',
        chromeDriver: getSeleniumFilePath([ 'chromedriver', '.exe' ]),
        seleniumServerJar: getSeleniumFilePath([ 'selenium-server-standalone', '.jar' ]),
        framework: "jasmine2",
        jasmineNodeOpts: {
            defaultTimeoutInterval: 600000, //rule-of-thumb - each spec finishes < 3 minutes
            isVerbose: true,
            showColors: true,
            /** Disable the default jasmine dot reporter */
            print: () => {
            }
        },
        allScriptsTimeout: 60000,
        getPageTimeout: 60000
    }
};

export const testCaseIds:Array<string> =
    new LogReporter().extractIdsFromExistingTestCases(getAllFilePathsWithinDirectory(path.join(__dirname, '/suites')));