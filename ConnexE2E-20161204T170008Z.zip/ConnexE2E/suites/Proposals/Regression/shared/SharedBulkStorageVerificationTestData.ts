/// <reference path="../../../../typings/index.d.ts" />

import Promise = protractor.promise.Promise;
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import { productRequiringBulkStorageResults, productRequiringBulkStorage } from "./SharedBulkStorageVerificationQueries";

export class SharedBulkStorageVerificationTestData extends BaseTestData {

    public agencyHasBulkStorage:boolean;

    protected queries:(() => Promise<any>)[] = [
        this.populateUserData()
    ];

    private populateUserData ():() => Promise<productRequiringBulkStorageResults> {
        return () => {
            const sql = productRequiringBulkStorage(this.salesPeriod.id, this.agencyHasBulkStorage);
            const results = this.queryService.executeSql<productRequiringBulkStorageResults[]>(sql);

            return results
                .then(data => {
                    const row = <productRequiringBulkStorageResults> getRandomQueryResult(data);

                    this.salesAgencies.push({
                        id: row.salesAgencyId,
                        name: row.salesAgencyName
                    });

                    this.salesRepresentatives.push({
                        id: row.salesRepId,
                        name: row.salesRepName
                    });

                    this.operations.push({
                        id: row.operationId,
                        name: row.operationName
                    });

                    this.businessPartners.push({
                        id: row.customerId,
                        name: row.customerName
                    });

                    this.products.push({
                        line: row.productLine,
                        name: row.productId,
                        subName: row.subproductId
                    });

                    return row;
                });
        };
    }
}