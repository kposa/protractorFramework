/// <reference path="../../../../typings/index.d.ts" />
import Promise = protractor.promise.Promise;

import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import { orgUnitResults, orgUnitFinder } from './queries';
import { getRandomNumberAsString } from '../../../../modules_v3/helpers/utilityHelpers';
import { getRandomQueryResult } from '../../../../modules_v3/helpers/utilityHelpers';

export class TestData425775 extends BaseTestData {
    /** Value used to full inputs in PVC form */
    public randomAcceleration = getRandomNumberAsString();
    public randomOverAcceleration = getRandomNumberAsString();
    public randomUnderAcceleration = getRandomNumberAsString();

    public randomAccelerationTwo = getRandomNumberAsString();
    public randomOverAccelerationTwo = getRandomNumberAsString();
    public randomUnderAccelerationTwo = getRandomNumberAsString();

    public randSalesAgencyId:string;

    protected queries: (() => Promise<any>)[] = [
        this.findOrgUnits()
    ];

    private findOrgUnits ():() => Promise<orgUnitResults> {
        return () => {
            const sql = orgUnitFinder(this.salesPeriod.id);
            const results = this.queryService.executeSql<orgUnitResults[]>(sql);

            return results.then(data => {
                const row = <orgUnitResults>getRandomQueryResult(data);
                this.randSalesAgencyId = row.salesAgencyId;

                return row;
            });
        };
    }
}