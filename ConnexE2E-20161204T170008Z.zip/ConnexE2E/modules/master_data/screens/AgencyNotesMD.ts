/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;

export class AgencyNotesMD {

    private notesLayoutParent = $('div.ng-scope.layout-column.flex');

    get verifyNoteAddedSuccessfully(): Promise<string> {
        return this.notesLayoutParent.getText();
    }
   
    public enterNote(note: string): void {
        let noteContainer = $('textarea[ng-model="vm.agencyNote.note"]');
        noteContainer.sendKeys(note);
    }
    
}