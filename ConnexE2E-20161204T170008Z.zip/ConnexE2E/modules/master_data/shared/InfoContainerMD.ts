/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

export class InfoContainerMD {
    
    public clickOnInfoIcon():void {
        clickElement($('invoice-information[invoice-id="vm.invoiceId"]').$('i.material-icons.md-36.md-light'));
    }

    public closeInfoContainer():void {
        clickElement($('div.pm-paper.z-depth-2.info-container.flex-vertical.active').$('i.material-icons.md-48.md-dark'));
    }

    get salesSeasonFromInfoCard():Promise<string> {
        return $('div.pm-style-body-1.subtitle').getText();
    }

    get isInfoIconFromInfoCardDisplayed():Promise<boolean> {
        return $('i.material-icons.md-48.md-dark').isDisplayed();
    }

    get operationFromInfoCard():Promise<string> {
        return $$('div.pm-style-body-2.name').get(0).getText();
    }

    get agencyFromInfoCard():Promise<string> {
        return $$('div.pm-style-body-2.name').get(1).getText();
    }

    public verifyLastModifiedDisplayed(): Promise<string> {
        return $('div.audit.footer').$('span.content-padding ').getText();
    }
}