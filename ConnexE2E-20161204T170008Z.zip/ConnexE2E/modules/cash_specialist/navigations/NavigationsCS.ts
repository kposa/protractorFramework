/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;
import {Impersonate} from "../../shared/Impersonate";
import {SearchCS} from "../screens/SearchCS";
import {Element} from "../../shared/Element";

let search = new SearchCS();
let imp = new Impersonate();
let e = new Element();

export class NavigationsCS {

    public impersonate(user_name:string, user_id:string):void {
        search.clickSearchBarHamburger();
        search.selectSearchBarHamburgerOption('Impersonate');
        imp.impersonateUserByNameAndId(user_name, user_id);
    }

    public selectItemFromHamburgerMenu(itemName:string):void {
        let hamburger = $('i[ng-click="drawerVM.toggleDrawerPosition()"]');
        e.clickElement(hamburger);
        e.clickElement(this.getHamburgerMenuItem(itemName));
    }

    private getHamburgerMenuItem(itemName:string):ElementFinder {
        let allHamburgerMenuItems = $('section[name="navigationDrawer"]').$$('span');
        return allHamburgerMenuItems.filter(function (elem) {
            return elem.getText().then(function (itemText) {
                return itemText.trim().toUpperCase() === itemName.trim().toUpperCase();
            });
        }).get(0);
    }
}
