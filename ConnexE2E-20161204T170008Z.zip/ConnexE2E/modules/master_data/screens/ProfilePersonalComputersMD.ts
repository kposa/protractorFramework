/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

export class ProfilePersonalComputersMD {

    private personalComputersCardContent = $('div.layout-margin.flex');
    private addComputerButton = $('button[aria-label="Add Agency Computer"]');
    private allTrashCans:ElementArrayFinder = $$('button[aria-label="delete"]');

    private clickFirstTrashCan(): void {
        clickElement(this.allTrashCans.get(0));
    }

    public addAgencyComputer(): void {
        clickElement(this.addComputerButton);
    }

    public enterModelNumber(modelNumber: string): void {
        let modelConntainer = $('input[name="model"]');
        modelConntainer.sendKeys(modelNumber)
    }

    public enterSerialNumber(serialNumber: string): void {
        let serialNumberContainer = $('input[name="serialNumber"]');
        serialNumberContainer.sendKeys(serialNumber);
    }

    public verifyRequiredDisplays(): Promise<string> {
        return this.personalComputersCardContent.getText();
    }

    public removeAllAgencyComputers(): void {
        this.clickFirstTrashCan();
        this.allTrashCans.count().then((cnt) => {
            if(cnt > 0) this.removeAllAgencyComputers();
        })
    }

}