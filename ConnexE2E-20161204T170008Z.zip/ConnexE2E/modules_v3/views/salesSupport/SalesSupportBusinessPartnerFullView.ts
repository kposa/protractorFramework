/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;
import { IView } from '../../interfaces/common/IView';
import { NotImplementedError } from '../../../common/exception/Exceptions';
import { SalesSupportHamburgerDrawerPartialView } from './SalesSupportHamburgerDrawerPartialView';

export class SalesSupportBusinessPartnerFullView implements IView {

    public hamburgerMenu = new HamburgerMenu();

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }
}

class HamburgerMenu extends SalesSupportHamburgerDrawerPartialView {
}