/// <reference path="../../../../typings/index.d.ts" />

import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';
import { createAccountDescriptionProc } from '../../../../modules_v3/testdata/sharedQueries/createAccountDescription/index';
import { addProductToAccountDescriptionProc } from '../../../../modules_v3/testdata/sharedQueries/addProductToAccountDescription/index';
import { existingData } from '../../../../modules_v3/testdata/sharedQueries/existingData/index';

export default class TestData319926 extends BaseTestData {
    protected queries: (() => Promise<any>)[] = [
        existingData(this.queryService, this),
        createAccountDescriptionProc(this.queryService, this),
        addProductToAccountDescriptionProc(this.queryService, this)
    ];
}