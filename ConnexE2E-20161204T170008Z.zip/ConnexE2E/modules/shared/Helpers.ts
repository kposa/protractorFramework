/// <reference path='../../typings/index.d.ts' />

/**
 * The helper methods in this class should only consist of JavaScript functionality
 * There should be no interaction with Protractor here
 */

import moment = require('moment');

export class Helpers {

    /**
     * @param min exclusive
     * @param max exclusive
     */
    public getRandomIntBetween(min:number, max:number):number {
        return Math.floor(Math.random() * (max - min + 1) + min);
    }

    /**
     * @param format
     *      1: MM/DD/YYYY
     *      2: MMDDYYYY
     *      3: Wednesday May 11 2016
     */
    public getFormattedDate(format:number, addSubtractDays?:number):string {
        var date = new Date();

        if (typeof addSubtractDays !== 'undefined')
            date.setTime(date.getTime() + addSubtractDays * 86400000);

        switch (format) {
            case 1:

                var month = ('0' + (date.getMonth() + 1)).slice(-2);
                var day = ('0' + date.getDate()).slice(-2);
                var year = date.getFullYear();
                return month + '/' + day + '/' + year;
            
            case 2:

                return this.getFormattedDate(1, addSubtractDays).replace(/\//g, '');
            case 3:
                return moment().format("dddd MMMM D YYYY");
        }
    }

    public getRandomItemFromArray(arr:Array<any>):any {
        return arr[this.getRandomIntBetween(0, arr.length - 1)];
    }

    private escapeRegExp(str:string):string {
        return str.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
    }

    public replaceAll(str:string, find:string, replace:string):string {
        if (!str)
            return str;
        return str.replace(new RegExp(this.escapeRegExp(find), 'g'), replace);
    }

    public validateEmail(email:string):boolean {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    }

    public stringToNumber(str:string):number {
        return parseFloat(str.replace(/[^0-9.]/g, ''));
    }

    public getLastParameterInUrl(href:string):string {
        return href.substring(href.lastIndexOf('/') + 1, href.length);
    }

    public removeEverythingButNumbersAndDecimals(str:string):string {
        return str.replace(/[^0-9.]/g, '');
    }

    public removeEverythingButLetters(str:string):string {
        return str.replace ( /[^a-zA-Z]/g, '' );
    }

    public validateAmountValue(str:string): boolean{
        var regexp = ($,/[0-9.]/);
        return regexp.test(str);
    }

    public guid(length:number, numbersOnly?:boolean, lettersOnly?:boolean):string {
        var text = '';
        var possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        if(numbersOnly) possible = possible.replace(/\D/g,'');
        if(lettersOnly) possible = possible.replace(/[^a-zA-Z]+/g, '');

        for (var i = 0; i < length; i++)
            text += possible.charAt(Math.floor(Math.random() * possible.length));

        return text;
    }
}
