/// <reference path='../../../typings/index.d.ts' />

import ElementFinder = protractor.ElementFinder;
import Promise = protractor.promise.Promise;
import { IOperationsFullView } from '../../interfaces/fullViews/IOperationsFullView';
import SearchDrawerView from "../shared/SearchDrawerPartialView";
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';
import {
    filterElements,
    isActive,
    containingText,
    matchingText
} from '../../../modules_v3/helpers/filterElementHelpers';
import { NotImplementedError } from '../../../common/exception/exceptions';
import ElementArrayFinder = protractor.ElementArrayFinder;

export class SalesRepOperationsFullView implements IOperationsFullView {

    private element = $(`section.operations`);
    private searchDrawer = new SearchDrawerView();
    private searchResults = this.element.$$(`li[ng-repeat='o in vm.filtered = (vm.operationList | filter:vm.search)']`);
    private filterByAgencyButton = $('button[ng-click="vm.viewAgencyList()"]').$('span');
    private searchBarHamburger = $('div[ng-click="showNav()"]');

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    public clickSearchResultMatchingText (text:string):void {
        clickElement(filterElements(this.searchResults, [ isActive(true), matchingText(text) ])().first());
    }

    public clickSearchResultContainingText (text:string):void {
        clickElement(filterElements(this.searchResults, [ isActive(true), containingText(text) ])().first());
    }

    public getSearchResultsByContainingId (headline:string):ElementArrayFinder {
        return filterElements(this.searchResults, [
            isActive(true),
            containingText(headline)
        ])();
    }

    public getSearchResultContentByContainingId (headline:string):Promise<string> {
        return this.getSearchResultsByContainingId(headline).first().getText();
    }

    public search (text:string):void {
        this.searchDrawer.search(text);
    }

    searchByTwoCriteria (firstCriteria:string, secondCriteria:string):void {
        throw new NotImplementedError();
    }

    public openSearch ():void {
        this.searchDrawer.openSearch();
    }

    public inputSearch (text:string):void {
        this.searchDrawer.inputSearch(text);
    }

    public submitSearch ():void {
        this.searchDrawer.submitSearch();
    }

    getSearchResultCount ():Promise<number> {
        return this.searchResults.count();
    }

    clickFirstGreenInvoiceButton ():void {
        throw new NotImplementedError();
    }

    clickFirstGreenDeliveriesButton ():void {
        throw new NotImplementedError();
    }

    public clickSearchBarHamburger ():void {
        clickElement(this.searchBarHamburger);
    }

    public scrollToLetter (text:string):void {
        let letter = filterElements(
            $$('li[ng-click="scrollToLetter(anchor.target)"]'), [ isActive(true), matchingText(text) ]
        )().first();
        clickElement(letter);
    }

    public filterBySalesAgencyIfAgencyButtonDisplayed (agencyId:string):void {
        this.filterByAgencyButton.isDisplayed().then((id) => {
            if (id) {
                this.clickFilterByAgencyButton();
                this.selectAgencyById(agencyId)
            }
        });
    }

    private clickFilterByAgencyButton ():void {
        clickElement(this.filterByAgencyButton);
    }

    public selectAgencyById (id:string):void {
        let agencyName = filterElements(
            $$('li[ng-click="vm.selectAgency(a)"]'),
            [
                isActive(true),
                containingText(id)
            ]
        )().first();
        clickElement(agencyName);
    }
}