/// <reference path="../../../../typings/index.d.ts" />

import { SearchMD2 } from "../../../../modules/master_data/screens/SearchMD2";
import { bootstrap } from "../../../SharedSteps/bootstrap";
import { AgencyMailingMD } from '../../../../modules/master_data/screens/AgencyMailingMD';
import { AgencyMD } from '../../../../modules/master_data/screens/AgencyMD';
import { ButtonMD } from '../../../../modules/master_data/shared/ButtonMD';
import { NavigationsMD } from '../../../../modules/master_data/navigations/NavigationsMD';
import { itw } from '../../../../modules_v3/helpers/itw';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import TestData341360 from './testData';
import MasterDataMasterSearchFullView from '../../../../modules_v3/views/masterData/MasterDataMasterSearchFullView';

const test = new TestCase(
	'341360',
	'Search Remove match on address from main search result for Sales Agency',
	UserRole.MASTER_DATA,
	ApplicationFeature.SEARCH
);

describe(test.stringify, () => {
    const td = new TestData341360();
    let searchMD = new SearchMD2();
    let navigationsMD = new MasterDataMasterSearchFullView();
    let agencyMD = new AgencyMD();
    let agencyMailingMD = new AgencyMailingMD();
    let buttonMD = new ButtonMD();

    itw(test.description, () => {
        td.populatePromise().then(() => {

            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.masterDataUser);

            //should search for sales agency by agency id
            searchMD.searchByCriteria(td.agencyId);
            searchMD.clickCategory('Sales agencies');

            //should check if search result includes agency details
            expect(searchMD.getSearchResultContentByContainingHeadline(td.agencyId)).toContain('Sales agency');
            expect(searchMD.getSearchResultContentByContainingHeadline(td.agencyId)).toContain(td.firstName);
            expect(searchMD.getSearchResultContentByContainingHeadline(td.agencyId)).toContain(td.street1);
            expect(searchMD.getSearchResultContentByContainingHeadline(td.agencyId)).toContain(td.city);
            expect(searchMD.getSearchResultContentByContainingHeadline(td.agencyId)).toContain(td.postalCode);

            // should select the agency
            searchMD.selectSearchResultByResultType('Sales agency');

            //should go the mailing address page and update street address 1
            agencyMD.selectMailingAddressCard();
            agencyMailingMD.enterStreetAddress1(td.firstName);
            buttonMD.clickSaveButton();

            // should select search option from the hamburger menu
            navigationsMD.selectOptionFromHamburgerMenu('Search');

            //should search agency by first name and last name
            searchMD.searchByTwoCriteria(td.firstName, td.lastName);
            searchMD.clickCategory('Sales agencies');

            //Should verify if user search sales agency by Agency's name which matches with street address 1
            // then sales agency and address should be displayed
            expect(searchMD.getSearchResultContentByContainingHeadline(td.agencyId)).toContain('Sales agency');
            expect(searchMD.getSearchResultContentByContainingHeadline(td.agencyId)).toContain(td.firstName);
            expect(searchMD.getSearchResultContentByContainingHeadline(td.agencyId)).toContain(td.lastName);
            expect(searchMD.getSearchResultContentByContainingHeadline(td.agencyId)).toContain(td.city);
            expect(searchMD.getSearchResultContentByContainingHeadline(td.agencyId)).toContain(td.postalCode);

            // should enter the original street address 1
            searchMD.selectSearchResultByResultType('Sales agency');
            agencyMD.selectMailingAddressCard();
            agencyMailingMD.enterStreetAddress1(td.street1);
            buttonMD.clickSaveButton();

        }, fail);
    });
});