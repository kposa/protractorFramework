/// <reference path="../../../../typings/index.d.ts" />

import { bootstrap } from '../../../SharedSteps/bootstrap';
import { itw } from '../../../../modules_v3/helpers/itw';
import { SalesRepOperationsFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationsFullView';
import {
    AccountDescriptionShare,
    createAccountDescription
} from '../../../SharedSteps/Sales Rep/createAccountDescription';
import { SalesRepInvoiceFullView } from '../../../../modules_v3/views/salesRep/SalesRepInvoiceFullView';
import { SalesRepOperationFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationFullView';
import { SalesRepEllipsePartialView } from '../../../../modules_v3/views/salesRep/SalesRepEllipsePartialView';
import SalesRepPreviewDocumentFullView from '../../../../modules_v3/views/salesRep/SalesRepPreviewDocumentFullView';
import { sharedSalesRepTestData } from './sharedSalesRepPreviewTestData';


export default function sharedMasterDataSearchSteps (description:string, td: sharedSalesRepTestData, pending?: string) {
    const salesRepOperations = new SalesRepOperationsFullView();
    const salesRepOpFullView = new SalesRepOperationFullView();
    const salesRepInvoiceFullView = new SalesRepInvoiceFullView();
    const ellipse = new SalesRepEllipsePartialView();
    const salesRepPreviewFullView = new SalesRepPreviewDocumentFullView();

    itw(description, () => {
        td.populatePromise().then(() => {
            bootstrap(td.salesRepresentative);

            //search for an operation and click on it
            salesRepOperations.search(td.operation.name);
            salesRepOperations.clickSearchResultContainingText(td.operation.name);

            createAccountDescription({
                salesPeriod: td.salesPeriod.id,
                shares: [ new AccountDescriptionShare(td.businessPartner, '100') ]
            }, td);

            browser.controlFlow().execute(function(){
                salesRepOpFullView.clickInvoiceButton(td.invoice.name);
                // products is the current page
                if (td.screen !== 'products') ellipse.select(td.screen);
                if (!td.invoiceAbsent){
                    salesRepInvoiceFullView.clickPreviewInvoice();
                    salesRepInvoiceFullView.clickShowButtonToPreviewInvoice();
                    expect(salesRepPreviewFullView.verifyPrintIcon()).toBeTruthy();
                    expect(salesRepPreviewFullView.verifyEmail()).toBeTruthy();
                }
                else{
                    expect(salesRepInvoiceFullView.previewInvoicePresent()).toBeFalsy();
                }
            });
        }, fail);
    }, pending);
};