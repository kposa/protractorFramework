/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

export class ProfileGeneralMD {

    private generalCardContent = $('div.layout-margin.flex');
    private firstKernelSizeDropdownParent = $('div.md-select-menu-container.md-active.md-clickable');

    public selectCertifiedDairyRepFromDropdown(): void {
        let certifiedDairyRep = $('md-select[ng-model="vm.certifiedDairyRepId.Value"]');
        let selectYesDropdownOption = $$('md-option[ng-repeat="option in vm.profile.certifiedDairyRepOptions"]').get(0);
        clickElement(certifiedDairyRep);
        clickElement(selectYesDropdownOption);
    }

    public enterCertifiedLivestockProfessionalName(livestockProfessionalName: string): void {
        let nameContainer = $('input[name="clpName"]');
        nameContainer.clear();
        nameContainer.sendKeys(livestockProfessionalName);
    }

    public selectTodaysDateFromDatePicker(): void {
        let datePickerButton = $('button[aria-label="Open calendar"]');
        let todaysDate = $('td.md-calendar-date.md-calendar-date-today');
        clickElement(datePickerButton);
        clickElement(todaysDate);
    }

    public selectPioneerPremiumSeedTreatmentFromDropdown(): void {
        let pioneerPremiumSeedTreatmentDropdown = $('md-select[ng-model="vm.pioneerPremiumSeedTreatmentId.Value"]');
        let selectYesDropdownOption = $$('md-option[ng-repeat="option in vm.profile.pioneerPremiumSeedTreatmentOptions"]').get(0);
        clickElement(pioneerPremiumSeedTreatmentDropdown);
        clickElement(selectYesDropdownOption);
    }

    public enterValueInCheckScannersContainer(): void {
        let checkScannersContainer = $('input[ng-model="vm.checkScannerCount"]');
        checkScannersContainer.sendKeys(protractor.Key.ARROW_UP);
        checkScannersContainer.sendKeys(protractor.Key.ARROW_UP);
        checkScannersContainer.sendKeys(protractor.Key.ARROW_DOWN);
    }

    public clickFirstKernelSizeDropdown(): void {
        let firstKernelSizeDropdown = $('md-select[name="firstKernelSize"]');
        clickElement(firstKernelSizeDropdown);
    }

    public selectFirstOption(): void {
        let selectFirstOptionFromDropdown = $$('md-option[ng-repeat="option in vm.profile.firstKernelSizePreferenceOptions"]').get(0);
        clickElement(selectFirstOptionFromDropdown);
    }

    public selectFirstKernelSizeFromDropdown(): void {
        let firstKernelSizeDropdown = $('md-select[name="firstKernelSize"]');
        let selectFirstOptionFromDropdown = $$('md-option[ng-repeat="option in vm.profile.firstKernelSizePreferenceOptions"]').get(0);
        clickElement(firstKernelSizeDropdown);
        clickElement(selectFirstOptionFromDropdown);
    }

    public selectSecondKernelSizeFromDropdown(): void {
        let secondKernelSizeDropdown = $('md-select[name="secondKernelSize"]');
        let selectSecondOptionFromDropdown = $$('md-option[ng-repeat="option in vm.profile.secondKernelSizePreferenceOptions"]').get(1);
        clickElement(secondKernelSizeDropdown);
        clickElement(selectSecondOptionFromDropdown);
    }

    public selectThirdKernelSizeFromDropdown(): void {
        let thirdKernelSizeDropdown = $('md-select[name="thirdKernelSize"]');
        let selectThirdOptionFromDropdown = $$('md-option[ng-repeat="option in vm.profile.thirdKernelSizePreferenceOptions"]').get(2);
        clickElement(thirdKernelSizeDropdown);
        clickElement(selectThirdOptionFromDropdown);
    }

    public selectMonthlyDrawCheckbox(): void {
        let monthlyDrawCheckbox = $('md-checkbox[ng-model="vm.monthlyDraw"]');
        clickElement(monthlyDrawCheckbox);
    }

    public verifyMonthlyDrawIsFalse(): Promise<string> {
        return this.generalCardContent.getText();
    }

    public getAllKernelSizeDropdownOptions(): ElementArrayFinder {
        let allResults = this.firstKernelSizeDropdownParent.$$('md-option[ng-repeat="option in vm.profile.firstKernelSizePreferenceOptions"]')
            .$$('div.md-text');
        return allResults;
    }
}

//7162435