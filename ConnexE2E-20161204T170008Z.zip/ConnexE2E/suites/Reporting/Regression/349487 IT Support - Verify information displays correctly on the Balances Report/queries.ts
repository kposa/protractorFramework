export interface ITSupportWithPioneerBalanceNonZeroPriorSalesPeriodResults {
    salesRepId: string,
    salesRepName: string,
    operationId: string,
    operationName: string,
    invoiceId: string,
    invoiceName: string,
    businessPartnerName: string,
    businessPartnerId : string,
    salesAgencyName : string,
    salesAgencyId : string,
    netInvoice : string,
    netPayments : string,
    netPending : string,
    pioneerBalance : string,
    salesPeriodYear : string,
    salesPeriodSeason : string
}

export function ITSupportWithPioneerBalanceNonZeroPriorSalesPeriod() {
    const { E2EInvoicesDatabaseName, E2EReportingDatabaseName } = process.env;
    
    return `
   
SELECT DISTINCT TOP 20
u.Name salesRepName, 
uo.UserId salesRepId, 
br.operationName operationName,
br.operationId operationId,  
i.Name invoiceName,
i.invoiceId invoiceId,
br.CustomerName businessPartnerName,
br.CustomerId businessPartnerId,
br.Year salesPeriodYear,
br.SeasonId salesPeriodSeason,
sa.Name salesAgencyName,
sa.salesAgencyId salesAgencyId,
br.NetInvoiceValue netInvoice,
br.NetPayments netPayments,
br.NetPendingPayments netPending,
(br.NetInvoiceValue + br.NetPayments + br.NetPendingPayments) pioneerBalance

FROM ${E2EReportingDatabaseName}.dbo.BalancesReport br
JOIN ${E2EInvoicesDatabaseName}.dbo.Invoice i ON i.InvoiceId = br.InvoiceId
JOIN ${E2EInvoicesDatabaseName}.dbo.UserOperation uo ON uo.OperationId = i.OperationId AND i.SalesPeriodId = uo.SalesPeriodId
JOIN ${E2EInvoicesDatabaseName}.dbo.[User] u ON u.UserId = uo.UserId
JOIN ${E2EInvoicesDatabaseName}.dbo.UserSalesAgency usa ON usa.SalesAgencyId = br.SalesAgencyId
JOIN ${E2EInvoicesDatabaseName}.dbo.SalesAgency sa ON sa.SalesAgencyId = usa.SalesAgencyId

WHERE (br.NetInvoiceValue + br.NetPayments + br.NetPendingPayments) <> 0 
AND uo.RoleId = 10 
AND uo.UserId LIKE '%@phiext.com'
AND i.SalesPeriodId <> (SELECT sp.SalesPeriodId FROM dbo.SalesPeriod sp WHERE sp.IsActive = 1 AND sp.IsCurrent =1)

    `;
}