/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import { filterElements, containingText, isActive } from '../../../modules_v3/helpers/filterElementHelpers';
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';
import {
    isAriaDisabled, isAriaEnabled, isAriaUnchecked,
    isDisabled
} from '../../../modules_v3/helpers/utilityElementHelpers';

export class AgencyStatusMD {

    private activeBeginningSalesPeriodDropdown = $('md-select[name="beginningSalesPeriod"]');
    private inactiveBeginningSalesPeriodDropdown = $('input[name="beginningSalesPeriod"]');
    private allowSAPTransactionsCheckbox = $('md-checkbox[ng-model="vm.allowSapTransactions"]');
    private finalSalesPeriodDropdown = $('md-select[name="endingSalesPeriod"]');
    private statusDropdown = $('md-select[name="status"]');

    public verifyFinalSalesPeriodDropdownEnabled (): Promise<boolean> {
        return isAriaEnabled(this.finalSalesPeriodDropdown);
    }

    public verifyAllowSAPTransactionsCheckboxEnabled (): Promise<boolean> {
        return isAriaEnabled(this.allowSAPTransactionsCheckbox);
    }

    public verifyAllowSAPTransactionsCheckboxUnchecked (): Promise<boolean> {
        return isAriaUnchecked(this.allowSAPTransactionsCheckbox);
    }

    public verifyBeginningSalesPeriodDropdownDisabled (): Promise<boolean> {
        return isDisabled(this.inactiveBeginningSalesPeriodDropdown);
    }

    public selectBeginingPeriodFromDropdown (sp: string): void {
        let selectOption = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(sp)
            ]
        )().first();
        clickElement(this.activeBeginningSalesPeriodDropdown);
        clickElement(selectOption);
    }

    public selectPendingActiveFromStatusDropdown (): void {
        let selectOption = $('md-option[value="1"]');
        clickElement(this.statusDropdown);
        clickElement(selectOption);
    }

    public selectPendingInactiveFromStatusDropdown (): void {
        let selectOption = $('md-option[value="3"]');
        clickElement(this.statusDropdown);
        clickElement(selectOption);
    }

    public selectInactiveFromStatusDropdown (): void {
        let selectOption = $('md-option[value="4"]');
        clickElement(this.statusDropdown);
        clickElement(selectOption);
    }

    public selectFinalSalesPeriod (sp: string): void {
        let selectOption = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(sp)
            ]
        )().first();
        clickElement(this.finalSalesPeriodDropdown);
        clickElement(selectOption);
    }

    public selectAllowSapTransactionCheckbox (): void {
        clickElement(this.allowSAPTransactionsCheckbox);
    }

}