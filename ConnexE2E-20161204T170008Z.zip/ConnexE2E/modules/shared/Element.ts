/// <reference path="../../typings/index.d.ts" />

/**
 * This class is responsible for all element clicks and the logic around them to check for "Oops" errors
 * It also provides common helper methods for elements such as returning 1 displayed element from a given list
 */

import ElementFinder = protractor.ElementFinder;
import ElementArrayFinder = protractor.ElementArrayFinder;
import Promise = webdriver.promise.Promise;
import {checkForOopsScreen} from "../../modules_v3/helpers/oopsScreenHelpers";

export class Element {

    public clickElement(elem:ElementFinder):void {
        browser.actions().mouseMove(elem.getWebElement());
        elem.click();
        checkForOopsScreen();
        this.closeAnyPopupNotificationsIfDisplayed();   //fixme do we need this?
    }

    public isAtLeast1Displayed(elems:ElementArrayFinder):Promise<boolean> {
        return elems.filter(function (elem, index) {
            return elem.isDisplayed().then(function (iD) {
                return iD;
            });
        }).then(function (filteredElements) {
            return filteredElements.length > 0;
        });
    }

    private checkForOopsScreen():void {
        let self = this;
        let allOops = $$('span.global-exception-icon');
        this.getDisplayedElemsCount(allOops).then(function (count) {
            if (count > 0) self.handleOopsScreen();
        });
    }

    private handleOopsScreen():void {
        $('div.global-exception-session').getText().then(function (sessionIDText) {
            sessionIDText = sessionIDText.trim().split(' ')[1];
            console.warn('Error: An oops screen appeared');
            console.warn('Session ID: ' + sessionIDText);
        });

        this.closeOopsScreen();
    }

    private closeOopsScreen():void {
        let closeButtons = $$('section.modal').$$('div.close-button');
        let closeBtn = closeButtons.filter(function (elem, index) {
            return elem.isDisplayed().then(function (iD) {
                return iD;
            });
        }).get(0);
        closeBtn.click();
    }

    private closeAnyPopupNotificationsIfDisplayed():void {
        let self = this;
        let allNotificationItems = $$('div.notifications-popup').$$('p.notification-text');
        allNotificationItems.filter(function (elem, index) {
            return elem.isDisplayed().then(function (iD) {
                return iD === true;
            });
        }).then(function (filteredElements) {
            if (filteredElements.length > 0) {
                self.closeNotificationBackDropIfDisplayed();
            }
        });
    }

    private closeNotificationBackDropIfDisplayed():void {
        let allBackdrops = $$('div[ng-click="vm.toggleNotificationsListDisplay()"]');
        allBackdrops.filter(function (elem, index) {
            return elem.isDisplayed().then(function (iD) {
                return iD === true;
            });
        }).then(function (filteredElems) {
            if (filteredElems.length == 1) filteredElems[0].click();
        });
    }

    public clickDisplayedElement(elemArr:ElementArrayFinder):void {
        let displayedElement = elemArr.filter((elem) => {
            return elem.isDisplayed().then((displayed:boolean) => {
                return displayed;
            });
        }).get(0);
        this.clickElement(displayedElement);
    }

    public getDisplayedElement(elemArr:ElementArrayFinder):ElementFinder {
        return elemArr.filter((elem) => {
            return elem.isDisplayed().then((displayed:boolean) => {
                return displayed;
            });
        }).get(0);
    }

    public clickDisplayedElementWithMatchingText(elemArr:ElementArrayFinder, matchingTxt:string):void {
        let elem = this.getDisplayedElementWithMatchingText(elemArr, matchingTxt);
        this.clickElement(elem);
    }

    public getDisplayedElementWithMatchingText(elemArr:ElementArrayFinder, matchingTxt:string):ElementFinder {
        return elemArr.filter((elem, index)=> {
            return elem.isDisplayed().then((iD)=> {
                return elem.getText().then((txt)=> {
                    return iD === true && txt === matchingTxt;
                });
            });
        }).first();
    }

    public clickDisplayedElementContainingText(elemArr:ElementArrayFinder, containingText:string):void {
        let elem = this.getDisplayedElementContainingText(elemArr, containingText);
        this.clickElement(elem);
    }

    public getDisplayedElementContainingText(elemArr:ElementArrayFinder, containingTxt:string):ElementFinder {
        return elemArr.filter((elem, index)=> {
            return elem.isDisplayed().then((iD)=> {
                return elem.getText().then((txt)=> {
                    return iD === true && Boolean(~txt.indexOf(containingTxt));
                });
            });
        }).first()
    }

    public getDisplayedElemsCount(elemArr:ElementArrayFinder):Promise<number> {
        return elemArr.filter(function (elem, index) {
            return elem.isDisplayed().then((iD)=> {
                return iD;
            });
        }).then(function (filteredElems) {
            return filteredElems.length;
        });
    }

    public hasClass(elem:ElementFinder, className:string):Promise<boolean> {
        return elem.getAttribute('class').then((classes)=> {
            return classes && classes.split(' ').indexOf(className) !== -1;
        });
    }
}