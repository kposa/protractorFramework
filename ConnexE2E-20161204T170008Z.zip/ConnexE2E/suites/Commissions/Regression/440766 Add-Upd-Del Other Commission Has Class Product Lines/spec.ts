/// <reference path="../../../../typings/index.d.ts" />

import MasterDataMasterSearchFullView from '../../../../modules_v3/views/masterData/MasterDataMasterSearchFullView';
import MasterDataCommissionsTabFullView from '../../../../modules_v3/views/masterData/MasterDataCommissionsTabFullView';
import { MasterDataOtherCommissionsFullView } from '../../../../modules_v3/views/masterData/MasterDataOtherCommissionsFullView';
import { MasterDataProductValueCommissionFullView } from '../../../../modules_v3/views/masterData/MasterDataProductValueCommissionFullView';
import { sharedOtherCommissionTestData } from '../shared/sharedOtherCommissionTestData';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
    '440766',
    'Add-Upd-Del Other Commissions w/Classification for Product Lines',
    UserRole.MASTER_DATA,
    ApplicationFeature.COMMISSIONS
);

describe(test.stringify, () => {
    const masterDataMasterSearchFullView = new MasterDataMasterSearchFullView();
    const masterDataCommissionsTabFullView = new MasterDataCommissionsTabFullView();
    const masterDataOtherCommissionsFullView = new MasterDataOtherCommissionsFullView();
    const masterDataPVCFullView = new MasterDataProductValueCommissionFullView();
    const td = new sharedOtherCommissionTestData();

    itw(test.description, () => {
        td.populatePromise().then(() => {
            // bootstrap (load, login, reset feature flags, impersonate)
            bootstrap(td.masterDataUser);

            // select a random sales agency
            masterDataMasterSearchFullView.search(td.randSalesAgencyId);
            masterDataMasterSearchFullView.selectFilterContainingText('Sales agencies');

            masterDataMasterSearchFullView.clickSearchResultContainingText(td.randSalesAgencyId);

            // navigate to the sales agency Other Commission screen
            masterDataCommissionsTabFullView.clickTabContainingText('Commission');
            masterDataCommissionsTabFullView.clickCardContainingText('Other Commission');

            // add a new commission with classification
            masterDataOtherCommissionsFullView.addCommission('With classification');

            // select a type from All Revenue, Specified Range, or Revenue Growth and configure
            masterDataOtherCommissionsFullView.selectSalesYear(td.salesPeriod.year.toString());
            masterDataOtherCommissionsFullView.selectClassification('C2');
            masterDataOtherCommissionsFullView.selectProgram('Accelerated');
            masterDataOtherCommissionsFullView.selectType('All Revenue');
            masterDataOtherCommissionsFullView.enterMaxCommission(td.randomValue);
            masterDataOtherCommissionsFullView.enterPercentValue(td.randomValueTwo);

            // verify the products box is checked
            expect(masterDataOtherCommissionsFullView.verifyApplyToAllProductsIsChecked()).toBeTruthy();

            // un-check the box
            masterDataOtherCommissionsFullView.toggleApplyToAllProducts();

            // select a product from drop down menu
            masterDataPVCFullView.selectItemFromProductLineDropDown('010 - Corn');

            // select the plus button
            masterDataPVCFullView.addProductLineItem();

            // select a new product from the drop down list and verify previous selection is not there
            expect(masterDataPVCFullView.selectItemFromProductLineDropDown('030 - Alfalfa')).not.toContain('010 - Corn');

            // delete the first product line
            masterDataPVCFullView.removeProductLineItem();

            // add 4 more product lines
            masterDataPVCFullView.addProductLineItem();
            masterDataPVCFullView.selectItemFromProductLineDropDown('070 - Sunflowers');
            masterDataPVCFullView.addProductLineItem();
            masterDataPVCFullView.selectItemFromProductLineDropDown('050 - Soybeans');
            masterDataPVCFullView.addProductLineItem();
            masterDataPVCFullView.selectItemFromProductLineDropDown('040 - Canola');
            masterDataPVCFullView.addProductLineItem();
            masterDataPVCFullView.selectItemFromProductLineDropDown('080 - Inoculants');

            // click Save & Close
            masterDataOtherCommissionsFullView.clickSalesAgencyOtherCommissionsSave('Save & Close');

            // edit one of the commissions
            masterDataOtherCommissionsFullView.editFirstCommissionRow();

            // delete another product line
            masterDataPVCFullView.removeProductLineItem();

            // check the apply to all products box
            masterDataOtherCommissionsFullView.toggleApplyToAllProducts();

            // save changes
            masterDataOtherCommissionsFullView.saveAfterEdit();

            // remove commission row
            masterDataOtherCommissionsFullView.removeFirstCommissionRow();
            masterDataOtherCommissionsFullView.clickCancelDeleteConfirmation('Delete');
        }, fail);
    });
});