/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import { filterElements, isActive, containingText } from '../../../modules_v3/helpers/filterElementHelpers';
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';
import { isAriaDisabled } from '../../../modules_v3/helpers/utilityElementHelpers';

export class PersonMD {

    private personTabParent = $$('div[ng-if="$mdTabsCtrl.enableDisconnect || tab.shouldRender()"]').get(2);

    public isPersonTypeDisplayed(): Promise<string> {
        return $('div[ng-click="vm.onCardClick(person)"]').$('div.person-header').getText();
    }

    public isPersonLastNameAndFirstNameDisplayed(): Promise<string> {
        return $('div.person-name.ellipsis').getText();
    }

    public isEditPersonButtonDisplayed(): Promise<string> {
        return $('button.md-accent.edit-button').$('span.ng-scope').getText();
    }

    public verifyPrimaryContactRadioButtonDisplayed():  Promise<boolean> {
        let primaryContactRadioButton = $('md-radio-button[ng-model="person.isPrimary"]');
        return primaryContactRadioButton.isPresent();
    }

    public verifyExactErrorMessageDisplayed(): Promise<string> {
        return $('div.error-messages').$('span.ng-scope').getText();
    }

    public expandFirstCardByClickingOnName(): void {
        let card = $$('div[ng-click="vm.onCardClick(person)"]').get(0);
        clickElement(card);
    }

    public expandSecondCardByClickingOnName(): void {
        let card = $$('div[ng-click="vm.onCardClick(person)"]').get(1);
        clickElement(card);
    }

    public isLegalContactCheckboxDisabled(): Promise<boolean> {
        return isAriaDisabled($$('md-checkbox[ng-model="person.isLegalContact"]').get(0));
    }

    public selectOptionFromPersonTypeDropdown(personType: string): void {
        let personTypeDropdown = $('md-select[ng-model="person.agencyPersonTypeId"]');
        let dropdownOption = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(personType)
            ]
        )().first();
        clickElement(personTypeDropdown);
        clickElement(dropdownOption);
    }

    public selectOptionFromPersonStatusDropdownForSecondCard(personStatus: string): void {
        let personStatusDropdown = $$('md-select[ng-model="person.agencyPersonStatusId"]').get(1);
        let dropdownOption = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(personStatus)
            ]
        )().first();
        clickElement(personStatusDropdown);
        clickElement(dropdownOption);
    }

    public clickTrashButton(): void {
        let trashButton = $('button[ng-if="vm.showDeleteButton(person)"]');
        clickElement(trashButton);
    }

    public selectPrimaryContactRadioButtonForFirstCard(): void {
        let primaryContactRadioButton = $$('md-radio-button[ng-model="person.isPrimary"]').get(0);
        clickElement(primaryContactRadioButton);
    }

    public selectPrimaryContactRadioButtonForSecondCard(): void {
        let primaryContactRadioButton = $$('md-radio-button[ng-model="person.isPrimary"]').get(1);
        clickElement(primaryContactRadioButton);
    }

    public selectLegalContactCheckboxForFirstCard(): void {
        let legalContactCheckbox = $$('md-checkbox[ng-model="person.isLegalContact"]').get(0);
        clickElement(legalContactCheckbox);
    }

    public selectLegalContactCheckboxForSecondCard(): void {
        let legalContactCheckbox = $$('md-checkbox[ng-model="person.isLegalContact"]').get(1);
        clickElement(legalContactCheckbox);
    }

    public clickSaveButtonForFirstCard(): void {
        let saveButton = $$('button[ng-click="vm.setSubmitAttempted(person)"]').get(0);
        clickElement(saveButton);
    }

    public clickSavebuttonForSecondCard(): void {
        let saveButton =  $$('button[ng-click="vm.setSubmitAttempted(person)"]').get(1);
        clickElement(saveButton);
    }

    public clickButton(buttonTxt: string) : void {
        let button = filterElements(
            $$('button'), [ isActive(true), containingText(buttonTxt) ]
        )().first();
        clickElement(button);
    }

}