/// <reference path='../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import { isPresentAndDisplayed } from '../../helpers/utilityElementHelpers';
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';
import { NotImplementedError } from '../../../common/exception/Exceptions';
import { IView } from '../../interfaces/common/IView';
import { filterElements, isActive, containingText, matchingText } from '../../helpers/filterElementHelpers';

export class AccountManagerOperationProfileToolFullView implements IView {

    private eachOperation = $$('button[ng-click="vm.selectOperation(operation.operationId)"]');
    private tableHeaders = $('md-list.header-row');

    isViewDisplayed ():Promise<boolean> {
        throw new NotImplementedError();
    }

    public isHamburgerDisplayed ():Promise<boolean> {
        let operationProfileToolHamburger = $('button[aria-label="Menu"]');
        return isPresentAndDisplayed(operationProfileToolHamburger);
    }

    public textOnOperationProfileToolPage ():Promise<string> {
        return $('div.ng-view').getText();
    }

    public clickAgencyDropDown ():void {
        let agencyDropDownArrow = $('button[aria-label="arrow_drop_down"]').$('md-icon');
        clickElement(agencyDropDownArrow);
    }

    public selectAgencyFromDropDown (agencyName:string):void {
        let agencyRecord = filterElements(
            $$('md-menu-item[ng-repeat="agency in vm.agencies"]'),
            [
                isActive(true),
                containingText(agencyName),
            ]
        )().first();
        clickElement(agencyRecord);
    }

    public isOperationHeaderDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed(this.tableHeaders.$('span[at="operation-name"]'));
    }

    public isPrimaryDecisionMakerHeaderDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed(this.tableHeaders.$('span[at="primary-decision-maker"]'));
    }

    public isTotalCommercialAcresHeaderDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed(this.tableHeaders.$('span[at="primary-decision-maker"]'));
    }

    public isLivestockHeaderDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('div.header-column.livestock-column'));
    }

    public isLastUpdatedHeaderDisplayed ():Promise<boolean> {
        return isPresentAndDisplayed($('div.lastOccurredOn-column.header-column'));
    }

    public areAllOperationNamesPopulated ():Promise<boolean> {
        return filterElements($$('div[at="operation-name"]'), [
            isActive(true), matchingText('')
        ])().count().then(c => c == 0);
    }

    public areAllPrimaryDecisionMakerNamesPopulated ():Promise<boolean> {
        return filterElements($$('div[at="primary-decision-maker"]'), [
            isActive(true), matchingText('')
        ])().count().then(c => c == 0);
    }

    public areAllTotalCommercialAcresPopulated ():Promise<boolean> {
        return filterElements(this.eachOperation.$$('div.right-column'), [
            isActive(true), matchingText('')
        ])().count().then(c => c == 0);
    }

    public clickTheFirstOperationRow ():void {
        let firstRecord = this.eachOperation.first();
        clickElement(firstRecord);
    }
}
