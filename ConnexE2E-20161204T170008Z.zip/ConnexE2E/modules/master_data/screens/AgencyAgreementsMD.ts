/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';

export class AgencyAgreementsMD {

    private cardsContent = $('md-content.card-page-content-margins.md-hue-1.layout-wrap.layout-row');

    public isSignedByTextDisplayedOnCard(): Promise<string> {
        return $$('div.agreement-carddata-label').get(0).getText();

    }

    public isDateSignedTextDisplayedOnCard(): Promise<string> {
        return $$('div.agreement-carddata-label').get(1).getText();
    }

    public clickAgreementCard(): void {
        let card = $('md-card[ng-repeat="agreement in vm.agencyAgreements"]');
        clickElement(card);
    }



}








