/// <reference path="../../../../typings/index.d.ts" />

import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { SharedITSupportEllipseNavigationSteps } from '../shared/SharedITSupportEllipseNavigationSteps';
import { SharedITSupportEllipseNavigationTestData } from '../shared/SharedITSupportEllipseNavigationTestData';

const test = new TestCase(
    '295852',
    'Ellipse Menu - Delivery Summary page',
    UserRole.IT_SUPPORT,
    ApplicationFeature.NAVIGATIONS
);

describe(test.stringify, () => {
    const sharedSteps = new SharedITSupportEllipseNavigationSteps();
    const td = new SharedITSupportEllipseNavigationTestData();

    td.accountDescriptionButtonText = 'Deliveries';

    td.ellipseItems = [
        td.availableEllipseItems.documents,
        td.availableEllipseItems.summary,
        td.availableEllipseItems.payments,
        td.availableEllipseItems.activityStatement,
        td.availableEllipseItems.accountDescription,
        td.availableEllipseItems.growthAndRetentionOverview
    ];

    sharedSteps.run(td, test.description);
});