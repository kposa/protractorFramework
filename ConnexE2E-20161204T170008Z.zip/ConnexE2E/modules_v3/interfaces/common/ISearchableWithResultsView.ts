/// <reference path="../../../typings/index.d.ts" />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;

import {ISearchableView} from "./ISearchableView";

export interface ISearchableWithResultsView extends ISearchableView {
    clickSearchResultMatchingText(text:string):void;
    clickSearchResultContainingText(text:string):void;
    getSearchResultCount():Promise<number>;
}