export class NotImplementedError extends Error {
    message: string = 'Not Implemented';

    constructor(message?: string) {
        super();
        if (message) this.message = message;
        this.stack = new Error().stack;
    }
}