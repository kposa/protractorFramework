/// <reference path="../../typings/index.d.ts" />

import {Element} from './Element';

let e = new Element();

export class Search {

    private searchField = $('input[placeholder="SearchCS"]');
    public searchBarHamburger = $('i[ng-click="drawerVM.toggleDrawerPosition()"]');
    public searchBarHamburgerMenuParent = $('section[name="navigationDrawer"]');

    public clickSearchBarHamburger():void {
        e.clickElement(this.searchBarHamburger);
    }

    public selectImpersonateFromHamburger():void {
        let impersonateOption = $('div[href="\'/impersonate\'"]');
        e.clickElement(impersonateOption);
    }

    public selectFeatureFlagsFromHamburger():void {
        let featureFlagsOption = $('div[href="\'/feature-flags\'"]');
        e.clickElement(featureFlagsOption);
    }
    
    public searchForAndSelectCriteria(criteria:string):void {
        this.searchField.sendKeys(criteria);
    }

    public searchByCriteria(criteria:string):void {
        let searchField = element(by.model('criteria'));
        searchField.clear();
        searchField.sendKeys(criteria);
        searchField.sendKeys(protractor.Key.ENTER);
    }

    public selectRadioButton(name:string):void {
        var radioButton = element(by.cssContainingText('div.pm-selection-label', name));
        e.clickElement(radioButton);
    }

    public selectSearchResult(id:number):void {
        let allResults = $$('div.pm-card');
        let foundResult = allResults.filter(function (elem) {
            return elem.getAttribute('at').then(function (at) {
                if(!at) return null;
                return at === id.toString();
            });
        }).get(0);
        e.clickElement(foundResult);
    }
}