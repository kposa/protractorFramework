/// <reference path= '../../../../typings/index.d.ts'/>

import Promise = webdriver.promise.Promise;

export class TD {

    french_UserName = 'Frigon';
    french_userId = 'frigorem@phiext.com';
    operationName = 'Ferme Maxilaix SENC';
    customerName = 'Michel Fafard';
    customer_Id = '17049817';
}