/// <reference path='../../../typings/index.d.ts' />

import Promise = webdriver.promise.Promise;
import ElementFinder = protractor.ElementFinder;
import { filterElements, isActive, containingText } from '../../../modules_v3/helpers/filterElementHelpers';
import { clickElement } from '../../../modules_v3/helpers/clickElementHelpers';
import { isAriaChecked } from '../../../modules_v3/helpers/utilityElementHelpers';

export class AgencyAddNewVendorMD {

    private addNewVendorParent = $('md-dialog.agency-vendor-dialog');
    private blockSapPaymentsCheckbox = $('md-checkbox[ng-model="vm.vendorDetail.isPaymentBlockedInSap"]');
    private requires1099Checkbox = $('md-checkbox[ng-model="vm.vendorDetail.requires1099"]');
    private beginSalesPeriodDropdown = $('md-select[ng-model="vm.vendorDetail.beginSalesPeriod"]');

    public enterName(vendorName: any): void{
        let nameContainer = $('input[ng-model="vm.vendorDetail.vendorName"]');
        nameContainer.clear();
        nameContainer.sendKeys(vendorName);
    }

    public selectOptionFromTypeDropdown(type: string): void {
        let typeDropdown = $('md-select[ng-model="vm.vendorDetail.vendorTypeId"]');
        let dropdownOption = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(type)
            ]
        )().first();
        clickElement(typeDropdown);
        clickElement(dropdownOption);
    }

    public selectOptionFromBeginSalesPeriodDropdown(): void {
        let selectFirstOption = $$('md-option[ng-repeat="sp in vm.salesPeriods"]').get(0);
        clickElement(this.beginSalesPeriodDropdown);
        clickElement(selectFirstOption);
    }

    public verifyBlockSapPaymentsCheckboxChecked(): Promise<boolean> {
        return isAriaChecked(this.blockSapPaymentsCheckbox);
    }

    public verifyRequires1099CheckboxChecked(): Promise<boolean> {
        return isAriaChecked(this.requires1099Checkbox);
    }

    public selectOptionFromUSTaxTypeDropdown(tt: string): void {
        let usTaxTypeDropdown = $('md-select[ng-model="vm.vendorTaxUS.taxTypeId"]');
        let dropdownOption = filterElements(
            $$('md-option'),
            [
                isActive(true),
                containingText(tt)
            ]
        )().first();
        clickElement(usTaxTypeDropdown);
        clickElement(dropdownOption);
    }

    public enterValueInVendorTaxUsContainer(taxValue: any): void {
        let vendorTaxContainer = $('input[ng-model="vm.vendorTaxUS.value"]');
        vendorTaxContainer.clear();
        vendorTaxContainer.sendKeys(taxValue);
    }

    public clickSaveIcon():  void {
        let saveButton = $('button[ng-click="vm.setSubmitAttempted()"]');
        clickElement(saveButton);
    }

}