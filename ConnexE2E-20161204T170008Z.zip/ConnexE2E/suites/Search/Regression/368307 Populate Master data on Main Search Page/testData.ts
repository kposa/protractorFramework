/// <reference path='../../../../typings/index.d.ts' />

import Promise = protractor.promise.Promise;
import BaseTestData from '../../../../modules_v3/testdata/BaseTestData';

export default class TestData368307 extends BaseTestData {

    public filters: Array<string> = ['Business partners','Operations','Sales agencies','Warehouses'
        ,'Territories', 'Pooling warehouses','Areas','Organization agencies','Commercial units',
        'Countries'];
}