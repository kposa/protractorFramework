/// <reference path="../../../../typings/index.d.ts" />

import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { bootstrap } from '../../../SharedSteps/bootstrap';
import { TestData359289 } from './testData';
import { itw } from '../../../../modules_v3/helpers/itw';
import { SalesRepOperationsFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationsFullView';
import { SalesRepEllipsePartialView } from '../../../../modules_v3/views/salesRep/SalesRepEllipsePartialView';
import { SalesRepOperationProfilePageFullView } from '../../../../modules_v3/views/salesRep/SalesRepOperationProfilePageFullView';

const test = new TestCase(
    '359289',
    'Commercial acres  section - Validating Save, Edit & Delete',
    UserRole.SALES_REP,
    ApplicationFeature.OPERATION_PROFILE
);

describe(test.stringify, () => {
    const td = new TestData359289();
    const salesRepOperationsFullView = new SalesRepOperationsFullView();
    const ellipse = new SalesRepEllipsePartialView();
    const operationProfilePage = new SalesRepOperationProfilePageFullView();
    
    itw(test.description, () => {
        td.populatePromise().then(() => {
            bootstrap(td.salesRepresentative);

            //search for an operation and click on it
            salesRepOperationsFullView.search(td.operation.name);
            salesRepOperationsFullView.clickSearchResultContainingText(td.operation.name);

            //select operation profile link from the ellipse to navigate to the operation profile page
            ellipse.select('operation profile');

            //should verify if all of the following headers are displayed on the operation Profile page
            operationProfilePage.clickAddButtonForHeadersContainingText('Commercial acres');

            //select the product line in the commercial Acres Dialog box
            operationProfilePage.commercialAcresDialog.selectProductLineFromDropdown();

            //verify that the save button is disabled
            expect(operationProfilePage.commercialAcresDialog.isSaveButtonDisabled()).toBeTruthy();

            //enter units into Dryland Acres input field
            operationProfilePage.commercialAcresDialog.enterValueIntoDrylandAcresInput(td.dryLandAcresValue);

            //click save to save commercial Acres Dialog box
            operationProfilePage.commercialAcresDialog.clickSave();

            //verify a confirmation box pops up as there are empty fields
            expect(operationProfilePage.commercialAcresDialog.isConfirmationDialogDisplayed()).toBeTruthy();

            //click on Cancel button of the confirmation box
            operationProfilePage.commercialAcresDialog.clickCancelConfirmationDialog();

            //enter invalid units into irrigated Acres input field
            operationProfilePage.commercialAcresDialog.enterValueIntoIrrigatedAcresInput(15.32);

            //verify that an error message is displayed
            expect(operationProfilePage.commercialAcresDialog.isInvalidMessageDisplayed()).toBeTruthy();

            //verify that the save button is disabled
            expect(operationProfilePage.commercialAcresDialog.isSaveButtonDisabled()).toBeTruthy();

            //enter units into irrigated Acres input field
            operationProfilePage.commercialAcresDialog.enterValueIntoIrrigatedAcresInput(td.irrigatedAcresValue);

            //verify total acres is equal to the sum of Dryland acres units and irrigated Acres units
            expect(operationProfilePage.commercialAcresDialog.verifyTotalAcresDisplayed()).toEqual(td.totalAcres.toString());

            //enter units into Pioneer Acres input field
            operationProfilePage.commercialAcresDialog.enterValueIntoPioneerAcresInput();

            //enter units into Competitive Brand Acres input field
            operationProfilePage.commercialAcresDialog.enterValueIntoCompetitiveBrandAcresInput();

            //click save to save commercial Acres Dialog box
            operationProfilePage.commercialAcresDialog.clickSave();

            //store the number of Commercial Acre Lines displayed
            let originalCommercialAcreLines = operationProfilePage.getNumberOfCommercialAcreLines();

            //verify that you can edit the Commercial Acre Line by clicking on it, changing a value and re-saving it
            operationProfilePage.clickFirstCommercialAcresLineItem();
            operationProfilePage.commercialAcresDialog.enterValueIntoDrylandAcresInput();
            operationProfilePage.commercialAcresDialog.clickSave();

            //verify deleting the first Commercial acre row by clicking on the trash icon at the corner of the line
            operationProfilePage.deleteFirstCommercialAcresRow();

            //verify that the line was deleted after clicking on the trash icon
            let commercialAcreLinesAfterDeletingARow = operationProfilePage.getNumberOfCommercialAcreLines();
            commercialAcreLinesAfterDeletingARow.then((newLines) => {
                originalCommercialAcreLines.then((oldLines) => {
                    expect(newLines).toEqual(oldLines - 1);
                });
            });
        }, fail);
    });
});
