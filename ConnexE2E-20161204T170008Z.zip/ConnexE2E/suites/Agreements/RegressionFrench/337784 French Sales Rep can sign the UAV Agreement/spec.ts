/// <reference path="../../../../typings/index.d.ts" />

import { ApplicationFeature, UserRole, TestCase } from '../../../../reporters/LogReporter/testConstants';
import { itw } from '../../../../modules_v3/helpers/itw';

const test = new TestCase(
	'337784',
	'French Sales Rep can sign the UAV Agreement',
	UserRole.SALES_REP,
	ApplicationFeature.AGREEMENTS
);

describe(test.stringify, () => {

	itw(test.description, () => {

	}, 'Needs re-write');
});